// Spelunker - gamepad input (Gamepad API, no libraries).
// Classic script attached to window.Game.Gamepad. main.js calls poll() once
// per frame; ship.js reads getAxisY()/getSpeedDir(); main.js consumes the
// button edges (A = fire/confirm, Start = pause toggle).
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('input-gamepad.js requires window.Game to be set up by main.js first');
  }

  var DEADZONE = 0.15;
  var TRIGGER_THRESHOLD = 0.3;
  var BTN_A = 0;
  var BTN_LT = 6;
  var BTN_RT = 7;
  var BTN_START = 9;

  // Pure: values inside the deadzone map to 0; outside, the remaining range
  // is rescaled so full deflection is +/-1 and the sign is kept.
  function mapDeadzone(value, deadzone) {
    var v = Number(value);
    if (!isFinite(v)) { return 0; }
    var dz = (typeof deadzone === 'number' && deadzone >= 0 && deadzone < 1) ? deadzone : 0;
    var mag = Math.abs(v);
    if (mag <= dz) { return 0; }
    if (mag > 1) { mag = 1; }
    var scaled = (mag - dz) / (1 - dz);
    return v < 0 ? -scaled : scaled;
  }

  var axisY = 0;
  var speedDir = 0; // -1 brake (left trigger), +1 accelerate (right trigger), 0 neither
  var fireHeld = false;
  var prevA = false;
  var prevStart = false;
  var confirmEdge = false;
  var startEdge = false;
  var connected = false;

  function clearState() {
    axisY = 0;
    speedDir = 0;
    fireHeld = false;
    prevA = false;
    prevStart = false;
    confirmEdge = false;
    startEdge = false;
    connected = false;
  }

  function firstPad() {
    if (typeof navigator === 'undefined' || !navigator || typeof navigator.getGamepads !== 'function') {
      return null;
    }
    var pads;
    try { pads = navigator.getGamepads(); } catch (e) { return null; }
    if (!pads) { return null; }
    for (var i = 0; i < pads.length; i++) {
      if (pads[i] && pads[i].connected !== false) { return pads[i]; }
    }
    return null;
  }

  function btn(pad, i) {
    var b = pad.buttons && pad.buttons[i];
    if (!b) { return 0; }
    if (typeof b === 'number') { return b; }
    return typeof b.value === 'number' && b.value > 0 ? b.value : (b.pressed ? 1 : 0);
  }

  function poll() {
    var pad = firstPad();
    if (!pad) {
      // Disconnected: neutral inputs so the ship cannot keep drifting.
      clearState();
      return;
    }
    connected = true;
    axisY = mapDeadzone(pad.axes && pad.axes.length > 1 ? pad.axes[1] : 0, DEADZONE);
    var rt = btn(pad, BTN_RT) > TRIGGER_THRESHOLD;
    var lt = btn(pad, BTN_LT) > TRIGGER_THRESHOLD;
    speedDir = (rt && !lt) ? 1 : ((lt && !rt) ? -1 : 0);
    var a = btn(pad, BTN_A) > 0.5 || !!(pad.buttons && pad.buttons[BTN_A] && pad.buttons[BTN_A].pressed);
    var start = btn(pad, BTN_START) > 0.5;
    fireHeld = a;
    if (a && !prevA) { confirmEdge = true; }
    if (start && !prevStart) { startEdge = true; }
    prevA = a;
    prevStart = start;
  }

  function consume(name) {
    var v = name === 'confirm' ? confirmEdge : startEdge;
    if (name === 'confirm') { confirmEdge = false; } else { startEdge = false; }
    return v;
  }

  Game.Gamepad = {
    mapDeadzone: mapDeadzone,
    poll: poll,
    reset: clearState,
    getAxisY: function () { return axisY; },
    getSpeedDir: function () { return speedDir; },
    isFireHeld: function () { return fireHeld; },
    isConnected: function () { return connected; },
    consumeConfirm: function () { return consume('confirm'); },
    consumeStart: function () { return consume('start'); },
    DEADZONE: DEADZONE
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { mapDeadzone: mapDeadzone };
  }
})();
