// menu.js - title-screen menu (STATES.TITLE): START, OPTIONS, HIGH SCORES.
//
// main.js's handleStart asks Game.Menu.handleKey / handleClick first; they
// return true when the event was consumed by the menu (navigation, activation,
// disabled item). Anything else returns false and main.js starts the game, so
// the "any key" fast path is kept. Left/Right are consumed (no-ops) on the
// title so arrow keys never start the game.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  var W = 640;
  var TOP = 156;
  var SUB_H = 20; // extra row height for an item's sub line
  var ROW_H = 30;
  var HIT_HALF_W = 130;

  var selected = 0;

  // Items. `enabled` is evaluated each time; `sub` is optional second line
  // text shown under the label.
  var items = [
    { id: 'start', label: 'START',
      enabled: function () { return true; },
      sub: function () {
        var s = Game.Settings;
        var d = s && s.get ? s.get('difficulty') : null;
        return typeof d === 'string' ? d.toUpperCase() : '';
      },
      run: function () { setState(Game.STATES.PLAYING); } },
    { id: 'options', label: 'OPTIONS',
      enabled: function () { return true; },
      run: function () { setState(Game.STATES.OPTIONS); } },
    { id: 'highscores', label: 'HIGH SCORES',
      enabled: function () {
        return !!(Game.HighScores && Game.HighScores.list && Game.STATES && Game.STATES.HIGHSCORES);
      },
      run: function () { setState(Game.STATES.HIGHSCORES); } },
    // Last so the positions of the items above stay stable.
    { id: 'daily', label: 'DAILY CAVE',
      enabled: function () { return !!(Game.Daily && Game.Daily.begin); },
      sub: function () {
        if (!Game.Daily) return '';
        var best = Game.Daily.getBest ? Game.Daily.getBest() : 0;
        return Game.Daily.label + (best ? ' - BEST ' + best : '');
      },
      run: function () { Game.Daily.begin(); setState(Game.STATES.PLAYING); } },
    { id: 'codex', label: 'CODEX',
      enabled: function () { return !!(Game.Codex && Game.STATES && Game.STATES.CODEX); },
      sub: function () {
        if (!(Game.Codex && Game.Codex.foundIds && Game.Codex.variants)) return '';
        return Game.Codex.foundIds().length + '/' + Game.Codex.variants().length + ' FOUND';
      },
      run: function () { setState(Game.STATES.CODEX); } }
  ];

  function setState(s) {
    if (s && Game.setState) Game.setState(s);
  }

  function inTitle() {
    return !!(Game.STATES && Game.getState && Game.getState() === Game.STATES.TITLE);
  }

  function isEnabled(i) {
    return !!items[i] && !!items[i].enabled();
  }

  // Vertical layout: START has a sub line so the rows below it shift down.
  function rowY(i) {
    var y = TOP;
    for (var k = 0; k < i; k++) y += ROW_H + (hasSub(k) ? SUB_H : 0);
    return y;
  }
  function hasSub(i) {
    var it = items[i];
    return !!(it && it.sub && it.sub());
  }
  function menuBottom() {
    return rowY(items.length - 1) + ROW_H / 2;
  }

  function itemAt(y) {
    for (var i = 0; i < items.length; i++) {
      var top = rowY(i) - ROW_H / 2;
      var bottom = top + ROW_H + (hasSub(i) ? SUB_H : 0);
      if (y >= top && y < bottom) return i;
    }
    return -1;
  }

  function select(i) {
    var n = items.length;
    selected = ((i % n) + n) % n;
  }

  // dir +1/-1: move to the next enabled item (wraps); stays put if none.
  function move(dir) {
    var n = items.length;
    var i = selected;
    for (var k = 0; k < n; k++) {
      i = (i + dir + n) % n;
      if (isEnabled(i)) { selected = i; return; }
    }
  }

  function activate(i) {
    if (i < 0 || i >= items.length || !isEnabled(i)) return false;
    selected = i;
    items[i].run();
    return true;
  }

  var MODIFIERS = { Shift: 1, Control: 1, Alt: 1, Meta: 1, CapsLock: 1, AltGraph: 1 };

  // Returns true when the menu consumed the keydown (caller must not start).
  function handleKey(e) {
    if (!inTitle() || !e) return false;
    var k = e.key;
    if (MODIFIERS[k]) return true; // a bare modifier press is not "any key"
    if (k === 'ArrowUp') { move(-1); return true; }
    if (k === 'ArrowDown') { move(1); return true; }
    if (k === 'ArrowLeft' || k === 'ArrowRight') return true;
    if (k === 'Enter') {
      if (e.repeat) return true;
      activate(selected);
      return true;
    }
    if (k === 'o' || k === 'O') { activate(1); return true; }
    return false;
  }

  // Map a mouse event to logical 640x400 coordinates (canvas is CSS-scaled).
  function logicalPoint(e) {
    var c = Game.canvas;
    if (!c || !c.getBoundingClientRect || !e) return null;
    var r = c.getBoundingClientRect();
    if (!r || !r.width || !r.height) return null;
    return { x: (e.clientX - r.left) * (Game.W || W) / r.width,
             y: (e.clientY - r.top) * (Game.H || 400) / r.height };
  }

  function hit(e) {
    var p = logicalPoint(e);
    if (!p) return -1;
    if (Math.abs(p.x - W / 2) > HIT_HALF_W) return -1;
    return itemAt(p.y);
  }

  function handleMove(e) {
    if (!inTitle()) return;
    var i = hit(e);
    if (i >= 0 && isEnabled(i)) selected = i;
  }

  // Returns true when the click landed on a menu item (activated or disabled).
  function handleClick(e) {
    if (!inTitle()) return false;
    var i = hit(e);
    if (i < 0) return false;
    activate(i);
    return true;
  }

  function palette() { return Game.Theme && Game.Theme.get ? Game.Theme.get() : null; }

  function text(ctx, str, x, y, color, role, scale, css) {
    if (Game.Font && Game.Font.draw) {
      Game.Font.draw(ctx, str, x, y, { role: role || 'body', css: css || 'bold 16px monospace',
        color: color, align: 'center', baseline: 'middle', scale: scale || 1 });
      return;
    }
    ctx.save();
    ctx.font = css || 'bold 16px monospace';
    ctx.fillStyle = color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(str, x, y);
    ctx.restore();
  }

  // Draws the menu items. opts: { blink } shows the prompt under the menu.
  function render(ctx, opts) {
    var P = palette();
    if (!ctx || !P) return;
    var grey = P.LIGHT_GREY || P.WHITE;
    var logoDrawn = !!(opts && opts.t !== undefined && Game.Logo && Game.Logo.draw && Game.Logo.draw(ctx, opts.t));
    if (!logoDrawn) text(ctx, 'CAVE RAIDER', W / 2, 100, P.YELLOW, 'title', 2, 'bold 44px monospace');
    for (var i = 0; i < items.length; i++) {
      var y = rowY(i);
      var on = isEnabled(i);
      var sel = i === selected && on;
      if (sel) {
        ctx.fillStyle = P.DARK_GREY || P.BLACK;
        ctx.fillRect(W / 2 - HIT_HALF_W, y - ROW_H / 2 + 2, HIT_HALF_W * 2, ROW_H - 4 + (hasSub(i) ? SUB_H : 0));
      }
      var col = !on ? (P.DARK_GREY || grey) : (sel ? P.YELLOW : P.WHITE);
      text(ctx, (sel ? '> ' : '') + items[i].label + (sel ? ' <' : ''), W / 2, y, col);
      if (hasSub(i)) text(ctx, items[i].sub(), W / 2, y + 19, on ? grey : col);
    }
    if (opts && opts.blink) {
      text(ctx, 'PRESS ANY KEY OR CLICK TO START', W / 2, menuBottom() + 26, P.WHITE);
    }
  }

  // Keyboard and click go through main.js's handleStart (ordering vs
  // projectile.js); only hover needs its own listener.
  if (Game.canvas && Game.canvas.addEventListener) {
    Game.canvas.addEventListener('mousemove', handleMove);
  }

  Game.Menu = {
    items: function () { return items.map(function (it) { return { id: it.id, label: it.label, enabled: it.enabled() }; }); },
    getSelected: function () { return selected; },
    select: select,
    activate: activate,
    handleKey: handleKey,
    handleClick: handleClick,
    handleMove: handleMove,
    render: render
  };
})();
