// sprite.js - code-defined pixel sprites and ordered (Bayer) dither.
//
// Loaded after pixel.js and theme.js. Sprites are text grids; each sprite
// pixel is 2x2 logical px (one buffer pixel). Colours come from Game.Theme
// ramps at render time, so a theme switch (Theme.version()) rebuilds the cache.
(function () {
  'use strict';

  window.Game = window.Game || {};

  var SCALE = 2; // logical px per sprite pixel

  var BAYER4 = [
    0, 8, 2, 10,
    12, 4, 14, 6,
    3, 11, 1, 9,
    15, 7, 13, 5
  ];

  var defs = {};
  var spriteCache = {};
  var patternCache = {};
  var cacheVersion = null;
  var cacheCount = 0;
  var warnedUnknown = {};

  function theme() {
    return window.Game.Theme;
  }

  function themeVersion() {
    var t = theme();
    return (t && t.version) ? t.version() : 0;
  }

  // Drop all caches when the theme changed since they were built.
  function checkVersion() {
    var v = themeVersion();
    if (v !== cacheVersion) {
      spriteCache = {};
      patternCache = {};
      cacheCount = 0;
      cacheVersion = v;
    }
  }

  function makeCanvas(w, h) {
    if (typeof document === 'undefined' || !document || typeof document.createElement !== 'function') {
      return null;
    }
    try {
      var c = document.createElement('canvas');
      if (!c || typeof c.getContext !== 'function') {
        return null;
      }
      c.width = w;
      c.height = h;
      return c;
    } catch (e) {
      return null;
    }
  }

  function rampFor(name) {
    var t = theme();
    return (t && t.ramp) ? t.ramp(name) : null;
  }

  // Theme.ramp falls back to the "ui" ramp for unknown names, so a name is
  // unknown when it yields nothing, or the ui ramp while not being "ui".
  function rampKnown(name) {
    var r = rampFor(name);
    if (!r || typeof r.length !== 'number') {
      return null;
    }
    if (name !== 'ui' && r === rampFor('ui')) {
      return null;
    }
    return r;
  }

  function define(name, def) {
    var where = 'Sprite "' + name + '"';
    if (!def || typeof def !== 'object') {
      throw new Error(where + ': missing definition');
    }
    var w = def.w, h = def.h, map = def.map, frames = def.frames;
    if (!(w > 0) || !(h > 0) || Math.floor(w) !== w || Math.floor(h) !== h) {
      throw new Error(where + ': w and h must be positive integers');
    }
    if (!map || typeof map !== 'object') {
      throw new Error(where + ': map must be an object');
    }
    if (!Array.isArray(frames) || frames.length === 0) {
      throw new Error(where + ': frames must be a non-empty array');
    }
    Object.keys(map).forEach(function (ch) {
      var label = where + ' map "' + ch + '"';
      if (ch.length !== 1) {
        throw new Error(label + ': key must be a single character');
      }
      if (ch === '.') {
        throw new Error(label + ': "." is always transparent');
      }
      var m = /^([^:]+):(\d+)$/.exec(String(map[ch]));
      if (!m) {
        throw new Error(label + ': value must be "rampName:index"');
      }
      var r = rampKnown(m[1]);
      if (!r) {
        throw new Error(label + ': unknown ramp "' + m[1] + '"');
      }
      if (+m[2] >= r.length) {
        throw new Error(label + ': index ' + m[2] + ' out of range for ramp "' + m[1] +
          '" (' + r.length + ' shades)');
      }
    });
    frames.forEach(function (frame, fi) {
      if (!Array.isArray(frame) || frame.length !== h) {
        throw new Error(where + ' frame ' + fi + ': expected ' + h + ' rows');
      }
      frame.forEach(function (row, ri) {
        if (typeof row !== 'string' || row.length !== w) {
          throw new Error(where + ' frame ' + fi + ' row ' + ri + ': expected exactly ' + w + ' characters');
        }
        for (var i = 0; i < row.length; i++) {
          var ch = row.charAt(i);
          if (ch !== '.' && !Object.prototype.hasOwnProperty.call(map, ch)) {
            throw new Error(where + ' frame ' + fi + ' row ' + ri + ': unknown character "' + ch + '"');
          }
        }
      });
    });
    defs[name] = { w: w, h: h, map: map, frames: frames };
    // A redefinition must not serve stale cached art.
    spriteCache = {};
    cacheCount = 0;
  }

  function frameIndex(def, frame) {
    var n = def.frames.length;
    var i = Math.floor(+frame || 0) % n;
    return i < 0 ? i + n : i;
  }

  function swapKey(swap) {
    if (!swap) { return ''; }
    return Object.keys(swap).sort().map(function (k) { return k + '>' + swap[k]; }).join(',');
  }

  // True when high-res art should be built (feature-detected).
  function hiRes() {
    var P = window.Game.Pixel;
    return !!(P && typeof P.hiRes === 'function' && typeof P.scale2x === 'function' && P.hiRes());
  }

  // Density: 1 retro, 2 high, 4 ultrahigh (feature-detected).
  function density() {
    var P = window.Game.Pixel;
    if (!hiRes()) { return 1; }
    return (typeof P.detail === 'function' && P.detail() >= 4) ? 4 : 2;
  }

  function render(def, fi, flash, swap, d) {
    var hi = d > 1;
    var cv = makeCanvas(def.w * d, def.h * d);
    if (!cv) { return null; }
    var cx = cv.getContext('2d');
    if (!cx) { return null; }
    var flashColor = null;
    if (flash) {
      var ui = rampFor('ui');
      flashColor = ui && ui[ui.length - 1];
    }
    var colorOf = {};
    Object.keys(def.map).forEach(function (ch) {
      var parts = def.map[ch].split(':');
      var rname = (swap && swap[parts[0]]) || parts[0];
      var r = rampFor(rname);
      var idx = +parts[1];
      colorOf[ch] = flashColor || (r && (r[idx] !== undefined ? r[idx] : r[r.length - 1]));
    });
    var rows = def.frames[fi];
    if (hi) {
      var smap = window.Game.Pixel.scale2x(def.w, def.h, function (x, y) {
        var c = rows[y].charAt(x);
        return c === '.' ? null : c;
      });
      if (d === 4) {
        // Second Scale2x pass on the first pass's output, keyed by colour
        // identity; indices map back to the original pixels.
        var w2 = def.w * 2, h2 = def.h * 2;
        var m2 = window.Game.Pixel.scale2x(w2, h2, function (x, y) {
          var i1 = smap[y * w2 + x];
          return i1 < 0 ? null : rows[Math.floor(i1 / def.w)].charAt(i1 % def.w);
        });
        var m4 = new Int32Array(m2.length);
        for (var q = 0; q < m2.length; q++) { m4[q] = m2[q] < 0 ? -1 : smap[m2[q]]; }
        smap = m4;
      }
      var ow = def.w * d;
      for (var oy = 0; oy < def.h * d; oy++) {
        for (var ox = 0; ox < ow; ox++) {
          var si = smap[oy * ow + ox];
          if (si < 0) { continue; }
          var sch = rows[Math.floor(si / def.w)].charAt(si % def.w);
          if (!colorOf[sch]) { continue; }
          cx.fillStyle = colorOf[sch];
          cx.fillRect(ox, oy, 1, 1);
        }
      }
      return cv;
    }
    for (var y = 0; y < def.h; y++) {
      for (var x = 0; x < def.w; x++) {
        var ch = rows[y].charAt(x);
        if (ch === '.' || !colorOf[ch]) { continue; }
        cx.fillStyle = colorOf[ch];
        cx.fillRect(x, y, 1, 1);
      }
    }
    return cv;
  }

  function draw(ctx, name, frame, x, y, opts) {
    var def = defs[name];
    if (!def) {
      if (!warnedUnknown[name]) {
        warnedUnknown[name] = true;
        if (typeof console !== 'undefined' && console.warn) {
          console.warn('Game.Sprite.draw: unknown sprite "' + name + '"');
        }
      }
      return;
    }
    if (!ctx || typeof ctx.drawImage !== 'function') { return; }
    opts = opts || {};
    checkVersion();
    var fi = frameIndex(def, frame);
    var key = name + '|' + fi + '|' + (opts.flash ? 1 : 0) + '|' + swapKey(opts.swap);
    var d = density();
    if (d === 2) { key += '|hr'; } else if (d === 4) { key += '|hr4'; }
    var cv = spriteCache[key];
    if (cv === undefined) {
      cv = render(def, fi, !!opts.flash, opts.swap, d);
      spriteCache[key] = cv;
      cacheCount++;
    }
    if (!cv) { return; }

    var P = window.Game.Pixel;
    var sn = (P && P.snap) ? P.snap : function (v) { return Math.round(v / SCALE) * SCALE; };
    var pw = def.w * SCALE, ph = def.h * SCALE;
    var px = sn(x - pw / 2), py = sn(y - ph / 2);

    ctx.save();
    ctx.imageSmoothingEnabled = false;
    if (opts.alpha !== undefined && opts.alpha !== null) {
      ctx.globalAlpha = ctx.globalAlpha * Math.max(0, Math.min(1, opts.alpha));
    }
    if (opts.flipX || opts.flipY) {
      ctx.translate(px + pw / 2, py + ph / 2);
      ctx.scale(opts.flipX ? -1 : 1, opts.flipY ? -1 : 1);
      ctx.drawImage(cv, -pw / 2, -ph / 2, pw, ph);
    } else {
      ctx.drawImage(cv, px, py, pw, ph);
    }
    ctx.restore();
  }

  // true where BAYER4 < level (level 0..16).
  function ditherMask(level) {
    var out = [];
    for (var i = 0; i < 16; i++) {
      out.push(BAYER4[i] < level);
    }
    return out;
  }

  // 4x4 buffer-px pattern (8x8 logical under the 0.5 buffer transform).
  function ditherPattern(ctx, colorA, colorB, level) {
    if (!ctx || typeof ctx.createPattern !== 'function') { return null; }
    checkVersion();
    var key = colorA + '|' + colorB + '|' + level;
    var p = patternCache[key];
    if (p) { return p; }
    var cv = makeCanvas(4, 4);
    if (!cv) { return null; }
    var cx = cv.getContext('2d');
    if (!cx) { return null; }
    var mask = ditherMask(level);
    for (var i = 0; i < 16; i++) {
      cx.fillStyle = mask[i] ? colorB : colorA;
      cx.fillRect(i % 4, Math.floor(i / 4), 1, 1);
    }
    p = ctx.createPattern(cv, 'repeat');
    if (p) { patternCache[key] = p; }
    return p;
  }

  window.Game.Sprite = {
    BAYER4: BAYER4,
    define: define,
    draw: draw,
    ditherMask: ditherMask,
    ditherPattern: ditherPattern,
    // Exposed for tests: number of offscreen sprites rendered since the last drop.
    _cacheSize: function () { return cacheCount; }
  };

  // Pipeline proof: a 5x5 cross.
  if (rampKnown('hull') && rampKnown('ui')) {
    define('debug-cross', {
      w: 5, h: 5,
      map: { a: 'hull:0', b: 'hull:2', w: 'ui:3' },
      frames: [[
        '..w..',
        '..b..',
        'wbabw',
        '..b..',
        '..w..'
      ]]
    });
  }
})();
