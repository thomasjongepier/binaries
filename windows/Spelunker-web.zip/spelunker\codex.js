// codex.js - discovery codex: three crystal and three fossil variants.
//
// Game.Codex: variants(), forType(type), choose(type), spriteFor(id),
// isFound(id), foundIds(), record(id), runFinds(), resetRun(), reload(),
// clear(), render(ctx). Found variants persist under 'spelunker.codex' (a JSON
// array of ids). Corrupt storage means nothing is found; storage failures keep
// the in-memory state working. choose() draws from Game.Random.stream('pickups')
// so the variant sequence is reproducible with a seed. Variants change look
// only; point values stay per type (Game.Balance).
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  var STORAGE_KEY = 'spelunker.codex';
  var W = 640;

  // sprite: base sprite name; swap: optional ramp swap passed to Sprite.draw.
  var VARIANTS = [
    { id: 'crystal-cyan', type: 'crystal', name: 'Cyan Crystal',
      desc: 'Clear and cold, it hums when struck.',
      sprite: 'pickup-crystal', swap: null },
    { id: 'crystal-violet', type: 'crystal', name: 'Violet Crystal',
      desc: 'Deep purple, grown in the dark.',
      sprite: 'pickup-crystal', swap: { crystal: 'enemy' } },
    { id: 'crystal-amber', type: 'crystal', name: 'Amber Crystal',
      desc: 'Warm glass with old light trapped inside.',
      sprite: 'pickup-crystal', swap: { crystal: 'fossil' } },
    { id: 'fossil-ammonite', type: 'fossil', name: 'Ammonite',
      desc: 'A spiral shell from a vanished sea.',
      sprite: 'pickup-fossil', swap: null },
    { id: 'fossil-trilobite', type: 'fossil', name: 'Trilobite',
      desc: 'Ribbed armour, segment by segment.',
      sprite: 'pickup-fossil-trilobite', swap: null },
    { id: 'fossil-fern', type: 'fossil', name: 'Fern Leaf',
      desc: 'A frond pressed into stone.',
      sprite: 'pickup-fossil-fern', swap: null }
  ];

  var found = {};   // id -> true (all runs)
  var runFound = []; // ids found this run, in order

  function byId(id) {
    for (var i = 0; i < VARIANTS.length; i++) if (VARIANTS[i].id === id) return VARIANTS[i];
    return null;
  }

  function getStorage() {
    try { return window.localStorage || null; } catch (e) { return null; }
  }

  function load() {
    found = {};
    var raw = null;
    try {
      var s = getStorage();
      if (s) raw = s.getItem(STORAGE_KEY);
    } catch (e) { return; }
    if (typeof raw !== 'string') return;
    var parsed;
    try { parsed = JSON.parse(raw); } catch (e) { return; }
    if (!Array.isArray(parsed)) return;
    for (var i = 0; i < parsed.length; i++) {
      if (typeof parsed[i] === 'string' && byId(parsed[i])) found[parsed[i]] = true;
    }
  }

  function save() {
    try {
      var s = getStorage();
      if (s) s.setItem(STORAGE_KEY, JSON.stringify(foundIds()));
    } catch (e) { /* quota / private mode: keep in-memory state */ }
  }

  function foundIds() {
    return VARIANTS.filter(function (v) { return found[v.id]; }).map(function (v) { return v.id; });
  }

  function forType(type) {
    return VARIANTS.filter(function (v) { return v.type === type; });
  }

  // Picks a variant id for a pickup type; null for types without variants.
  function choose(type) {
    var list = forType(type);
    if (!list.length) return null;
    var r = Game.Random && Game.Random.stream ? Game.Random.stream('pickups').next() : 0;
    var i = Math.min(list.length - 1, Math.floor(r * list.length));
    return list[i].id;
  }

  // Marks a variant found. Returns true when it is new to the codex.
  function record(id) {
    if (!byId(id)) return false;
    if (runFound.indexOf(id) < 0) runFound.push(id);
    if (found[id]) return false;
    found[id] = true;
    save();
    return true;
  }

  function runFinds() { return runFound.slice(); }
  function resetRun() { runFound = []; }
  function clear() { found = {}; runFound = []; save(); }
  function isFound(id) { return !!found[id]; }
  function spriteFor(id) {
    var v = byId(id);
    return v ? { name: v.sprite, swap: v.swap } : null;
  }
  function nameOf(id) { var v = byId(id); return v ? v.name : ''; }

  // ---- screen ------------------------------------------------------------

  function inScreen() {
    return !!(Game.STATES && Game.STATES.CODEX && Game.getState &&
              Game.getState() === Game.STATES.CODEX);
  }
  function back() {
    if (Game.setState && Game.STATES) Game.setState(Game.STATES.TITLE);
  }
  function onKeyDown(e) {
    if (!inScreen() || !e) return;
    if (e.key === 'Escape') {
      back();
      if (e.preventDefault) e.preventDefault();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    }
  }
  function onClick() { if (inScreen()) back(); }

  function text(ctx, s, x, y, color, align, role, css) {
    var F = Game.Font;
    if (F && F.draw) {
      F.draw(ctx, s, x, y, { role: role || 'body', css: css || 'bold 16px monospace',
        color: color, align: align || 'left', baseline: 'middle', scale: 1 });
    }
  }

  function render(ctx) {
    var P = Game.Theme && Game.Theme.get ? Game.Theme.get() : null;
    if (!ctx || !P) return;
    var grey = P.LIGHT_GREY || P.WHITE;
    ctx.fillStyle = P.BLACK;
    ctx.fillRect(0, 0, W, Game.H || 400);
    text(ctx, 'CODEX', W / 2, 44, P.YELLOW, 'center', 'title', 'bold 32px monospace');
    var y = 100, n = 0;
    for (var i = 0; i < VARIANTS.length; i++) {
      var v = VARIANTS[i];
      var on = !!found[v.id];
      if (on) n++;
      if (on && Game.Sprite && Game.Sprite.draw) {
        Game.Sprite.draw(ctx, v.sprite, 0, 150, y, v.swap ? { swap: v.swap } : undefined);
      } else {
        text(ctx, '?', 150, y, P.DARK_GREY || grey, 'center');
      }
      text(ctx, on ? v.name.toUpperCase() : '???', 190, y - 8, on ? P.YELLOW : (P.DARK_GREY || grey), 'left');
      text(ctx, on ? v.desc : '???', 190, y + 10, on ? grey : (P.DARK_GREY || grey), 'left', 'body', '12px monospace');
      y += 44;
    }
    text(ctx, 'FOUND ' + n + '/' + VARIANTS.length, W / 2, 360, P.GREEN || P.WHITE, 'center');
    text(ctx, 'ESC OR CLICK: BACK', W / 2, 382, grey, 'center', 'body', '12px monospace');
  }

  load();

  if (typeof window.addEventListener === 'function') {
    window.addEventListener('keydown', onKeyDown);
  }
  if (Game.canvas && Game.canvas.addEventListener) {
    Game.canvas.addEventListener('click', onClick);
  }

  Game.Codex = {
    STORAGE_KEY: STORAGE_KEY,
    variants: function () { return VARIANTS.map(function (v) { return { id: v.id, type: v.type, name: v.name, desc: v.desc }; }); },
    forType: function (t) { return forType(t).map(function (v) { return v.id; }); },
    choose: choose,
    spriteFor: spriteFor,
    nameOf: nameOf,
    isFound: isFound,
    foundIds: foundIds,
    record: record,
    runFinds: runFinds,
    resetRun: resetRun,
    reload: load,
    clear: clear,
    render: render
  };
})();
