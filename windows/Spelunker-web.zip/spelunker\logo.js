// logo.js - the CAVE RAIDER title logo.
//
// Game.Font 'large' face at scale 3, shaded with the 'fire' ramp (one band per
// pair of glyph rows), a 2-buffer-px dark outline and a 3-px drop shadow, a
// slow whole-pixel bob, and a light glint that sweeps across every 3 seconds.
// Coordinates are logical (640x400); 1 buffer px = 2 logical px.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  var TEXT = 'CAVE RAIDER';
  var PX = 2;                 // logical px per buffer px
  var SCALE = 3;
  var CENTER_Y = 86;          // logical, before the bob
  var OUTLINE = 2;            // buffer px
  var SHADOW = 3;             // buffer px, down and right
  var BOB_AMPLITUDE = 2;      // buffer px
  var BOB_RATE = 1.4;         // radians per second
  var GLINT_PERIOD = 3;       // seconds
  var GLINT_SWEEP = 0.7;      // seconds the sweep takes
  var GLINT_WIDTH = 24;       // logical px

  // Vertical offset in logical px; always a whole number of buffer px.
  function bobOffset(t) {
    return Math.round(Math.sin((t || 0) * BOB_RATE) * BOB_AMPLITUDE) * PX + 0; // + 0 turns -0 into 0
  }

  // Sweep progress 0..1 while the glint is travelling, otherwise -1.
  function glintProgress(t) {
    if (!(t >= 0)) return -1;
    var phase = t % GLINT_PERIOD;
    return phase < GLINT_SWEEP ? phase / GLINT_SWEEP : -1;
  }

  function textWidth() {
    var F = Game.Font;
    if (F && F.measure) return F.measure(TEXT, { face: 'large', scale: SCALE });
    return TEXT.length * 9 * PX * SCALE;
  }

  function draw(ctx, t) {
    var F = Game.Font;
    var P = Game.Theme && Game.Theme.get ? Game.Theme.get() : null;
    if (!ctx || !P || !F || !F.draw) return false;
    var cx = (Game.W || 640) / 2;
    var cy = CENTER_Y + bobOffset(t);
    var dark = P.BLACK;
    function put(dx, dy, color) {
      F.draw(ctx, TEXT, cx + dx * PX, cy + dy * PX,
        { face: 'large', scale: SCALE, color: color, align: 'center', baseline: 'middle' });
    }
    put(SHADOW, SHADOW, dark);
    for (var dy = -OUTLINE; dy <= OUTLINE; dy++) {
      for (var dx = -OUTLINE; dx <= OUTLINE; dx++) {
        if (Math.abs(dx) === OUTLINE && Math.abs(dy) === OUTLINE) continue; // round the corners
        if (dx || dy) put(dx, dy, dark);
      }
    }
    put(0, 0, 'fire');

    var g = glintProgress(t);
    if (g >= 0 && ctx.clip) {
      var w = textWidth();
      var left = cx - w / 2;
      var x = Math.round((left - GLINT_WIDTH + g * (w + GLINT_WIDTH)) / PX) * PX;
      ctx.save();
      ctx.beginPath();
      ctx.rect(x, cy - 40, GLINT_WIDTH, 80);
      ctx.clip();
      put(0, 0, P.WHITE);
      ctx.restore();
    }
    return true;
  }

  Game.Logo = {
    TEXT: TEXT,
    GLINT_PERIOD: GLINT_PERIOD,
    bobOffset: bobOffset,
    glintProgress: glintProgress,
    draw: draw
  };
})();
