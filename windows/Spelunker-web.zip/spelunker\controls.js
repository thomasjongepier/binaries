// controls.js - remappable keyboard bindings.
//
// Game.Controls.ACTIONS: up, down, left, right, fire, pause, lamp, mute.
// Bindings are stored in Game.Settings under 'controls' as
// { action: [key, ...] }. Keys are normalised names: single characters are
// lowercase ('w'), the space bar is 'Space', everything else is KeyboardEvent.key
// ('ArrowUp', 'Escape'). Corrupt or partial stored data falls back to defaults.
//
// matches(event, action) - does this keyboard event belong to the action.
// isDown(action)         - is any key bound to the action currently held.
// bind(action, key)      - rebind to a single key; rejects a key used by another
//                          action. Returns { ok, reason, conflict }.
(function () {
  'use strict';

  window.Game = window.Game || {};

  var ACTIONS = ['up', 'down', 'left', 'right', 'fire', 'pause', 'lamp', 'mute'];
  var DEFAULT_BINDINGS = {
    up: ['ArrowUp', 'w'],
    down: ['ArrowDown', 's'],
    left: ['ArrowLeft'],
    right: ['ArrowRight'],
    fire: ['Space'],
    pause: ['p', 'Escape'],
    lamp: ['l'],
    mute: ['m']
  };
  var MAX_KEYS_PER_ACTION = 4;
  var IGNORED = { Shift: 1, Control: 1, Alt: 1, Meta: 1, AltGraph: 1, CapsLock: 1,
    Dead: 1, Unidentified: 1, Process: 1, OS: 1 };

  var bindings = null;
  var down = {};
  var capturing = false;

  function copyDefaults() {
    var o = {};
    ACTIONS.forEach(function (a) { o[a] = DEFAULT_BINDINGS[a].slice(); });
    return o;
  }

  // Normalise a KeyboardEvent.key (or stored name); null when unusable.
  function normalize(key) {
    if (typeof key !== 'string' || !key) { return null; }
    if (key === ' ' || key === 'Spacebar' || key === 'Space') { return 'Space'; }
    if (IGNORED[key]) { return null; }
    return key.length === 1 ? key.toLowerCase() : key;
  }

  function eventKey(e) {
    if (!e) { return null; }
    if (e.code === 'Space') { return 'Space'; }
    return normalize(e.key);
  }

  function sanitize(raw) {
    var out = {};
    var used = {};
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) { return copyDefaults(); }
    for (var i = 0; i < ACTIONS.length; i++) {
      var a = ACTIONS[i];
      var list = [];
      var src = Object.prototype.hasOwnProperty.call(raw, a) ? raw[a] : null;
      if (Array.isArray(src)) {
        for (var j = 0; j < src.length && list.length < MAX_KEYS_PER_ACTION; j++) {
          var k = normalize(src[j]);
          if (k && !used[k] && list.indexOf(k) < 0) { list.push(k); }
        }
      }
      if (!list.length) {
        // Missing / invalid action: use its defaults (minus keys already taken).
        list = DEFAULT_BINDINGS[a].filter(function (k) { return !used[k]; });
        if (!list.length) { return copyDefaults(); }
      }
      list.forEach(function (k) { used[k] = a; });
      out[a] = list;
    }
    return out;
  }

  function settings() { return window.Game.Settings || null; }

  function load() {
    var S = settings();
    bindings = sanitize(S && S.get ? S.get('controls') : null);
  }

  function ensure() { if (!bindings) { load(); } }

  function getBindings() {
    ensure();
    var o = {};
    ACTIONS.forEach(function (a) { o[a] = bindings[a].slice(); });
    return o;
  }

  function keysFor(action) {
    ensure();
    return bindings[action] ? bindings[action].slice() : [];
  }

  // Raw KeyboardEvent.key values for an action (e.g. to synthesise keyups).
  function eventKeysFor(action) {
    return keysFor(action).map(function (k) { return k === 'Space' ? ' ' : k; });
  }

  function actionFor(key) {
    ensure();
    for (var i = 0; i < ACTIONS.length; i++) {
      if (bindings[ACTIONS[i]].indexOf(key) >= 0) { return ACTIONS[i]; }
    }
    return null;
  }

  function matches(e, action) {
    ensure();
    var k = eventKey(e);
    return !!k && !!bindings[action] && bindings[action].indexOf(k) >= 0;
  }

  function isDown(action) {
    ensure();
    var list = bindings[action];
    if (!list) { return false; }
    for (var i = 0; i < list.length; i++) {
      if (down[list[i]]) { return true; }
    }
    return false;
  }

  function persist() {
    var S = settings();
    if (S && S.set) { S.set('controls', getBindings()); }
  }

  function bind(action, key) {
    ensure();
    if (!bindings[action]) { return { ok: false, reason: 'unknown action' }; }
    var k = normalize(key);
    if (!k) { return { ok: false, reason: 'invalid key' }; }
    var other = actionFor(k);
    if (other && other !== action) {
      return { ok: false, reason: 'already used by ' + other.toUpperCase(), conflict: other };
    }
    bindings[action] = [k];
    persist();
    return { ok: true };
  }

  function resetDefaults() {
    bindings = copyDefaults();
    persist();
  }

  // Human-readable key name for the capture screen.
  function label(key) {
    if (key === 'Space') { return 'SPACE'; }
    if (key.indexOf('Arrow') === 0) { return key.slice(5).toUpperCase(); }
    return key.toUpperCase();
  }

  function setCapturing(on) { capturing = !!on; }
  function isCapturing() { return capturing; }

  function onKeyDown(e) { var k = eventKey(e); if (k) { down[k] = true; } }
  function onKeyUp(e) { var k = eventKey(e); if (k) { down[k] = false; } }
  function clearDown() { down = {}; }

  if (typeof window.addEventListener === 'function') {
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', clearDown);
  }
  if (settings() && settings().onChange) {
    settings().onChange(function (key) { if (key === 'controls') { load(); } });
  }

  window.Game.Controls = {
    ACTIONS: ACTIONS,
    DEFAULT_BINDINGS: DEFAULT_BINDINGS,
    getBindings: getBindings,
    keysFor: keysFor,
    eventKeysFor: eventKeysFor,
    actionFor: actionFor,
    matches: matches,
    isDown: isDown,
    bind: bind,
    resetDefaults: resetDefaults,
    reload: load,
    label: label,
    normalize: normalize,
    setCapturing: setCapturing,
    isCapturing: isCapturing
  };
})();
