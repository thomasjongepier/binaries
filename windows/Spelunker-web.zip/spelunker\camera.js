// camera.js - screen shake and hit-stop.
//
// Game.Camera.shake(intensity, seconds): intensity is the peak offset in
// logical px; it decays linearly to zero. Stacked shakes keep the stronger
// current amplitude and the longer remaining time.
// Game.Camera.offset(): {x, y}, both snapped to whole buffer pixels (even
// logical values) with Game.Pixel.snap. Always {0, 0} when the screenShake
// setting is off. Uses its own random stream 'camera'.
// Game.Camera.hitStop(seconds) / isFrozen(): brief world freeze. Stacked
// hit-stops never exceed MAX_HITSTOP seconds in total. Hit-stop ignores the
// screenShake setting. main.js calls update(dt) every frame, even when frozen.
(function () {
  'use strict';

  window.Game = window.Game || {};

  var MAX_HITSTOP = 0.15;

  var amp = 0;       // current peak amplitude, logical px
  var shakeTime = 0; // remaining shake seconds
  var shakeTotal = 0;
  var stopTime = 0;  // remaining hit-stop seconds
  var cached = null; // offset for the current frame

  function rng() {
    var R = window.Game.Random;
    if (R && R.stream) { return R.stream('camera'); }
    return { range: function (a, b) { return a + Math.random() * (b - a); } };
  }

  function enabled() {
    var S = window.Game.Settings;
    if (S && S.get) { return S.get('screenShake') !== false && !S.get('reduceMotion'); }
    return true;
  }

  function snap(v) {
    var P = window.Game.Pixel;
    if (P && P.snap) { return P.snap(v); }
    return Math.round(v / 2) * 2;
  }

  function shake(intensity, seconds) {
    if (!(intensity > 0) || !(seconds > 0)) { return; }
    var cur = shakeTime > 0 ? amp * (shakeTime / shakeTotal) : 0;
    amp = Math.max(cur, intensity);
    shakeTime = Math.max(shakeTime, seconds);
    shakeTotal = shakeTime;
    cached = null;
  }

  function hitStop(seconds) {
    if (!(seconds > 0)) { return; }
    stopTime = Math.min(MAX_HITSTOP, stopTime + seconds);
  }

  function isFrozen() {
    return stopTime > 0;
  }

  function update(dt) {
    if (!(dt > 0)) { return; }
    stopTime = Math.max(0, stopTime - dt);
    shakeTime = Math.max(0, shakeTime - dt);
    if (shakeTime === 0) { amp = 0; }
    cached = null;
  }

  function offset() {
    if (!enabled() || shakeTime <= 0 || amp <= 0) {
      return { x: 0, y: 0 };
    }
    if (!cached) {
      var a = amp * (shakeTime / shakeTotal);
      var r = rng();
      cached = { x: snap(r.range(-a, a)) + 0, y: snap(r.range(-a, a)) + 0 };
    }
    return { x: cached.x, y: cached.y };
  }

  function reset() {
    amp = 0; shakeTime = 0; shakeTotal = 0; stopTime = 0; cached = null;
  }

  window.Game.Camera = {
    MAX_HITSTOP: MAX_HITSTOP,
    shake: shake,
    offset: offset,
    hitStop: hitStop,
    isFrozen: isFrozen,
    update: update,
    reset: reset
  };
})();
