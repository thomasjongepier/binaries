// Spelunker - player projectiles (fired by the ship).
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so main.js can call Projectiles.update/render each
// frame, following the same pattern as cave.js/ship.js/collision.js.
//
// Projectiles are tracked in plain screen-space: they spawn at the ship's
// current screen position and travel rightward at a constant speed until
// they leave the right edge of the canvas or exceed a max lifetime. They do
// not need to interact with cave scroll, so no world-x conversion is
// needed here.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('projectile.js requires window.Game to be set up by main.js first');
  }

  var canvas = Game.canvas;
  var ctx = Game.ctx;
  function palette() { return Game.Theme.get(); }

  // ---- Tuning constants ----
  var PROJECTILE_SPEED = 400; // px/sec, screen-space rightward speed
  var FIRE_COOLDOWN = 0.25; // seconds, minimum interval between shots
  var MAX_LIFETIME = 2; // seconds, backstop despawn timer
  var PROJECTILE_WIDTH = 8;
  var PROJECTILE_HEIGHT = 2;
  // Starting ammo: 25 shots. At the 0.25s cooldown that's a little over 6
  // seconds of sustained fire before running dry - enough to feel usable
  // during a run without feeling unlimited, while leaving room for the
  // future pickup-items task to meaningfully replenish it via addAmmo().
  var STARTING_AMMO = 14;

  var projectiles = []; // each: { x, y, age }
  var cooldownTimer = 0; // seconds remaining until next shot is allowed
  var ammo = STARTING_AMMO;

  function reset() {
    projectiles = [];
    cooldownTimer = 0;
    ammo = STARTING_AMMO;
  }

  function spawn() {
    if (!Game.Ship || !Game.Ship.getPosition) {
      return;
    }
    var pos = Game.Ship.getPosition();
    projectiles.push({
      x: pos.screenX,
      y: pos.y,
      age: 0
    });
  }

  // Attempts to fire a projectile, subject to the cooldown, the current
  // game state, and available ammo. Only fires during 'playing' so stray
  // title/gameover input doesn't queue up a shot that appears the instant
  // play begins. Both the cooldown check and the ammo check must pass for
  // a shot to be fired; ammo is only decremented when a shot actually
  // spawns, so it never goes negative and a shot blocked purely by
  // cooldown never costs ammo.
  function tryFire() {
    if (!Game.getState || Game.getState() !== Game.STATES.PLAYING) {
      return;
    }
    if (Game.isPaused && Game.isPaused()) {
      return;
    }
    if (cooldownTimer > 0) {
      return;
    }
    if (ammo <= 0) {
      return;
    }
    spawn();
    ammo -= 1;
    cooldownTimer = FIRE_COOLDOWN;
    if (Game.Audio && Game.Audio.playFireSound) {
      Game.Audio.playFireSound();
    }
  }

  function onKeyDown(e) {
    var C = Game.Controls;
    var isFire = (C && C.matches) ? C.matches(e, 'fire')
      : (e.code === 'Space' || e.key === ' ' || e.key === 'Spacebar');
    if (isFire) {
      e.preventDefault();
      tryFire();
    }
  }

  function onFireClick() {
    tryFire();
  }

  window.addEventListener('keydown', onKeyDown);
  canvas.addEventListener('mousedown', onFireClick);

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    if (cooldownTimer > 0) {
      cooldownTimer = Math.max(0, cooldownTimer - dt);
    }

    for (var i = projectiles.length - 1; i >= 0; i--) {
      var p = projectiles[i];
      p.x += PROJECTILE_SPEED * dt;
      p.age += dt;

      if (p.x > Game.W || p.age > MAX_LIFETIME) {
        projectiles.splice(i, 1);
      }
    }
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    ctx.fillStyle = palette().WHITE;
    for (var i = 0; i < projectiles.length; i++) {
      var p = projectiles[i];
      ctx.fillRect(p.x, p.y - PROJECTILE_HEIGHT / 2, PROJECTILE_WIDTH, PROJECTILE_HEIGHT);
    }
  }

  function getAll() {
    return projectiles;
  }

  function getAmmo() {
    return ammo;
  }

  // Increases ammo by a whole, finite, nonnegative amount. Invalid input is
  // ignored so callers cannot corrupt the ammo state with NaN, Infinity,
  // fractions, or negative values.
  function addAmmo(n) {
    if (typeof n !== 'number' || !isFinite(n) || n < 0 || Math.floor(n) !== n) {
      return;
    }
    ammo += n;
  }

  Game.Projectiles = {
    update: update,
    render: render,
    reset: reset,
    tryFire: tryFire,
    getAll: getAll,
    getAmmo: getAmmo,
    addAmmo: addAmmo
  };
})();
