// Pixel framebuffer: in pixel mode (modern theme) the whole frame is drawn
// into a 320x200 offscreen canvas and upscaled without smoothing, so every
// buffer pixel is a hard square. Draw code keeps using 640x400 logical
// coordinates; beginFrame's context carries a 0.5 scale transform.
(function () {
  'use strict';

  window.Game = window.Game || {};

  var SCALE = 2; // logical px per buffer px
  var BW = 320;
  var BH = 200;

  // Created once at load. Guarded so this file loads under the Node DOM stub.
  var buffer = null;
  var bctx = null;
  if (typeof document !== 'undefined' && document && typeof document.createElement === 'function') {
    try {
      var c = document.createElement('canvas');
      if (c && typeof c.getContext === 'function') {
        c.width = BW;
        c.height = BH;
        buffer = c;
        bctx = c.getContext('2d');
      }
    } catch (e) {
      buffer = null;
      bctx = null;
    }
  }

  // Snap a logical coordinate onto the buffer pixel grid.
  // Retro resolution (default) uses the 320x200 buffer; 'high' bypasses it.
  // Output density: 1 = retro (320x200 buffer), 2 = high, 4 = ultrahigh.
  function detail() {
    var S = window.Game && window.Game.Settings;
    var r = (S && S.get) ? S.get('resolution') : 'retro';
    return r === 'ultrahigh' ? 4 : (r === 'high' ? 2 : 1);
  }

  function enabled() {
    return detail() === 1;
  }

  function snap(v) {
    var step = SCALE / detail(); // 2 / 1 / 0.5
    return Math.round(v / step) * step;
  }

  // Returns the context to draw the frame into: the buffer (logical-coordinate
  // transform) or null if no buffer is available (caller falls back to main).
  function beginFrame(mainCtx) {
    if (!bctx) {
      return null;
    }
    bctx.setTransform(1 / SCALE, 0, 0, 1 / SCALE, 0, 0);
    return bctx;
  }

  // Blit the buffer over the full main-canvas bitmap, hard-edged.
  function endFrame(mainCtx) {
    if (!bctx || !mainCtx) {
      return;
    }
    mainCtx.setTransform(1, 0, 0, 1, 0, 0);
    mainCtx.imageSmoothingEnabled = false;
    mainCtx.drawImage(buffer, 0, 0, buffer.width, buffer.height,
      0, 0, mainCtx.canvas.width, mainCtx.canvas.height);
  }

  // Scale2x (EPX). getKey(x, y) returns a comparable identity for the source
  // pixel, or null for transparent. Returns an Int32Array of 2w*2h entries
  // (row-major) holding the source index (y*w+x) whose colour each output
  // pixel takes, or -1 when that output pixel is transparent.
  function scale2x(w, h, getKey) {
    var keys = new Array(w * h);
    var x, y;
    for (y = 0; y < h; y++) {
      for (x = 0; x < w; x++) {
        var k = getKey(x, y);
        keys[y * w + x] = (k === undefined) ? null : k;
      }
    }
    var out = new Int32Array(w * 2 * h * 2);
    for (y = 0; y < h; y++) {
      for (x = 0; x < w; x++) {
        var pi = y * w + x;
        var ai = y > 0 ? pi - w : pi;
        var di = y < h - 1 ? pi + w : pi;
        var ci = x > 0 ? pi - 1 : pi;
        var bi = x < w - 1 ? pi + 1 : pi;
        var A = keys[ai], B = keys[bi], C = keys[ci], D = keys[di];
        var o1 = pi, o2 = pi, o3 = pi, o4 = pi;
        if (C === A && C !== D && A !== B) { o1 = ai; }
        if (A === B && A !== C && B !== D) { o2 = bi; }
        if (D === C && D !== B && C !== A) { o3 = ci; }
        if (B === D && B !== A && D !== C) { o4 = di; }
        var r = (y * 2) * (w * 2) + x * 2;
        out[r] = keys[o1] === null ? -1 : o1;
        out[r + 1] = keys[o2] === null ? -1 : o2;
        out[r + w * 2] = keys[o3] === null ? -1 : o3;
        out[r + w * 2 + 1] = keys[o4] === null ? -1 : o4;
      }
    }
    return out;
  }

  window.Game.Pixel = {
    scale2x: scale2x,
    hiRes: function () { return detail() > 1; },
    detail: detail,
    SCALE: SCALE,
    BW: BW,
    BH: BH,
    snap: snap,
    enabled: enabled,
    beginFrame: beginFrame,
    endFrame: endFrame,
    getBuffer: function () { return buffer; }
  };
})();
