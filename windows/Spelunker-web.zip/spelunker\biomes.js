// Spelunker - biomes. Named cave sections that change every BIOME_LENGTH
// distance points, cycling. Each biome tints the rock palette (same colours in
// classic and modern) and scales hazard trigger chances. Game.Balance is not
// touched; hazards.js multiplies at roll time.
(function () {
  'use strict';
  window.Game = window.Game || {};
  var Game = window.Game;

  var BIOME_LENGTH = 2000;   // distance points per biome
  var FADE_DURATION = 3;     // seconds for the rock palette crossfade
  var FADE_STEPS = 6;        // quantised steps, so cave tiles rebuild few times
  var BANNER_DURATION = 2;   // seconds the ENTERING banner shows

  // rock: 5-colour ramp, dark to light; null = use the active theme's rock.
  var BIOMES = [
    { name: 'Crystal Caverns', rock: null, gas: 1, collapse: 1 },
    { name: 'Toxic Mines', gas: 1.5, collapse: 1,
      rock: ['#0d1c0f', '#1c3a1c', '#2f5c27', '#4d7d3a', '#7fae58'] },
    { name: 'Magma Depths', gas: 1, collapse: 1.5,
      rock: ['#2b0f09', '#4b1d11', '#722f1a', '#9b482a', '#c8693c'] }
  ];

  var absIndex = 0;      // floor(distance / BIOME_LENGTH), unbounded
  var fromIdx = 0;       // cycled index we are fading away from
  var fade = 1;          // 0..1 crossfade progress toward the current biome
  var bannerTimer = 0;
  var bannerName = '';
  var visualCounter = 0; // monotonic; bumps whenever the rock ramp changes
  var lastStep = FADE_STEPS;
  var cache = null;
  var reached = [BIOMES[0].name]; // unique biome names visited this run, in order

  function indexAt(distancePoints) {
    if (typeof distancePoints !== 'number' || !isFinite(distancePoints) || distancePoints < 0) return 0;
    return Math.floor(distancePoints / BIOME_LENGTH);
  }
  function cycled(i) { return i % BIOMES.length; }
  function curIdx() { return cycled(absIndex); }

  function current() {
    var b = BIOMES[curIdx()];
    return { index: curIdx(), absoluteIndex: absIndex, name: b.name, gas: b.gas, collapse: b.collapse };
  }

  // type: 'gas' | 'collapse'. Unknown types give 1.
  function hazardMultiplier(type) {
    var b = BIOMES[curIdx()];
    return (type === 'gas' || type === 'collapse') ? b[type] : 1;
  }

  function reset() {
    absIndex = 0; fromIdx = 0; fade = 1; bannerTimer = 0; bannerName = '';
    lastStep = FADE_STEPS;
    visualCounter++; // palette snaps back to Crystal Caverns
    cache = null;
    reached = [BIOMES[0].name];
  }

  function update(dt) {
    if (typeof dt !== 'number' || !(dt > 0)) return;
    var S = Game.Score;
    var idx = indexAt(S && S.distancePoints);
    if (idx !== absIndex) {
      // Crossfade starts from whatever is currently shown.
      fromIdx = fade >= 1 ? curIdx() : fromIdx;
      absIndex = idx;
      fade = 0;
      lastStep = -1;
      bannerTimer = BANNER_DURATION;
      bannerName = BIOMES[curIdx()].name;
      if (reached.indexOf(bannerName) < 0) reached.push(bannerName);
    }
    if (bannerTimer > 0) bannerTimer = Math.max(0, bannerTimer - dt);
    if (fade < 1) fade = Math.min(1, fade + dt / FADE_DURATION);
    var step = Math.round(fade * FADE_STEPS);
    if (step !== lastStep) { lastStep = step; visualCounter++; cache = null; }
  }

  function hexToRgb(h) {
    var n = parseInt(h.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function mix(a, b, t) {
    var x = hexToRgb(a), y = hexToRgb(b), s = '#';
    for (var i = 0; i < 3; i++) {
      var h = Math.round(x[i] + (y[i] - x[i]) * t).toString(16).toUpperCase();
      s += h.length < 2 ? '0' + h : h;
    }
    return s;
  }

  // Rock ramp for the current moment given the theme's base rock ramp.
  function rockRamp(base) {
    if (!base || base.length < 5) return base;
    if (cache && cache.base === base) return cache.ramp;
    var from = BIOMES[fromIdx].rock || base;
    var to = BIOMES[curIdx()].rock || base;
    var t = Math.round(fade * FADE_STEPS) / FADE_STEPS;
    var out = [];
    for (var i = 0; i < base.length; i++) {
      out.push(from === to || t >= 1 ? to[i] : (t <= 0 ? from[i] : mix(from[i], to[i], t)));
    }
    cache = { base: base, ramp: out };
    return out;
  }

  function renderBanner(rctx) {
    if (bannerTimer <= 0) return;
    var c = rctx || Game.ctx;
    var pal = Game.Theme && Game.Theme.get ? Game.Theme.get() : { YELLOW: '#BFCE72' };
    var text = 'ENTERING: ' + bannerName.toUpperCase();
    if (Game.Font && Game.Font.draw) {
      Game.Font.draw(c, text, Game.W / 2, 100, {
        role: 'title', css: 'bold 22px monospace', color: pal.YELLOW,
        align: 'center', baseline: 'middle', scale: 1
      });
    } else {
      c.save();
      c.font = 'bold 22px monospace';
      c.fillStyle = pal.YELLOW;
      c.textAlign = 'center';
      c.textBaseline = 'middle';
      c.fillText(text, Game.W / 2, 100);
      c.restore();
    }
  }

  Game.Biomes = {
    current: current,
    indexAt: indexAt,
    hazardMultiplier: hazardMultiplier,
    gasMultiplier: function () { return hazardMultiplier('gas'); },
    collapseMultiplier: function () { return hazardMultiplier('collapse'); },
    update: update,
    reset: reset,
    getReached: function () { return reached.slice(); },
    rockRamp: rockRamp,
    version: function () { return visualCounter; },
    bannerText: function () { return bannerTimer > 0 ? 'ENTERING: ' + bannerName.toUpperCase() : ''; },
    renderBanner: renderBanner,
    BIOME_LENGTH: BIOME_LENGTH,
    FADE_DURATION: FADE_DURATION,
    BANNER_DURATION: BANNER_DURATION,
    names: function () { return BIOMES.map(function (b) { return b.name; }); }
  };
})();
