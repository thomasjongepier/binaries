// Spelunker - ammo-restock pickups.
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so main.js can call Pickups.update/render each
// frame, following the same pattern as enemy.js/cave.js/ship.js/
// collision.js/projectile.js.
//
// Pickups are tracked in WORLD-space (worldX, y), exactly like enemy.js,
// so they scroll "for free" with the camera without needing per-frame
// velocity math. Spawn uses the SAME safe-margin/lookahead pattern as
// enemy.js (see spelunker-427.2/spelunker-427.4, which fixed wall-overlap
// and stale-bounds bugs in that pattern) - reused verbatim here rather
// than reinvented.
//
// Ship-vs-pickup collection is handled HERE (inside update()), not in
// collision.js, since pickups are purely positive (no lives/crash/
// invulnerability interaction at all) and collision.js is meant to stay
// focused on hazards only. Pickups are never checked against projectiles -
// they are a reward, not a target.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('pickup.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;
  function palette() { return Game.Theme.get(); }

  // ---- Tuning constants ----
  // Distinct from enemy.js's 2-4s enemy spawn interval, so pickups don't
  // spawn in lockstep with enemies.
  var SPAWN_INTERVAL_MIN = 9; // seconds
  var SPAWN_INTERVAL_MAX = 14; // seconds
  // Must be <= cave.js's SEGMENT_SPACING so getCaveBoundsAtX is queried
  // within the range cave.js's ensureGeneratedAhead guarantees is already
  // generated - same reasoning/derivation as enemy.js's SPAWN_AHEAD_BUFFER,
  // reused verbatim so the two values can never drift apart from cave.js's
  // actual generation guarantee. 40 is a fallback only in case cave.js
  // hasn't populated Game.Cave yet for some reason.
  var SPAWN_AHEAD_BUFFER = (Game.Cave && Game.Cave.SEGMENT_SPACING) || 40; // px beyond the right edge, world-x
  var PICKUP_RADIUS = 12; // collision + render size, comparable to ENEMY_RADIUS
  // Pickups use a static y (no bob), so the spawn margin only needs to
  // cover the radius + a small safety buffer (no bob amplitude to add).
  var SPAWN_MARGIN = PICKUP_RADIUS + 5; // px
  var CULL_SCREEN_X = -100; // remove once this far behind the camera, matches enemy.js
  var AMMO_RESTOCK_AMOUNT = 5; // ammo granted per pickup collected

  // Shield pickups are a separate, rarer bonus system - independent spawn
  // timer from the ammo pickups above so neither cadence affects the other.
  var SHIELD_SPAWN_INTERVAL_MIN = 15; // seconds
  var SHIELD_SPAWN_INTERVAL_MAX = 22; // seconds
  var SHIELD_RESTORE_AMOUNT = 25; // ~1/4 of MAX_SHIELD per pickup

  // Crystal pickups: pure discovery/collectible, no gameplay-resource effect
  // (unlike ammo/shield above) - just a score value. Spawn cadence sits
  // between the ammo and shield intervals so it reads as "fairly common".
  var CRYSTAL_SPAWN_INTERVAL_MIN = Game.Balance.discoveries.crystal.SPAWN_MIN; // seconds
  var CRYSTAL_SPAWN_INTERVAL_MAX = Game.Balance.discoveries.crystal.SPAWN_MAX; // seconds
  var CRYSTAL_SCORE_VALUE = Game.Balance.discoveries.crystal.VALUE;

  // Fossil pickups: rarer discovery, worth more. Independent spawn timer,
  // same reasoning as shield's independence from ammo above.
  var FOSSIL_SPAWN_INTERVAL_MIN = Game.Balance.discoveries.fossil.SPAWN_MIN; // seconds
  var FOSSIL_SPAWN_INTERVAL_MAX = Game.Balance.discoveries.fossil.SPAWN_MAX; // seconds
  var FOSSIL_SCORE_VALUE = Game.Balance.discoveries.fossil.VALUE;

  var pickups = []; // each: { worldX, y, type: 'ammo' | 'shield' | 'crystal' | 'fossil' }
  var spawnTimer = 0; // seconds remaining until next ammo spawn
  var shieldSpawnTimer = 0; // seconds remaining until next shield spawn
  var crystalSpawnTimer = 0; // seconds remaining until next crystal spawn
  var fossilSpawnTimer = 0; // seconds remaining until next fossil spawn
  var discoveryScore = 0; // accumulated score from crystal/fossil pickups
  var discoveriesCollected = 0; // count of crystal/fossil pickups collected

  function randRange(min, max) {
    return min + Game.Random.stream('pickups').next() * (max - min);
  }

  function resetSpawnTimer() {
    spawnTimer = randRange(SPAWN_INTERVAL_MIN, SPAWN_INTERVAL_MAX);
  }

  function resetShieldSpawnTimer() {
    shieldSpawnTimer = randRange(SHIELD_SPAWN_INTERVAL_MIN, SHIELD_SPAWN_INTERVAL_MAX);
  }

  function resetCrystalSpawnTimer() {
    crystalSpawnTimer = randRange(CRYSTAL_SPAWN_INTERVAL_MIN, CRYSTAL_SPAWN_INTERVAL_MAX);
  }

  function resetFossilSpawnTimer() {
    fossilSpawnTimer = randRange(FOSSIL_SPAWN_INTERVAL_MIN, FOSSIL_SPAWN_INTERVAL_MAX);
  }

  function reset() {
    pickups = [];
    discoveryScore = 0;
    discoveriesCollected = 0;
    if (Game.Codex && Game.Codex.resetRun) { Game.Codex.resetRun(); }
    resetSpawnTimer();
    resetShieldSpawnTimer();
    resetCrystalSpawnTimer();
    resetFossilSpawnTimer();
  }

  function spawn(type) {
    if (!Game.Cave || !Game.Cave.getScrollX || !Game.Cave.getCaveBoundsAtX) {
      return;
    }
    var scrollX = Game.Cave.getScrollX();
    var spawnWorldX = scrollX + Game.W + SPAWN_AHEAD_BUFFER;
    var bounds = Game.Cave.getCaveBoundsAtX(spawnWorldX);

    var top = bounds.top + SPAWN_MARGIN;
    var bottom = bounds.bottom - SPAWN_MARGIN;
    var y;
    if (top >= bottom) {
      // Gap too narrow for the margin - fall back to the gap's midpoint so
      // we still spawn something reasonable rather than skipping entirely.
      y = (bounds.top + bounds.bottom) / 2;
    } else {
      y = randRange(top, bottom);
    }

    var pk = { worldX: spawnWorldX, y: y, type: type };
    if (Game.Codex && Game.Codex.choose) {
      var variant = Game.Codex.choose(type);
      if (variant) { pk.variant = variant; }
    }
    pickups.push(pk);
  }

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    animTime += dt;

    spawnTimer -= dt;
    if (spawnTimer <= 0) {
      spawn('ammo');
      resetSpawnTimer();
    }

    shieldSpawnTimer -= dt;
    if (shieldSpawnTimer <= 0) {
      spawn('shield');
      resetShieldSpawnTimer();
    }

    crystalSpawnTimer -= dt;
    if (crystalSpawnTimer <= 0) {
      spawn('crystal');
      resetCrystalSpawnTimer();
    }

    fossilSpawnTimer -= dt;
    if (fossilSpawnTimer <= 0) {
      spawn('fossil');
      resetFossilSpawnTimer();
    }

    var scrollX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;

    // ---- Ship collision: collect pickup, restock ammo. Purely positive -
    // never touches lives/crash/invulnerability logic (that all lives in
    // collision.js and is not called from here at all). Reverse-iterate so
    // splicing mid-loop never skips an element, matching enemy.js's proven
    // -correct removal pattern for enemy-vs-projectile hits.
    if (Game.Ship && Game.Ship.getPosition) {
      var pos = Game.Ship.getPosition();
      var shipRadius = (Game.Ship && Game.Ship.SHIP_RADIUS) || 10;
      for (var pi = pickups.length - 1; pi >= 0; pi--) {
        var pk = pickups[pi];
        var dx = pos.worldX - pk.worldX;
        var dy = pos.y - pk.y;
        var hitRadius = shipRadius + PICKUP_RADIUS;
        if ((dx * dx + dy * dy) <= (hitRadius * hitRadius)) {
          pickups.splice(pi, 1);
          if (pk.type === 'shield') {
            if (Game.Collision && Game.Collision.restoreShield) {
              Game.Collision.restoreShield(SHIELD_RESTORE_AMOUNT);
            }
            if (Game.Audio && Game.Audio.playShieldPickupSound) {
              Game.Audio.playShieldPickupSound(Game.Audio.panForX ? Game.Audio.panForX(pk.worldX - scrollX) : undefined);
            }
          } else if (pk.type === 'crystal') {
            if (pk.variant && Game.Codex && Game.Codex.record) { Game.Codex.record(pk.variant); }
            discoveryScore += CRYSTAL_SCORE_VALUE;
            if (Game.Score && Game.Score.addDiscovery) Game.Score.addDiscovery(CRYSTAL_SCORE_VALUE);
            discoveriesCollected++;
            if (Game.Effects && Game.Effects.pulseDiscovery) {
              Game.Effects.pulseDiscovery(pk.worldX - scrollX, pk.y);
            }
            if (Game.Audio && Game.Audio.playDiscoverySound) {
              Game.Audio.playDiscoverySound(Game.Audio.panForX ? Game.Audio.panForX(pk.worldX - scrollX) : undefined);
            }
          } else if (pk.type === 'fossil') {
            if (pk.variant && Game.Codex && Game.Codex.record) { Game.Codex.record(pk.variant); }
            discoveryScore += FOSSIL_SCORE_VALUE;
            if (Game.Score && Game.Score.addDiscovery) Game.Score.addDiscovery(FOSSIL_SCORE_VALUE);
            discoveriesCollected++;
            if (Game.Effects && Game.Effects.pulseDiscovery) {
              Game.Effects.pulseDiscovery(pk.worldX - scrollX, pk.y);
            }
            if (Game.Audio && Game.Audio.playDiscoverySound) {
              Game.Audio.playDiscoverySound(Game.Audio.panForX ? Game.Audio.panForX(pk.worldX - scrollX) : undefined);
            }
          } else {
            if (Game.Projectiles && Game.Projectiles.addAmmo) {
              Game.Projectiles.addAmmo(AMMO_RESTOCK_AMOUNT);
            }
            if (Game.Audio && Game.Audio.playAmmoPickupSound) {
              Game.Audio.playAmmoPickupSound(Game.Audio.panForX ? Game.Audio.panForX(pk.worldX - scrollX) : undefined);
            }
          }
        }
      }
    }

    // ---- Cull pickups sufficiently far behind the camera. ----
    for (var ci = pickups.length - 1; ci >= 0; ci--) {
      var screenX = pickups[ci].worldX - scrollX;
      if (screenX < CULL_SCREEN_X) {
        pickups.splice(ci, 1);
      }
    }
  }

  // ---- Sprites: 12x12 buffer px, 4 frames at 8 fps, outline = ramp[0]. ----
  // Characters: o ramp[0] (outline), a/b/c ramp[1..3], w ui white (sparkle).
  var SPRITE_SIZE = 12;
  var ANIM_FPS = 8;
  var HALO_SIZE = SPRITE_SIZE + 2;
  var SPRITE_NAMES = {
    ammo: 'pickup-ammo',
    shield: 'pickup-shield',
    crystal: 'pickup-crystal',
    fossil: 'pickup-fossil'
  };
  // Extra fossil sprites (the codex variants), defined below with the rest.
  var EXTRA_SPRITES = { 'pickup-fossil-trilobite': trilobiteFrame, 'pickup-fossil-fern': fernFrame };
  var animTime = 0; // seconds, drives the sprite frame

  // Build rows from a per-pixel character function (code-defined grid).
  function buildRows(size, fn) {
    var rows = [];
    for (var y = 0; y < size; y++) {
      var row = '';
      for (var x = 0; x < size; x++) { row += fn(x, y); }
      rows.push(row);
    }
    return rows;
  }

  function inDisc(x, y, size) {
    var c = (size - 1) / 2;
    var dx = x - c, dy = y - c;
    return dx * dx + dy * dy <= (size / 2) * (size / 2) - 0.5;
  }

  // Disc with 1 px outline, shaded by distance from an upper-left light.
  // overlay(x, y) may return a replacement character or null.
  function orbRows(overlay) {
    return buildRows(SPRITE_SIZE, function (x, y) {
      if (!inDisc(x, y, SPRITE_SIZE)) { return '.'; }
      var edge = !inDisc(x - 1, y, SPRITE_SIZE) || !inDisc(x + 1, y, SPRITE_SIZE) ||
        !inDisc(x, y - 1, SPRITE_SIZE) || !inDisc(x, y + 1, SPRITE_SIZE);
      if (edge) { return 'o'; }
      var o = overlay(x, y);
      if (o) { return o; }
      var d = Math.sqrt((x - 3.5) * (x - 3.5) + (y - 3.5) * (y - 3.5));
      return d < 2.6 ? 'c' : (d < 5.2 ? 'b' : 'a');
    });
  }

  function ammoFrame(f) {
    var phase = f * Math.PI / 8; // 4 dots, 90 deg symmetric, 22.5 deg per frame
    var dots = {};
    for (var k = 0; k < 4; k++) {
      var ang = phase + k * Math.PI / 2;
      dots[Math.floor(5.5 + 3.6 * Math.cos(ang)) + ',' + Math.floor(5.5 + 3.6 * Math.sin(ang))] = true;
    }
    return orbRows(function (x, y) {
      if (x === 3 && y === 3) { return 'w'; }
      return dots[x + ',' + y] ? 'c' : null;
    });
  }

  function shieldFrame(f) {
    var arm = [1, 2, 3, 2][f]; // plus mark pulses
    return orbRows(function (x, y) {
      var inH = (y === 5 || y === 6) && x >= 5 - arm && x <= 6 + arm;
      var inV = (x === 5 || x === 6) && y >= 5 - arm && y <= 6 + arm;
      return (inH || inV) ? 'w' : null;
    });
  }

  function crystalFrame(f) {
    var band = [7, 10, 13, 16][f]; // shine sweeps diagonally across the gem
    return buildRows(SPRITE_SIZE, function (x, y) {
      var dx = x - 5.5, dy = y - 5.5;
      var m = Math.abs(dx) + Math.abs(dy);
      if (m > 6) { return '.'; }
      if (m > 5) { return 'o'; }
      if (x + y === band) { return 'w'; }
      if (m < 2.5) { return 'c'; }
      if (dy < 0) { return dx < 0 ? 'c' : 'b'; }
      return dx < 0 ? 'b' : 'a';
    });
  }

  function fossilFrame(f) {
    var spiral = {};
    var rot = f * Math.PI / 2;
    for (var i = 0; i <= 80; i++) {
      var th = i / 80 * Math.PI * 4;
      var r = 0.7 + th * (3.9 / (Math.PI * 4));
      spiral[Math.floor(5.5 + r * Math.cos(th + rot)) + ',' + Math.floor(5.5 + r * Math.sin(th + rot))] = true;
    }
    return orbRows(function (x, y) {
      return spiral[x + ',' + y] ? 'o' : null;
    });
  }

  // Trilobite: oval body with rib lines across it; the shine sweeps along it.
  function trilobiteFrame(f) {
    return orbRows(function (x, y) {
      if (x === 3 + f * 2 && y === 5) { return 'w'; }
      if (y === 2 || y === 9) { return null; }
      return (x === 3 || x === 5 || x === 7) ? 'o' : null;
    });
  }

  // Fern leaf: a diagonal stem with leaflets branching off both sides.
  function fernFrame(f) {
    return orbRows(function (x, y) {
      var d = x - y; // stem runs along the main diagonal
      if (d === 0) { return 'o'; }
      if ((x + y) % 2 === 0 && Math.abs(d) === 2 && x + y > 4 && x + y < 18) { return 'o'; }
      return (x + y === 6 + f * 3) ? 'w' : null;
    });
  }

  function haloRows() {
    var c = (HALO_SIZE - 1) / 2;
    return buildRows(HALO_SIZE, function (x, y) {
      var d = Math.sqrt((x - c) * (x - c) + (y - c) * (y - c));
      return (d > 5.7 && d <= 6.9) ? 'h' : '.';
    });
  }

  var SPRITE_FRAMES = {
    ammo: ammoFrame, shield: shieldFrame, crystal: crystalFrame, fossil: fossilFrame
  };

  if (Game.Sprite && Game.Sprite.define) {
    Object.keys(EXTRA_SPRITES).forEach(function (name) {
      var frames = [];
      for (var f = 0; f < 4; f++) { frames.push(EXTRA_SPRITES[name](f)); }
      Game.Sprite.define(name, {
        w: SPRITE_SIZE, h: SPRITE_SIZE,
        map: { o: 'fossil:0', a: 'fossil:1', b: 'fossil:2', c: 'fossil:3', w: 'ui:3' },
        frames: frames
      });
    });
    Object.keys(SPRITE_NAMES).forEach(function (type) {
      var gen = SPRITE_FRAMES[type];
      var frames = [];
      for (var f = 0; f < 4; f++) { frames.push(gen(f)); }
      Game.Sprite.define(SPRITE_NAMES[type], {
        w: SPRITE_SIZE, h: SPRITE_SIZE,
        map: { o: type + ':0', a: type + ':1', b: type + ':2', c: type + ':3', w: 'ui:3' },
        frames: frames
      });
      Game.Sprite.define(SPRITE_NAMES[type] + '-halo', {
        w: HALO_SIZE, h: HALO_SIZE,
        map: { h: type + ':1' },
        frames: [haloRows()]
      });
    });
  }

  // One table-driven draw: halo on every other animation frame, then sprite.
  function drawPickup(type, x, y, variant) {
    if (!(Game.Sprite && Game.Sprite.draw)) { return; }
    var name = SPRITE_NAMES[type] || SPRITE_NAMES.ammo;
    var swap;
    var vs = variant && Game.Codex && Game.Codex.spriteFor ? Game.Codex.spriteFor(variant) : null;
    if (vs) { name = vs.name; swap = vs.swap || undefined; }
    var frame = Math.floor(animTime * ANIM_FPS);
    if (frame % 2 === 0) {
      Game.Sprite.draw(ctx, SPRITE_NAMES[type] + '-halo', 0, x, y, swap ? { swap: swap } : undefined);
    }
    Game.Sprite.draw(ctx, name, frame, x, y, swap ? { swap: swap } : undefined);
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    var scrollX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;

    for (var i = 0; i < pickups.length; i++) {
      var pk = pickups[i];
      var screenX = pk.worldX - scrollX;

      // Cull off-screen draws (kept in the update list until CULL_SCREEN_X).
      if (screenX < -PICKUP_RADIUS || screenX > Game.W + PICKUP_RADIUS) {
        continue;
      }

      drawPickup(pk.type, screenX, pk.y, pk.variant);
    }
  }

  function getAll() {
    return pickups;
  }

  function getScore() {
    return discoveryScore;
  }

  function getDiscoveryCount() {
    return discoveriesCollected;
  }

  Game.Pickups = {
    update: update,
    render: render,
    reset: reset,
    getAll: getAll,
    getScore: getScore,
    getDiscoveryCount: getDiscoveryCount
  };
})();
