// controls-screen.js - key capture panel for the options screen.
//
// Adds a "Controls" row to Game.SettingsScreen. Activating it opens a panel
// listing every action with its keys. Up/Down select, Enter starts capture,
// the next key press binds the highlighted action. Escape cancels a capture
// while Escape is bound to pause (the default); once pause is rebound, Escape
// is an ordinary capturable key. A key used by another action is rejected with
// a message. Delete resets all bindings. Escape (outside capture) goes back.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  var W = 640;
  var TOP = 84;
  var ROW_H = 27;
  var LABEL_X = 150;
  var VALUE_RIGHT = 490;

  var selected = 0;
  var capturing = false;
  var message = '';

  function C() { return Game.Controls || null; }

  function actions() { return C() ? C().ACTIONS : []; }

  function setCapture(on) {
    capturing = !!on;
    if (C() && C().setCapturing) { C().setCapturing(capturing); }
  }

  function escapeCancels() {
    var c = C();
    return !!c && c.keysFor('pause').indexOf('Escape') >= 0;
  }

  function onKey(e) {
    var c = C();
    var list = actions();
    if (!c || !list.length) { close(); return; }
    var key = e.key;
    if (capturing) {
      if (key === 'Escape' && escapeCancels()) {
        setCapture(false);
        message = 'CANCELLED';
        return;
      }
      if (e.repeat) { return; }
      var res = c.bind(list[selected], key);
      if (res.ok) {
        setCapture(false);
        message = list[selected].toUpperCase() + ' BOUND TO ' + c.label(c.normalize(key));
      } else if (res.reason === 'invalid key') {
        message = 'KEY NOT ALLOWED';
      } else {
        message = c.label(c.normalize(key)) + ' ' + res.reason.toUpperCase();
      }
      return;
    }
    if (key === 'ArrowUp') { selected = (selected - 1 + list.length) % list.length; message = ''; }
    else if (key === 'ArrowDown') { selected = (selected + 1) % list.length; message = ''; }
    else if (key === 'Enter') { setCapture(true); message = 'PRESS A KEY FOR ' + list[selected].toUpperCase(); }
    else if (key === 'Delete') { c.resetDefaults(); message = 'DEFAULTS RESTORED'; }
    else if (key === 'Escape') { close(); }
  }

  function close() {
    setCapture(false);
    message = '';
    if (Game.SettingsScreen && Game.SettingsScreen.closePanel) { Game.SettingsScreen.closePanel(); }
  }

  function open() {
    selected = 0;
    message = '';
    setCapture(false);
    if (Game.SettingsScreen && Game.SettingsScreen.openPanel) {
      Game.SettingsScreen.openPanel({ onKey: onKey, render: render });
    }
  }

  function text(ctx, str, x, y, align, color, role, scale) {
    var css = 'bold ' + (scale > 1 ? 24 : 16) + 'px monospace';
    if (Game.Font && Game.Font.draw) {
      Game.Font.draw(ctx, str, x, y, { role: role || 'body', css: css, color: color,
        align: align, baseline: 'middle', scale: scale || 1 });
      return;
    }
    ctx.save();
    ctx.font = css;
    ctx.fillStyle = color;
    ctx.textAlign = align;
    ctx.textBaseline = 'middle';
    ctx.fillText(str, x, y);
    ctx.restore();
  }

  function render(ctx) {
    var P = Game.Theme && Game.Theme.get ? Game.Theme.get() : null;
    var c = C();
    if (!ctx || !P || !c) { return; }
    var H = Game.H || 400;
    var list = actions();
    ctx.fillStyle = P.BLUE;
    ctx.fillRect(0, 0, W, H);
    text(ctx, 'CONTROLS', W / 2, 40, 'center', P.YELLOW, 'title', 2);
    for (var i = 0; i < list.length; i++) {
      var y = TOP + i * ROW_H;
      var sel = i === selected;
      if (sel) {
        ctx.fillStyle = capturing ? P.PURPLE : P.DARK_GREY;
        ctx.fillRect(LABEL_X - 16, y - ROW_H / 2 + 2, VALUE_RIGHT - LABEL_X + 32, ROW_H - 4);
      }
      var col = sel ? P.YELLOW : P.WHITE;
      text(ctx, list[i].toUpperCase(), LABEL_X, y, 'left', col);
      var keyText = (sel && capturing) ? '...' : c.keysFor(list[i]).map(c.label).join(' / ');
      text(ctx, keyText, VALUE_RIGHT, y, 'right', col);
    }
    text(ctx, message, W / 2, H - 56, 'center', P.WHITE);
    var help = capturing
      ? (escapeCancels() ? 'PRESS A KEY  ESC CANCEL' : 'PRESS A KEY')
      : 'ENTER REBIND  DEL RESET  ESC BACK';
    text(ctx, help, W / 2, H - 28, 'center', P.LIGHT_GREY || P.WHITE);
  }

  if (Game.SettingsScreen && Game.SettingsScreen.registerRow) {
    Game.SettingsScreen.registerRow({ key: 'controls', label: 'Controls', type: 'action',
      valueLabel: 'EDIT', onActivate: open });
  }

  Game.ControlsScreen = {
    open: open,
    close: close,
    onKey: onKey,
    render: render,
    isCapturing: function () { return capturing; },
    getMessage: function () { return message; },
    getSelected: function () { return selected; }
  };
})();
