// Spelunker - shared song-assembly helpers for the chronological-measure
// score files (e.g. music-bach.js). A song supplies:
//   tracks   - object keyed by voice key, each value {instrument, header}
//   measures - chronological array of {label, <voiceKey>: [noteLines...]}
// and these helpers derive the notation string and the measure timeline.

(function () {
  // Resolves music-parser.js's durationOfNoteString() whether running in the
  // browser (music-parser.js loads first per index.html's script order and
  // attaches to window.Game) or under Node, where it must be required.
  function getMusicParser() {
    if (typeof window !== 'undefined' && window.Game && window.Game.MusicParser) {
      return window.Game.MusicParser;
    }
    if (typeof require !== 'undefined') {
      return require('./music-parser.js');
    }
    throw new Error('music-score.js: music-parser.js is not available (load it before music-score.js)');
  }

  // Sums the durations (seconds) of every line in a measure part (a part may
  // span multiple continuation lines), reusing music-parser.js's
  // durationOfNoteString() rather than duplicating duration math.
  function durationOfPart(part, bpm) {
    var musicParser = getMusicParser();
    var total = 0;
    for (var i = 0; i < part.length; i++) {
      total += musicParser.durationOfNoteString(part[i], bpm);
    }
    return total;
  }

  function buildTrackNotation(key, track, measures) {
    var lines = [track.header, 'TRACK ' + key + ' ' + track.instrument];

    measures.forEach(function (measure) {
      var parts = measure[key];
      if (!parts || !parts.length) {
        return;
      }

      lines.push(measure.label);
      parts.forEach(function (part) {
        lines.push(part);
      });
    });

    return lines.join('\n');
  }

  // Builds the full notation string. `title` is an array of comment lines
  // (a single string is also accepted). The TEMPO line is built from `bpm`,
  // so the notation and the measure timeline share one tempo value.
  function buildNotation(title, bpm, tracks, measures) {
    var titleLines = Array.isArray(title) ? title : [title];
    return titleLines
      .concat(['TEMPO ' + bpm, ''])
      .concat(Object.keys(tracks).map(function (key) {
        return buildTrackNotation(key, tracks[key], measures);
      }))
      .join('\n\n');
  }

  // Chronological {label, startTime} array, one entry per measure, where
  // startTime is the cumulative seconds from the top of the piece to the
  // start of that measure (first entry's startTime is 0). A measure's own
  // duration is the max of the durations of whichever voices (keys of
  // `tracks`) it has: voices play in sync, so the measure's length is
  // bounded by its longest voice.
  function buildMeasureMap(tracks, measures, bpm) {
    var voiceKeys = Object.keys(tracks);
    var map = [];
    var cursor = 0;
    measures.forEach(function (measure) {
      map.push({ label: measure.label, startTime: cursor });

      var measureDuration = 0;
      voiceKeys.forEach(function (key) {
        var part = measure[key];
        if (part && part.length) {
          var partDuration = durationOfPart(part, bpm);
          if (partDuration > measureDuration) {
            measureDuration = partDuration;
          }
        }
      });

      cursor += measureDuration;
    });
    return map;
  }

  var MusicScore = {
    buildNotation: buildNotation,
    buildMeasureMap: buildMeasureMap
  };

  if (typeof window !== 'undefined') {
    window.MusicScore = MusicScore;
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = MusicScore;
  }
})();
