// Spelunker - synthesized sound effects via the Web Audio API.
// Vanilla JS, no build tools, no dependencies, no external audio files.
// Attaches to window.Game (created by main.js) so other scripts (e.g.
// projectile.js, collision.js) can call Game.Audio.playFireSound()/
// playCrashSound() following the same defensive-guard style used
// elsewhere in the codebase (Game.Audio && Game.Audio.playX && ...()).
//
// AudioContext lifecycle: browsers block/suspend AudioContexts created
// before a genuine user gesture, so we deliberately do NOT create one at
// script-parse time. Instead, ensureAudioContext() lazily creates the
// context (or resumes it if it already exists but is suspended) the FIRST
// time either play function is called. Since tryFire()/triggerCrash() are
// themselves only ever reachable via prior user interaction (keydown/click
// during 'playing', which itself requires the title/gameover "any key or
// click to start" gesture to have already happened), this call site is
// guaranteed to be within a user-gesture-originated call stack the first
// time it matters, and the resume()/create is idempotent afterward.
(function () {
  'use strict';

  // Node fallback (mirrors music-parser.js's pattern) so this file's new
  // multi-track scheduling logic can be exercised/traced standalone via
  // `node audio.js` or a require()-based test harness, without altering
  // browser behavior (window is always defined there).
  var isNode = typeof window === 'undefined';
  var Game = isNode ? {} : window.Game;
  if (!isNode && !Game) {
    throw new Error('audio.js requires window.Game to be set up by main.js first');
  }

  var audioContext = null;

  // Creates the shared AudioContext on first use, or resumes it if the
  // browser auto-suspended it. Safe to call every time a sound is played;
  // does nothing beyond the first create/resume once the context is running.
  function ensureAudioContext() {
    if (isNode) {
      // No Web Audio API under Node; standalone tests either exercise the
      // scheduling logic directly or inject a fake ctx via __setTestEnv().
      return testEnv && testEnv.ctx ? testEnv.ctx : null;
    }
    var AudioContextCtor = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextCtor) {
      return null; // Web Audio API unsupported; callers must no-op gracefully
    }
    if (!audioContext) {
      audioContext = new AudioContextCtor();
    }
    if (audioContext.state === 'suspended' && audioContext.resume) {
      audioContext.resume();
    }
    return audioContext;
  }

  // ---------------------------------------------------------------------
  // Audio bus. Every sound goes through one of two buses instead of straight
  // to ctx.destination:
  //   sfxBus / musicBus (GainNode)
  //     -> dry path -> masterGain
  //     -> send gain (SFX 0.25, music 0.35) -> reverb (ConvolverNode) -> masterGain
  //   masterGain -> DynamicsCompressorNode -> ctx.destination
  // The reverb impulse response is generated procedurally (no audio files).
  // The buses are built once per AudioContext (on first use) and never
  // recreated. If createConvolver / createDynamicsCompressor / createBuffer is
  // missing, the compressor and reverb are skipped and the dry path connects
  // to the destination only.
  var REVERB_SECONDS = 2.2;
  var SFX_REVERB_SEND = 0.25;
  var MUSIC_REVERB_SEND = 0.35;

  var audioBuses = null;      // { ctx, sfx, music, master, compressor, reverb }

  // 2.2 s stereo impulse response: white noise with an exponentially
  // decaying envelope (about -60 dB at the end).
  function buildReverbImpulse(ctx) {
    var rate = ctx.sampleRate || 44100;
    var length = Math.max(1, Math.floor(rate * REVERB_SECONDS));
    var buffer = ctx.createBuffer(2, length, rate);
    for (var ch = 0; ch < 2; ch++) {
      var data = buffer.getChannelData(ch);
      for (var i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-6.9 * i / length);
      }
    }
    return buffer;
  }

  function connectBusToReverb(bus, sendLevel, ctx, master, reverb) {
    bus.connect(master); // dry
    if (reverb) {
      var send = ctx.createGain();
      send.gain.setValueAtTime(sendLevel, ctx.currentTime || 0);
      bus.connect(send);
      send.connect(reverb);
    }
  }

  function getAudioBuses(ctx) {
    if (audioBuses && audioBuses.ctx === ctx) {
      return audioBuses;
    }
    var sfx = ctx.createGain();
    var music = ctx.createGain();
    var master = ctx.createGain();
    var compressor = null;
    var reverb = null;
    if (ctx.createConvolver && ctx.createDynamicsCompressor && ctx.createBuffer) {
      compressor = ctx.createDynamicsCompressor();
      reverb = ctx.createConvolver();
      reverb.buffer = buildReverbImpulse(ctx);
      reverb.connect(master);
      master.connect(compressor);
      compressor.connect(ctx.destination);
    } else {
      master.connect(ctx.destination);
    }
    connectBusToReverb(sfx, SFX_REVERB_SEND, ctx, master, reverb);
    connectBusToReverb(music, MUSIC_REVERB_SEND, ctx, master, reverb);
    audioBuses = { ctx: ctx, sfx: sfx, music: music, master: master, compressor: compressor, reverb: reverb };
    applyBusVolumes();
    return audioBuses;
  }

  // Volume control (Game.Settings keys musicVolume / sfxVolume, both 0..1).
  // A volume of 0 is silent and 1 leaves the sound unchanged. MUTE WINS over
  // the music slider: while isMusicMuted (the M key) the music bus gain is 0
  // whatever musicVolume says, and the M key never touches the SFX bus.
  function getSettings() {
    if (isNode) {
      return testEnv ? testEnv.settings : null;
    }
    return Game.Settings || null;
  }

  function readVolume(key) {
    var settings = getSettings();
    var v = settings && settings.get ? settings.get(key) : undefined;
    if (typeof v !== 'number' || !isFinite(v)) {
      return 1;
    }
    return Math.min(1, Math.max(0, v));
  }

  // Pushes the current settings + mute state onto the bus gains. Called when
  // the buses are created, when a volume setting changes and when M toggles.
  function applyBusVolumes() {
    if (!audioBuses) {
      return;
    }
    var now = audioBuses.ctx.currentTime || 0;
    if (audioBuses.music.gain.cancelScheduledValues) {
      audioBuses.music.gain.cancelScheduledValues(now); // drops any pending duck
    }
    audioBuses.music.gain.setValueAtTime(isMusicMuted ? 0 : readVolume('musicVolume'), now);
    audioBuses.sfx.gain.setValueAtTime(readVolume('sfxVolume'), now);
  }

  var hookedSettings = null;
  function hookSettings(settings) {
    if (!settings || !settings.onChange || settings === hookedSettings) {
      return;
    }
    hookedSettings = settings;
    settings.onChange(function (key) {
      if (key === 'musicVolume' || key === 'sfxVolume') {
        applyBusVolumes();
      } else if (key === 'intensityLayer') {
        syncIntensityLayer();
      } else if (key === 'musicTrack') {
        setMusicTrack(settings.get('musicTrack'));
      }
    });
  }
  if (!isNode && Game.Settings) {
    hookSettings(Game.Settings);
  }

  function getSfxDestination(ctx) {
    return getAudioBuses(ctx).sfx;
  }

  function getMusicDestination(ctx) {
    return getAudioBuses(ctx).music;
  }

  // ---------------------------------------------------------------------
  // Shared synthesis helpers.

  var noiseBuffers = [];  // [{ ctx, buffer }]: one cached noise buffer per ctx

  // 1 s of white noise, built once per AudioContext. Returns null when the
  // context cannot make buffers (callers then skip their noise layer).
  function getNoiseBuffer(ctx) {
    for (var i = 0; i < noiseBuffers.length; i++) {
      if (noiseBuffers[i].ctx === ctx) {
        return noiseBuffers[i].buffer;
      }
    }
    if (!ctx.createBuffer) {
      return null;
    }
    var rate = ctx.sampleRate || 44100;
    var length = Math.max(1, Math.floor(rate));
    var buffer = ctx.createBuffer(1, length, rate);
    var data = buffer.getChannelData(0);
    for (var n = 0; n < length; n++) {
      data[n] = Math.random() * 2 - 1;
    }
    noiseBuffers = [{ ctx: ctx, buffer: buffer }];
    return buffer;
  }

  // Creates a noise source (not yet started). Returns null if unsupported.
  function createNoiseSource(ctx, loop) {
    var buffer = ctx.createBufferSource ? getNoiseBuffer(ctx) : null;
    if (!buffer) {
      return null;
    }
    var source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = !!loop;
    return source;
  }

  function createFilter(ctx, type, freq, q, when) {
    var filter = ctx.createBiquadFilter();
    filter.type = type;
    filter.frequency.setValueAtTime(freq, when);
    if (q !== undefined && filter.Q) {
      filter.Q.setValueAtTime(q, when);
    }
    return filter;
  }

  // One-shot voice cap: at most MAX_ONE_SHOTS effect sounds may be sounding at
  // once; further ones are dropped (not queued). Tracked by audio-clock end
  // time, so no timers are needed.
  var MAX_ONE_SHOTS = 8;
  var oneShotEnds = [];

  function acquireOneShot(ctx, duration) {
    var now = ctx.currentTime || 0;
    oneShotEnds = oneShotEnds.filter(function (end) { return end > now; });
    if (oneShotEnds.length >= MAX_ONE_SHOTS) {
      return false;
    }
    oneShotEnds.push(now + duration);
    return true;
  }

  // The context + capability check shared by the new noise-based effects.
  // Returns the ctx, or null when audio (or a needed node type) is missing.
  function getEffectsContext() {
    var ctx = ensureAudioContext();
    if (!ctx || !ctx.createBiquadFilter || !ctx.createBufferSource) {
      return null;
    }
    return ctx;
  }

  // ---------------------------------------------------------------------
  // Thrust engine loop: looping noise through a lowpass plus a sawtooth, both
  // summed into one gain, routed to the SFX bus. All parameter changes are
  // 0.05 s linear ramps (never abrupt).
  var ENGINE_RAMP = 0.05;
  var ENGINE_CUTOFF_IDLE = 300, ENGINE_CUTOFF_FULL = 1400;
  var ENGINE_FREQ_IDLE = 55, ENGINE_FREQ_FULL = 82;
  var ENGINE_GAIN_IDLE = 0.03, ENGINE_GAIN_FULL = 0.12;
  var engine = null; // { ctx, noise, saw, filter, gain, throttle }

  function rampParam(param, value, now) {
    if (param.cancelScheduledValues) {
      param.cancelScheduledValues(now);
    }
    param.linearRampToValueAtTime(value, now + ENGINE_RAMP);
  }

  function engineLerp(a, b, t) {
    return a + (b - a) * t;
  }

  function startEngine() {
    if (engine) {
      return; // idempotent
    }
    var ctx = getEffectsContext();
    if (!ctx || !ctx.createOscillator) {
      return;
    }
    var now = ctx.currentTime || 0;
    var noise = createNoiseSource(ctx, true);
    var filter = createFilter(ctx, 'lowpass', ENGINE_CUTOFF_IDLE, undefined, now);
    var gain = ctx.createGain();
    gain.gain.setValueAtTime(ENGINE_GAIN_IDLE, now);
    var saw = ctx.createOscillator();
    saw.type = 'sawtooth';
    saw.frequency.setValueAtTime(ENGINE_FREQ_IDLE, now);
    if (noise) {
      noise.connect(filter);
    }
    filter.connect(gain);
    saw.connect(gain);
    gain.connect(getSfxDestination(ctx));
    if (noise) {
      noise.start(now);
    }
    saw.start(now);
    engine = { ctx: ctx, noise: noise, saw: saw, filter: filter, gain: gain, throttle: 0 };
  }

  // throttle 0..1 (clamped); smoothly moves cutoff, pitch and level.
  function setEngine(throttle) {
    if (!engine) {
      return;
    }
    var t = typeof throttle === 'number' && isFinite(throttle) ? Math.min(1, Math.max(0, throttle)) : 0;
    var now = engine.ctx.currentTime || 0;
    engine.throttle = t;
    rampParam(engine.filter.frequency, engineLerp(ENGINE_CUTOFF_IDLE, ENGINE_CUTOFF_FULL, t), now);
    rampParam(engine.saw.frequency, engineLerp(ENGINE_FREQ_IDLE, ENGINE_FREQ_FULL, t), now);
    rampParam(engine.gain.gain, engineLerp(ENGINE_GAIN_IDLE, ENGINE_GAIN_FULL, t), now);
  }

  function disconnectQuietly(node) {
    try {
      node.disconnect();
    } catch (e) {
      // Already disconnected.
    }
  }

  // Fades out over the ramp time, stops the sources and disconnects the
  // nodes once they have ended. Safe to call when no engine is running.
  function stopEngine() {
    if (!engine) {
      return;
    }
    var e = engine;
    engine = null;
    var now = e.ctx.currentTime || 0;
    rampParam(e.gain.gain, 0, now);
    var stopAt = now + ENGINE_RAMP + 0.01;
    var sources = [e.saw];
    if (e.noise) {
      sources.push(e.noise);
    }
    sources.forEach(function (src) {
      try {
        src.stop(stopAt);
      } catch (err) {
        // Already stopped.
      }
    });
    e.saw.onended = function () {
      [e.saw, e.noise, e.filter, e.gain].forEach(function (node) {
        if (node) {
          disconnectQuietly(node);
        }
      });
    };
  }

  // Stereo placement for world sounds. panForX() maps a screen x to a pan
  // (-1..1, clamped to +-0.8 so nothing hard-pans); sfxOutput() returns the
  // node a one-shot should connect to: a StereoPannerNode feeding the SFX bus
  // when a pan is given and the browser supports it, else the SFX bus itself
  // (centred). The panner is GC'd with its source nodes.
  var MAX_PAN = 0.8;

  function clampPan(pan) {
    return Math.min(MAX_PAN, Math.max(-MAX_PAN, pan));
  }

  function panForX(x) {
    var width = (Game.W > 0) ? Game.W : 640;
    if (typeof x !== 'number' || !isFinite(x)) {
      return 0;
    }
    return clampPan((x - width / 2) / (width / 2));
  }

  function sfxOutput(ctx, pan) {
    var bus = getSfxDestination(ctx);
    if (typeof pan !== 'number' || !isFinite(pan) || !ctx.createStereoPanner) {
      return bus;
    }
    var panner = ctx.createStereoPanner();
    panner.pan.setValueAtTime(clampPan(pan), ctx.currentTime || 0);
    panner.connect(bus);
    return panner;
  }

  // Sine/triangle tone with a linear attack and exponential decay to silence.
  function playTone(ctx, out, type, freq, startTime, duration, peak, attack) {
    var osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, startTime);
    var gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(peak, startTime + attack);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
    osc.connect(gain);
    gain.connect(out);
    osc.start(startTime);
    osc.stop(startTime + duration);
    return osc;
  }

  // Layered shot: a 10 ms noise tick plus a triangle sweep 900 -> 300 Hz over
  // 0.12 s.
  var FIRE_SWEEP_SECONDS = 0.12;
  function playFireSound() {
    var ctx = ensureAudioContext();
    if (!ctx || !acquireOneShot(ctx, FIRE_SWEEP_SECONDS)) {
      return;
    }
    var now = ctx.currentTime;
    var out = getSfxDestination(ctx);

    var tick = createNoiseSource(ctx, false);
    if (tick) {
      var tickGain = ctx.createGain();
      tickGain.gain.setValueAtTime(0.18, now);
      tickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.01);
      tick.connect(tickGain);
      tickGain.connect(out);
      tick.start(now);
      tick.stop(now + 0.01);
    }

    var sweep = ctx.createOscillator();
    sweep.type = 'triangle';
    sweep.frequency.setValueAtTime(900, now);
    sweep.frequency.exponentialRampToValueAtTime(300, now + FIRE_SWEEP_SECONDS);
    var sweepGain = ctx.createGain();
    sweepGain.gain.setValueAtTime(0.2, now);
    sweepGain.gain.exponentialRampToValueAtTime(0.001, now + FIRE_SWEEP_SECONDS);
    sweep.connect(sweepGain);
    sweepGain.connect(out);
    sweep.start(now);
    sweep.stop(now + FIRE_SWEEP_SECONDS);
  }

  // Explosion voices (no voice-cap bookkeeping; callers do that): a noise
  // burst through a lowpass sweeping 1800 -> 200 Hz over 0.5 s, plus a sine sub
  // thump 60 -> 30 Hz over 0.3 s.
  var EXPLOSION_SECONDS = 0.5;
  function buildExplosion(ctx, out, now) {
    var noise = ctx.createBiquadFilter ? createNoiseSource(ctx, false) : null;
    if (noise) {
      var filter = createFilter(ctx, 'lowpass', 1800, undefined, now);
      filter.frequency.exponentialRampToValueAtTime(200, now + EXPLOSION_SECONDS);
      var noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.3, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + EXPLOSION_SECONDS);
      noise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(out);
      noise.start(now);
      noise.stop(now + EXPLOSION_SECONDS);
    }
    var sub = ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(60, now);
    sub.frequency.exponentialRampToValueAtTime(30, now + 0.3);
    var subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.4, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    sub.connect(subGain);
    subGain.connect(out);
    sub.start(now);
    sub.stop(now + 0.3);
  }

  function playExplosionSound(pan) {
    var ctx = ensureAudioContext();
    if (!ctx || !acquireOneShot(ctx, EXPLOSION_SECONDS)) {
      return;
    }
    buildExplosion(ctx, sfxOutput(ctx, pan), ctx.currentTime);
    duckMusic(ctx);
  }

  // Player crash: the explosion plus a short descending two-note chime.
  function playCrashSound() {
    var ctx = ensureAudioContext();
    if (!ctx || !acquireOneShot(ctx, EXPLOSION_SECONDS)) {
      return;
    }
    var now = ctx.currentTime;
    var out = getSfxDestination(ctx);
    buildExplosion(ctx, out, now);
    playTone(ctx, out, 'sine', 784, now + 0.05, 0.16, 0.12, 0.01);
    playTone(ctx, out, 'sine', 523, now + 0.17, 0.2, 0.12, 0.01);
    duckMusic(ctx);
  }

  // Ammo pickup: rising three-note sine arpeggio (C5 E5 G5).
  function playAmmoPickupSound(pan) {
    var ctx = ensureAudioContext();
    if (!ctx || !acquireOneShot(ctx, 0.3)) {
      return;
    }
    var now = ctx.currentTime;
    var out = sfxOutput(ctx, pan);
    var freqs = [523, 659, 784];
    for (var i = 0; i < freqs.length; i++) {
      playTone(ctx, out, 'sine', freqs[i], now + i * 0.07, 0.12, 0.2, 0.01);
    }
  }

  // Shield pickup: warm two-note chord (E4 + B4) with a soft attack.
  function playShieldPickupSound(pan) {
    var ctx = ensureAudioContext();
    if (!ctx || !acquireOneShot(ctx, 0.5)) {
      return;
    }
    var now = ctx.currentTime;
    var out = sfxOutput(ctx, pan);
    playTone(ctx, out, 'sine', 330, now, 0.5, 0.18, 0.04);
    playTone(ctx, out, 'sine', 494, now, 0.5, 0.14, 0.04);
  }

  // ---------------------------------------------------------------------
  // Warning sounds.

  // Wall scrape: 0.15 s of bandpassed noise (400 -> 900 Hz, Q 2); level scales
  // with strength (0..1).
  var SCRAPE_SECONDS = 0.15;
  var SCRAPE_MAX_GAIN = 0.3;
  function playWallScrape(strength) {
    var ctx = getEffectsContext();
    if (!ctx || !acquireOneShot(ctx, SCRAPE_SECONDS)) {
      return;
    }
    var s = typeof strength === 'number' && isFinite(strength) ? Math.min(1, Math.max(0, strength)) : 0;
    var now = ctx.currentTime;
    var noise = createNoiseSource(ctx, false);
    if (!noise) {
      return;
    }
    var filter = createFilter(ctx, 'bandpass', 400, 2, now);
    filter.frequency.linearRampToValueAtTime(900, now + SCRAPE_SECONDS);
    var gain = ctx.createGain();
    gain.gain.setValueAtTime(Math.max(0.0002, SCRAPE_MAX_GAIN * s), now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + SCRAPE_SECONDS);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(getSfxDestination(ctx));
    noise.start(now);
    noise.stop(now + SCRAPE_SECONDS);
  }

  // Stamina gasp: 0.4 s of breathy bandpassed noise, swelling then fading.
  var GASP_SECONDS = 0.4;
  function playGasp() {
    var ctx = getEffectsContext();
    if (!ctx || !acquireOneShot(ctx, GASP_SECONDS)) {
      return;
    }
    var now = ctx.currentTime;
    var noise = createNoiseSource(ctx, false);
    if (!noise) {
      return;
    }
    var filter = createFilter(ctx, 'bandpass', 700, 0.8, now);
    filter.frequency.linearRampToValueAtTime(1500, now + 0.15);
    filter.frequency.linearRampToValueAtTime(900, now + GASP_SECONDS);
    var gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(0.25, now + 0.12);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + GASP_SECONDS);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(getSfxDestination(ctx));
    noise.start(now);
    noise.stop(now + GASP_SECONDS);
  }

  // Low-shield heartbeat: a 60 Hz sine thump, two per second, until switched
  // off. Idempotent; every thump is scheduled from a single pending timer, so
  // turning it off leaves nothing scheduled.
  var HEARTBEAT_INTERVAL_MS = 500;
  var heartbeatTimer = null;

  function playHeartbeatThump() {
    var ctx = ensureAudioContext();
    if (!ctx) {
      return false;
    }
    playTone(ctx, getSfxDestination(ctx), 'sine', 60, ctx.currentTime, 0.18, 0.5, 0.01);
    return true;
  }

  function setLowShieldWarning(on) {
    if (!on) {
      if (heartbeatTimer !== null) {
        clearTimeout(heartbeatTimer);
        heartbeatTimer = null;
      }
      return;
    }
    if (heartbeatTimer !== null) {
      return;
    }
    var tick = function () {
      if (!playHeartbeatThump()) {
        heartbeatTimer = null;
        return;
      }
      heartbeatTimer = setTimeout(tick, HEARTBEAT_INTERVAL_MS);
    };
    tick();
  }

  // Short, low-pitched thud/rumble - a dull "cave-in" impact sound, used
  // by hazards.js's triggerCollapse(). Deeper and slower than
  // playCrashSound() so the two remain distinguishable.
  function playHazardCollapseSound() {
    var ctx = ensureAudioContext();
    if (!ctx) {
      return;
    }

    var now = ctx.currentTime;
    var duration = 0.3;

    var oscillator = ctx.createOscillator();
    oscillator.type = 'sawtooth';
    oscillator.frequency.setValueAtTime(90, now);
    oscillator.frequency.exponentialRampToValueAtTime(30, now + duration);

    var gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(0.3, now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + duration);

    oscillator.connect(gainNode);
    gainNode.connect(getSfxDestination(ctx));

    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  // Short, higher-pitched wobbling hiss - used by hazards.js's
  // triggerGas(). Frequency oscillates (LFO on a second oscillator
  // modulating the tone oscillator's frequency) to read as a "hiss/warble"
  // distinct from the collapse thud's straight downward sweep.
  function playHazardGasSound() {
    var ctx = ensureAudioContext();
    if (!ctx) {
      return;
    }

    var now = ctx.currentTime;
    var duration = 0.35;

    var oscillator = ctx.createOscillator();
    oscillator.type = 'triangle';
    oscillator.frequency.setValueAtTime(500, now);

    var lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.setValueAtTime(28, now);
    var lfoGain = ctx.createGain();
    lfoGain.gain.setValueAtTime(120, now);
    lfo.connect(lfoGain);
    lfoGain.connect(oscillator.frequency);

    var gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(0.2, now);
    gainNode.gain.exponentialRampToValueAtTime(0.001, now + duration);

    oscillator.connect(gainNode);
    gainNode.connect(getSfxDestination(ctx));

    oscillator.start(now);
    lfo.start(now);
    oscillator.stop(now + duration);
    lfo.stop(now + duration);
  }

  // Dispatches to the right hazard SFX by type ('collapse' or 'gas').
  // Unrecognized types no-op silently rather than throwing, matching the
  // defensive-guard style used elsewhere in this file.
  function playHazardSound(type) {
    if (type === 'collapse') {
      playHazardCollapseSound();
    } else if (type === 'gas') {
      playHazardGasSound();
    }
  }

  // Short, bright two-note ascending chime - a pleasant "ding" used by
  // pickup.js on crystal/fossil discovery collection. Distinct from both
  // hazard sounds (higher pitch, sine tone, ascending rather than
  // descending/wobbling) and from playFireSound()/playCrashSound() (sine
  // rather than square/sawtooth, two-note chime rather than a single sweep).
  function playDiscoverySound(pan) {
    var ctx = ensureAudioContext();
    if (!ctx) {
      return;
    }
    var out = sfxOutput(ctx, pan);

    var now = ctx.currentTime;
    var noteDuration = 0.12;

    var freqs = [880, 1320];
    for (var i = 0; i < freqs.length; i++) {
      var startTime = now + i * noteDuration;

      var oscillator = ctx.createOscillator();
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(freqs[i], startTime);

      var gainNode = ctx.createGain();
      gainNode.gain.setValueAtTime(0.001, startTime);
      gainNode.gain.linearRampToValueAtTime(0.25, startTime + 0.01);
      gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + noteDuration);

      oscillator.connect(gainNode);
      gainNode.connect(out);

      oscillator.start(startTime);
      oscillator.stop(startTime + noteDuration);
    }
  }

  // Simple single-oscillator organ voice. This is intentionally cheap:
  // one square wave per scheduled note, shaped by a soft envelope. It
  // trades realism for stability and keeps polyphonic playback lighter.
  function playInstrumentNote_organBasic(ctx, freq, startTime, duration, activeOscillators) {
    var gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(0, startTime);
    gainNode.connect(getMusicDestination(ctx));

    var oscillator = ctx.createOscillator();
    oscillator.type = 'square';
    oscillator.frequency.setValueAtTime(freq, startTime);
    oscillator.connect(gainNode);

    // Keep a small attack/release so note boundaries stay click-free.
    gainNode.gain.linearRampToValueAtTime(0.06, startTime + 0.01);
    // Hold near-steady for most of the note, then release just before the
    // note's nominal end so back-to-back notes don't click together.
    var releaseStart = startTime + Math.max(duration - 0.03, 0.01);
    gainNode.gain.setValueAtTime(0.06, releaseStart);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    oscillator.start(startTime);
    oscillator.stop(startTime + duration);

    if (activeOscillators) {
      activeOscillators.push(oscillator);
    }
    return 1;
  }

  // Single-oscillator "lead" synthesis for the new multi-track engine
  // (MUSIC_FORMAT.md's 'lead' instrument): a sawtooth wave, slightly
  // punchier/sharper envelope than the organ's (faster attack, no long
  // sustain plateau) so a lead line reads as distinct from the organ track
  // when they play concurrently.
  function playInstrumentNote_leadBasic(ctx, freq, startTime, duration, activeOscillators) {
    var gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(0, startTime);
    // Sharper attack than organ's 20ms: 10ms.
    gainNode.gain.linearRampToValueAtTime(0.09, startTime + 0.01);
    var releaseStart = startTime + Math.max(duration - 0.05, 0.01);
    gainNode.gain.setValueAtTime(0.09, releaseStart);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);
    gainNode.connect(getMusicDestination(ctx));

    var oscillator = ctx.createOscillator();
    oscillator.type = 'sawtooth';
    oscillator.frequency.setValueAtTime(freq, startTime);
    oscillator.connect(gainNode);

    oscillator.start(startTime);
    oscillator.stop(startTime + duration);

    if (activeOscillators) {
      activeOscillators.push(oscillator);
    }
  }

  // ---------------------------------------------------------------------
  // Rich music voices. Oscillator cap: at most MAX_OSCILLATORS_PER_NOTE per
  // note (organ: main saw + one +7 cent saw + octave-below sine + 3rd-harmonic
  // chiff sine + vibrato LFO = 5). Notes
  // shorter than SHORT_NOTE_SECONDS use only the main oscillator. If the
  // context has no createBiquadFilter, the plain single-oscillator voices
  // above are used instead. Every voice function returns how many oscillators
  // it created (the scheduler counts them against its per-call budget).
  var MAX_OSCILLATORS_PER_NOTE = 5;
  var SHORT_NOTE_SECONDS = 0.05;
  var VIBRATO_MIN_SECONDS = 0.4;
  // ORGAN_PEAK: envelope peak over the summed saws. The old voice had three
  // unity saws at 0.03 (summed 3 x 0.03 = 0.09); with two saws 0.045 keeps the
  // same summed amplitude (2 x 0.045 = 0.09).
  var ORGAN_PEAK = 0.045;
  var ORGAN_ATTACK = 0.007;  // short so 32nd/16th notes have a defined front
  var ORGAN_RELEASE = 0.035;
  var ORGAN_FILTER_OPEN_HZ = 5000;  // pipe-speech brightness at note onset
  var ORGAN_FILTER_HZ = 2200;       // steady-state lowpass cutoff
  var ORGAN_FILTER_SWEEP = 0.05;    // seconds for the cutoff to settle
  var ORGAN_CHIFF_GAIN = 0.3;
  var ORGAN_CHIFF_DECAY = 0.04;

  // Click-free envelope that always finishes at startTime + duration: linear
  // attack from 0, hold, exponential release to near silence at the note end
  // (attack/release shrink proportionally for very short notes).
  function applyNoteEnvelope(gainParam, startTime, duration, peak, attack, release) {
    var total = attack + release;
    if (duration < total) {
      attack = duration * attack / total;
      release = duration * release / total;
    }
    var end = startTime + duration;
    gainParam.setValueAtTime(0, startTime);
    gainParam.linearRampToValueAtTime(peak, startTime + attack);
    gainParam.setValueAtTime(peak, end - release);
    gainParam.exponentialRampToValueAtTime(0.0001, end);
  }

  function startVoiceOscillator(osc, startTime, duration, activeOscillators) {
    osc.start(startTime);
    osc.stop(startTime + duration);
    if (activeOscillators) {
      activeOscillators.push(osc);
    }
  }

  // Disconnects a finished voice's gain/filter nodes from the graph once its
  // main oscillator has ended (all of a voice's oscillators stop at the same
  // instant). Without this every note's envelope gain stays an input of the
  // music bus for the whole session and the audio thread's per-block cost
  // grows with elapsed time (tools/audio-render.js: 13x after 160 s).
  function releaseVoiceOnEnd(osc, nodes) {
    osc.onended = function () {
      for (var i = 0; i < nodes.length; i++) {
        disconnectQuietly(nodes[i]);
      }
    };
  }

  function playInstrumentNote_organ(ctx, freq, startTime, duration, activeOscillators) {
    if (!ctx.createBiquadFilter) {
      return playInstrumentNote_organBasic(ctx, freq, startTime, duration, activeOscillators);
    }
    var envGain = ctx.createGain();
    applyNoteEnvelope(envGain.gain, startTime, duration, ORGAN_PEAK, ORGAN_ATTACK, ORGAN_RELEASE);
    envGain.connect(getMusicDestination(ctx));
    var filter = createFilter(ctx, 'lowpass', ORGAN_FILTER_OPEN_HZ, 0.7, startTime);
    // Bright onset settling to the steady-state cutoff.
    filter.frequency.exponentialRampToValueAtTime(ORGAN_FILTER_HZ, startTime + ORGAN_FILTER_SWEEP);
    filter.connect(envGain);

    var count = 0;
    var main = ctx.createOscillator();
    main.type = 'sawtooth';
    main.frequency.setValueAtTime(freq, startTime);
    main.connect(filter);
    startVoiceOscillator(main, startTime, duration, activeOscillators);
    count++;
    var voiceNodes = [filter, envGain];
    releaseVoiceOnEnd(main, voiceNodes);
    if (duration < SHORT_NOTE_SECONDS) {
      return count;
    }

    var saw = ctx.createOscillator();
    saw.type = 'sawtooth';
    saw.frequency.setValueAtTime(freq, startTime);
    saw.detune.setValueAtTime(7, startTime);
    saw.connect(filter);
    startVoiceOscillator(saw, startTime, duration, activeOscillators);
    count++;

    var sub = ctx.createOscillator();
    sub.type = 'sine';
    sub.frequency.setValueAtTime(freq / 2, startTime);
    var subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.35, startTime);
    sub.connect(subGain);
    subGain.connect(envGain);
    voiceNodes.push(subGain);
    startVoiceOscillator(sub, startTime, duration, activeOscillators);
    count++;

    // Chiff: brief 3rd-harmonic sine decaying within 40 ms (pipe onset).
    if (freq * 3 <= 8000) {
      var chiff = ctx.createOscillator();
      chiff.type = 'sine';
      chiff.frequency.setValueAtTime(freq * 3, startTime);
      var chiffGain = ctx.createGain();
      chiffGain.gain.setValueAtTime(ORGAN_CHIFF_GAIN, startTime);
      chiffGain.gain.exponentialRampToValueAtTime(0.0001, startTime + ORGAN_CHIFF_DECAY);
      chiff.connect(chiffGain);
      chiffGain.connect(envGain);
      voiceNodes.push(chiffGain);
      startVoiceOscillator(chiff, startTime, duration, activeOscillators);
      count++;
    }

    if (duration >= VIBRATO_MIN_SECONDS && count < MAX_OSCILLATORS_PER_NOTE) {
      var lfo = ctx.createOscillator();
      lfo.type = 'sine';
      lfo.frequency.setValueAtTime(5, startTime);
      var depth = ctx.createGain();
      depth.gain.setValueAtTime(4, startTime); // cents
      lfo.connect(depth);
      depth.connect(main.detune);
      voiceNodes.push(depth);
      startVoiceOscillator(lfo, startTime, duration, activeOscillators);
      count++;
    }
    return count;
  }

  function playInstrumentNote_lead(ctx, freq, startTime, duration, activeOscillators) {
    if (!ctx.createBiquadFilter) {
      return playInstrumentNote_leadBasic(ctx, freq, startTime, duration, activeOscillators);
    }
    var envGain = ctx.createGain();
    applyNoteEnvelope(envGain.gain, startTime, duration, 0.07, 0.01, 0.05);
    envGain.connect(getMusicDestination(ctx));
    var filter = createFilter(ctx, 'lowpass', 3200, 0.7, startTime);
    filter.connect(envGain);
    var osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freq, startTime);
    osc.connect(filter);
    startVoiceOscillator(osc, startTime, duration, activeOscillators);
    releaseVoiceOnEnd(osc, [filter, envGain]);
    return 1;
  }

  // Harpsichord: plucked, bright, fast-decaying (not sustained). Sawtooth
  // through a lowpass whose cutoff falls like a plucked string's brightness,
  // plus a 4' register (octave up, quieter) on notes long enough to hear it.
  // Own envelope (a decay, not applyNoteEnvelope's sustain): near-instant
  // attack, exponential decay with a pitch-dependent time constant, then a
  // short damper release that ends exactly at startTime + duration.
  var HARPSICHORD_PEAK = 0.05;
  var HARPSICHORD_ATTACK = 0.003;
  var HARPSICHORD_DAMPER = 0.03;
  var HARPSICHORD_CHOIR_GAIN = 0.35;

  // peak/tau are optional overrides (the FM piano reuses this shape).
  function applyPluckEnvelope(gainParam, startTime, duration, freq, peak, tau) {
    if (peak === undefined) { peak = HARPSICHORD_PEAK; }
    var end = startTime + duration;
    var attack = HARPSICHORD_ATTACK;
    var damper = HARPSICHORD_DAMPER;
    if (duration < attack + damper) {
      var total = attack + damper;
      attack = duration * attack / total;
      damper = duration * damper / total;
    }
    if (tau === undefined) {
      tau = Math.min(1.2, Math.max(0.18, 1.1 * Math.sqrt(220 / freq)));
    }
    var sustainEnd = end - damper;
    var level = peak * Math.exp(-(sustainEnd - startTime) / tau);
    gainParam.setValueAtTime(0, startTime);
    gainParam.linearRampToValueAtTime(peak, startTime + attack);
    if (sustainEnd > startTime + attack) {
      gainParam.exponentialRampToValueAtTime(Math.max(level, 0.0001), sustainEnd);
    }
    gainParam.exponentialRampToValueAtTime(0.0001, end);
  }

  function playInstrumentNote_harpsichord(ctx, freq, startTime, duration, activeOscillators) {
    var envGain = ctx.createGain();
    applyPluckEnvelope(envGain.gain, startTime, duration, freq);
    envGain.connect(getMusicDestination(ctx));

    var main = ctx.createOscillator();
    main.type = 'sawtooth';
    main.frequency.setValueAtTime(freq, startTime);

    if (!ctx.createBiquadFilter) {
      main.connect(envGain);
      startVoiceOscillator(main, startTime, duration, activeOscillators);
      releaseVoiceOnEnd(main, [envGain]);
      return 1;
    }

    var filter = createFilter(ctx, 'lowpass', Math.min(freq * 10, 6000), 0.7, startTime);
    filter.frequency.exponentialRampToValueAtTime(
      Math.max(freq * 2.5, 600), startTime + Math.min(duration, 0.35));
    filter.connect(envGain);
    main.connect(filter);
    startVoiceOscillator(main, startTime, duration, activeOscillators);
    var voiceNodes = [filter, envGain];
    releaseVoiceOnEnd(main, voiceNodes);
    var count = 1;

    if (duration >= SHORT_NOTE_SECONDS && freq * 2 <= 8000) {
      var choir = ctx.createOscillator();
      choir.type = 'sawtooth';
      choir.frequency.setValueAtTime(freq * 2, startTime);
      var choirGain = ctx.createGain();
      choirGain.gain.setValueAtTime(HARPSICHORD_CHOIR_GAIN, startTime);
      choir.connect(choirGain);
      choirGain.connect(filter);
      voiceNodes.push(choirGain);
      startVoiceOscillator(choir, startTime, duration, activeOscillators);
      count++;
    }
    return count;
  }

  // FM piano / electric piano: 2-operator FM (sine carrier, sine modulator at
  // freq * FM_MOD_RATIO) whose modulation index decays like a struck key's
  // brightness, plus (notes >= SHORT_NOTE_SECONDS, tine <= 9 kHz) a brief sine
  // "tine" at 14 x freq for the hammer attack. At most 3 oscillators per note.
  var FM_PEAK = 0.07;          // carrier peak gain (sine is quieter than saws)
  var FM_MOD_RATIO = 1;
  var FM_TINE_RATIO = 14;
  var FM_TINE_GAIN = 0.12;     // x FM_PEAK
  var FM_TINE_DECAY = 0.06;
  var FM_TINE_MAX_HZ = 9000;
  var FM_INDEX_DECAY = 0.4;

  function fmIndexStart(freq) {
    return Math.min(4.5, Math.max(1.2, 4.2 * Math.pow(220 / freq, 0.4)));
  }

  function playInstrumentNote_fmpiano(ctx, freq, startTime, duration, activeOscillators) {
    var tau = Math.min(2.0, Math.max(0.3, 1.6 * Math.sqrt(220 / freq)));
    var envGain = ctx.createGain();
    applyPluckEnvelope(envGain.gain, startTime, duration, freq, FM_PEAK, tau);
    envGain.connect(getMusicDestination(ctx));

    var carrier = ctx.createOscillator();
    carrier.type = 'sine';
    carrier.frequency.setValueAtTime(freq, startTime);
    carrier.connect(envGain);

    var modFreq = freq * FM_MOD_RATIO;
    var mod = ctx.createOscillator();
    mod.type = 'sine';
    mod.frequency.setValueAtTime(modFreq, startTime);
    var modGain = ctx.createGain();
    var i0 = fmIndexStart(freq);
    var i1 = 0.35 * i0;
    modGain.gain.setValueAtTime(i0 * modFreq, startTime);
    modGain.gain.exponentialRampToValueAtTime(i1 * modFreq, startTime + Math.min(duration, FM_INDEX_DECAY));
    mod.connect(modGain);
    modGain.connect(carrier.frequency);

    startVoiceOscillator(carrier, startTime, duration, activeOscillators);
    startVoiceOscillator(mod, startTime, duration, activeOscillators);
    var voiceNodes = [modGain, envGain];
    releaseVoiceOnEnd(carrier, voiceNodes);
    var count = 2;

    if (duration >= SHORT_NOTE_SECONDS && freq * FM_TINE_RATIO <= FM_TINE_MAX_HZ) {
      var tine = ctx.createOscillator();
      tine.type = 'sine';
      tine.frequency.setValueAtTime(freq * FM_TINE_RATIO, startTime);
      var tineGain = ctx.createGain();
      tineGain.gain.setValueAtTime(FM_TINE_GAIN * FM_PEAK, startTime);
      tineGain.gain.exponentialRampToValueAtTime(0.0001, startTime + Math.min(duration, FM_TINE_DECAY));
      tine.connect(tineGain);
      tineGain.connect(envGain);
      voiceNodes.push(tineGain);
      startVoiceOscillator(tine, startTime, duration, activeOscillators);
      count++;
    }
    return count;
  }

  // Dispatches to the correct synthesis function for a given instrument
  // name (per MUSIC_FORMAT.md's instrument keywords: 'organ', 'lead',
  // 'harpsichord', 'fmpiano').
  // Used by the new multi-track engine (playMultiTrackPhrase() below).
  // Unrecognized instrument names fall back to 'organ' rather than
  // throwing, so a malformed/unknown instrument name never silently drops
  // an entire track's audio.
  function playNoteWithInstrument(instrumentName, ctx, freq, startTime, duration, activeOscillators) {
    if (instrumentName === 'lead') {
      return playInstrumentNote_lead(ctx, freq, startTime, duration, activeOscillators);
    }
    if (instrumentName === 'harpsichord') {
      return playInstrumentNote_harpsichord(ctx, freq, startTime, duration, activeOscillators);
    }
    if (instrumentName === 'fmpiano') {
      return playInstrumentNote_fmpiano(ctx, freq, startTime, duration, activeOscillators);
    }
    return playInstrumentNote_organ(ctx, freq, startTime, duration, activeOscillators);
  }
  // ---------------------------------------------------------------------
  // Playlist: the background music plays the SONGS below in order and wraps
  // around (BWV 565 Fugue -> Toccata -> BWV 914 Fugue -> ...) with NO gap: each piece starts
  // at the previous piece's exact audio-clock end (any silence between pieces
  // is rests written into the scores). Each registry entry names the
  // window globals (built by music-bach.js / music-bach-538.js / music-bach-914.js) holding the
  // notation string and the measure map for that piece.
  var SONGS = [
    // The Fugue is six back-to-back sections (one tempo each), see music-bach.js.
    { title: 'BWV 565 Fugue', notationGlobal: 'MUSIC_BACH_NOTATION', measureMapGlobal: 'MUSIC_BACH_MEASURE_MAP' },
    { title: 'BWV 565 Fugue', notationGlobal: 'MUSIC_BACH_NOTATION_2', measureMapGlobal: 'MUSIC_BACH_MEASURE_MAP_2' },
    { title: 'BWV 565 Fugue', notationGlobal: 'MUSIC_BACH_NOTATION_3', measureMapGlobal: 'MUSIC_BACH_MEASURE_MAP_3' },
    { title: 'BWV 565 Fugue', notationGlobal: 'MUSIC_BACH_NOTATION_4', measureMapGlobal: 'MUSIC_BACH_MEASURE_MAP_4' },
    { title: 'BWV 565 Fugue', notationGlobal: 'MUSIC_BACH_NOTATION_5', measureMapGlobal: 'MUSIC_BACH_MEASURE_MAP_5' },
    { title: 'BWV 565 Fugue', notationGlobal: 'MUSIC_BACH_NOTATION_6', measureMapGlobal: 'MUSIC_BACH_MEASURE_MAP_6' },
    { title: 'BWV 538 Toccata', notationGlobal: 'MUSIC_BACH_538_NOTATION', measureMapGlobal: 'MUSIC_BACH_538_MEASURE_MAP' },
    // Keep BWV 914 after the Toccata and give its multi-section Fugue a unique id.
    { title: 'BWV 914 Fugue', id: 'bwv914', notationGlobal: 'MUSIC_BACH_914_NOTATION', measureMapGlobal: 'MUSIC_BACH_914_MEASURE_MAP' },
    { title: 'BWV 914 Fugue', id: 'bwv914', notationGlobal: 'MUSIC_BACH_914_NOTATION_2', measureMapGlobal: 'MUSIC_BACH_914_MEASURE_MAP_2' },
    { title: 'BWV 914 Fugue', id: 'bwv914', notationGlobal: 'MUSIC_BACH_914_NOTATION_3', measureMapGlobal: 'MUSIC_BACH_914_MEASURE_MAP_3' },
    { title: 'BWV 914 Fugue', id: 'bwv914', notationGlobal: 'MUSIC_BACH_914_NOTATION_4', measureMapGlobal: 'MUSIC_BACH_914_MEASURE_MAP_4' },
    { title: 'BWV 914 Fugue', id: 'bwv914', notationGlobal: 'MUSIC_BACH_914_NOTATION_5', measureMapGlobal: 'MUSIC_BACH_914_MEASURE_MAP_5' },
    { title: 'BWV 914 Fugue', id: 'bwv914', notationGlobal: 'MUSIC_BACH_914_NOTATION_6', measureMapGlobal: 'MUSIC_BACH_914_MEASURE_MAP_6' },
    { title: 'BWV 914 Fugue', id: 'bwv914', notationGlobal: 'MUSIC_BACH_914_NOTATION_7', measureMapGlobal: 'MUSIC_BACH_914_MEASURE_MAP_7' },
    { title: 'BWV 914 Fugue', id: 'bwv914', notationGlobal: 'MUSIC_BACH_914_NOTATION_8', measureMapGlobal: 'MUSIC_BACH_914_MEASURE_MAP_8' },
    { title: 'BWV 914 Fugue', id: 'bwv914', notationGlobal: 'MUSIC_BACH_914_NOTATION_9', measureMapGlobal: 'MUSIC_BACH_914_MEASURE_MAP_9' }
  ];

  // Index into SONGS of the piece that is playing (or will play on the next
  // startMusic()). Deliberately NOT reset by stopMusic()/startMusic(): a
  // restart (gameover -> playing) replays the current piece from its start.
  var currentSongIndex = 0;

  // Test-only injection point. Under Node there is no window/AudioContext,
  // so tests call __setTestEnv({ globals, parser, ctx, isPlaying }) to supply
  // the notation/measure-map globals, Game.MusicParser, a fake AudioContext
  // and the "game is in PLAYING state" check. Always null in the browser.
  var testEnv = null;

  function readGlobal(name) {
    if (isNode) {
      return testEnv && testEnv.globals ? testEnv.globals[name] : undefined;
    }
    return window[name];
  }

  function getParser() {
    if (isNode) {
      return testEnv ? testEnv.parser : null;
    }
    return Game.MusicParser;
  }

  // Pure helper: index of the song after `index` in a list of `count`, wrapping.
  function nextSongIndex(index, count) {
    return (index + 1) % count;
  }

  // Music choice (Game.Settings 'musicTrack'): 'playlist' (every SONGS entry in
  // order, repeating) or the id of one piece. A piece is a run of consecutive
  // SONGS entries sharing a title (the sections are one piece); an optional
  // explicit id wins, otherwise use the lower-cased last word of the title.
  // Computed from SONGS on every call so a new entry shows up on its own.
  function getPieces() {
    var pieces = [];
    for (var i = 0; i < SONGS.length; i++) {
      var last = pieces[pieces.length - 1];
      if (last && last.title === SONGS[i].title) {
        last.end = i;
      } else {
        var words = SONGS[i].title.split(' ');
        pieces.push({ id: SONGS[i].id || words[words.length - 1].toLowerCase(), label: SONGS[i].title, title: SONGS[i].title, start: i, end: i });
      }
    }
    return pieces;
  }

  // [{ id, label }]: 'playlist' first, then one entry per piece.
  function getMusicChoices() {
    var choices = [{ id: 'playlist', label: 'Playlist' }];
    var pieces = getPieces();
    for (var i = 0; i < pieces.length; i++) {
      choices.push({ id: pieces[i].id, label: pieces[i].label });
    }
    return choices;
  }

  function isValidMusicTrack(id) {
    var choices = getMusicChoices();
    for (var i = 0; i < choices.length; i++) {
      if (choices[i].id === id) {
        return true;
      }
    }
    return false;
  }

  var musicTrack = 'playlist';

  // Active choice id: the stored setting when it names a known choice, else the
  // last value given to setMusicTrack(), else 'playlist'.
  function getMusicTrack() {
    var settings = getSettings();
    var v = settings && settings.get ? settings.get('musicTrack') : undefined;
    if (typeof v === 'string' && isValidMusicTrack(v)) {
      return v;
    }
    return isValidMusicTrack(musicTrack) ? musicTrack : 'playlist';
  }

  // Inclusive SONGS index range [first, last] that the playlist repeats within.
  function getScopeRange() {
    var id = getMusicTrack();
    var pieces = getPieces();
    for (var i = 0; i < pieces.length; i++) {
      if (pieces[i].id === id) {
        return { first: pieces[i].start, last: pieces[i].end };
      }
    }
    return { first: 0, last: SONGS.length - 1 };
  }

  // The song after `index` within the active scope, wrapping last -> first.
  function nextScopedSongIndex(index) {
    var range = getScopeRange();
    return index >= range.last || index < range.first ? range.first : index + 1;
  }

  // The song before `index` within the active scope, wrapping first -> last.
  function prevScopedSongIndex(index) {
    var range = getScopeRange();
    return index <= range.first || index > range.last ? range.last : index - 1;
  }

  // Pure helper: label of the last measure-map entry whose startTime <= elapsed
  // (the map is chronological), or null if none. Strips the leading '# ' that
  // the generators emit. Tolerates a missing/empty map.
  function lookupMeasureLabel(map, elapsed) {
    if (!map || !map.length) {
      return null;
    }
    var label = null;
    for (var i = 0; i < map.length; i++) {
      if (map[i].startTime <= elapsed) {
        label = map[i].label;
      } else {
        break;
      }
    }
    if (typeof label !== 'string') {
      return null;
    }
    var trimmed = label.trim();
    if (trimmed.indexOf('# ') === 0) {
      trimmed = trimmed.slice(2).trim();
    }
    return trimmed;
  }

  // Pure helper: 'BWV 538 Toccata - Measure 12'.
  function formatSongLabel(title, measureLabel) {
    return title + ' - ' + measureLabel;
  }

  // Per-index lazy parse cache. songCache[i] is the parsed song, or false if
  // parsing was attempted and failed (so we log once and never retry).
  var songCache = [];

  // Lazily parses SONGS[index]'s notation (via Game.MusicParser.parse()),
  // caching the result so parsing happens once even across repeated
  // startMusic()/stopMusic() cycles. Returns the parsed song, or null if the
  // parser or the notation global is unavailable, parsing throws, or the song
  // has no playable duration (empty tracks) - callers treat null as "skip this
  // song" and must not propagate an exception into game logic.
  function getParsedSong(index) {
    if (songCache[index]) {
      return songCache[index];
    }
    if (songCache[index] === false) {
      return null;
    }
    songCache[index] = false;
    var title = SONGS[index].title;
    try {
      var parser = getParser();
      if (!parser || !parser.parse) {
        console.warn('Game.Audio: Game.MusicParser is unavailable; skipping "' + title + '".');
        return null;
      }
      var notation = readGlobal(SONGS[index].notationGlobal);
      if (!notation) {
        console.warn('Game.Audio: ' + SONGS[index].notationGlobal + ' is unavailable; skipping "' + title + '".');
        return null;
      }
      var parsed = parser.parse(notation);
      var duration = parsed && parsed.tracks ? getTotalSongDuration(parsed) : 0;
      if (!isFinite(duration) || duration <= 0) {
        console.warn('Game.Audio: "' + title + '" has no playable notes; skipping.');
        return null;
      }
      songCache[index] = parsed;
      return parsed;
    } catch (e) {
      console.warn('Game.Audio: failed to parse "' + title + '"; skipping.', e);
      return null;
    }
  }

  // Starting at `startIndex` and wrapping around, finds the first song that
  // parses, makes it the current song and returns its parsed object. Returns
  // null (leaving currentSongIndex untouched) if every song fails, which
  // callers treat as "music unavailable".
  function selectPlayableSong(startIndex) {
    var range = getScopeRange();
    var count = range.last - range.first + 1;
    if (startIndex < range.first || startIndex > range.last) {
      startIndex = range.first;
    }
    for (var attempt = 0; attempt < count; attempt++) {
      var index = range.first + (startIndex - range.first + attempt) % count;
      var parsed = getParsedSong(index);
      if (parsed) {
        currentSongIndex = index;
        return parsed;
      }
    }
    return null;
  }

  // Parsed object for the current song, or null if it is unavailable.
  function getCurrentSong() {
    return getParsedSong(currentSongIndex);
  }

  // Starts the playlist music from the beginning of the current piece, via the
  // polyphonic multi-track engine below. Public name/signature unchanged so
  // main.js is unaffected. No-ops if every song is unavailable or if music is
  // already playing (startMultiTrackMusic()'s own guard).
  function startMusic() {
    previewActive = false; // a game start adopts any menu preview
    playingScope = getMusicTrack();
    var song = selectPlayableSong(currentSongIndex);
    if (!song) {
      return;
    }
    startMultiTrackMusic(song);
  }

  function isMusicPlaying() {
    return isMultiTrackPlaying;
  }

  // True while music started by toggleMusicPreview() is playing.
  var previewActive = false;
  // Scope in effect for the music now playing; refreshed by startMusic().
  var playingScope = null;

  // Changes the repeat scope (see getMusicChoices()). Unknown ids are ignored
  // (returns false). If music is playing it restarts from the beginning of the
  // chosen piece (not gapless). Switching TO 'playlist' does not restart: the
  // current section keeps playing and the playlist continues from it (the
  // scope for the next advance is read from the setting/musicTrack). The
  // change is detected against playingScope (the scope in effect when music
  // started or was last switched), not the possibly stale musicTrack, so it is
  // right regardless of load order. Also writes the stored setting, so the options row stays in step.
  function setMusicTrack(id) {
    if (!isValidMusicTrack(id)) {
      return false;
    }
    var wasPlaying = isMultiTrackPlaying;
    var changed = id !== playingScope;
    playingScope = id;
    musicTrack = id;
    var settings = getSettings();
    if (settings && settings.set && settings.get && settings.get('musicTrack') !== id) {
      settings.set('musicTrack', id); // onChange re-enters here with changed === false
    }
    if (wasPlaying && changed && id !== 'playlist') {
      var keepPreview = previewActive;
      stopMultiTrackMusic();
      var range = getScopeRange();
      currentSongIndex = range.first;
      startMusic();
      previewActive = keepPreview;
    }
    return true;
  }

  // Options-menu "Play music": starts the chosen piece from its start, or stops
  // the music if it is playing. Runs inside the user's key/click handler, so
  // ensureAudioContext() creates/resumes the AudioContext under the browser's
  // autoplay policy. Returns whether music is playing afterwards.
  function toggleMusicPreview() {
    if (isMultiTrackPlaying) {
      stopMusic();
      return false;
    }
    ensureAudioContext();
    if (getMusicTrack() !== 'playlist') {
      currentSongIndex = getScopeRange().first;
    }
    startMusic();
    previewActive = isMultiTrackPlaying;
    return isMultiTrackPlaying;
  }

  // Jumps to the start of the next section (SONGS entry) after the one now
  // audible, honouring the repeat scope (nextScopedSongIndex). The audible
  // section is currentPhraseSongIndex after resolving any pending phrase, as
  // in getCurrentMeasureLabel(); currentSongIndex may already be the next song
  // during the advance lead. stopMultiTrackMusic() bumps the generation and
  // clears the advance timer and pendingPhrase, so the old chain cannot also
  // advance. Returns false (and does nothing) when music is not playing.
  function skipToSection(targetIndexFn) {
    if (!isMultiTrackPlaying) {
      return false;
    }
    var ctx = ensureAudioContext();
    if (ctx) {
      resolvePhrase(ctx.currentTime);
    }
    var targetIndex = targetIndexFn(currentPhraseSongIndex);
    var keepPreview = previewActive;
    stopMultiTrackMusic();
    currentSongIndex = targetIndex;
    startMusic();
    previewActive = keepPreview;
    return true;
  }

  function skipToNextSection() {
    return skipToSection(nextScopedSongIndex);
  }

  // Mirror of skipToNextSection(): jumps to the start of the previous section
  // within the scope (prevScopedSongIndex, wrapping first -> last).
  function skipToPreviousSection() {
    return skipToSection(prevScopedSongIndex);
  }

  // Called when the options menu is left: stops a menu-started preview unless a
  // game is running.
  function stopMusicPreview() {
    if (previewActive && !isGamePlaying()) {
      stopMusic();
    }
  }

  // Stops the music via stopMultiTrackMusic(). currentSongIndex is kept, so
  // the next startMusic() replays the current piece from its start.
  function stopMusic() {
    previewActive = false;
    stopMultiTrackMusic();
  }

  // ---------------------------------------------------------------------
  // Polyphonic (multi-track) playback engine. Operates on the exact
  // structured output shape of Game.MusicParser.parse():
  //   { tempo: <number>, tracks: [ { name, instrument, notes: [ { freq,
  //   duration, isRest } ] }, ... ] }
  // Now wired in above via startMusic()/stopMusic().

  var isMultiTrackPlaying = false;
  var multiTrackLoopTimeoutId = null;
  // Bumped whenever a pass is scheduled or music is stopped; an end-of-pass
  // timer only acts if its captured generation is still current.
  var playbackGeneration = 0;

  // Module-scoped so getCurrentMeasureLabel() (below) can compute "how far
  // into the current phrase pass are we" from outside playMultiTrackPhrase()
  // itself. Set at the top of every playMultiTrackPhrase() pass to that
  // pass's ctx.currentTime; null whenever no pass has ever been scheduled.
  var currentPhraseBaseTime = null;
  // Length in seconds of the current pass's music. getCurrentMeasureLabel()
  // returns null once elapsed passes this (only possible if the next pass
  // could not be chained).
  var currentPhraseDuration = 0;
  // Index into SONGS of the pass the three values above describe. Differs
  // from currentSongIndex during the lead window, when the next song has
  // already been selected/scheduled but has not started sounding yet.
  var currentPhraseSongIndex = 0;
  // The next pass, scheduled ahead of its start (see ADVANCE_LEAD_MS):
  // { baseTime, duration, songIndex } or null. It becomes the "current"
  // phrase (the three variables above) exactly when the audio clock reaches
  // baseTime - see resolvePhrase().
  var pendingPhrase = null;

  // Mute state for background music ONLY - sound effects (playFireSound()/
  // playCrashSound()) never check this flag and are completely unaffected.
  // Defaults to false (unmuted) so first-ever load behaves exactly as
  // before this feature was added.
  var isMusicMuted = false;

  // Tracks every oscillator node scheduled during the CURRENT in-flight
  // playMultiTrackPhrase() pass, so stopMultiTrackMusic() can force-stop
  // them immediately rather than letting them ring out to their originally
  // scheduled stop() time. Without this, a stop-then-immediately-restart
  // (e.g. gameover -> playing) leaves the previous phrase's still-sounding
  // notes overlapping with the freshly started phrase's notes. Cleared at
  // the start of each new phrase pass (a completed prior pass's oscillators
  // have already naturally stopped and don't need force-stopping or to be
  // kept around) and after stopMultiTrackMusic() force-stops them.
  // With gapless chaining the previous pass's last notes are still sounding
  // while the next pass is scheduled, so a new pass moves the old list to
  // tailOscillators instead of dropping it; stop/mute silence both lists.
  var activeOscillators = [];
  var tailOscillators = [];

  // Promotes pendingPhrase to the current phrase once the audio clock has
  // reached its start. Called by everything that reads the current phrase.
  function resolvePhrase(now) {
    if (pendingPhrase && now >= pendingPhrase.baseTime) {
      currentPhraseBaseTime = pendingPhrase.baseTime;
      currentPhraseDuration = pendingPhrase.duration;
      currentPhraseSongIndex = pendingPhrase.songIndex;
      pendingPhrase = null;
    }
  }

  // Force-stops every oscillator of the in-flight pass and of the previous
  // pass's still-sounding tail. Never throws.
  function stopAllOscillators() {
    var lists = [tailOscillators, activeOscillators];
    for (var l = 0; l < lists.length; l++) {
      for (var i = 0; i < lists[l].length; i++) {
        try {
          lists[l][i].stop();
        } catch (e) {
          // Already stopped/finished naturally; nothing to do.
        }
      }
    }
    tailOscillators = [];
    activeOscillators = [];
  }

  // Sums a single track's note durations. Mirrors getTotalMelodyDuration()'s
  // approach above (an explicit independent sum, not derived from a
  // scheduling loop's cursor side-effect).
  function getTrackDuration(track) {
    var total = 0;
    for (var i = 0; i < track.notes.length; i++) {
      total += track.notes[i].duration;
    }
    return total;
  }

  // The piece's total loop length is the MAX across all tracks' individual
  // summed durations (not the sum of them) - a shorter harmony/bass track
  // and a longer melody track must both loop back together in sync at the
  // point where the LONGEST track finishes.
  function getTotalSongDuration(parsedSong) {
    var durations = parsedSong.tracks.map(getTrackDuration);
    if (durations.length === 0) {
      return 0;
    }
    return Math.max.apply(null, durations);
  }

  // Rolling (look-ahead) scheduling: instead of creating every note's
  // oscillator+gain up front (~2900 for the Toccata, a 60-130 ms main-thread
  // hitch), each pass schedules only the notes starting within
  // LOOKAHEAD_SECONDS of the audio clock, and a timer re-runs the scheduler
  // every LOOKAHEAD_TICK_MS. No single call creates more than
  // MAX_OSCILLATORS_PER_CALL oscillators; if that cap is hit before the
  // look-ahead window is full, the next call follows after CATCHUP_TICK_MS.
  var LOOKAHEAD_SECONDS = 3;
  var LOOKAHEAD_TICK_MS = 1000;
  var CATCHUP_TICK_MS = 10;
  var MAX_OSCILLATORS_PER_CALL = 300;
  // The end-of-pass timer fires this long BEFORE the pass's audio-clock end so
  // the next song is parsed and its first notes scheduled ahead of the
  // boundary (well inside LOOKAHEAD_SECONDS); the next pass is then started at
  // the exact end time, not when the timer fires.
  var ADVANCE_LEAD_MS = 500;

  // Starts one pass through every track of parsedSong, all tracks starting
  // at the SAME shared audioContext.currentTime reference. Each track keeps
  // its own time cursor (and note index) in the pass state and walks its own
  // notes sequentially, so within a track notes play back-to-back, but
  // ACROSS tracks notes overlap (true polyphony). The notes themselves are
  // scheduled incrementally by schedulePassChunk().
  // testCtx is an optional override used only by standalone Node tests
  // (see module.exports below) to inject a fake AudioContext-like object,
  // since ensureAudioContext() always returns null under Node (no real Web
  // Audio API available there). In the browser this parameter is never
  // passed by any call site, so behavior there is unaffected.
  //
  // startTime (optional) is the audio-clock time the pass starts at; used to
  // chain a pass onto the exact end of the previous one. Defaults to
  // ctx.currentTime, and is clamped up to it so nothing is scheduled in the
  // past (e.g. when a throttled timer fired after the boundary).
  function playMultiTrackPhrase(parsedSong, testCtx, startTime) {
    if (!isMultiTrackPlaying) {
      return;
    }
    var ctx = testCtx || ensureAudioContext();
    if (!ctx) {
      return;
    }

    var totalDuration = getTotalSongDuration(parsedSong);
    // Never schedule a zero/invalid-duration pass for malformed input.
    if (!isFinite(totalDuration) || totalDuration <= 0) {
      isMultiTrackPlaying = false;
      return;
    }

    var now = ctx.currentTime;
    var baseTime = (typeof startTime === 'number' && isFinite(startTime)) ? Math.max(startTime, now) : now;

    // The new phrase takes over the measure-label state exactly at baseTime:
    // immediately if it starts now, otherwise as a pending phrase that
    // resolvePhrase() promotes when the audio clock reaches it. (An older
    // pending phrase, if any, is promoted first so it is never lost.)
    if (pendingPhrase) {
      currentPhraseBaseTime = pendingPhrase.baseTime;
      currentPhraseDuration = pendingPhrase.duration;
      currentPhraseSongIndex = pendingPhrase.songIndex;
      pendingPhrase = null;
    }
    if (baseTime > now) {
      pendingPhrase = { baseTime: baseTime, duration: totalDuration, songIndex: currentSongIndex };
    } else {
      currentPhraseBaseTime = baseTime;
      currentPhraseDuration = totalDuration;
      currentPhraseSongIndex = currentSongIndex;
    }

    // The previous pass's oscillators may still be sounding its last notes
    // while this pass is scheduled: keep them as the tail (so stop/mute still
    // silence them) and start this pass's own list fresh. The tail before
    // that belongs to a pass that has long finished and is dropped.
    tailOscillators = activeOscillators;
    activeOscillators = [];

    var pass = {
      // Only one timer is ever pending (multiTrackLoopTimeoutId);
      // stopMultiTrackMusic() and toggleMute()'s resume path clear it, and
      // the generation token makes a timer that somehow still fires after a
      // stop/restart a no-op, so a stale timer can never schedule more notes
      // or start a second song concurrently.
      generation: ++playbackGeneration,
      song: parsedSong,
      ctx: ctx,
      testCtx: testCtx,
      // Audio-clock end of this pass; the next pass starts exactly here.
      endTime: baseTime + totalDuration,
      cursors: [],
      indices: []
    };
    for (var t = 0; t < parsedSong.tracks.length; t++) {
      pass.cursors.push(baseTime);
      pass.indices.push(0);
    }
    schedulePassChunk(pass);
  }

  // One look-ahead step of a pass: schedules the not-yet-scheduled notes that
  // start before ctx.currentTime + LOOKAHEAD_SECONDS (at most
  // MAX_OSCILLATORS_PER_CALL oscillators), then arms the single pending timer:
  // either the next look-ahead step, or - once every note is scheduled - the
  // end-of-pass timer that advances the playlist.
  //
  // While muted, notes are consumed (cursors advance) without creating any
  // oscillators, so the loop stays logically "running" silently. This is what
  // lets toggleMute()'s unmute branch resume audibly without a full
  // stop->start round-trip.
  function schedulePassChunk(pass) {
    var ctx = pass.ctx;
    var horizon = ctx.currentTime + LOOKAHEAD_SECONDS;
    var budget = MAX_OSCILLATORS_PER_CALL;
    var capHit = false;
    var remaining = false;

    for (var t = 0; t < pass.song.tracks.length; t++) {
      var track = pass.song.tracks[t];
      var cursor = pass.cursors[t];
      var n = pass.indices[t];
      while (n < track.notes.length) {
        var note = track.notes[n];
        var audible = !isMusicMuted && !note.isRest;
        if (!isMusicMuted) {
          if (cursor >= horizon) {
            break;
          }
          if (audible && budget <= 0) {
            capHit = true;
            break;
          }
        }
        // A note that has already ended on the audio clock (the scheduler ran
        // late: stalled/throttled main thread) is inaudible, so it gets no
        // nodes and costs no budget. Without this, a late call spent its
        // whole budget building dead notes (start/stop in the past), delaying
        // the live ones and lengthening the stall (tools/audio-load.js
        // --late=N shows ~90% of the oscillators of a 4 s stall are dead).
        if (audible && cursor + note.duration > ctx.currentTime) {
          budget -= playNoteWithInstrument(track.instrument, ctx, note.freq, cursor, note.duration, activeOscillators) || 1;
        }
        cursor += note.duration;
        n++;
      }
      pass.cursors[t] = cursor;
      pass.indices[t] = n;
      if (n < track.notes.length) {
        remaining = true;
      }
    }

    var delayMs;
    if (remaining) {
      delayMs = capHit ? CATCHUP_TICK_MS : LOOKAHEAD_TICK_MS;
    } else {
      // Fire ADVANCE_LEAD_MS before the audio-clock end (see advancePlaylist).
      delayMs = Math.max(0, (pass.endTime - ctx.currentTime) * 1000 - ADVANCE_LEAD_MS);
    }
    multiTrackLoopTimeoutId = setTimeout(function () {
      if (pass.generation !== playbackGeneration || !isMultiTrackPlaying) {
        return;
      }
      multiTrackLoopTimeoutId = null;
      if (remaining) {
        schedulePassChunk(pass);
      } else {
        // End-of-pass: advance the playlist (Fugue -> Toccata -> Fugue).
        advancePlaylist(pass.testCtx, pass.endTime);
      }
    }, delayMs);
  }

  // Moves to the next playable song after the current one (skipping songs
  // that failed to load; with only one playable song this replays it) and
  // starts it at startTime (the previous pass's exact audio-clock end; called
  // ADVANCE_LEAD_MS early, so it is normally still in the future).
  // playMultiTrackPhrase() clamps it to ctx.currentTime if the timer ran late.
  // If nothing is playable the music simply stops.
  function advancePlaylist(testCtx, startTime) {
    var song = selectPlayableSong(nextScopedSongIndex(currentSongIndex));
    if (!song) {
      isMultiTrackPlaying = false;
      return;
    }
    playMultiTrackPhrase(song, testCtx, startTime);
  }

  // Starts the looping multi-track background music for the given parsed
  // song. No-ops if already playing, matching startMusic()'s guard above so
  // repeated calls never stack multiple concurrent loops.
  function startMultiTrackMusic(parsedSong) {
    if (isMultiTrackPlaying) {
      return;
    }
    isMultiTrackPlaying = true;
    playMultiTrackPhrase(parsedSong);
    syncIntensityLayer();
  }

  // Stops the looping multi-track background music: flips the flag (so
  // playMultiTrackPhrase()'s next scheduled iteration no-ops instead of
  // scheduling more notes), clears the pending setTimeout, and force-stops
  // every oscillator scheduled during the current in-flight phrase pass and
  // the tail of the previous one (tailOscillators)
  // (see activeOscillators above) so nothing from the stopped phrase keeps
  // sounding into a subsequent startMultiTrackMusic() call. oscillator.stop()
  // with no argument stops it immediately (at the current time); wrapped in
  // try/catch because calling stop() on an oscillator that has ALREADY
  // naturally finished throws InvalidStateError in strict Web Audio
  // implementations, and stopMultiTrackMusic() must never throw (it's safe
  // to call repeatedly, or when nothing is playing).
  function stopMultiTrackMusic() {
    isMultiTrackPlaying = false;
    stopIntensityLayer();
    playbackGeneration++;
    if (multiTrackLoopTimeoutId !== null) {
      clearTimeout(multiTrackLoopTimeoutId);
      multiTrackLoopTimeoutId = null;
    }
    pendingPhrase = null;
    stopAllOscillators();
  }

  // Force-stops whatever is currently sounding from the in-flight phrase
  // pass WITHOUT flipping isMultiTrackPlaying and WITHOUT clearing the
  // pending multiTrackLoopTimeoutId - unlike stopMultiTrackMusic(), which
  // does both of those because it means "the game itself no longer wants
  // music playing". This helper is only used by toggleMute()'s mute branch,
  // where the game still logically wants music playing, it just needs to be
  // silent right now; the already-scheduled next pass will re-check
  // isMusicMuted and simply stay silent too (see playMultiTrackPhrase()).
  function forceSilenceCurrentPass() {
    stopAllOscillators();
  }

  function isGamePlaying() {
    if (isNode) {
      return !!(testEnv && testEnv.isPlaying && testEnv.isPlaying());
    }
    // Not while paused: unmuting (M) mid-pause must not start music.
    if (Game.isPaused && Game.isPaused()) {
      return false;
    }
    return !!(Game.getState && Game.STATES && Game.getState() === Game.STATES.PLAYING);
  }

  // Flips the music-mute flag and returns the new state. Sound effects
  // (playFireSound()/playCrashSound()) never consult isMusicMuted and are
  // completely unaffected by this toggle.
  //
  // Mute branch: if a phrase is currently sounding, force-silence it right
  // now via forceSilenceCurrentPass() (same underlying mechanism as
  // stopMultiTrackMusic()'s force-stop). Deliberately does NOT touch
  // isMultiTrackPlaying or multiTrackLoopTimeoutId, so the game's own
  // "music should be playing" state machine is untouched - the loop keeps
  // ticking in the background, just silently (each subsequent
  // playMultiTrackPhrase() pass checks isMusicMuted and skips scheduling
  // audible oscillators while it's true).
  //
  // Unmute branch: only takes action if the game is currently in the
  // PLAYING state or a menu preview is active (title/gameover have no music sounding to resume).
  //   - If isMultiTrackPlaying is already true (the loop was silently
  //     ticking the whole time we were muted), jump straight into an
  //     audible pass immediately: clear the pending silent tick and call
  //     playMultiTrackPhrase() directly, rather than waiting for the next
  //     already-scheduled tick (which could be up to a full song length
  //     away). This does not double-schedule: clearing
  //     multiTrackLoopTimeoutId first, then playMultiTrackPhrase()
  //     re-populates it with exactly one new pending tick.
  //   - If isMultiTrackPlaying is false (mute was toggled before music was
  //     ever logically started, e.g. on the title screen), just start music
  //     normally via startMusic().
  function toggleMute() {
    isMusicMuted = !isMusicMuted;
    applyBusVolumes(); // mute wins over the music volume slider
    if (isMusicMuted) {
      forceSilenceCurrentPass();
    } else if (isGamePlaying() || previewActive) {
      if (isMultiTrackPlaying) {
        if (multiTrackLoopTimeoutId !== null) {
          clearTimeout(multiTrackLoopTimeoutId);
          multiTrackLoopTimeoutId = null;
        }
        // Resume the CURRENT piece (not a hard-coded one) from its start.
        var song = getCurrentSong();
        if (song) {
          playMultiTrackPhrase(song);
        } else {
          isMultiTrackPlaying = false;
        }
      } else {
        startMusic();
      }
    }
    return isMusicMuted;
  }

  function isMuted() {
    return isMusicMuted;
  }

  // Returns the label of whichever measure is currently sounding, prefixed
  // with the current piece's title (e.g. 'BWV 538 Toccata - Measure 12'), for
  // on-screen display, or null if music isn't playing / no timing info is
  // available. Computed from the current pass's base time plus elapsed time,
  // looked up against the CURRENT song's measure map (a window global named
  // by SONGS[currentPhraseSongIndex].measureMapGlobal; chronological, each entry's
  // startTime in seconds from the piece's start). Tolerant of maps whose
  // length disagrees with the audio (e.g. the Fugue's unequal track lengths,
  // spelunker-kqg): elapsed past the last entry simply shows the last measure.
  // The label switches to the next song exactly at the audio-clock boundary
  // (resolvePhrase()), not when the early advance timer schedules it; during
  // that lead window it still belongs to the old song.
  function getCurrentMeasureLabel() {
    if (!isMultiTrackPlaying || currentPhraseBaseTime === null) {
      return null;
    }
    var ctx = ensureAudioContext();
    if (!ctx) {
      return null;
    }
    resolvePhrase(ctx.currentTime);
    var song = SONGS[currentPhraseSongIndex];
    var elapsed = ctx.currentTime - currentPhraseBaseTime;
    if (elapsed >= currentPhraseDuration) {
      return null; // past the end of the current phrase (nothing chained): no measure label
    }
    var label = lookupMeasureLabel(readGlobal(song.measureMapGlobal), elapsed);
    if (label === null) {
      return null;
    }
    return formatSongLabel(song.title, label);
  }

  // 0..1 progress through the current pass's music, or null when nothing is
  // playing (same null conditions as the label).
  function getMeasureProgress() {
    if (!isMultiTrackPlaying || currentPhraseBaseTime === null || !(currentPhraseDuration > 0)) {
      return null;
    }
    var ctx = ensureAudioContext();
    if (!ctx) {
      return null;
    }
    resolvePhrase(ctx.currentTime);
    var elapsed = ctx.currentTime - currentPhraseBaseTime;
    if (elapsed >= currentPhraseDuration) {
      return null;
    }
    return Math.max(0, elapsed / currentPhraseDuration);
  }

  // ---------------------------------------------------------------------
  // Music ducking: loud events (explosion, crash) pull the music bus down to
  // DUCK_FACTOR x its base level for a moment. The target is always computed
  // from the BASE level (volume setting, or 0 while muted), never from the
  // current value, and all pending automation is cancelled first, so repeated
  // events restart the same envelope instead of stacking. Ducking only moves
  // the bus gain; it never stops the music.
  var DUCK_FACTOR = 0.6;
  var DUCK_ATTACK = 0.05;
  var DUCK_HOLD = 0.3;
  var DUCK_RELEASE = 0.3;

  function duckMusic(ctx) {
    var param = getAudioBuses(ctx).music.gain;
    var now = ctx.currentTime || 0;
    var base = isMusicMuted ? 0 : readVolume('musicVolume');
    var ducked = base * DUCK_FACTOR;
    var current = typeof param.value === 'number' ? param.value : base;
    if (param.cancelScheduledValues) {
      param.cancelScheduledValues(now);
    }
    param.setValueAtTime(current, now);
    param.linearRampToValueAtTime(ducked, now + DUCK_ATTACK);
    param.setValueAtTime(ducked, now + DUCK_ATTACK + DUCK_HOLD);
    param.linearRampToValueAtTime(base, now + DUCK_ATTACK + DUCK_HOLD + DUCK_RELEASE);
  }

  // ---------------------------------------------------------------------
  // Hard-zone intensity layer: an optional hi-hat (40 ms of noise through a
  // 7 kHz bandpass) on every eighth note of the current song, on its own gain
  // node into the music bus. It fades in over 2 s while Cave.getZoneType() is
  // 'hard' and out over 2 s otherwise. It exists only while the Settings key
  // intensityLayer is true AND music is playing; no nodes are created
  // otherwise. A single polling timer (INTENSITY_TICK_MS) watches the zone and
  // schedules hats INTENSITY_LOOKAHEAD seconds ahead, aligned to the current
  // pass's start time.
  var INTENSITY_FADE = 2;
  var INTENSITY_TICK_MS = 100;
  var INTENSITY_LOOKAHEAD = 0.5;
  var INTENSITY_LEVEL = 0.3;
  var HIHAT_SECONDS = 0.04;
  var intensity = null; // { ctx, gain, timerId, target, silentAfter, base, nextHat }

  function intensityEnabled() {
    var settings = getSettings();
    return !!(settings && settings.get && settings.get('intensityLayer') === true);
  }

  function getZoneType() {
    if (isNode) {
      return testEnv && testEnv.zoneType ? testEnv.zoneType() : null;
    }
    return Game.Cave && Game.Cave.getZoneType ? Game.Cave.getZoneType() : null;
  }

  function playHiHat(ctx, when, out) {
    var noise = createNoiseSource(ctx, false);
    if (!noise) {
      return;
    }
    var filter = createFilter(ctx, 'bandpass', 7000, 1, when);
    var env = ctx.createGain();
    env.gain.setValueAtTime(0.5, when);
    env.gain.exponentialRampToValueAtTime(0.001, when + HIHAT_SECONDS);
    noise.connect(filter);
    filter.connect(env);
    env.connect(out);
    noise.start(when);
    noise.stop(when + HIHAT_SECONDS);
    releaseVoiceOnEnd(noise, [filter, env]);
  }

  function intensityTick() {
    var layer = intensity;
    if (!layer) {
      return;
    }
    layer.timerId = null;
    var ctx = layer.ctx;
    var now = ctx.currentTime || 0;
    var target = getZoneType() === 'hard' ? 1 : 0;
    if (target !== layer.target) {
      var param = layer.gain.gain;
      var current = typeof param.value === 'number' ? param.value : 0;
      if (param.cancelScheduledValues) {
        param.cancelScheduledValues(now);
      }
      param.setValueAtTime(current, now);
      param.linearRampToValueAtTime(target * INTENSITY_LEVEL, now + INTENSITY_FADE);
      layer.target = target;
      if (target === 0) {
        layer.silentAfter = now + INTENSITY_FADE;
      }
    }

    resolvePhrase(now);
    var song = getParsedSong(currentPhraseSongIndex);
    var tempo = song && song.tempo > 0 ? song.tempo : 120;
    var eighth = 30 / tempo;
    var base = currentPhraseBaseTime;
    if (base !== null && base !== layer.base) {
      layer.base = base;
      layer.nextHat = Math.max(0, Math.ceil((now - base) / eighth));
    }
    if (base !== null && !isMusicMuted && (layer.target === 1 || now < layer.silentAfter + INTENSITY_LOOKAHEAD)) {
      var horizon = now + INTENSITY_LOOKAHEAD;
      for (;;) {
        var when = base + layer.nextHat * eighth;
        if (when >= horizon || when - base >= currentPhraseDuration) {
          break;
        }
        if (when >= now - 0.05) {
          playHiHat(ctx, Math.max(when, now), layer.gain);
        }
        layer.nextHat++;
      }
    }
    layer.timerId = setTimeout(intensityTick, INTENSITY_TICK_MS);
  }

  function startIntensityLayer() {
    if (intensity) {
      return;
    }
    var ctx = ensureAudioContext();
    if (!ctx || !ctx.createBiquadFilter || !ctx.createBufferSource) {
      return;
    }
    var gain = ctx.createGain();
    gain.gain.setValueAtTime(0, ctx.currentTime || 0);
    gain.connect(getMusicDestination(ctx));
    intensity = { ctx: ctx, gain: gain, timerId: null, target: 0, silentAfter: -Infinity, base: null, nextHat: 0 };
    intensityTick();
  }

  function stopIntensityLayer() {
    if (!intensity) {
      return;
    }
    var layer = intensity;
    intensity = null;
    if (layer.timerId !== null) {
      clearTimeout(layer.timerId);
    }
    disconnectQuietly(layer.gain);
  }

  // Starts or stops the layer to match (music playing && setting on).
  function syncIntensityLayer() {
    if (isMultiTrackPlaying && intensityEnabled()) {
      startIntensityLayer();
    } else {
      stopIntensityLayer();
    }
  }

  // Global M-key mute/unmute toggle for background music, working in ANY
  // game state (title/playing/gameover) - deliberately NOT gated on
  // Game.getState() the way handleStart()'s "any key starts the game"
  // listener in main.js is, since muting should always be available.
  // Registered here (rather than in main.js) since it's purely an audio
  // concern and this file already owns all Game.Audio state; there is no
  // central "global keys" dispatcher elsewhere to hook into instead (main.js,
  // ship.js and projectile.js each register their own independent
  // 'keydown' listeners on window). No preventDefault() needed: 'm'/'M' has
  // no browser default behavior worth blocking. Confirmed no existing
  // keydown handler anywhere in the codebase checks for 'm'/'M' (main.js's
  // handleStart reacts to ANY key, but does not special-case 'm'; ship.js
  // checks ArrowUp/ArrowDown/ArrowLeft/ArrowRight/w/W/s/S; projectile.js
  // checks Space/' '/'Spacebar').
  if (!isNode) {
    window.addEventListener('keydown', function (event) {
      var C = Game.Controls;
      if (C && C.isCapturing && C.isCapturing()) { return; }
      var isMute = (C && C.matches) ? C.matches(event, 'mute') : (event.key === 'm' || event.key === 'M');
      if (isMute) {
        toggleMute();
      }
    });
  }

  Game.Audio = {
    playFireSound: playFireSound,
    playCrashSound: playCrashSound,
    panForX: panForX,
    playExplosionSound: playExplosionSound,
    playAmmoPickupSound: playAmmoPickupSound,
    playShieldPickupSound: playShieldPickupSound,
    playWallScrape: playWallScrape,
    playGasp: playGasp,
    setLowShieldWarning: setLowShieldWarning,
    startEngine: startEngine,
    stopEngine: stopEngine,
    setEngine: setEngine,
    playHazardSound: playHazardSound,
    playDiscoverySound: playDiscoverySound,
    startMusic: startMusic,
    stopMusic: stopMusic,
    startMultiTrackMusic: startMultiTrackMusic,
    stopMultiTrackMusic: stopMultiTrackMusic,
    toggleMute: toggleMute,
    isMuted: isMuted,
    getCurrentMeasureLabel: getCurrentMeasureLabel,
    getMusicChoices: getMusicChoices,
    setMusicTrack: setMusicTrack,
    isMusicPlaying: isMusicPlaying,
    toggleMusicPreview: toggleMusicPreview,
    skipToNextSection: skipToNextSection,
    skipToPreviousSection: skipToPreviousSection,
    stopMusicPreview: stopMusicPreview,
    getMeasureProgress: getMeasureProgress
  };

  // Expose internal scheduling helpers for standalone Node-based testing
  // (mirrors music-parser.js's module.exports pattern), without affecting
  // browser behavior (module is undefined there).
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      playMultiTrackPhrase: playMultiTrackPhrase,
      getTotalSongDuration: getTotalSongDuration,
      getTrackDuration: getTrackDuration,
      startMultiTrackMusic: startMultiTrackMusic,
      stopMultiTrackMusic: stopMultiTrackMusic,
      playNoteWithInstrument: playNoteWithInstrument,
      toggleMute: toggleMute,
      isMuted: isMuted,
      startMusic: startMusic,
      stopMusic: stopMusic,
      getCurrentMeasureLabel: getCurrentMeasureLabel,
      getMusicChoices: getMusicChoices,
      setMusicTrack: setMusicTrack,
      isMusicPlaying: isMusicPlaying,
      toggleMusicPreview: toggleMusicPreview,
      skipToNextSection: skipToNextSection,
      skipToPreviousSection: skipToPreviousSection,
    skipToPreviousSection: skipToPreviousSection,
      stopMusicPreview: stopMusicPreview,
      // Playlist internals, exported for tests.
      SONGS: SONGS,
      nextSongIndex: nextSongIndex,
      lookupMeasureLabel: lookupMeasureLabel,
      formatSongLabel: formatSongLabel,
      getParsedSong: getParsedSong,
      selectPlayableSong: selectPlayableSong,
      getCurrentSongIndex: function () { return currentSongIndex; },
      playFireSound: playFireSound,
      playCrashSound: playCrashSound,
      playHazardSound: playHazardSound,
      playDiscoverySound: playDiscoverySound,
      getAudioBuses: getAudioBuses,
      panForX: panForX,
      playExplosionSound: playExplosionSound,
      playAmmoPickupSound: playAmmoPickupSound,
      playShieldPickupSound: playShieldPickupSound,
      playWallScrape: playWallScrape,
      playGasp: playGasp,
      setLowShieldWarning: setLowShieldWarning,
      startEngine: startEngine,
      stopEngine: stopEngine,
      setEngine: setEngine,
      __setTestEnv: function (env) { testEnv = env; if (env && env.settings) { hookSettings(env.settings); } }
    };
  }
})();
