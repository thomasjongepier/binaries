// background.js - three parallax layers drawn behind the cave walls (nu2.19).
//   far   : rock silhouettes at 0.25x scroll, ramp 'backdrop' shade 1
//   mid   : stalactites/stalagmites at 0.5x, shade 2 with a shade-3 edge
//   glints: sparse twinkling crystal sprites at 0.35x
// Layer shapes come from the separate seeded 'background' stream, so cave
// generation is unaffected. Each layer is a horizontally wrapping offscreen
// tile (one canvas px = 1 buffer px), rebuilt when Game.Theme.version() changes.
// Layer offsets are whole buffer pixels.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  // Retro: 2 logical px per buffer px. High: 1 logical px, tiles twice as large
  // (K = 2) with the same shapes sampled at finer steps and smooth gradients.
  function hiRes() { return !!(Game.Pixel && Game.Pixel.hiRes && Game.Pixel.hiRes()); }
  function px() { return hiRes() ? 1 : 2; }
  function kk() { return 2 / px(); } // detail factor: 1 retro, 2 high
  var TW0 = 320; // tile width in buffer px (shape space, wraps)
  var TH0 = 200; // tile height in buffer px (shape space)
  var TW = TW0; // current tile width in render units (retro 320, high 640)
  var TH = TH0;
  var FAR = 0.25, MID = 0.5, GLINT = 0.35;
  var GLINT_COUNT = 14;
  var GLINT_FPS = 8;

  var shapes = null; // generated once
  var tiles = { far: null, mid: null };
  var tilesVersion = null;
  var tilesMode = null;
  var glintDefined = false;

  function themeVersion() {
    return (Game.Theme && Game.Theme.version) ? Game.Theme.version() : 0;
  }

  function ramp() {
    var r = (Game.Theme && Game.Theme.ramp) ? Game.Theme.ramp('backdrop') : null;
    if (r && r.length >= 4) { return r; }
    var p = (Game.Theme && Game.Theme.get) ? Game.Theme.get() : {};
    var b = p.BLUE || p.BLACK || '#000';
    return [p.BLACK || '#000', b, b, b];
  }

  function generateShapes() {
    var rs = Game.Random.stream('background');
    var s = { far: { top: [], bot: [] }, mid: [], glints: [] };
    var i, k;
    // Far silhouettes: sums of integer-period sines (periodic over TW).
    ['top', 'bot'].forEach(function (side) {
      for (k = 0; k < 3; k++) {
        s.far[side].push({ f: 1 + k * 2 + rs.int(0, 1), p: rs.range(0, 6.283), a: rs.range(8, 16) });
      }
      s.far[side + 'Base'] = rs.int(66, 86);
    });
    // Mid formations: center column, half width, length, direction.
    for (i = 0; i < 12; i++) {
      s.mid.push({
        c: Math.floor((i + rs.range(0.1, 0.9)) * TW0 / 12),
        w: rs.int(5, 12),
        len: rs.int(34, 72),
        top: rs.next() < 0.5
      });
    }
    for (i = 0; i < GLINT_COUNT; i++) {
      s.glints.push({
        x: rs.int(0, TW0 - 1),
        y: rs.int(8, TH0 - 9),
        phase: rs.int(0, 2)
      });
    }
    return s;
  }

  function makeCanvas() {
    if (typeof document === 'undefined' || !document || typeof document.createElement !== 'function') {
      return null;
    }
    try {
      var cv = document.createElement('canvas');
      cv.width = TW;
      cv.height = TH;
      return (cv.getContext && cv.getContext('2d')) ? cv : null;
    } catch (e) {
      return null;
    }
  }

  function bayer(x, y) {
    var B = Game.Sprite && Game.Sprite.BAYER4;
    return B ? B[(y & 3) * 4 + (x & 3)] : ((x + y) & 1) * 8;
  }

  // Per-column edge heights (render units) of the far silhouettes. Integer-period
  // sines wrap exactly at TW, so the seam is invisible. Retro: one int/column;
  // high: finer columns, heights scaled by K and left fractional (smooth edge).
  function farHeights(side) {
    var out = [];
    var terms = shapes.far[side];
    var K = kk();
    for (var c = 0; c < TW; c++) {
      var h = shapes.far[side + 'Base'];
      for (var k = 0; k < terms.length; k++) {
        h += terms[k].a * Math.sin(6.283185 * (terms[k].f * c / TW) + terms[k].p);
      }
      out.push(K === 1 ? Math.max(4, Math.round(h)) : Math.max(4 * K, h * K));
    }
    return out;
  }

  // Tiny hex lerp for the high-res smooth gradients.
  function lerpHex(a, b, t) {
    function parse(c) {
      if (typeof c !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(c)) { return null; }
      return [parseInt(c.slice(1, 3), 16), parseInt(c.slice(3, 5), 16), parseInt(c.slice(5, 7), 16)];
    }
    var A = parse(a), B = parse(b);
    if (!A || !B) { return t < 0.5 ? a : b; }
    var out = '#';
    for (var i = 0; i < 3; i++) {
      var v = Math.round(A[i] + (B[i] - A[i]) * t);
      out += (v < 16 ? '0' : '') + v.toString(16);
    }
    return out;
  }

  function buildFar(R) {
    var cv = makeCanvas();
    if (!cv) { return null; }
    var cx = cv.getContext('2d');
    var top = farHeights('top'), bot = farHeights('bot');
    var K = kk();
    var DITHER = 6 * K; // dithered (retro) / smoothly graded (high) band depth toward the edge
    for (var c = 0; c < TW; c++) {
      for (var y = 0; y < TH; y++) {
        var d = -1; // distance inside the silhouette from its edge
        if (y < top[c]) { d = top[c] - 1 - y; }
        else if (y >= TH - bot[c]) { d = y - (TH - bot[c]); }
        if (d < 0) { continue; }
        var col = R[1];
        if (d < DITHER) {
          // edge fades from backdrop[0] to backdrop[1] with Bayer dither
          col = K === 1
            ? (bayer(c, y) < Math.round(d * 16 / DITHER) ? R[1] : R[0])
            : lerpHex(R[0], R[1], d / DITHER);
        }
        cx.fillStyle = col;
        cx.fillRect(c, y, 1, 1);
      }
    }
    return cv;
  }

  function buildMid(R) {
    var cv = makeCanvas();
    if (!cv) { return null; }
    var cx = cv.getContext('2d');
    var K = kk();
    var topH = new Array(TW), botH = new Array(TW), c, i;
    for (c = 0; c < TW; c++) { topH[c] = 0; botH[c] = 0; }
    for (i = 0; i < shapes.mid.length; i++) {
      var f = shapes.mid[i];
      var fw = f.w * K, fc = f.c * K, fl = f.len * K;
      for (var dx = -fw; dx <= fw; dx++) {
        var h = Math.round(fl * (1 - Math.abs(dx) / (fw + 1)));
        var col = (((fc + dx) % TW) + TW) % TW;
        if (f.top) { topH[col] = Math.max(topH[col], h); } else { botH[col] = Math.max(botH[col], h); }
      }
    }
    // Base rock lip so formations hang from / rise out of something.
    for (c = 0; c < TW; c++) {
      var tl = topH[c] + 4 * K, bl = botH[c] + 4 * K;
      cx.fillStyle = R[2];
      cx.fillRect(c, 0, 1, tl);
      cx.fillRect(c, TH - bl, 1, bl);
      // 1 px highlight edge in backdrop[3]: the tip pixel plus the step
      // against the left neighbour, so the lit side reads as a hard edge.
      var pl = (c + TW - 1) % TW;
      var plT = topH[pl] + 4 * K, plB = botH[pl] + 4 * K;
      cx.fillStyle = R[3];
      cx.fillRect(c, tl - 1, 1, 1);
      if (plT < tl) { cx.fillRect(c, plT, 1, tl - plT); }
      cx.fillRect(c, TH - bl, 1, 1);
      if (plB < bl) { cx.fillRect(c, TH - bl, 1, bl - plB); }
    }
    return cv;
  }

  function defineGlint() {
    if (glintDefined || !Game.Sprite || !Game.Sprite.define) { return; }
    try {
      Game.Sprite.define('crystal-glint', {
        w: 3, h: 3,
        map: { a: 'crystal:1', b: 'crystal:2', w: 'crystal:3' },
        frames: [
          ['...', '.a.', '...'],
          ['.b.', 'bwb', '.b.'],
          ['.a.', 'aba', '.a.']
        ]
      });
      glintDefined = true;
    } catch (e) {
      glintDefined = false;
    }
  }

  function ensure() {
    if (!shapes) { shapes = generateShapes(); }
    defineGlint();
    var v = themeVersion();
    var mode = hiRes() ? 'high' : 'retro';
    if (v !== tilesVersion || mode !== tilesMode) {
      tilesMode = mode;
      TW = TW0 * kk();
      TH = TH0 * kk();
      var R = ramp();
      tiles.far = buildFar(R);
      tiles.mid = buildMid(R);
      tilesVersion = v;
    }
  }

  // Layer offset in whole buffer px for a world scrollX (logical px).
  function layerOffset(scrollX, factor) {
    return Math.floor(scrollX / px() * factor);
  }

  function snap(v) {
    return (Game.Pixel && Game.Pixel.snap) ? Game.Pixel.snap(v) : Math.round(v / px()) * px();
  }

  function drawTile(ctx, tile, off) {
    if (!tile) { return; }
    var PX = px();
    var o = ((off % TW) + TW) % TW;
    var x = snap(-o * PX);
    ctx.drawImage(tile, x, 0, TW * PX, TH * PX);
    ctx.drawImage(tile, x + TW * PX, 0, TW * PX, TH * PX);
  }

  // Draws the layers into ctx (logical 640x400 coordinates). nowMs is optional.
  function render(ctx, scrollX, nowMs) {
    if (!ctx || typeof ctx.drawImage !== 'function' || !Game.Random || !Game.Random.stream) { return; }
    ensure();
    var PX = px();
    var K = kk();
    var sx = +scrollX || 0;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    drawTile(ctx, tiles.far, layerOffset(sx, FAR));
    drawTile(ctx, tiles.mid, layerOffset(sx, MID));
    if (glintDefined && Game.Sprite && Game.Sprite.draw) {
      var t = (nowMs === undefined ? Date.now() : nowMs) / 1000;
      var go = ((layerOffset(sx, GLINT) % TW) + TW) % TW;
      for (var i = 0; i < shapes.glints.length; i++) {
        var g = shapes.glints[i];
        var frame = (Math.floor(t * GLINT_FPS / 2) + g.phase) % 3;
        for (var rep = 0; rep < 2; rep++) {
          var bx = g.x * K - go + rep * TW;
          if (bx >= -2 * K && bx < TW + 2 * K) {
            // sprite center, in logical px
            Game.Sprite.draw(ctx, 'crystal-glint', frame, (bx + 1.5 * K) * PX, (g.y * K + 1.5 * K) * PX);
          }
        }
      }
    }
    ctx.restore();
  }

  Game.Background = {
    render: render,
    layerOffset: layerOffset,
    FAR: FAR, MID: MID, GLINT: GLINT,
    TILE_W: TW0,
    _tileWidth: function () { ensure(); return TW; }
  };
})();
