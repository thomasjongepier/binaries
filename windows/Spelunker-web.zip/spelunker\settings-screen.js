// settings-screen.js - data-driven options screen (STATES.OPTIONS).
//
// Game.SettingsScreen.registerRow({ key, label, type: 'toggle'|'choice'|'slider',
// options, step }) adds a row; values are read/written via Game.Settings.
// Rows whose feature is not built yet still show and store their value.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  var W = 640;
  var TOP = 76;
  var ROW_H = 24;
  var LABEL_X = 110;
  var VALUE_RIGHT = 530;
  var BAR_W = 120;
  var DEFAULT_STEP = 0.1;
  var MAX_VISIBLE = 12; // rows 76..352 px: clear of the title and the footer

  var rows = [];
  var selected = 0;
  var scroll = 0; // index of the first visible row

  function settings() { return Game.Settings || null; }

  function clamp01(v) {
    v = Number(v);
    if (!isFinite(v)) return 0;
    return v < 0 ? 0 : (v > 1 ? 1 : v);
  }

  function round2(v) { return Math.round(v * 100) / 100; }

  function registerRow(def) {
    if (!def || typeof def.key !== 'string' || !def.key) return false;
    if (def.type !== 'toggle' && def.type !== 'choice' && def.type !== 'slider' && def.type !== 'action') return false;
    var row = {
      key: def.key,
      label: typeof def.label === 'string' && def.label ? def.label : def.key,
      type: def.type
    };
    if (typeof def.label === 'function') row.label = def.label; // dynamic: called at render time
    if (def.type === 'choice') {
      if (!Array.isArray(def.options) || !def.options.length) return false;
      row.options = def.options.slice();
      if (typeof def.optionLabel === 'function') row.optionLabel = def.optionLabel;
    }
    if (def.type === 'action') {
      if (typeof def.onActivate !== 'function') return false;
      row.onActivate = def.onActivate;
      row.valueLabel = (typeof def.valueLabel === 'string' || typeof def.valueLabel === 'function') ? def.valueLabel : 'OPEN';
    }
    if (def.type === 'slider') {
      var st = Number(def.step);
      row.step = (isFinite(st) && st > 0 && st <= 1) ? st : DEFAULT_STEP;
    }
    for (var i = 0; i < rows.length; i++) {
      if (rows[i].key === row.key) { rows[i] = row; return true; }
    }
    rows.push(row);
    return true;
  }

  function getRows() { return rows.slice(); }
  function getSelected() { return selected; }

  // Keep the selected row inside the visible window; clamp the window.
  function clampScroll() {
    var maxScroll = Math.max(0, rows.length - MAX_VISIBLE);
    if (selected < scroll) scroll = selected;
    if (selected >= scroll + MAX_VISIBLE) scroll = selected - MAX_VISIBLE + 1;
    scroll = scroll < 0 ? 0 : (scroll > maxScroll ? maxScroll : scroll);
    return scroll;
  }
  function getScroll() { return clampScroll(); }
  function getVisibleCount() { return Math.min(MAX_VISIBLE, rows.length); }

  function select(i) {
    if (!rows.length) { selected = 0; scroll = 0; return; }
    selected = ((i % rows.length) + rows.length) % rows.length;
    clampScroll();
  }

  // A panel (e.g. the key-capture screen) can take over keys and rendering:
  // { onKey(e), render(ctx) }. Opened by an 'action' row, closed with closePanel().
  var panel = null;
  function openPanel(p) { panel = p || null; }
  function closePanel() { panel = null; }
  function hasPanel() { return !!panel; }

  function currentValue(row) {
    var s = settings();
    var v = s ? s.get(row.key) : undefined;
    if (row.type === 'slider') return clamp01(v);
    return v;
  }

  // dir: +1 / -1. wrap: Enter-style activation wraps sliders back to 0.
  function change(index, dir, wrap) {
    var row = rows[index];
    var s = settings();
    if (!row || !s) return false;
    if (row.type === 'action') {
      row.onActivate();
      return true;
    }
    var v = currentValue(row);
    if (row.type === 'toggle') {
      return s.set(row.key, !v);
    }
    if (row.type === 'choice') {
      var i = row.options.indexOf(v);
      if (i < 0) i = 0;
      i = (i + (dir < 0 ? -1 : 1) + row.options.length) % row.options.length;
      return s.set(row.key, row.options[i]);
    }
    var next = v + (dir < 0 ? -row.step : row.step);
    if (wrap && next > 1 + 1e-9) next = 0;
    return s.set(row.key, clamp01(round2(next)));
  }

  function setSlider(index, fraction) {
    var row = rows[index];
    var s = settings();
    if (!row || row.type !== 'slider' || !s) return false;
    return s.set(row.key, clamp01(round2(clamp01(fraction))));
  }

  function inOptions() {
    return !!(Game.STATES && Game.getState && Game.getState() === Game.STATES.OPTIONS);
  }

  function consume(e) {
    if (e && e.preventDefault) e.preventDefault();
    if (e && e.stopImmediatePropagation) e.stopImmediatePropagation();
  }

  function onKeyDown(e) {
    if (!inOptions() || !e) return;
    if (panel) { panel.onKey(e); consume(e); return; }
    var k = e.key;
    if (k === 'ArrowUp') { select(selected - 1); consume(e); }
    else if (k === 'ArrowDown') { select(selected + 1); consume(e); }
    else if ((k === 'ArrowLeft' && e.shiftKey) || k === '<') {
      if (audio && audio.skipToPreviousSection) audio.skipToPreviousSection();
      consume(e);
    }
    else if (k === 'ArrowLeft') { change(selected, -1, false); consume(e); }
    else if ((k === 'ArrowRight' && e.shiftKey) || k === '>') {
      if (audio && audio.skipToNextSection) audio.skipToNextSection();
      consume(e);
    }
    else if (k === 'ArrowRight') { change(selected, 1, false); consume(e); }
    else if (k === 'Enter') { change(selected, 1, true); consume(e); }
    else if (k === 'Escape') {
      consume(e);
      if (Game.setState) Game.setState(Game.STATES.TITLE);
    }
  }

  // Map a mouse event to logical coordinates (640x400, canvas CSS-scaled).
  function logicalPoint(e) {
    var c = Game.canvas;
    if (!c || !c.getBoundingClientRect) return null;
    var r = c.getBoundingClientRect();
    if (!r || !r.width || !r.height) return null;
    var h = Game.H || 400;
    return { x: (e.clientX - r.left) * (Game.W || W) / r.width,
             y: (e.clientY - r.top) * h / r.height };
  }

  function rowAt(y) {
    var v = Math.floor((y - (TOP - ROW_H / 2)) / ROW_H);
    var i = v + clampScroll();
    return (v >= 0 && v < MAX_VISIBLE && i >= 0 && i < rows.length) ? i : -1;
  }

  function onMouseMove(e) {
    if (!inOptions() || panel) return;
    var p = logicalPoint(e);
    if (!p) return;
    var i = rowAt(p.y);
    if (i >= 0) selected = i;
  }

  function onClick(e) {
    if (!inOptions() || panel) return;
    var p = logicalPoint(e);
    if (!p) return;
    var i = rowAt(p.y);
    if (i < 0) return;
    selected = i;
    var row = rows[i];
    if (row.type === 'slider' && p.x >= VALUE_RIGHT - BAR_W && p.x <= VALUE_RIGHT) {
      setSlider(i, (p.x - (VALUE_RIGHT - BAR_W)) / BAR_W);
    } else {
      change(i, 1, true);
    }
  }

  function palette() { return Game.Theme && Game.Theme.get ? Game.Theme.get() : null; }

  function text(ctx, str, x, y, align, color, role, scale) {
    var css = 'bold ' + (scale > 1 ? 24 : 16) + 'px monospace';
    if (Game.Font && Game.Font.draw) {
      Game.Font.draw(ctx, str, x, y, { role: role || 'body', css: css, color: color,
        align: align, baseline: 'middle', scale: scale || 1 });
      return;
    }
    ctx.save();
    ctx.font = css;
    ctx.fillStyle = color;
    ctx.textAlign = align;
    ctx.textBaseline = 'middle';
    ctx.fillText(str, x, y);
    ctx.restore();
  }

  // Small scroll indicator triangle centred on (x, y); dir -1 up, +1 down.
  function arrow(ctx, x, y, dir) {
    ctx.beginPath();
    ctx.moveTo(x - 6, y + dir * 3);
    ctx.lineTo(x + 6, y + dir * 3);
    ctx.lineTo(x, y - dir * 3);
    ctx.closePath();
    ctx.fill();
  }

  function valueText(row) {
    if (row.type === 'action') return typeof row.valueLabel === 'function' ? String(row.valueLabel()) : row.valueLabel;
    var v = currentValue(row);
    if (row.type === 'toggle') return v ? 'ON' : 'OFF';
    if (row.type === 'choice') return row.optionLabel ? String(row.optionLabel(v)) : String(v).toUpperCase();
    return Math.round(v * 100) + '%';
  }

  // opts.overlay: the caller already drew a backdrop (attract mode); dim it
  // instead of painting the opaque blue background.
  function render(ctx, opts) {
    var P = palette();
    if (!ctx || !P) return;
    if (panel) { panel.render(ctx); return; }
    var H = Game.H || 400;
    if (opts && opts.overlay) {
      ctx.save();
      ctx.fillStyle = 'rgba(0, 0, 32, 0.55)';
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    } else {
      ctx.fillStyle = P.BLUE;
      ctx.fillRect(0, 0, W, H);
    }
    text(ctx, 'OPTIONS', W / 2, 44, 'center', P.YELLOW, 'title', 2);
    var first = clampScroll();
    var last = Math.min(rows.length, first + MAX_VISIBLE);
    for (var i = first; i < last; i++) {
      var row = rows[i];
      var y = TOP + (i - first) * ROW_H;
      var sel = i === selected;
      if (sel) {
        ctx.fillStyle = P.DARK_GREY;
        ctx.fillRect(LABEL_X - 16, y - ROW_H / 2 + 2, VALUE_RIGHT - LABEL_X + 32, ROW_H - 4);
      }
      var col = sel ? P.YELLOW : P.WHITE;
      text(ctx, typeof row.label === 'function' ? row.label() : row.label, LABEL_X, y, 'left', col);
      if (row.type === 'slider') {
        var bx = VALUE_RIGHT - BAR_W;
        ctx.fillStyle = P.BLACK;
        ctx.fillRect(bx, y - 6, BAR_W, 12);
        ctx.fillStyle = col;
        ctx.fillRect(bx, y - 5, Math.round(BAR_W * currentValue(row)), 10);
        text(ctx, valueText(row), bx - 8, y, 'right', col);
      } else {
        text(ctx, valueText(row), VALUE_RIGHT, y, 'right', col);
      }
    }
    ctx.fillStyle = P.YELLOW;
    if (first > 0) { arrow(ctx, W - 70, TOP - ROW_H / 2 - 6, -1); }
    if (last < rows.length) { arrow(ctx, W - 70, TOP + MAX_VISIBLE * ROW_H - ROW_H / 2 + 6, 1); }
    text(ctx, 'UP/DOWN SELECT  LEFT/RIGHT CHANGE  ESC BACK', W / 2, H - 28, 'center', P.LIGHT_GREY || P.WHITE);
  }

  // Initial rows.
  registerRow({ key: 'theme', label: 'Theme', type: 'choice', options: ['classic', 'modern'] });
  registerRow({ key: 'resolution', label: 'Resolution', type: 'choice', options: ['retro', 'high', 'ultrahigh'] });
  registerRow({ key: 'difficulty', label: 'Difficulty', type: 'choice', options: ['easy', 'normal', 'hard'] });
  registerRow({ key: 'musicVolume', label: 'Music volume', type: 'slider', step: 0.1 });
  registerRow({ key: 'sfxVolume', label: 'SFX volume', type: 'slider', step: 0.1 });
  // Music selection and preview (Game.Audio loads before this file). The choice
  // list comes from Audio's SONGS registry; 'Play music' toggles playback from
  // the user's key/click, which is what lets the browser start the AudioContext.
  var audio = Game.Audio || null;
  var musicChoices = audio && audio.getMusicChoices ? audio.getMusicChoices() : [{ id: 'playlist', label: 'Playlist' }];
  registerRow({ key: 'musicTrack', label: 'Music', type: 'choice',
    options: musicChoices.map(function (c) { return c.id; }),
    optionLabel: function (id) {
      for (var i = 0; i < musicChoices.length; i++) { if (musicChoices[i].id === id) return musicChoices[i].label.toUpperCase(); }
      return String(id).toUpperCase();
    } });
  function musicPlaying() { return !!(audio && audio.isMusicPlaying && audio.isMusicPlaying()); }
  registerRow({ key: 'playMusic', type: 'action',
    label: function () { return musicPlaying() ? 'Stop music' : 'Play music'; },
    valueLabel: function () {
      if (!musicPlaying()) return 'PLAY';
      var m = audio.getCurrentMeasureLabel ? audio.getCurrentMeasureLabel() : null;
      return m ? m.toUpperCase() : 'PLAYING';
    },
    onActivate: function () { if (audio && audio.toggleMusicPreview) audio.toggleMusicPreview(); } });
  registerRow({ key: 'screenShake', label: 'Screen shake', type: 'toggle' });
  registerRow({ key: 'hazardFlash', label: 'Hazard flash', type: 'toggle' });
  registerRow({ key: 'headlamp', label: 'Headlamp', type: 'toggle' });
  registerRow({ key: 'bloom', label: 'Bloom', type: 'toggle' });
  registerRow({ key: 'reduceMotion', label: 'Reduce motion', type: 'toggle' });
  registerRow({ key: 'enemyShapes', label: 'Enemy shapes', type: 'toggle' });
  registerRow({ key: 'highContrast', label: 'High contrast', type: 'toggle' });
  registerRow({ key: 'crt', label: 'CRT scanlines', type: 'toggle' });
  registerRow({ key: 'intensityLayer', label: 'Hard-zone hi-hat', type: 'toggle' });

  // Keep the active theme in step with the stored setting.
  function applyTheme() {
    var s = settings();
    if (s && Game.Theme && Game.Theme.set) Game.Theme.set(s.get('theme'));
  }
  if (settings()) {
    applyTheme();
    if (settings().onChange) {
      settings().onChange(function (key) { if (key === 'theme') applyTheme(); });
    }
  }

  if (typeof window.addEventListener === 'function') {
    window.addEventListener('keydown', onKeyDown);
  }
  if (Game.canvas && Game.canvas.addEventListener) {
    Game.canvas.addEventListener('mousemove', onMouseMove);
    Game.canvas.addEventListener('click', onClick);
  }

  Game.SettingsScreen = {
    registerRow: registerRow,
    getRows: getRows,
    getSelected: getSelected,
    getScroll: getScroll,
    getVisibleCount: getVisibleCount,
    select: select,
    change: change,
    setSlider: setSlider,
    openPanel: openPanel,
    closePanel: closePanel,
    hasPanel: hasPanel,
    render: render
  };
})();
