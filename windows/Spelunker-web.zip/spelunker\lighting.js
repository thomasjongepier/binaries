// lighting.js - headlamp: the cave is dark except around the ship.
//
// Game.Lighting.render(rctx) draws a darkness overlay with a lamp-shaped hole
// at the ship. Pixel mode (modern theme) uses 4 stepped darkness levels with
// Bayer-dithered edges, precomputed once into a cached lamp canvas and stamped
// at the ship; classic mode uses a smooth radial gradient. L toggles the
// Settings 'headlamp' flag while playing.
(function () {
  'use strict';

  window.Game = window.Game || {};

  var LOGICAL_W = 640;
  var LOGICAL_H = 400;
  var BUF_W = 320;
  var BUF_H = 200;
  var SCALE = 2; // logical px per buffer px

  var INNER_R = 60;   // fully lit inside this (logical px)
  var OUTER_R = 170;  // darkest level reached by here (logical px)
  var MAX_DARK = 0.82;
  // Darkness per band, and where each dithered transition starts / how wide.
  var LEVELS = [0, 0.35, 0.6, 0.82];
  var TRANS_START = [60, 100, 140]; // logical px
  var TRANS_WIDTH = 20;             // logical px

  var canvas = null;
  var lctx = null;
  var lamp = null; // cached pixel-mode lamp (destination-out mask)
  var lampHalf = 0; // buffer px from centre to edge of the lamp canvas

  function makeCanvas(w, h) {
    if (typeof document === 'undefined' || !document || typeof document.createElement !== 'function') { return null; }
    try {
      var c = document.createElement('canvas');
      if (!c || typeof c.getContext !== 'function') { return null; }
      c.width = w;
      c.height = h;
      return c;
    } catch (e) {
      return null;
    }
  }

  // Created once; resized (not recreated) when the mode changes.
  function ensureCanvas(pixelMode) {
    var w = pixelMode ? BUF_W : LOGICAL_W;
    var h = pixelMode ? BUF_H : LOGICAL_H;
    if (!canvas) {
      canvas = makeCanvas(w, h);
      lctx = canvas ? canvas.getContext('2d') : null;
      if (!lctx) { canvas = null; return false; }
    }
    if (canvas.width !== w) { canvas.width = w; }
    if (canvas.height !== h) { canvas.height = h; }
    return true;
  }

  // Darkness level index (0..3) for a buffer pixel at logical distance d.
  function levelFor(d, bx, by, masks) {
    var level = 0;
    for (var i = 0; i < TRANS_START.length; i++) {
      var t = (d - TRANS_START[i]) / TRANS_WIDTH;
      if (t <= 0) { break; }
      if (t >= 1) { level = i + 1; continue; }
      // Dithered transition i -> i+1: higher level where BAYER4 < t*16.
      var m = masks[Math.max(1, Math.min(15, Math.round(t * 16)))];
      if (m[(by & 3) * 4 + (bx & 3)]) { level = i + 1; }
      break;
    }
    return level;
  }

  // Cached lamp: opaque where the lamp clears the darkness fully, partially
  // transparent in the dimmer bands. Used with 'destination-out'.
  function buildLamp() {
    lampHalf = Math.ceil(OUTER_R / SCALE) + 1;
    var size = lampHalf * 2 + 1;
    var c = makeCanvas(size, size);
    var cx = c ? c.getContext('2d') : null;
    if (!cx) { return null; }
    var Sprite = window.Game.Sprite;
    var masks = [];
    for (var l = 0; l <= 16; l++) {
      masks.push((Sprite && Sprite.ditherMask) ? Sprite.ditherMask(l) : new Array(16).fill(l >= 8));
    }
    for (var y = 0; y < size; y++) {
      for (var x = 0; x < size; x++) {
        var dx = (x - lampHalf) * SCALE;
        var dy = (y - lampHalf) * SCALE;
        var d = Math.sqrt(dx * dx + dy * dy);
        var dark = LEVELS[levelFor(d, x, y, masks)];
        var a = 1 - dark / MAX_DARK;
        if (a <= 0) { continue; }
        cx.fillStyle = 'rgba(0,0,0,' + a.toFixed(4) + ')';
        cx.fillRect(x, y, 1, 1);
      }
    }
    return c;
  }

  function shipPos() {
    var S = window.Game.Ship;
    if (S && S.getPosition) {
      var p = S.getPosition();
      if (p && isFinite(p.screenX) && isFinite(p.y)) { return { x: p.screenX, y: p.y }; }
    }
    return { x: LOGICAL_W / 4, y: LOGICAL_H / 2 };
  }

  function enabled() {
    var S = window.Game.Settings;
    return !(S && S.get) || S.get('headlamp') !== false;
  }

  function render(rctx) {
    if (!rctx || !enabled()) { return; }
    var theme = window.Game.Theme && window.Game.Theme.get ? window.Game.Theme.get() : null;
    // Pixel mode only when the frame really is the pixel buffer.
    var pixelMode = !!(theme && theme.pixelMode) && !!(window.Game.Pixel && window.Game.Pixel.getBuffer && window.Game.Pixel.getBuffer()) &&
      (!window.Game.Pixel.enabled || window.Game.Pixel.enabled());
    if (pixelMode && !ensureCanvas(true)) { return; }
    var pos = shipPos();

    if (!pixelMode) {
      renderClassic(rctx, pos);
      return;
    }
    lctx.setTransform(1, 0, 0, 1, 0, 0);
    lctx.globalCompositeOperation = 'source-over';
    lctx.clearRect(0, 0, canvas.width, canvas.height);
    lctx.fillStyle = 'rgba(0,0,0,' + MAX_DARK + ')';
    lctx.fillRect(0, 0, canvas.width, canvas.height);
    lctx.globalCompositeOperation = 'destination-out';
    if (!lamp) { lamp = buildLamp(); }
    if (lamp) {
      lctx.drawImage(lamp, Math.round(pos.x / SCALE) - lampHalf, Math.round(pos.y / SCALE) - lampHalf);
    }
    lctx.globalCompositeOperation = 'source-over';

    // The caller's transform maps logical coords (buffer or main bitmap).
    rctx.save();
    rctx.globalCompositeOperation = 'source-over';
    rctx.drawImage(canvas, 0, 0, LOGICAL_W, LOGICAL_H);
    rctx.restore();
  }

  // Classic mode: the gradient is rendered once into a small darkness stamp
  // (transparent centre -> MAX_DARK at OUTER_R) and drawn at the ship, with
  // four flat rects covering the rest. No per-frame gradient or full-frame
  // offscreen pass.
  var stamp = null;
  function buildStamp() {
    var n = OUTER_R * 2;
    var c = makeCanvas(n, n);
    var cx = c ? c.getContext('2d') : null;
    if (!cx) { return null; }
    var g = cx.createRadialGradient(OUTER_R, OUTER_R, INNER_R, OUTER_R, OUTER_R, OUTER_R);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, 'rgba(0,0,0,' + MAX_DARK + ')');
    cx.fillStyle = g;
    cx.fillRect(0, 0, n, n);
    return c;
  }

  function renderClassic(rctx, pos) {
    if (!stamp) { stamp = buildStamp(); }
    if (!stamp) { return; }
    var n = OUTER_R * 2;
    var x0 = Math.round(pos.x) - OUTER_R;
    var y0 = Math.round(pos.y) - OUTER_R;
    // Stamp rect clipped to the frame; rects fill the frame around it.
    var cx0 = Math.max(0, Math.min(LOGICAL_W, x0));
    var cx1 = Math.max(0, Math.min(LOGICAL_W, x0 + n));
    var cy0 = Math.max(0, Math.min(LOGICAL_H, y0));
    var cy1 = Math.max(0, Math.min(LOGICAL_H, y0 + n));
    rctx.save();
    rctx.globalCompositeOperation = 'source-over';
    rctx.fillStyle = 'rgba(0,0,0,' + MAX_DARK + ')';
    if (cy0 > 0) { rctx.fillRect(0, 0, LOGICAL_W, cy0); }
    if (cy1 < LOGICAL_H) { rctx.fillRect(0, cy1, LOGICAL_W, LOGICAL_H - cy1); }
    if (cx0 > 0 && cy1 > cy0) { rctx.fillRect(0, cy0, cx0, cy1 - cy0); }
    if (cx1 < LOGICAL_W && cy1 > cy0) { rctx.fillRect(cx1, cy0, LOGICAL_W - cx1, cy1 - cy0); }
    if (cx1 > cx0 && cy1 > cy0) { rctx.drawImage(stamp, x0, y0); }
    rctx.restore();
  }

  function onKeyDown(e) {
    var G = window.Game;
    if (!e || e.repeat) { return; }
    var isLamp = (G.Controls && G.Controls.matches) ? G.Controls.matches(e, 'lamp') : (e.key === 'l' || e.key === 'L');
    if (!isLamp) { return; }
    if (!G.getState || G.getState() !== G.STATES.PLAYING) { return; }
    if (G.Settings && G.Settings.get && G.Settings.set) {
      G.Settings.set('headlamp', !G.Settings.get('headlamp'));
    }
  }
  if (typeof window.addEventListener === 'function') {
    window.addEventListener('keydown', onKeyDown);
  }

  window.Game.Lighting = {
    render: render,
    isEnabled: enabled,
    OUTER_R: OUTER_R,
    INNER_R: INNER_R,
    LEVELS: LEVELS
  };
})();
