// Spelunker - the Fugue from J. S. Bach's Toccata in E minor, BWV 914.
//
// GENERATED FILE - DO NOT EDIT BY HAND. Regenerate with:
//   node tools/midi-to-measures.js --format game-js --out music-bach-914.js
// Source: tools/sources/bwv914-fugue-aligned.mid, merged from two public MIDI
// transcriptions (midiworld.com, credited to John Sankey; tobis-notenarchiv.de).
// The source MIDI licence is not stated. Timing follows a recording.
// The MIDI was aligned to input_audio/BWV-914-fugue.mp3; notes are snapped
// to a 1/32-whole-note grid and split into monophonic keyboard tracks.
// Each tempo section is a separate score because the parser supports one
// tempo per notation. Sections play back to back; no trailing pause is added.

var Bach914ScoreHelpers = (typeof window !== 'undefined' && window.MusicScore)
  ? window.MusicScore
  : require('./music-score.js');

// ---- Section 1: measures 1-8, 118.7 bpm ----
var FUGUE_914_TRACKS = {
  v7: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 7.'
  },
  v8: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 8.'
  }
};

var FUGUE_914_MEASURES = [
  {
    label: '# Measure 1',
    v7: ['R,16 B4,16 A4,16 B4,16 G4,16 A4,16 F#4,16 G4,16 E4,16 E5,16 B4,16 E5,16 G4,16 B4,16 E4,16 C5,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 2',
    v7: ['D#4,16 C5,16 D#4,16 C5,16 D#4,16 C5,16 D#4,16 C5,16 D4,16 F#4,16 B4,16 F#4,16 D4,16 F#4,16 B4,16 F#4,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 3',
    v7: ['C#4,16 B4,16 C#4,16 B4,16 C#4,16 B4,16 C#4,16 B4,16 C4,16 E4,16 A4,16 E4,16 C4,16 E4,16 A4,16 E4,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 4',
    v7: ['B3,16 A4,16 G4,16 A4,16 F#4,16 B4,16 A4,16 B4,16 G4,16 A4,16 F#4,16 G4,16 E4,16 G4,16 F#4,16 E4,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 5',
    v7: ['D4,8 A#3,8 B3,8 C#4,8 D4,4 R,8 D4,8'],
    v8: ['R,16 F#5,16 E5,16 F#5,16 D5,16 E5,16 C#5,16 D5,16 B4,16 B5,16 F#5,16 B5,16 D5,16 F#5,16 B4,16 G5,16']
  },
  {
    label: '# Measure 6',
    v7: ['C#4,4 A#4,16 R,16 A#4,16 R,16 A4,16 C#5,16 F#4,8 F4,8 F#4,8'],
    v8: ['A#4,16 G5,16 A#4,16 G5,16 R,16 G5,16 R,16 G5,16 R,8 F#5,16 C#5,16 A4,16 C#5,16 F#5,16 C#5,16']
  },
  {
    label: '# Measure 7',
    v7: ['B3,4 G#4,16 R,16 G#4,16 R,16 G4,16 B4,16 E4,8 D#4,8 E4,8'],
    v8: ['G#4,16 F#5,16 G#4,16 F#5,16 R,16 F#5,16 R,16 F#5,16 R,8 E5,16 B4,16 G4,16 B4,16 E5,16 B4,16']
  },
  {
    label: '# Measure 8',
    v7: ['A#3,8 B3,4 A#3,8 B3,4 R,8 D#5,8'],
    v8: ['F#4,16 E5,16 D5,16 E5,16 C#5,16 F#5,16 E5,16 F#5,16 D5,16 E5,16 C#5,16 D5,16 B4,16 B4,16 A4,16 B4,16']
  }
];

var MUSIC_BACH_914_BPM = 118.7;
var MUSIC_BACH_914_MEASURE_MAP = Bach914ScoreHelpers.buildMeasureMap(FUGUE_914_TRACKS, FUGUE_914_MEASURES, MUSIC_BACH_914_BPM);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_MEASURE_MAP = MUSIC_BACH_914_MEASURE_MAP; }
var MUSIC_BACH_914_NOTATION = Bach914ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue of the Toccata in E minor, BWV 914 (measures 1-8)',
  '# Converted from the aligned performance MIDI; timing follows the recording.'
], MUSIC_BACH_914_BPM, FUGUE_914_TRACKS, FUGUE_914_MEASURES);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_NOTATION = MUSIC_BACH_914_NOTATION; }

// ---- Section 2: measures 9-12, 117.8 bpm ----
var FUGUE_914_TRACKS_2 = {
  v3: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 3.'
  },
  v7: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 7.'
  },
  v8: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 8.'
  }
};

var FUGUE_914_MEASURES_2 = [
  {
    label: '# Measure 9',
    v3: ['R,1'],
    v7: ['E5,4 R,16 E5,16 D5,16 E5,16 C5,16 D5,16 B4,16 C5,16 A4,16 B4,16 G4,16 A4,16'],
    v8: ['G4,16 A4,16 F#4,16 G4,16 E4,8 F#4,16 G#4,16 A4,8 G4,8 F#4,8 E4,8']
  },
  {
    label: '# Measure 10',
    v3: ['R,16 B3,16 A3,16 B3,16 G3,16 A3,16 F#3,16 G3,16 E3,16 E4,16 B3,16 E4,16 G3,16 B3,16 E3,16 C4,16'],
    v7: ['F#4,8 B4,8 C#5,8 D#5,8 E5,4 R,8 E5,8'],
    v8: ['E4,8 D#4,8 E4,8 F#4,8 G4,4 R,8 G4,8']
  },
  {
    label: '# Measure 11',
    v3: ['D#3,16 C4,16 D#3,16 C4,16 D#3,16 R,16 D#3,16 R,16 D3,16 F#3,16 D5,8 C#5,8 D5,8'],
    v7: ['F#5,4 R,4. B4,8 A#4,8 B4,8'],
    v8: ['F#4,4 R,16 C4,16 R,16 C4,16 R,8 B3,16 F#3,16 D3,16 F#3,16 B3,16 F#3,16']
  },
  {
    label: '# Measure 12',
    v3: ['E5,4 R,4. A4,8 G#4,8 A4,8'],
    v7: ['E4,4 R,16 B3,16 R,16 B3,16 R,8 A3,16 R,8. A3,16 R,16'],
    v8: ['C#3,16 B3,16 C#3,16 B3,16 C#3,16 R,16 C#3,16 R,16 C3,16 E3,16 R,16 E3,16 C3,16 E3,16 R,16 E3,16']
  }
];

var MUSIC_BACH_914_BPM_2 = 117.8;
var MUSIC_BACH_914_MEASURE_MAP_2 = Bach914ScoreHelpers.buildMeasureMap(FUGUE_914_TRACKS_2, FUGUE_914_MEASURES_2, MUSIC_BACH_914_BPM_2);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_MEASURE_MAP_2 = MUSIC_BACH_914_MEASURE_MAP_2; }
var MUSIC_BACH_914_NOTATION_2 = Bach914ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue of the Toccata in E minor, BWV 914 (measures 9-12)',
  '# Converted from the aligned performance MIDI; timing follows the recording.'
], MUSIC_BACH_914_BPM_2, FUGUE_914_TRACKS_2, FUGUE_914_MEASURES_2);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_NOTATION_2 = MUSIC_BACH_914_NOTATION_2; }

// ---- Section 3: measures 13-33, 116.1 bpm ----
var FUGUE_914_TRACKS_3 = {
  v3: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 3.'
  },
  v5: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 5.'
  },
  v7: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 7.'
  },
  v8: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 8.'
  }
};

var FUGUE_914_MEASURES_3 = [
  {
    label: '# Measure 13',
    v3: ['B4,4 A4,8 F#4,8 G4,8 F#4,8 G4,8 F#4,8'],
    v5: ['R,1'],
    v7: ['D#4,8 E4,4 D#4,8 E4,8 A4,8 B4,4'],
    v8: ['B2,16 A3,16 G3,16 A3,16 F#3,16 B3,16 A3,16 B3,16 G3,16 A3,16 F#3,16 G3,16 E3,16 F#3,16 D3,16 E3,16']
  },
  {
    label: '# Measure 14',
    v3: ['E4,4 E4,16. R,32 E4,8 D#4,8 E4,4 D#4,8'],
    v5: ['R,2. R,32 G4,32 F#4,8.'],
    v7: ['E5,8 D5,8 C5,8 B4,8 A4,16 B4,16 G4,16 A4,16 G4,32 F#4,32 B3,16 A3,16 B3,16'],
    v8: ['C3,16 D3,16 B2,16 C3,16 A2,16 B2,16 G2,16 A2,16 F#2,8 E2,8 B2,16 R,8.']
  },
  {
    label: '# Measure 15',
    v3: ['E4,4 G4,16 G4,16 F#4,16 G4,16 E4,16 F#4,16 R,8 R,32 B4,32 R,8.'],
    v5: ['G4,16 B4,16 A4,16 B4,16 R,16 E5,16 D5,16 E5,16 C#5,16 D5,16 B4,16 C#5,16 B4,32 A#4,32 A#4,8.'],
    v7: ['R,2 R,8 D4,16 E4,16 C#4,4'],
    v8: ['E3,4 R,2 R,16 F#3,16 E3,16 F#3,16']
  },
  {
    label: '# Measure 16',
    v3: ['B4,4 D5,16 E5,16 C#5,16 R,16 D5,16 R,16 C#5,16 R,16 D5,16 R,16 C#5,16 R,16'],
    v5: ['R,16 F#5,16 E5,16 F#5,16 R,8. E5,16 R,16 E5,16 R,16 E5,16 R,16 E5,16 R,16 E5,16'],
    v7: ['R,4 R,16 F#3,16 R,16 F#3,16 R,16 F#3,16 R,16 F#3,16 R,16 F#3,16 R,16 F#3,16'],
    v8: ['D3,16 E3,16 C#3,16 D3,16 B2,16 R,16 A#2,16 R,16 B2,16 R,16 A#2,16 R,16 B2,16 R,16 A#2,16 R,16']
  },
  {
    label: '# Measure 17',
    v3: ['D5,8 A#4,8 B4,8 E5,8 R,4. D5,8'],
    v5: ['R,8 C#5,8 D5,8 C#5,8 D5,4 R,8 B4,8'],
    v7: ['R,16 F#3,16 E3,16 F#3,16 R,16 E3,16 R,8. B3,16 F#3,16 B3,16 R,8. G3,16'],
    v8: ['B2,16 R,8. D3,16 R,16 C#3,16 D3,16 B2,16 R,8. D3,16 F#3,16 B2,16 R,16']
  },
  {
    label: '# Measure 18',
    v3: ['C#5,4 R,4. A4,8 G#4,8 A4,8'],
    v5: ['E4,4 R,4. F#5,8 F5,8 F#5,8'],
    v7: ['R,16 G3,16 R,16 G3,16 R,16 G3,16 R,16 G3,16 R,8 F#3,16 R,8. F#3,16 R,16'],
    v8: ['A#2,16 R,16 A#2,16 R,16 A#2,16 R,16 A#2,16 R,16 A2,16 C#3,16 R,16 C#3,16 A2,16 C#3,16 R,16 C#3,16']
  },
  {
    label: '# Measure 19',
    v3: ['B4,4 R,2 R,8 E4,8'],
    v5: ['R,2 R,8 E5,8 D#5,8 E5,8'],
    v7: ['R,16 F#3,16 R,16 F#3,16 R,16 F#3,16 R,16 F#3,16 R,8 E3,16 R,8. E3,16 R,16'],
    v8: ['G#2,16 R,16 G#2,16 R,16 G#2,16 R,16 G#2,16 R,16 G2,16 B2,16 R,16 B2,16 G2,16 B2,16 R,16 B2,16']
  },
  {
    label: '# Measure 20',
    v3: ['F#4,4 E4,8 C#4,8 B4,16 F#5,16 B4,16 F#5,16 B4,16 F#5,16 A4,16 F#5,16'],
    v5: ['A#4,8 B4,4 A#4,8 F#4,8 F#4,8 F#4,8 F#4,8'],
    v7: ['R,16 E3,16 D3,16 E3,16 C#3,16 F#3,16 E3,16 F#3,16 D3,4 R,8 D#3,8'],
    v8: ['F#2,16 R,2. R,8.']
  },
  {
    label: '# Measure 21',
    v3: ['G4,16 F#5,16 G4,16 F#5,16 R,16 E5,16 R,16 E5,16 R,16 E5,16 R,16 E5,16 R,16 D#5,16 R,16 D#5,16'],
    v5: ['B3,4 G4,16 R,16 G4,16 R,16 F#4,16 R,16 F#4,16 R,16 F#4,16 R,16 F#4,16 R,16'],
    v7: ['E3,8 F#3,8 G3,8 E3,8 A3,8 F#3,8 B3,8 A3,8'],
    v8: ['R,1']
  },
  {
    label: '# Measure 22',
    v3: ['R,16 D5,16 R,16 D5,16 R,16 C5,16 R,16 C5,16 R,16 B4,16 R,16 B4,16 R,16 B4,16 A4,16 G4,16'],
    v5: ['E4,16 R,16 E4,16 R,16 E4,16 R,16 E4,16 R,16 D#4,16 R,16 D#4,16 R,16 E4,16 R,8.'],
    v7: ['G#3,8 E3,8 A3,4. A3,8 G3,8 F#3,16 E3,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 23',
    v3: ['A4,16 B4,16 R,16 A4,16 R,16 A4,16 R,8. A4,16 R,8. G4,16 F#4,16 R,16'],
    v5: ['R,8 G4,16 R,16 F#4,16 R,16 G4,16 F#4,16 G4,16 R,16 G4,16 F#4,16 E4,16 R,8 E4,16'],
    v7: ['F#3,16 G3,16 E3,16 F#3,16 D#3,16 F#3,16 E3,16 D#3,16 E3,16 F#3,16 E3,16 F#3,16 G3,16 B3,16 A3,16 G3,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 24',
    v3: ['F#4,16 G4,16 R,16 F#4,16 R,16 F#4,16 R,8. B4,16 R,16 B4,16 R,16 B4,16 R,16 B4,16'],
    v5: ['R,8 E4,16 R,16 D#4,16 R,16 E4,16 D#4,16 E4,16 R,16 D#4,16 R,16 E4,16 R,16 D#4,16 R,16'],
    v7: ['A3,16 B3,16 G3,16 A3,16 F#3,16 A3,16 G3,16 F#3,16 G3,16 A3,16 F#3,16 A3,16 G3,16 A3,16 F#3,16 A3,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 25',
    v3: ['R,16 E5,16 B4,16 D5,16 C5,16 D5,16 B4,16 D5,16 C5,16 D5,16 B4,16 D5,16 C5,16 D5,16 B4,16 D5,16'],
    v5: ['E4,16 R,4 E4,16 R,16 E4,16 R,16 E4,16 R,16 E4,16 R,16 E4,16 R,16 E4,16'],
    v7: ['G3,8 G#3,8 A3,16 R,16 G#3,16 R,16 A3,16 R,16 G#3,16 R,16 A3,16 R,16 G#3,16 R,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 26',
    v3: ['C5,16 A5,16 G5,16 A5,16 F#5,16 G5,16 E5,16 F#5,16 D#5,8 D#5,8 E5,8 F#5,8'],
    v5: ['R,2 R,16 B4,16 A4,16 B4,16 G4,16 A4,16 F#4,16 G4,16'],
    v7: ['A3,8 B3,8 C4,8 A3,8 B3,8 R,4.'],
    v8: ['R,1']
  },
  {
    label: '# Measure 27',
    v3: ['G5,8 R,16 E5,16 R,8 G5,8 F#5,4 R,4'],
    v5: ['E4,16 E5,16 B4,16 R,16 G4,16 B4,16 R,16 C5,16 R,16 C5,16 R,16 C5,16 R,16 C5,16 R,16 C5,16'],
    v7: ['R,4. E4,16 R,16 D#4,16 R,16 D#4,16 R,16 D#4,16 R,16 D#4,16 R,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 28',
    v3: ['R,8 B5,8 A#5,8 B5,8 R,2'],
    v5: ['R,8 B4,16 R,8. B4,16 R,16 E5,4 R,16 B4,16 R,16 B4,16'],
    v7: ['D4,16 F#4,16 R,16 F#4,16 D4,16 F#4,16 R,16 F#4,16 C#4,16 B4,16 C#4,16 B4,16 C#4,16 R,16 C#4,16 R,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 29',
    v3: ['R,8 A5,8 G#5,8 A5,8 D#5,8 E5,4 D#5,8'],
    v5: ['R,8 A4,16 R,8. A4,16 R,8 A4,16 G4,16 A4,16 F#4,16 B4,16 A4,16 B4,16'],
    v7: ['C4,16 E4,16 R,16 E4,16 C4,16 E4,16 R,16 E4,16 B3,16 R,4. R,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 30',
    v3: ['E5,4 R,16 B5,16 A5,16 B5,16 G5,8 F#5,8 E5,8 D5,8'],
    v5: ['G4,16 A4,16 F#4,16 G4,16 E4,4 R,16 E5,16 D5,16 E5,16 C#5,16 D5,16 B4,16 C#5,16'],
    v7: ['R,1'],
    v8: ['R,1']
  },
  {
    label: '# Measure 31',
    v3: ['C#5,4 F#5,8 E5,8 D5,8 R,16 B4,16 R,8 D5,8'],
    v5: ['A#4,4 R,16 B4,8 A#4,16 B4,16 B4,16 F#4,16 R,8 F#4,16 R,16 G4,16'],
    v7: ['R,16 F#4,16 E4,16 F#4,16 D4,16 E4,16 C#4,16 D4,16 B3,16 R,8. D4,16 R,16 B3,16 R,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 32',
    v3: ['C#5,4 R,4. C#5,8 D5,8 C#5,8'],
    v5: ['R,16 G4,16 R,16 G4,16 R,16 G4,16 R,16 G4,16 R,8 F#4,16 R,8. F#4,16 R,16'],
    v7: ['A#3,16 R,16 A#3,16 R,16 A#3,16 R,16 A#3,16 R,16 A3,16 C#4,16 R,16 C#4,16 A3,16 C#4,16 R,16 C#4,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 33',
    v3: ['B4,4 R,4. B4,8 C#5,8 B4,8'],
    v5: ['R,16 F#4,16 R,16 F#4,16 R,16 F#4,16 R,16 F#4,16 R,8 E4,16 R,8. E4,16 R,16'],
    v7: ['G#3,16 R,16 G#3,16 R,16 G#3,16 R,16 G#3,16 R,16 G3,16 B3,16 R,16 B3,16 G3,16 B3,16 R,16 B3,16'],
    v8: ['R,1']
  }
];

var MUSIC_BACH_914_BPM_3 = 116.1;
var MUSIC_BACH_914_MEASURE_MAP_3 = Bach914ScoreHelpers.buildMeasureMap(FUGUE_914_TRACKS_3, FUGUE_914_MEASURES_3, MUSIC_BACH_914_BPM_3);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_MEASURE_MAP_3 = MUSIC_BACH_914_MEASURE_MAP_3; }
var MUSIC_BACH_914_NOTATION_3 = Bach914ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue of the Toccata in E minor, BWV 914 (measures 13-33)',
  '# Converted from the aligned performance MIDI; timing follows the recording.'
], MUSIC_BACH_914_BPM_3, FUGUE_914_TRACKS_3, FUGUE_914_MEASURES_3);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_NOTATION_3 = MUSIC_BACH_914_NOTATION_3; }

// ---- Section 4: measures 34-47, 114.5 bpm ----
var FUGUE_914_TRACKS_4 = {
  v3: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 3.'
  },
  v5: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 5.'
  },
  v7: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 7.'
  },
  v8: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 8.'
  }
};

var FUGUE_914_MEASURES_4 = [
  {
    label: '# Measure 34',
    v3: ['A#4,8 B4,4 A#4,8 F#5,16 B4,16 E5,16 A#4,16 D5,16 G4,16 C#5,16 F#4,16'],
    v5: ['R,16 E4,16 D4,16 E4,16 C#4,16 F#4,16 E4,16 F#4,16 D4,8 C#4,8 B3,8 A3,8'],
    v7: ['F#3,16 R,2 F#4,16 R,16 E4,16 R,16 D4,16 R,16 C#4,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 35',
    v3: ['B4,16 E4,16 A4,16 D#4,16 G4,16 C#4,16 F#4,16 B3,16 E4,16 A#3,16 D4,16 B3,16 C#4,16 G#3,16 A#3,16 R,16'],
    v5: ['G3,8 F#3,8 E3,8 D3,8 C#3,8 B2,8 R,8. E3,16'],
    v7: ['R,16 B3,16 R,16 A3,16 R,16 G3,16 R,16 F#3,16 R,16 E3,16 R,16 D3,16 R,16 C#3,16 R,16 C#3,16'],
    v8: ['R,2. E2,8 F#2,8']
  },
  {
    label: '# Measure 36',
    v3: ['R,16 B3,16 F#3,16 A3,16 G3,16 E4,16 B3,16 D4,16 C4,16 F#4,16 C#4,16 E4,16 D4,16 G4,16 D#4,16 F#4,16'],
    v5: ['D#3,16 R,16 D#3,8 E3,8 G#3,8 A3,8 A#3,8 B3,8 R,8'],
    v7: ['B2,8 R,2. B2,8'],
    v8: ['R,1']
  },
  {
    label: '# Measure 37',
    v3: ['E4,16 E5,16 B4,16 D5,16 C5,8 R,8. D5,16 A4,16 C5,16 B4,8 F#4,16 A4,16'],
    v5: ['R,4 R,16 A3,16 R,16 G3,16 F#3,8 R,8. G3,16 R,16 F#3,16'],
    v7: ['C3,8 R,4 E3,16 R,4. R,16 D#3,16 R,16'],
    v8: ['R,8 G#2,8 A2,16 R,2 R,8.']
  },
  {
    label: '# Measure 38',
    v3: ['G4,16 A4,16 F#4,16 A4,16 G4,16 A4,16 F#4,16 A4,16 G4,16 B4,16 F#4,16 A4,16 G4,8 R,16 F4,16'],
    v5: ['R,16 B3,16 R,16 B3,16 R,16 B3,16 R,16 B3,16 R,4 R,16 B3,16 D4,16 R,16'],
    v7: ['E3,16 R,16 D#3,16 R,16 E3,16 R,16 D#3,16 R,16 E3,16 G3,16 D#3,16 F#3,16 E3,16 R,8 D3,16'],
    v8: ['R,2. R,8 B2,16 R,16']
  },
  {
    label: '# Measure 39',
    v3: ['E4,16 F4,16 R,16 F4,16 E4,16 F4,16 R,16 F4,16 E4,8. E4,16 F#4,16 G4,16 R,16 G4,16'],
    v5: ['R,8 D4,16 R,8. D4,16 R,4. R,16 E4,16 R,16'],
    v7: ['R,16 G3,16 R,16 G3,16 R,16 G3,16 R,16 G3,16 R,16 G3,16 R,16 A3,16 R,16 A3,16 R,16 A3,16'],
    v8: ['C3,16 R,16 B2,16 R,16 C3,16 R,16 B2,16 R,16 C3,16 R,16 C#3,16 R,16 D3,16 R,16 C#3,16 R,16']
  },
  {
    label: '# Measure 40',
    v3: ['F#4,8. F#4,16 G4,16 A4,16 R,16 A4,16 G#4,8. G#4,16 A4,16 B4,16 R,16 B4,16'],
    v5: ['R,4. F#4,16 R,4. R,16 G#4,16 R,16'],
    v7: ['R,16 A3,16 R,16 B3,16 R,16 B3,16 R,16 B3,16 R,16 B3,16 R,16 C#4,16 R,16 C#4,16 R,16 C#4,16'],
    v8: ['D3,16 R,16 D#3,16 R,16 E3,16 R,16 D#3,16 R,16 E3,16 R,16 F3,16 R,16 F#3,16 R,16 F3,16 R,16']
  },
  {
    label: '# Measure 41',
    v3: ['A#4,8 B4,16 R,8 R,32 D4,32 R,8. F#5,16 E5,16 F#5,16 D5,16 E5,16 C#5,16 D5,16'],
    v5: ['R,8. D4,16 D4,32 C#4,32 D4,32 C#4,32 C#4,16 B3,16 B3,8 R,8 B3,8 R,8'],
    v7: ['R,16 C#4,16 R,16 B3,16 R,16 B3,16 R,16 A#3,16 R,8 A#3,8 R,8 E3,8'],
    v8: ['F#3,16 R,16 D3,16 R,16 E3,16 R,16 F#3,16 R,16 D3,8 C#3,8 B2,8 A#2,8']
  },
  {
    label: '# Measure 42',
    v3: ['B4,16 B5,16 F#5,16 B5,16 D5,16 F#5,16 B4,16 G5,16 A#4,16 G5,16 A#4,16 G5,16 A#4,16 G5,16 A#4,16 G5,16'],
    v5: ['R,1'],
    v7: ['D3,4 R,8 D3,8 C#3,4 R,4'],
    v8: ['B2,4 R,8 B2,8 E3,4 R,4']
  },
  {
    label: '# Measure 43',
    v3: ['A4,16 C#5,16 F#5,16 C#5,16 A4,16 C#5,16 F#5,16 C#5,16 G#4,16 F#5,16 G#4,16 F#5,16 R,16 F#5,16 R,16 F#5,16'],
    v5: ['R,8 A3,8 G#3,8 A3,8 B3,4 G#4,16 R,16 G#4,16 R,16'],
    v7: ['R,2 B2,4 R,4'],
    v8: ['R,8 F#3,8 F3,8 F#3,8 R,2']
  },
  {
    label: '# Measure 44',
    v3: ['R,8 E5,16 R,8. E5,16 R,8 E5,16 D5,16 E5,16 C#5,16 F#5,16 E5,16 F#5,16'],
    v5: ['G4,16 B4,16 R,16 B4,16 G4,16 B4,16 R,16 B4,16 F#4,16 R,4. R,16'],
    v7: ['R,8 G3,8 F#3,8 G3,8 F#3,8 B3,4 A#3,8'],
    v8: ['R,8 E3,8 D#3,8 E3,8 A#2,8 B2,8 E3,8 F#3,8']
  },
  {
    label: '# Measure 45',
    v3: ['D5,16 E5,16 C#5,16 D5,16 B4,16 B4,16 A4,16 B4,16 G#4,16 A4,16 F#4,16 G#4,16 E4,4'],
    v5: ['R,4. D5,4. R,16 E5,16 D5,16 E5,16'],
    v7: ['B3,4 R,2 R,8 G#3,8'],
    v8: ['B2,4 R,8 B2,8 E3,4 R,4']
  },
  {
    label: '# Measure 46',
    v3: ['E4,4 E4,16. R,32 E4,8 D4,4 D4,16. R,32 E4,8'],
    v5: ['C5,16 D5,16 B4,16 C5,16 A4,8 C5,4 C5,8 B4,4'],
    v7: ['A3,4 R,16 A3,16 G3,16 A3,16 R,4 R,16 A3,16 R,8'],
    v8: ['R,2 F#3,16 G3,16 E3,16 F#3,16 G3,16 R,16 F#3,16 G3,16']
  },
  {
    label: '# Measure 47',
    v3: ['E4,8 F#4,4 G4,4 A4,4 B4,8'],
    v5: ['C5,4 D5,4 E5,16 F#5,16 D5,16 E5,16 F#5,16 G5,16 E5,16 F#5,16'],
    v7: ['A3,16 B3,16 R,16 A3,16 B3,16 C4,16 R,16 B3,16 C4,4 D4,4'],
    v8: ['R,8 G3,16 R,8. A3,16 R,2 R,16']
  }
];

var MUSIC_BACH_914_BPM_4 = 114.5;
var MUSIC_BACH_914_MEASURE_MAP_4 = Bach914ScoreHelpers.buildMeasureMap(FUGUE_914_TRACKS_4, FUGUE_914_MEASURES_4, MUSIC_BACH_914_BPM_4);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_MEASURE_MAP_4 = MUSIC_BACH_914_MEASURE_MAP_4; }
var MUSIC_BACH_914_NOTATION_4 = Bach914ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue of the Toccata in E minor, BWV 914 (measures 34-47)',
  '# Converted from the aligned performance MIDI; timing follows the recording.'
], MUSIC_BACH_914_BPM_4, FUGUE_914_TRACKS_4, FUGUE_914_MEASURES_4);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_NOTATION_4 = MUSIC_BACH_914_NOTATION_4; }

// ---- Section 5: measures 48-53, 115.7 bpm ----
var FUGUE_914_TRACKS_5 = {
  v3: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 3.'
  },
  v5: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 5.'
  },
  v7: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 7.'
  },
  v8: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 8.'
  }
};

var FUGUE_914_MEASURES_5 = [
  {
    label: '# Measure 48',
    v3: ['B4,8 C5,4 D5,4 C5,8 B4,8 R,8'],
    v5: ['G5,16 A5,16 F#5,16 G5,16 A5,16 B5,16 G5,16 A5,16 B5,16 C6,16 A5,16 B5,16 G5,16 A5,16 F#5,16 A5,16'],
    v7: ['E4,4 F#4,4 G4,8 R,4 A4,8'],
    v8: ['R,2 R,8 C4,8 D4,4']
  },
  {
    label: '# Measure 49',
    v3: ['B4,4 R,2.'],
    v5: ['G5,4 R,4 R,16 A5,16 G5,16 A5,16 F#5,16 G5,16 E5,16 F#5,16'],
    v7: ['R,1'],
    v8: ['R,16 G3,16 F#3,16 G3,16 E3,16 F#3,16 D3,16 E3,16 C#3,8 A2,8 D3,8 C3,8']
  },
  {
    label: '# Measure 50',
    v3: ['D5,4 R,16 E5,16 D5,16 E5,16 C5,4 R,16 D5,16 C5,16 D5,16'],
    v5: ['R,1'],
    v7: ['R,16 B3,16 A3,16 B3,16 G#3,4 R,16 A3,16 G3,16 A3,16 F#3,4'],
    v8: ['B2,16 R,2. R,8.']
  },
  {
    label: '# Measure 51',
    v3: ['B4,16 G4,16 F#4,16 E4,16 D#4,8 R,8. E4,16 D4,16 C4,16 B3,8 R,8'],
    v5: ['R,16 E5,16 D#5,16 E5,16 F#5,16 A4,16 B4,16 A4,16 G4,16 C5,16 B4,16 C5,16 D5,16 F4,16 G4,16 F4,16'],
    v7: ['G3,16 R,4 R,16 D#3,8 E3,16 R,4. R,16'],
    v8: ['R,2. R,8 B2,8']
  },
  {
    label: '# Measure 52',
    v3: ['R,16 C4,16 B3,16 A3,16 G#3,8 R,2 A3,8'],
    v5: ['E4,16 A4,16 G#4,16 A4,16 B4,16 D4,16 E4,16 D4,16 C4,16 A4,16 G4,16 A4,16 F#4,16 G4,16 E4,16 F#4,16'],
    v7: ['R,1'],
    v8: ['C3,16 R,4 R,16 G#2,8 A2,4 R,4']
  },
  {
    label: '# Measure 53',
    v3: ['B3,16 C4,16 A3,16 B3,16 R,16 E4,16 R,16 D#4,16 R,16 C4,16 R,16 B3,16 R,16 A3,16 R,16 G#3,16'],
    v5: ['D#4,8 F#4,8 B4,16 R,16 A4,16 R,16 G4,16 E4,16 F#4,16 D4,16 E4,16 C4,16 D4,16 B3,16'],
    v7: ['R,4 G3,16 A3,16 F#3,16 G3,16 E3,16 R,16 D3,16 R,16 C3,16 R,16 B2,16 R,16'],
    v8: ['R,1']
  }
];

var MUSIC_BACH_914_BPM_5 = 115.7;
var MUSIC_BACH_914_MEASURE_MAP_5 = Bach914ScoreHelpers.buildMeasureMap(FUGUE_914_TRACKS_5, FUGUE_914_MEASURES_5, MUSIC_BACH_914_BPM_5);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_MEASURE_MAP_5 = MUSIC_BACH_914_MEASURE_MAP_5; }
var MUSIC_BACH_914_NOTATION_5 = Bach914ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue of the Toccata in E minor, BWV 914 (measures 48-53)',
  '# Converted from the aligned performance MIDI; timing follows the recording.'
], MUSIC_BACH_914_BPM_5, FUGUE_914_TRACKS_5, FUGUE_914_MEASURES_5);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_NOTATION_5 = MUSIC_BACH_914_NOTATION_5; }

// ---- Section 6: measures 54-56, 109.6 bpm ----
var FUGUE_914_TRACKS_6 = {
  v3: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 3.'
  },
  v5: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 5.'
  },
  v7: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 7.'
  },
  v8: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 8.'
  }
};

var FUGUE_914_MEASURES_6 = [
  {
    label: '# Measure 54',
    v3: ['A3,16 F#3,16 G3,16 E3,16 F#3,16 D#3,16 E3,16 C#3,16 D#3,8 E3,8 R,4'],
    v5: ['C4,16 A4,16 B3,16 G4,16 R,16 F#4,16 R,16 E4,16 R,16 F#4,16 R,16 E4,16 R,16 E4,16 R,16 D#4,16'],
    v7: ['R,4 A3,16 R,16 G3,16 R,16 F#3,16 R,16 G3,16 R,16 F#3,16 R,16 F#3,16 R,16'],
    v8: ['R,2. A2,8 B2,8']
  },
  {
    label: '# Measure 55',
    v3: ['R,4 G3,16 R,16 F#3,16 G3,16 E3,16 R,8. G3,16 B3,16 E3,16 R,16'],
    v5: ['E4,8 R,8. B4,16 A4,16 B4,16 G4,4 R,8 G4,8'],
    v7: ['R,16 B3,16 A3,16 B3,16 R,16 A3,16 R,8. E4,16 B3,16 E4,16 R,8. C4,16'],
    v8: ['E2,8 R,2. R,8']
  },
  {
    label: '# Measure 56',
    v3: ['D#3,16 R,16 D#3,16 R,16 D#3,16 R,16 D#3,16 R,16 D3,16 F#3,16 R,16 F#3,16 D3,16 F#3,16 R,16 F#3,16'],
    v5: ['F#4,16 E4,16 F#4,16 E4,16 F#4,16 E4,16 F#4,16 E4,16 F#4,8 R,16 B4,16 A#4,8 B4,8'],
    v7: ['R,16 C4,16 R,16 C4,16 R,16 C4,16 R,16 C4,16 R,8 B3,16 R,8. B3,16 R,16'],
    v8: ['R,1']
  }
];

var MUSIC_BACH_914_BPM_6 = 109.6;
var MUSIC_BACH_914_MEASURE_MAP_6 = Bach914ScoreHelpers.buildMeasureMap(FUGUE_914_TRACKS_6, FUGUE_914_MEASURES_6, MUSIC_BACH_914_BPM_6);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_MEASURE_MAP_6 = MUSIC_BACH_914_MEASURE_MAP_6; }
var MUSIC_BACH_914_NOTATION_6 = Bach914ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue of the Toccata in E minor, BWV 914 (measures 54-56)',
  '# Converted from the aligned performance MIDI; timing follows the recording.'
], MUSIC_BACH_914_BPM_6, FUGUE_914_TRACKS_6, FUGUE_914_MEASURES_6);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_NOTATION_6 = MUSIC_BACH_914_NOTATION_6; }

// ---- Section 7: measures 57-67, 113.8 bpm ----
var FUGUE_914_TRACKS_7 = {
  v3: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 3.'
  },
  v5: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 5.'
  },
  v7: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 7.'
  },
  v8: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 8.'
  }
};

var FUGUE_914_MEASURES_7 = [
  {
    label: '# Measure 57',
    v3: ['C#3,16 R,16 C#3,16 R,16 C#3,16 R,16 C#3,16 R,16 C3,16 E3,16 R,16 E3,16 C3,16 E3,16 R,16 E3,16'],
    v5: ['R,16 D#4,16 E4,16 D#4,16 E4,16 D#4,16 E4,16 D#4,16 E4,8 R,16 A4,16 G#4,8 A4,8'],
    v7: ['E4,16 B3,16 R,16 B3,16 R,16 B3,16 R,16 B3,16 R,8 A3,16 R,8. A3,16 R,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 58',
    v3: ['B2,16 A3,16 G3,16 A3,16 F#3,16 R,8. G3,16 R,8. A3,16 R,8.'],
    v5: ['R,4 A4,8 D#4,8 B4,8 E4,8 C5,8 F#4,8'],
    v7: ['D#4,8 E4,8 R,16 B3,16 A3,16 B3,16 R,16 C4,16 B3,16 C4,16 R,16 D4,16 C4,16 D4,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 59',
    v3: ['B3,16 R,8. C4,16 R,8. D4,16 R,8. E4,16 R,8.'],
    v5: ['D5,8 G4,8 E5,8 A4,8 F#5,8 B4,8 G5,8 C#5,8'],
    v7: ['R,16 E4,16 D4,16 E4,16 R,16 F#4,16 E4,16 F#4,16 R,16 G4,16 F#4,16 G4,16 R,16 A4,16 G4,16 A4,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 60',
    v3: ['F#4,16 R,8. G4,16 R,8. A4,8 R,4 B4,16 C5,16'],
    v5: ['A5,8 D#5,8 B5,8 E5,8 C6,16 B5,16 A5,16 G#5,16 A5,16 B5,16 G5,16 A5,16'],
    v7: ['R,16 B4,16 A4,16 B4,16 R,16 C5,16 B4,16 C5,16 R,8 B4,8 C5,16 D5,16 R,8'],
    v8: ['R,1']
  },
  {
    label: '# Measure 61',
    v3: ['A4,16 B4,16 G4,16 A4,16 F#4,16 A4,16 G4,16 F#4,16 G4,16 A4,16 F#4,16 A4,16 G4,16 A4,16 F#4,16 A4,16'],
    v5: ['F#5,16 G5,16 R,16 F#5,16 R,16 F#5,16 R,8. B5,16 R,16 B5,16 R,16 B5,16 R,16 B5,16'],
    v7: ['R,8 E5,16 R,16 D#5,16 R,16 E5,16 D#5,16 E5,16 R,16 D#5,16 R,16 E5,16 R,16 D#5,16 R,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 62',
    v3: ['G4,8 G#4,8 A4,8 G4,8 F#4,8 G4,8 F#4,8 E4,8'],
    v5: ['R,16 B5,16 R,2. R,8'],
    v7: ['E5,16 R,16 B4,16 D5,16 C5,16 D5,16 B4,16 C5,16 A4,16 C5,16 B4,16 C5,16 A4,16 B4,16 G4,16 A4,16'],
    v8: ['R,1']
  },
  {
    label: '# Measure 63',
    v3: ['D#4,8 R,4. R,16 E4,16 B3,16 E4,16 G3,16 B3,16 E3,16 C4,16'],
    v5: ['R,8 D#5,8 E5,8 D#5,8 E5,4 R,8 G4,8'],
    v7: ['F#4,8 B4,8 C#5,8 F#5,8 G5,4 R,8 E5,8'],
    v8: ['R,16 B2,16 A2,16 B2,16 G2,16 A2,16 F#2,16 G2,16 E2,16 R,4. R,16']
  },
  {
    label: '# Measure 64',
    v3: ['D#3,16 C4,16 D#3,16 C4,16 D#3,16 R,16 D#3,16 R,16 D3,16 F#3,16 B4,8 A#4,8 B4,8'],
    v5: ['F#4,4 R,16 C4,16 R,16 C4,16 R,8 B3,16 F#3,16 D3,16 F#3,16 B3,16 F#3,16'],
    v7: ['F#5,16 E5,16 F#5,16 E5,16 F#5,16 E5,16 F#5,16 E5,16 F#5,4 R,8 F#5,8'],
    v8: ['R,1']
  },
  {
    label: '# Measure 65',
    v3: ['E4,4 R,4. A4,8 G#4,8 A4,8'],
    v5: ['C#3,16 B3,16 R,16 B3,16 R,16 B3,16 R,16 B3,16 R,8 A3,16 R,8. A3,16 R,16'],
    v7: ['E5,16 D#5,16 E5,16 D#5,16 E5,16 D#5,16 E5,16 D#5,16 E5,4 R,8 E5,8'],
    v8: ['R,8 C#3,16 R,16 C#3,16 R,16 C#3,16 R,16 C3,16 E3,16 R,16 E3,16 C3,16 E3,16 R,16 E3,16']
  },
  {
    label: '# Measure 66',
    v3: ['F#4,8 E5,4 D#5,8 B4,8 B4,8 B4,8 B4,8'],
    v5: ['R,16 A3,16 G3,16 A3,16 F#3,16 B3,16 A3,16 B3,16 G3,16 A3,16 F#3,16 A3,16 G3,16 A3,16 F#3,16 A3,16'],
    v7: ['D#5,8 B4,8 A4,8 F#4,8 E5,16 B5,16 D#5,16 B5,16 E5,16 B5,16 D#5,16 B5,16'],
    v8: ['B2,16 R,2. R,8.']
  },
  {
    label: '# Measure 67',
    v3: ['B4,8 B4,8 B4,8 B4,8 B4,8 B4,8 B4,8 B4,8'],
    v5: ['G3,16 A3,16 F#3,16 A3,16 G3,16 A3,16 F#3,16 A3,16 G3,16 A3,16 F#3,16 A3,16 G3,16 A3,16 F#3,16 A3,16'],
    v7: ['E5,16 B5,16 D#5,16 B5,16 E5,16 B5,16 D#5,16 B5,16 E5,16 B5,16 D#5,16 B5,16 E5,16 B5,16 D#5,16 B5,16'],
    v8: ['R,1']
  }
];

var MUSIC_BACH_914_BPM_7 = 113.8;
var MUSIC_BACH_914_MEASURE_MAP_7 = Bach914ScoreHelpers.buildMeasureMap(FUGUE_914_TRACKS_7, FUGUE_914_MEASURES_7, MUSIC_BACH_914_BPM_7);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_MEASURE_MAP_7 = MUSIC_BACH_914_MEASURE_MAP_7; }
var MUSIC_BACH_914_NOTATION_7 = Bach914ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue of the Toccata in E minor, BWV 914 (measures 57-67)',
  '# Converted from the aligned performance MIDI; timing follows the recording.'
], MUSIC_BACH_914_BPM_7, FUGUE_914_TRACKS_7, FUGUE_914_MEASURES_7);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_NOTATION_7 = MUSIC_BACH_914_NOTATION_7; }

// ---- Section 8: measures 68-70, 103.3 bpm ----
var FUGUE_914_TRACKS_8 = {
  v3: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 3.'
  },
  v5: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 5.'
  },
  v7: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 7.'
  },
  v8: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 8.'
  }
};

var FUGUE_914_MEASURES_8 = [
  {
    label: '# Measure 68',
    v3: ['B4,8 R,16 G4,16 E4,8 E4,8 E4,8 E4,8 B3,8 B2,8'],
    v5: ['G3,32 E3,32 G3,32 C4,32 E4,16 E4,16 B3,8 A4,16 B4,16 A4,16 B4,16 A4,16 B4,16 F#4,8 F#4,8'],
    v7: ['E5,8 R,8 F#4,16 B4,16 F#4,8 F#4,8 F#4,8 E4,8 E4,8'],
    v8: ['R,8. E3,16 R,8 B2,8 R,8 B2,8 A4,16 B4,16 A4,16 B4,16']
  },
  {
    label: '# Measure 69',
    v3: ['R,16 B2,16 A4,16 B4,16 F#4,8 F#4,8 F#4,8 E4,8 E4,8 D#4,8'],
    v5: ['F#4,8 D#4,8 C4,16 B3,16 C4,16 A3,16 B3,32 A3,32 G3,16 A4,16 B4,16 A4,16 B4,16 A4,16 B4,16'],
    v7: ['D#4,8 B3,16 G3,16 A4,16 B4,16 A4,16 B4,16 A4,16 B4,16 F#4,8 F#4,8 F#4,8'],
    v8: ['A4,16 B4,16 F#4,8 E4,8 E4,8 D#4,8 C4,32 B3,32 A3,16 B3,8 B2,8']
  },
  {
    label: '# Measure 70',
    v3: ['R,2 R,16 D#4,16 E4,16 R,16 E4,16 R,8.'],
    v5: ['R,16 A4,16 B4,16 R,8. B4,16 R,2 R,16'],
    v7: ['R,8. F#4,16 G#4,16 A4,16 R,16 F#4,16 G#4,16 R,8 F#4,16 R,4'],
    v8: ['E3,4 R,2 R,16 A3,16 B3,16 F#3,16']
  }
];

var MUSIC_BACH_914_BPM_8 = 103.3;
var MUSIC_BACH_914_MEASURE_MAP_8 = Bach914ScoreHelpers.buildMeasureMap(FUGUE_914_TRACKS_8, FUGUE_914_MEASURES_8, MUSIC_BACH_914_BPM_8);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_MEASURE_MAP_8 = MUSIC_BACH_914_MEASURE_MAP_8; }
var MUSIC_BACH_914_NOTATION_8 = Bach914ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue of the Toccata in E minor, BWV 914 (measures 68-70)',
  '# Converted from the aligned performance MIDI; timing follows the recording.'
], MUSIC_BACH_914_BPM_8, FUGUE_914_TRACKS_8, FUGUE_914_MEASURES_8);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_NOTATION_8 = MUSIC_BACH_914_NOTATION_8; }

// ---- Section 9: measures 71-72, 101.1 bpm ----
var FUGUE_914_TRACKS_9 = {
  v1: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 1.'
  },
  v2: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 2.'
  },
  v3: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 3.'
  },
  v4: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 4.'
  },
  v5: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 5.'
  },
  v6: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 6.'
  },
  v7: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 7.'
  },
  v8: {
    instrument: 'fmpiano',
    header: '# BWV 914 voice 8.'
  }
};

var FUGUE_914_MEASURES_9 = [
  {
    label: '# Measure 71',
    v1: ['R,1'],
    v2: ['R,2. R,16 B4,8.'],
    v3: ['R,8 E4,16 R,4. R,16 G#2,4.'],
    v4: ['R,2. R,8 G#4,8'],
    v5: ['R,2. E3,4'],
    v6: ['R,2. R,8. E4,16'],
    v7: ['R,2. E2,4'],
    v8: ['G#3,16 B3,16 R,16 B3,16 G#3,16 D#3,16 E3,16 B2,16 G#2,16 E2,8 B2,4 B2,16']
  },
  {
    label: '# Measure 72',
    v1: ['E5,1'],
    v2: ['B4,1'],
    v3: ['G#2,1'],
    v4: ['G#4,1'],
    v5: ['E3,1'],
    v6: ['E4,1'],
    v7: ['E2,1'],
    v8: ['B2,1']
  }
];

var MUSIC_BACH_914_BPM_9 = 101.1;
var MUSIC_BACH_914_MEASURE_MAP_9 = Bach914ScoreHelpers.buildMeasureMap(FUGUE_914_TRACKS_9, FUGUE_914_MEASURES_9, MUSIC_BACH_914_BPM_9);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_MEASURE_MAP_9 = MUSIC_BACH_914_MEASURE_MAP_9; }
var MUSIC_BACH_914_NOTATION_9 = Bach914ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue of the Toccata in E minor, BWV 914 (measures 71-72)',
  '# Converted from the aligned performance MIDI; timing follows the recording.'
], MUSIC_BACH_914_BPM_9, FUGUE_914_TRACKS_9, FUGUE_914_MEASURES_9);
if (typeof window !== 'undefined') { window.MUSIC_BACH_914_NOTATION_9 = MUSIC_BACH_914_NOTATION_9; }

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    MUSIC_BACH_914_NOTATION: MUSIC_BACH_914_NOTATION,
    MUSIC_BACH_914_MEASURE_MAP: MUSIC_BACH_914_MEASURE_MAP,
    MUSIC_BACH_914_NOTATION_2: MUSIC_BACH_914_NOTATION_2,
    MUSIC_BACH_914_MEASURE_MAP_2: MUSIC_BACH_914_MEASURE_MAP_2,
    MUSIC_BACH_914_NOTATION_3: MUSIC_BACH_914_NOTATION_3,
    MUSIC_BACH_914_MEASURE_MAP_3: MUSIC_BACH_914_MEASURE_MAP_3,
    MUSIC_BACH_914_NOTATION_4: MUSIC_BACH_914_NOTATION_4,
    MUSIC_BACH_914_MEASURE_MAP_4: MUSIC_BACH_914_MEASURE_MAP_4,
    MUSIC_BACH_914_NOTATION_5: MUSIC_BACH_914_NOTATION_5,
    MUSIC_BACH_914_MEASURE_MAP_5: MUSIC_BACH_914_MEASURE_MAP_5,
    MUSIC_BACH_914_NOTATION_6: MUSIC_BACH_914_NOTATION_6,
    MUSIC_BACH_914_MEASURE_MAP_6: MUSIC_BACH_914_MEASURE_MAP_6,
    MUSIC_BACH_914_NOTATION_7: MUSIC_BACH_914_NOTATION_7,
    MUSIC_BACH_914_MEASURE_MAP_7: MUSIC_BACH_914_MEASURE_MAP_7,
    MUSIC_BACH_914_NOTATION_8: MUSIC_BACH_914_NOTATION_8,
    MUSIC_BACH_914_MEASURE_MAP_8: MUSIC_BACH_914_MEASURE_MAP_8,
    MUSIC_BACH_914_NOTATION_9: MUSIC_BACH_914_NOTATION_9,
    MUSIC_BACH_914_MEASURE_MAP_9: MUSIC_BACH_914_MEASURE_MAP_9
  };
}
