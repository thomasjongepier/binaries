// Spelunker - parser for the plain-text music notation format described in
// MUSIC_FORMAT.md. Vanilla JS, no build tools, no dependencies, no ES
// modules. Attaches to window.Game (created by main.js), following the same
// shared-namespace pattern used by audio.js/cave.js/ship.js/enemy.js.
//
// Nothing in the codebase calls Game.MusicParser yet - this is pure parsing
// logic, wiring it into audio.js's playback is left to a later task (see
// MUSIC_FORMAT.md and the spelunker-a35 epic).
(function () {
  'use strict';

  // In a browser this attaches to window.Game (set up by main.js). Under
  // Node (e.g. `node music-parser.js` for standalone testing, see bottom of
  // file) there is no window/Game, so fall back to a throwaway object -
  // module.exports below is what standalone test scripts actually use.
  var isNode = typeof window === 'undefined';
  var Game = isNode ? {} : window.Game;
  if (!isNode && !Game) {
    throw new Error('music-parser.js requires window.Game to be set up by main.js first');
  }

  // Semitone offsets from A (within the same octave number), per
  // MUSIC_FORMAT.md §2.6. Keys are normalized to uppercase letter + optional
  // accidental exactly as written in the spec's table.
  var SEMITONE_TABLE = {
    'C': -9,
    'C#': -8, 'Db': -8,
    'D': -7,
    'D#': -6, 'Eb': -6,
    'E': -5,
    'F': -4,
    'F#': -3, 'Gb': -3,
    'G': -2,
    'G#': -1, 'Ab': -1,
    'A': 0,
    'A#': 1, 'Bb': 1,
    'B': 2
  };

  var VALID_DENOMINATORS = { '1': true, '2': true, '4': true, '8': true, '16': true, '32': true };
  var VALID_INSTRUMENTS = { 'organ': true, 'lead': true, 'harpsichord': true, 'fmpiano': true };
  var DEFAULT_TEMPO = 120;
  var DEFAULT_INSTRUMENT = 'organ';

  // Matches a TEMPO directive line, e.g. "TEMPO 120" or "TEMPO 96.5".
  var TEMPO_RE = /^TEMPO\s+(-?\d+(?:\.\d+)?)\s*$/i;

  // Matches a TRACK header line, e.g. "TRACK melody organ" or "TRACK bass".
  var TRACK_RE = /^TRACK\s+(\S+)(?:\s+(\S+))?\s*$/i;

  // Matches a single pitch token, e.g. "A5,8", "A#5,8", "Bb4,4.".
  // Per §2.2, the accidental (if any) must appear between the note letter
  // and the octave digits - this regex enforces that ordering by construction.
  // NOTE: the denominator alternation is ordered "16|32|1|2|4|8" (longest
  // first) deliberately - JS regex alternation picks the first alternative
  // that matches at a position rather than the longest, so "1|2|4|8|16|32"
  // would match just the "1" in "16" and leave a stray "6" behind.
  var PITCH_RE = /^([A-Ga-g])([#b]?)(\d+),(16|32|1|2|4|8)(\.?)$/;

  // Matches a rest token, e.g. "R,8" or "R,4.". Same longest-first
  // alternation-ordering note as PITCH_RE above applies here.
  var REST_RE = /^[Rr],(16|32|1|2|4|8)(\.?)$/;

  // Converts a duration token's denominator (+ optional dot) into seconds,
  // per MUSIC_FORMAT.md §4: base_seconds = (60/BPM) * (4/denominator),
  // dotted notes multiply that by 1.5.
  function durationToSeconds(denominator, isDotted, bpm) {
    var baseSeconds = (60 / bpm) * (4 / denominator);
    return isDotted ? baseSeconds * 1.5 : baseSeconds;
  }

  // Converts a note letter + accidental + octave into a frequency in Hz,
  // per MUSIC_FORMAT.md §2.6: freq = 440 * 2^(semitone_offset_from_A4 / 12).
  function noteToFrequency(letter, accidental, octave) {
    var pitchClass = letter.toUpperCase() + accidental;
    var tableOffset = SEMITONE_TABLE[pitchClass];
    if (tableOffset === undefined) {
      throw new Error('music-parser: invalid pitch class "' + pitchClass + '"');
    }
    var semitoneOffset = tableOffset + (octave - 4) * 12;
    return 440 * Math.pow(2, semitoneOffset / 12);
  }

  // A single note/rest token, per the §2.1 grammar. Used to scan a
  // note-line's body for tokens directly, rather than splitting on
  // "[ \t,]+" first - naive splitting would incorrectly break a single
  // token like "A5,8" apart, since its internal pitch/duration comma is
  // indistinguishable, character-for-character, from the comma that (per
  // §1) may *also* separate two whole tokens (e.g. "A5,8,R,8"). Scanning
  // for whole tokens and treating any run of [ \t,]+ *between* them as a
  // separator sidesteps that ambiguity.
  // Same longest-first alternation-ordering note as PITCH_RE/REST_RE above:
  // "16"/"32" must be tried before "1" or the scan would stop mid-denominator.
  var TOKEN_RE = /[A-Ga-g][#b]?\d+,(?:16|32|1|2|4|8)\.?|[Rr],(?:16|32|1|2|4|8)\.?/g;

  // Splits a note-line's body into individual note/rest tokens. Per §1,
  // any run of comma/space/tab characters between tokens is treated as a
  // single delimiter, so "A5,8 R,8", "A5,8,R,8", and "A5,8   R,8" are all
  // equivalent token sequences. Anything on the line that isn't a
  // recognized token or a separator run is surfaced as a stray/unparseable
  // token so malformed input still errors out rather than being silently
  // dropped.
  function splitTokens(line) {
    var trimmed = line.replace(/^[ \t,]+|[ \t,]+$/g, '');
    if (trimmed === '') {
      return [];
    }

    var tokens = [];
    var cursor = 0;
    TOKEN_RE.lastIndex = 0;
    var match;
    while ((match = TOKEN_RE.exec(trimmed)) !== null) {
      if (match.index !== cursor) {
        // Whatever sits between cursor and match.index must be pure
        // separator chars ([ \t,]+); anything else is a stray token.
        var gap = trimmed.slice(cursor, match.index);
        if (!/^[ \t,]+$/.test(gap)) {
          tokens.push(gap.replace(/^[ \t,]+/, ''));
        }
      }
      tokens.push(match[0]);
      cursor = TOKEN_RE.lastIndex;
    }
    if (cursor < trimmed.length) {
      var tail = trimmed.slice(cursor);
      if (!/^[ \t,]+$/.test(tail)) {
        tokens.push(tail.replace(/^[ \t,]+/, ''));
      }
    }
    return tokens;
  }

  // Parses one note/rest token into a structured note object, given the
  // piece's (already-resolved) BPM.
  function parseNoteToken(token, bpm) {
    var restMatch = REST_RE.exec(token);
    if (restMatch) {
      var restDenominator = parseInt(restMatch[1], 10);
      var restDotted = restMatch[2] === '.';
      return {
        freq: 0,
        duration: durationToSeconds(restDenominator, restDotted, bpm),
        isRest: true
      };
    }

    var pitchMatch = PITCH_RE.exec(token);
    if (pitchMatch) {
      var letter = pitchMatch[1];
      var accidental = pitchMatch[2];
      var octave = parseInt(pitchMatch[3], 10);
      var denominator = parseInt(pitchMatch[4], 10);
      var dotted = pitchMatch[5] === '.';

      if (octave < 0 || octave > 8) {
        throw new Error('music-parser: octave out of range (0-8) in note token "' + token + '"');
      }
      // VALID_DENOMINATORS is redundant with the regex's alternation but
      // kept as an explicit guard in case the regex is ever loosened.
      if (!VALID_DENOMINATORS[String(denominator)]) {
        throw new Error('music-parser: invalid duration denominator in note token "' + token + '"');
      }

      return {
        freq: noteToFrequency(letter, accidental, octave),
        duration: durationToSeconds(denominator, dotted, bpm),
        isRest: false
      };
    }

    throw new Error('music-parser: unrecognized note/rest token "' + token + '"');
  }

  // Computes the total duration (in seconds) of a single note-string (one
  // measure-part line, e.g. 'D4,16 A4,16 C#4,16 A4,16') at a given BPM.
  // Reuses the same TOKEN_RE scanning + durationToSeconds() logic that
  // parseNoteToken() uses internally, so duration math lives in exactly one
  // place.
  function durationOfNoteString(str, bpm) {
    var tokens = splitTokens(str);
    var total = 0;
    for (var t = 0; t < tokens.length; t++) {
      total += parseNoteToken(tokens[t], bpm).duration;
    }
    return total;
  }

  // Parses a full notation text (per MUSIC_FORMAT.md) into a structured,
  // multi-track note schedule:
  //
  //   {
  //     tempo: <number>,           // resolved BPM (default 120 if omitted)
  //     tracks: [
  //       {
  //         name: <string>,
  //         instrument: 'organ' | 'lead' | 'harpsichord' | 'fmpiano',
  //         notes: [
  //           { freq: <Hz number>, duration: <seconds number>, isRest: <bool> },
  //           ...
  //         ]
  //       },
  //       ...
  //     ]
  //   }
  //
  // Rests are represented as { freq: 0, duration: <seconds>, isRest: true }
  // (freq is not meaningful for rests; isRest is the authoritative flag).
  //
  // Throws an Error (with a descriptive message) for any malformed input,
  // including: a TEMPO line appearing more than once or after a TRACK
  // header, a duplicate TRACK name, an unrecognized instrument keyword, an
  // out-of-range octave, or an unparseable note/rest token.
  function parse(notationText) {
    var lines = notationText.split(/\r\n|\r|\n/);

    var tempo = null;
    var tracks = [];
    var trackNames = Object.create(null);
    var currentTrack = null;
    var sawTrack = false;

    for (var i = 0; i < lines.length; i++) {
      var rawLine = lines[i];
      var line = rawLine.replace(/^\s+|\s+$/g, '');

      if (line === '') {
        continue; // blank line, ignored
      }
      if (line.charAt(0) === '#') {
        continue; // comment line, ignored
      }

      var tempoMatch = TEMPO_RE.exec(line);
      if (tempoMatch) {
        if (tempo !== null) {
          throw new Error('music-parser: TEMPO may only appear once (line ' + (i + 1) + ')');
        }
        if (sawTrack) {
          throw new Error('music-parser: TEMPO must appear before any TRACK block (line ' + (i + 1) + ')');
        }
        var parsedTempo = parseFloat(tempoMatch[1]);
        if (!isFinite(parsedTempo) || parsedTempo <= 0) {
          throw new Error('music-parser: TEMPO must be a positive number, got "' + tempoMatch[1] + '" (line ' + (i + 1) + ')');
        }
        tempo = parsedTempo;
        continue;
      }

      var trackMatch = TRACK_RE.exec(line);
      if (trackMatch) {
        sawTrack = true;
        var trackName = trackMatch[1];
        var instrumentRaw = trackMatch[2];
        var instrument = instrumentRaw ? instrumentRaw.toLowerCase() : DEFAULT_INSTRUMENT;

        if (!VALID_INSTRUMENTS[instrument]) {
          throw new Error('music-parser: unrecognized instrument "' + instrumentRaw + '" (line ' + (i + 1) + ')');
        }
        if (trackNames[trackName]) {
          throw new Error('music-parser: duplicate TRACK name "' + trackName + '" (line ' + (i + 1) + ')');
        }
        trackNames[trackName] = true;

        currentTrack = { name: trackName, instrument: instrument, notes: [] };
        tracks.push(currentTrack);
        continue;
      }

      // Otherwise this line is (part of) a note sequence body.
      if (!currentTrack) {
        throw new Error('music-parser: note tokens found before any TRACK header (line ' + (i + 1) + ')');
      }

      var resolvedBpm = tempo === null ? DEFAULT_TEMPO : tempo;
      var tokens = splitTokens(line);
      for (var t = 0; t < tokens.length; t++) {
        try {
          currentTrack.notes.push(parseNoteToken(tokens[t], resolvedBpm));
        } catch (err) {
          throw new Error(err.message + ' (line ' + (i + 1) + ')');
        }
      }
    }

    if (tracks.length === 0) {
      throw new Error('music-parser: song must contain at least one non-empty TRACK');
    }
    for (var trackIndex = 0; trackIndex < tracks.length; trackIndex++) {
      if (tracks[trackIndex].notes.length === 0) {
        throw new Error('music-parser: TRACK "' + tracks[trackIndex].name + '" must contain at least one note');
      }
    }

    return {
      tempo: tempo === null ? DEFAULT_TEMPO : tempo,
      tracks: tracks
    };
  }

  Game.MusicParser = {
    parse: parse,
    durationOfNoteString: durationOfNoteString
  };

  // Allow standalone `node music-parser.js` execution for quick manual
  // testing outside the browser (no-op inside a browser, since `module`
  // is undefined there).
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { parse: parse, durationOfNoteString: durationOfNoteString };
  }
})();
