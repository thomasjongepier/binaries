// highscores.js - persistent top-10 table, initials entry and table screen.
//
// Game.HighScores: list(), qualifies(score), insert(entry), clear(), reload().
// Entry: { initials: 'ABC' (A-Z or '-'), score, distance, kills, date }.
// All localStorage access is wrapped in try/catch; corrupt storage reads as an
// empty table. In-memory results still work when storage throws.
//
// Initials entry (GAMEOVER): main.js calls beginEntry(stats) when a run ends,
// routes keydowns to handleEntryKey(e) (returns true when consumed, so the key
// never restarts the game) and draws renderEntry(ctx). The table screen
// (STATES.HIGHSCORES) is drawn by render(ctx); Escape or a click returns to
// the title menu.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  var STORAGE_KEY = 'spelunker.highscores';
  var MAX_ENTRIES = 10;
  var W = 640;

  var table = [];
  var lastInserted = null; // the entry object most recently inserted (for highlight)

  function getStorage() {
    try { return window.localStorage || null; } catch (e) { return null; }
  }

  function num(v) {
    v = Math.floor(Number(v));
    return isFinite(v) && v > 0 ? v : 0;
  }

  function cleanInitials(s) {
    s = typeof s === 'string' ? s.toUpperCase() : '';
    return /^[A-Z-]{3}$/.test(s) ? s : '---';
  }

  function clean(e) {
    if (!e || typeof e !== 'object') return null;
    var score = Number(e.score);
    if (!isFinite(score) || score < 0) return null;
    return {
      initials: cleanInitials(e.initials),
      score: Math.floor(score),
      distance: num(e.distance),
      kills: num(e.kills),
      date: typeof e.date === 'string' ? e.date : ''
    };
  }

  function sortCap(arr) {
    // Stable: equal scores keep insertion order (older first).
    var indexed = arr.map(function (e, i) { return { e: e, i: i }; });
    indexed.sort(function (a, b) { return (b.e.score - a.e.score) || (a.i - b.i); });
    return indexed.slice(0, MAX_ENTRIES).map(function (x) { return x.e; });
  }

  function load() {
    table = [];
    lastInserted = null;
    var raw = null;
    try {
      var s = getStorage();
      if (s) raw = s.getItem(STORAGE_KEY);
    } catch (e) { return; }
    if (typeof raw !== 'string') return;
    var parsed;
    try { parsed = JSON.parse(raw); } catch (e) { return; }
    if (!Array.isArray(parsed)) return;
    var out = [];
    for (var i = 0; i < parsed.length; i++) {
      var c = clean(parsed[i]);
      if (c) out.push(c);
    }
    table = sortCap(out);
  }

  function save() {
    try {
      var s = getStorage();
      if (s) s.setItem(STORAGE_KEY, JSON.stringify(table));
    } catch (e) { /* quota / private mode: keep in-memory table */ }
  }

  function list() {
    return table.map(function (e) {
      return { initials: e.initials, score: e.score, distance: e.distance, kills: e.kills, date: e.date };
    });
  }

  function qualifies(score) {
    score = Number(score);
    if (!isFinite(score) || score <= 0) return false;
    if (table.length < MAX_ENTRIES) return true;
    return score > table[table.length - 1].score;
  }

  // Returns the 0-based rank the entry took, or -1 if it did not make the table.
  function insert(entry) {
    var c = clean(entry);
    if (!c || !qualifies(c.score)) return -1;
    table.push(c);
    table = sortCap(table);
    var rank = table.indexOf(c);
    lastInserted = rank >= 0 ? c : null;
    save();
    return rank;
  }

  function clear() {
    table = [];
    lastInserted = null;
    save();
  }

  // ---- initials entry ----------------------------------------------------

  var entry = null; // { letters: '', stats: {...} } while entering

  function isEntering() { return !!entry; }

  // graceMs: letters are ignored for this long after the run ends, so keys
  // still held (or auto-repeating) from flying do not type initials.
  function beginEntry(stats, graceMs) {
    stats = stats || {};
    if (!qualifies(stats.score)) { entry = null; return false; }
    entry = { letters: '', stats: stats, since: Date.now(), grace: Number(graceMs) > 0 ? Number(graceMs) : 0 };
    return true;
  }

  function cancelEntry() { entry = null; }

  function getEntryLetters() { return entry ? entry.letters : ''; }

  function confirmEntry() {
    if (!entry) return -1;
    var letters = entry.letters;
    while (letters.length < 3) letters += '-';
    var st = entry.stats;
    var date = '';
    try { date = new Date().toISOString(); } catch (e) { date = ''; }
    entry = null;
    return insert({ initials: letters, score: st.score, distance: st.distance, kills: st.kills, date: date });
  }

  // True when the key was consumed by the entry (never restarts the game).
  function handleEntryKey(e) {
    if (!entry || !e) return false;
    var k = e.key;
    if (k === 'Enter') {
      if (!e.repeat) confirmEntry();
    } else if (k === 'Backspace') {
      entry.letters = entry.letters.slice(0, -1);
    } else if (typeof k === 'string' && /^[a-zA-Z]$/.test(k)) {
      if (!e.repeat && Date.now() - entry.since >= entry.grace && entry.letters.length < 3) entry.letters += k.toUpperCase();
    }
    // Everything else is swallowed too, so no stray key restarts the run.
    return true;
  }

  // ---- drawing -----------------------------------------------------------

  function palette() { return Game.Theme && Game.Theme.get ? Game.Theme.get() : null; }

  function text(ctx, str, x, y, align, color, role, scale, css) {
    css = css || ('bold ' + (scale > 1 ? 24 : 16) + 'px monospace');
    if (Game.Font && Game.Font.draw) {
      Game.Font.draw(ctx, str, x, y, { role: role || 'body', css: css, color: color,
        align: align, baseline: 'middle', scale: scale || 1 });
      return;
    }
    ctx.save();
    ctx.font = css;
    ctx.fillStyle = color;
    ctx.textAlign = align;
    ctx.textBaseline = 'middle';
    ctx.fillText(str, x, y);
    ctx.restore();
  }

  function pad2(n) { return (n < 10 ? ' ' : '') + n; }

  // Table screen.
  function render(ctx) {
    var P = palette();
    if (!ctx || !P) return;
    var H = Game.H || 400;
    ctx.fillStyle = P.BLUE;
    ctx.fillRect(0, 0, W, H);
    text(ctx, 'HIGH SCORES', W / 2, 40, 'center', P.YELLOW, 'title', 2);
    if (!table.length) {
      text(ctx, 'NO SCORES YET', W / 2, H / 2, 'center', P.WHITE);
    }
    for (var i = 0; i < table.length; i++) {
      var y = 90 + i * 25;
      var e = table[i];
      var hot = e === lastInserted;
      var col = hot ? P.YELLOW : P.WHITE;
      text(ctx, pad2(i + 1) + '.', 190, y, 'left', col);
      text(ctx, e.initials, 250, y, 'left', col);
      text(ctx, String(e.score), 450, y, 'right', col);
    }
    text(ctx, 'ESC OR CLICK TO GO BACK', W / 2, H - 28, 'center', P.LIGHT_GREY || P.WHITE);
  }

  // Initials panel drawn over the game-over screen. blink: boolean cursor phase.
  function renderEntry(ctx, blink) {
    var P = palette();
    if (!ctx || !P || !entry) return;
    // Compact strip at the bottom so the stats above (y < 300) stay visible.
    var px = 120, py = 300, pw = 400, ph = 100;
    ctx.fillStyle = P.BLACK;
    ctx.fillRect(px, py, pw, ph);
    ctx.fillStyle = P.YELLOW;
    ctx.fillRect(px, py, pw, 2);
    text(ctx, 'NEW HIGH SCORE! ENTER INITIALS', W / 2, py + 16, 'center', P.YELLOW);
    for (var i = 0; i < 3; i++) {
      var x = W / 2 - 40 + i * 40;
      var ch = entry.letters.charAt(i);
      var active = i === entry.letters.length && blink;
      ctx.fillStyle = active ? P.YELLOW : (P.DARK_GREY || P.WHITE);
      ctx.fillRect(x - 14, py + 66, 28, 3);
      if (ch) text(ctx, ch, x, py + 52, 'center', P.YELLOW, 'body', 2, 'bold 24px monospace');
    }
    text(ctx, 'ENTER: OK   BACKSPACE: DELETE', W / 2, py + 86, 'center', P.LIGHT_GREY || P.WHITE);
  }

  // ---- table screen input ------------------------------------------------

  function inScreen() {
    return !!(Game.STATES && Game.STATES.HIGHSCORES && Game.getState &&
              Game.getState() === Game.STATES.HIGHSCORES);
  }

  function back() {
    if (Game.setState && Game.STATES) Game.setState(Game.STATES.TITLE);
  }

  function onKeyDown(e) {
    if (!inScreen() || !e) return;
    if (e.key === 'Escape') {
      back();
      if (e.preventDefault) e.preventDefault();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    }
  }

  function onClick() {
    if (inScreen()) back();
  }

  load();

  if (typeof window.addEventListener === 'function') {
    window.addEventListener('keydown', onKeyDown);
  }
  if (Game.canvas && Game.canvas.addEventListener) {
    Game.canvas.addEventListener('click', onClick);
  }

  Game.HighScores = {
    STORAGE_KEY: STORAGE_KEY,
    MAX_ENTRIES: MAX_ENTRIES,
    list: list,
    qualifies: qualifies,
    insert: insert,
    clear: clear,
    reload: load,
    isEntering: isEntering,
    beginEntry: beginEntry,
    cancelEntry: cancelEntry,
    getEntryLetters: getEntryLetters,
    handleEntryKey: handleEntryKey,
    confirmEntry: confirmEntry,
    render: render,
    renderEntry: renderEntry
  };
})();
