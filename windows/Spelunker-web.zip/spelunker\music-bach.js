// Spelunker - the complete Fugue of J. S. Bach's Toccata and Fugue in D minor,
// BWV 565, from measure 30 (the A-G-A-F-A-E-A pickup) to the final measure 143.
//
// GENERATED FILE - DO NOT EDIT BY HAND. Regenerate with:
//   node tools/ly-to-measures.js --format game-js --out music-bach.js
// Source fixes belong in tools/ly-to-measures.js; tests/songs.test.js fails if
// this file drifts from the generator.
//
// Source: the public-domain Bach-Gesellschaft score transcribed by the Mutopia
// Project (Mutopia-2011/09/11-1780), vendored as LilyPond in
// tools/sources/bwv565-toccata-fugue.ly and converted automatically by
// tools/ly-to-measures.js.
//
// Playback starts at the measure-30 pickup. The Fugue is split into 6 back-to-back
// sections (one per tempo marking: Fugue 120 bpm, Recitativo 90 bpm, Adagissimo 68 bpm, Presto 80 bpm, Adagio Vivace 83 bpm, Molto Adagio 60 bpm).
// Each section is its own score (MUSIC_BACH_NOTATION[_N] / MUSIC_BACH_MEASURE_MAP[_N])
// because the parser supports one TEMPO per song; audio.js plays them in order.
// The last section ends with 1 whole-rest bar(s) (about 3 s of silence)
// labelled as the final measure, as a breath before the playlist wraps.
// The music is kept in chronological measure order; each stave voice (and
// each independent layer of it) becomes one synchronized track.

// Song-assembly helpers shared with other score files. In the browser
// music-score.js loads before this file (see index.html) and attaches to
// window.MusicScore; under Node it is required directly.
var BachScoreHelpers = (typeof window !== 'undefined' && window.MusicScore)
  ? window.MusicScore
  : require('./music-score.js');

// ---- Section 1: Fugue (measures 30-126, 120 bpm) ----

var FUGUE_TRACKS = {
  upper: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 1.'
  },
  upper_2: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 2.'
  },
  upper_3: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 3.'
  },
  lower: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 1.'
  },
  lower_2: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 2.'
  },
  pedal: {
    instrument: 'organ',
    header: '# Pedal, layer 1.'
  }
};

var FUGUE_MEASURES = [
  {
    label: '# Pickup in measure 30',
    upper: ['R,4. R,16'],
    upper_2: ['R,4. R,16'],
    upper_3: ['R,4. R,16'],
    lower: ['A4,16 G4,16 A4,16 F4,16 A4,16 E4,16 A4,16'],
    lower_2: ['R,4. R,16'],
    pedal: ['R,4. R,16']
  },
  {
    label: '# Measure 31',
    upper: ['R,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D4,16 A4,16 C#4,16 A4,16 D4,16 A4,16 E4,16 A4,16',
      'F4,16 A4,16 A3,16 A4,16 B3,16 A4,16 C#4,16 A4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 32',
    upper: [
      'R,2',
      'R,16 D5,16 C5,16 D5,16 Bb4,16 D5,16 A4,16 D5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D4,16 A4,16 C#4,16 A4,16 D4,16 A4,16 E4,16 A4,16',
      'F4,8 F#4,8 G4,8 C4,8'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 33',
    upper: [
      'G4,16 D5,16 F#4,16 D5,16 G4,16 D5,16 A4,16 D5,16',
      'Bb4,16 D5,16 D4,16 D5,16 E4,16 D5,16 F#4,16 D5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Bb3,8 A3,8 Bb3,8 C4,8',
      'D4,8 F#3,8 G3,8 A3,8'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 34',
    upper: [
      'G4,16 D5,16 F#4,16 D5,16 G4,16 D5,16 A4,16 D5,16',
      'Bb4,8 D5,8 Bb4,8 D5,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Bb3,8 A3,8 Bb3,8 F#3,8',
      'G3,16 G4,16 G3,16 G4,16 D4,16 G4,16 D4,16 G4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 35',
    upper: [
      'Eb5,8 G4,8 Eb5,8 G4,8',
      'C5,8 A4,8 C5,8 A4,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C4,16 Eb4,16 C4,16 Eb4,16 C4,16 Eb4,16 C4,16 Eb4,16',
      'C4,16 F4,16 C4,16 F4,16 C4,16 F4,16 C4,16 F4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 36',
    upper: [
      'D5,8 F4,8 D5,8 F4,8',
      'Bb4,8 G4,8 Bb4,8 G4,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Bb3,16 D4,16 Bb3,16 D4,16 Bb3,16 D4,16 Bb3,16 D4,16',
      'Bb3,16 E4,16 Bb3,16 E4,16 Bb3,16 E4,16 Bb3,16 E4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 37',
    upper: [
      'C#5,8 E4,8 C#5,8 E4,8',
      'A4,8 F4,8 A4,8 F4,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'A3,16 C#4,16 A3,16 C#4,16 A3,16 C#4,16 A3,16 C#4,16',
      'F3,16 D4,16 F3,16 D4,16 F3,16 D4,16 F3,16 D4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 38',
    upper: [
      'G4,8 C#4,8 G4,8 C#4,8',
      'F4,8 D4,8 F4,8 D4,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'E3,16 Bb3,16 E3,16 Bb3,16 E3,16 Bb3,16 E3,16 Bb3,16',
      'D3,16 A3,16 D3,16 A3,16 D3,16 A3,16 D3,16 A3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 39',
    upper: [
      'E4,8 Bb3,8 E4,8 Bb3,8',
      'R,16 A5,16 G5,16 A5,16 F5,16 A5,16 E5,16 A5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'E3,16 G3,16 E3,16 G3,16 E3,16 G3,16 E3,16 G3,16',
      'A3,8 A3,8 A3,8 A3,8'
    ],
    lower_2: [
      'R,2',
      'F3,8 E3,8 D3,8 G3,8'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 40',
    upper: [
      'D5,16 A5,16 C#5,16 A5,16 D5,16 A5,16 E5,16 A5,16',
      'F5,16 A5,16 A4,16 A5,16 B4,16 A5,16 C#5,16 A5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'A3,8 A3,8 A3,8 A3,8',
      'A3,8 A3,8 A3,8 A3,8'
    ],
    lower_2: [
      'F3,8 E3,8 F3,8 C#3,8',
      'D3,8 C#3,8 D3,8 E3,8'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 41',
    upper: [
      'D5,16 A5,16 C#5,16 A5,16 D5,16 A5,16 E5,16 A5,16',
      'F5,16 A5,16 E5,16 A5,16 D5,16 A5,16 C5,16 A5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'A3,8 A3,8 A3,8 A3,8',
      'A3,4 D4,4'
    ],
    lower_2: [
      'F3,8 E3,8 F3,8 C#3,8',
      'D3,4 F3,4'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 42',
    upper: [
      'Bb4,16 A5,16 C5,16 A5,16 D5,16 G5,16 Bb4,16 G5,16',
      'E5,16 G5,16 D5,16 G5,16 C5,16 G5,16 Bb4,16 G5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D4,4 R,4',
      'C4,4 C4,4'
    ],
    lower_2: [
      'G3,4 R,4',
      'C3,4 E3,4'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 43',
    upper: [
      'A4,16 G5,16 Bb4,16 G5,16 C5,16 F5,16 A4,16 F5,16',
      'D5,16 F5,16 C5,16 F5,16 Bb4,16 F5,16 A4,16 F5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C4,4 R,4',
      'Bb3,4 Bb3,4'
    ],
    lower_2: [
      'F3,4 R,4',
      'Bb2,4 D3,4'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 44',
    upper: [
      'G4,16 F5,16 A4,16 F5,16 Bb4,16 E5,16 G4,16 E5,16',
      'C#5,16 E5,16 Bb4,16 E5,16 A4,16 E5,16 G4,16 E5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Bb3,4 R,4',
      'A3,4 A3,4'
    ],
    lower_2: [
      'E3,4 R,4',
      'A2,4 C#3,4'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 45',
    upper: [
      'F4,16 E5,16 G4,16 E5,16 A4,16 D5,16 F4,16 D5,16',
      'E4,16 E5,16 E4,16 E5,16 F4,16 D5,16 F4,16 D5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'A3,4 R,8 D4,8',
      'C#4,8 C#4,8 D4,8 D4,8'
    ],
    lower_2: [
      'D3,4 R,8 F3,8',
      'Bb3,8 Bb3,8 A3,8 A3,8'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 46',
    upper: [
      'Bb4,16 C#5,16 Bb4,16 C#5,16 A4,16 D5,16 F4,16 D5,16',
      'E4,16 E5,16 E4,16 E5,16 F4,16 D5,16 F4,16 D5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'E4,4 R,8 D4,8',
      'C#4,8 C#4,8 D4,8 D4,8'
    ],
    lower_2: [
      'G3,4 R,8 A3,8',
      'Bb3,8 Bb3,8 A3,8 A3,8'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 47',
    upper: [
      'R,16 D5,16 C#5,16 D5,16 B4,16 D5,16 C#5,16 B4,16',
      'C#5,4 E4,16 G4,16 F4,16 E4,16'
    ],
    upper_2: [
      'R,2',
      'R,16 A4,16 G4,16 A4,16 R,4'
    ],
    upper_3: ['R,1'],
    lower: ['E4,4 R,2.'],
    lower_2: ['G#3,4 R,2.'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 48',
    upper: [
      'F4,4 F5,16 D5,16 C#5,16 B4,16',
      'C#5,4 E5,4'
    ],
    upper_2: [
      'R,16 D5,16 C#5,16 D5,16 D4,4',
      'A3,16 A4,16 G4,16 A4,16 C#4,16 G4,16 F4,16 E4,16'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 49',
    upper: [
      'E5,8 D5,4 C#5,8',
      'C5,4 Bb4,4'
    ],
    upper_2: [
      'F4,4 E4,4',
      'D4,8 A4,4 G4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'R,16 D4,16 C#4,16 D4,16 A3,16 A3,16 G3,16 A3,16',
      'F#3,16 D4,16 C#4,16 D4,16 G3,16 F4,16 Eb4,16 D4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 50',
    upper: [
      'A4,4 A4,4',
      'G4,4 G4,4'
    ],
    upper_2: [
      'G4,4 F#4,4',
      'F4,4 Eb4,4'
    ],
    upper_3: ['R,1'],
    lower: [
      'C#4,16 E4,16 A3,16 C#4,16 D3,16 Eb4,16 D4,16 C4,16',
      'B3,16 D4,16 G3,16 B3,16 C3,16 D4,16 C4,16 Bb3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 51',
    upper: [
      'F#4,8 A4,4 Eb5,8',
      'D5,4 Bb4,8 G5,8'
    ],
    upper_2: [
      'Eb4,8 D4,8 F#4,8 C5,4',
      'Bb4,16 A4,16 R,8 Bb4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'A3,16 C4,16 F#3,16 A3,16 D3,16 C4,16 Bb3,16 A3,16',
      'Bb3,16 A4,16 G4,16 F#4,16 G4,16 Bb3,16 A3,16 G3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 52',
    upper: [
      'G5,8 F#5,8 G5,4',
      'Bb4,8 D5,8 D5,8 D5,8'
    ],
    upper_2: [
      'A4,4 D5,8 C5,8',
      'R,8 A4,8 Bb4,8 F#4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'D4,4 R,8 D4,8',
      'D4,8 D4,8 D4,8 C4,8'
    ],
    lower_2: ['R,1'],
    pedal: [
      'R,16 D3,16 C3,16 D3,16 Bb2,16 D3,16 A2,16 D3,16',
      'G2,16 D3,16 F#2,16 D3,16 G2,16 D3,16 A2,16 D3,16'
    ]
  },
  {
    label: '# Measure 53',
    upper: [
      'D5,8 D5,8 D5,8 D5,8',
      'D5,8 D5,8 D5,8 D5,8'
    ],
    upper_2: [
      'G4,8 F#4,8 G4,8 A4,8',
      'Bb4,8 A4,8 Bb4,8 F#4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'Bb3,8 D4,8 D4,8 C4,8',
      'Bb3,8 D4,8 D4,8 C4,8'
    ],
    lower_2: ['R,1'],
    pedal: [
      'Bb2,16 D3,16 D2,16 D3,16 E2,16 D3,16 F#2,16 D3,16',
      'G2,16 D3,16 F#2,16 D3,16 G2,16 D3,16 A2,16 D3,16'
    ]
  },
  {
    label: '# Measure 54',
    upper: [
      'D5,16 G5,16 F5,16 G5,16 E5,16 F5,16 D5,16 E5,16',
      'C5,16 A5,16 G5,16 A5,16 F5,16 G5,16 E5,16 F5,16'
    ],
    upper_2: [
      'G4,16 Bb4,16 A4,16 Bb4,16 G4,16 A4,16 F4,16 G4,16',
      'E4,16 C5,16 Bb4,16 C5,16 A4,16 Bb4,16 G4,16 A4,16'
    ],
    upper_3: ['R,1'],
    lower: ['Bb3,4 R,2.'],
    lower_2: ['R,1'],
    pedal: [
      'Bb2,4 R,8 B2,8',
      'C3,4 R,8 C#3,8'
    ]
  },
  {
    label: '# Measure 55',
    upper: [
      'D5,16 Bb5,16 A5,16 Bb5,16 G5,16 A5,16 F5,16 G5,16',
      'E5,16 C6,16 Bb5,16 C6,16 A5,16 Bb5,16 G5,16 A5,16'
    ],
    upper_2: [
      'F4,16 D5,16 C5,16 D5,16 Bb4,16 C5,16 A4,16 Bb4,16',
      'G4,16 E5,16 D5,16 E5,16 C5,16 D5,16 Bb4,16 C5,16'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: [
      'D3,4 R,8 D3,8',
      'E3,4 R,8 E3,8'
    ]
  },
  {
    label: '# Measure 56',
    upper: [
      'F5,16 Eb5,16 D5,16 C5,16 D5,16 C5,16 Bb4,16 A4,16',
      'Bb4,16 D5,16 Bb4,16 A4,16 G4,16 Bb4,16 G4,16 F4,16'
    ],
    upper_2: [
      'A4,8 F4,8 Bb4,16 A4,16 G4,16 F4,16',
      'G4,16 Bb4,16 G4,16 F4,16 E4,16 G4,16 E4,16 D4,16'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: [
      'F3,8 A2,8 Bb2,8 D3,8',
      'G2,4 R,8 Bb2,8'
    ]
  },
  {
    label: '# Measure 57',
    upper: [
      'E4,16 F4,16 G4,16 A4,16 Bb4,16 D5,16 C5,16 Bb4,16',
      'A4,4 C5,8 Bb4,8'
    ],
    upper_2: [
      'C4,16 D4,16 E4,16 F4,16 G4,8 E4,8',
      'F4,4 R,4'
    ],
    upper_3: ['R,1'],
    lower: [
      'R,2',
      'R,16 C4,16 Bb3,16 C4,16 A3,16 C4,16 G3,16 C4,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'Bb2,8 A2,8 G2,8 C3,8',
      'F2,4 R,4'
    ]
  },
  {
    label: '# Measure 58',
    upper: [
      'A4,8 G4,8 A4,8 Bb4,8',
      'C5,8 E4,8 F4,8 G4,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F3,16 C4,16 E3,16 C4,16 F3,16 C4,16 G3,16 C4,16',
      'A3,16 C4,16 C3,16 C4,16 D3,16 C4,16 E3,16 C4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 59',
    upper: [
      'A4,8 G4,8 A4,8 Bb4,8',
      'C5,16 Bb4,16 A4,16 G4,16 F4,16 Eb4,16 D4,16 C4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F3,16 C4,16 E3,16 C4,16 F3,16 C4,16 G3,16 C4,16',
      'A3,4 R,4'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 60',
    upper: [
      'D5,16 C5,16 Bb4,16 A4,16 G4,16 F4,16 E4,16 D4,16',
      'E5,16 D5,16 C5,16 Bb4,16 A4,16 G4,16 F4,16 E4,16'
    ],
    upper_2: [
      'Bb3,8 R,4.',
      'C4,8 R,4.'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 61',
    upper: [
      'F5,16 E5,16 D5,16 C5,16 Bb4,16 A4,16 G4,16 F4,16',
      'G5,16 F5,16 E5,16 D5,16 C5,16 Bb4,16 A4,16 G4,16'
    ],
    upper_2: [
      'D4,8 R,4.',
      'E4,8 R,4.'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 62',
    upper: [
      'A5,16 F5,16 E5,16 F5,16 C5,8 E5,16 F5,16',
      'A5,16 F5,16 E5,16 F5,16 C5,8 E5,16 F5,16'
    ],
    upper_2: [
      'F4,8 R,8. F5,16 R,8',
      'F4,8 R,8. F5,16 R,8'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 63',
    upper: [
      'G5,16 E5,16 D5,16 E5,16 C5,8 D5,16 E5,16',
      'G5,16 E5,16 D5,16 E5,16 C5,8 D5,16 E5,16'
    ],
    upper_2: [
      'E4,8 R,8. E5,16 R,8',
      'E4,8 R,8. E5,16 R,8'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 64',
    upper: [
      'A5,16 F5,16 E5,16 F5,16 C5,8 E5,16 F5,16',
      'A5,16 F5,16 E5,16 F5,16 C5,8 E5,16 F5,16'
    ],
    upper_2: [
      'F4,8 R,8. F5,16 R,8',
      'F4,8 R,8. F5,16 R,8'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 65',
    upper: [
      'G5,16 E5,16 D5,16 E5,16 C5,8 D5,16 E5,16',
      'G5,16 E5,16 D5,16 E5,16 C5,8 D5,16 E5,16'
    ],
    upper_2: [
      'E4,8 R,8. E5,16 R,8',
      'E4,8 R,8. E5,16 R,8'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 66',
    upper: [
      'F5,16 G5,16 F5,16 E5,16 D5,16 C5,16 B4,16 A4,16',
      'B4,16 G4,16 B4,16 D5,16 F5,16 A5,16 F5,16 D5,16'
    ],
    upper_2: [
      'D4,8 R,2.',
      'R,8'
    ],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 67',
    upper: [
      'B4,16 G4,16 B4,16 D5,16 F5,16 A5,16 F5,16 D5,16',
      'Bb4,16 G4,16 Bb4,16 C5,16 E5,16 G5,16 E5,16 C5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 68',
    upper: [
      'Bb4,16 G4,16 Bb4,16 C5,16 E5,16 G5,16 E5,16 C5,16',
      'A4,16 F4,16 A4,16 C5,16 D5,16 F5,16 D5,16 Bb4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 69',
    upper: [
      'A4,16 F4,16 A4,16 C5,16 D5,16 F5,16 D5,16 Bb4,16',
      'G4,16 E4,16 G4,16 Bb4,16 C#5,16 E5,16 C#5,16 Bb4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 70',
    upper: [
      'G4,16 E4,16 G4,16 Bb4,16 C#5,16 E5,16 C#5,16 Bb4,16',
      'R,16 A5,16 G5,16 A5,16 F5,16 A5,16 E5,16 A5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'R,2',
      'A4,8 C#5,8 D5,8 G4,8'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 71',
    upper: [
      'D5,16 A5,16 C#5,16 A5,16 D5,16 A5,16 E5,16 A5,16',
      'F5,16 A5,16 A4,16 A5,16 B4,16 A5,16 C#5,16 A5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F4,8 A4,8 B4,8 C#5,8',
      'D5,8 C#5,8 D5,8 E5,8'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 72',
    upper: [
      'D5,16 A5,16 C#5,16 A5,16 D5,8 E5,8',
      'D5,8 C5,8 Bb4,8 A4,8'
    ],
    upper_2: [
      'R,2',
      'R,8 A4,8 G4,8 F#4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'F5,8 E5,8 F5,8 C#5,8',
      'R,16 F#4,16 E4,16 F#4,16 R,16 D4,16 C4,16 D4,16'
    ],
    lower_2: [
      'R,4 R,16 A4,16 G4,16 A4,16',
      'R,2'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 73',
    upper: [
      'Bb4,16 A4,16 G4,16 F4,16 E4,16 D4,16 C#4,16 B3,16',
      'R,2'
    ],
    upper_2: [
      'G4,8 R,2.',
      'R,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'Bb3,16 C4,16 Bb3,16 A3,16 G3,16 F3,16 E3,16 D3,16',
      'C#3,16 A2,16 C#3,16 E3,16 G3,16 Bb3,16 G3,16 E3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 74',
    upper: ['R,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C#3,16 A2,16 C#3,16 E3,16 G3,16 Bb3,16 G3,16 E3,16',
      'D3,16 A2,16 D3,16 F3,16 A3,16 D4,16 A3,16 F3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 75',
    upper: ['R,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D3,16 A2,16 D3,16 F3,16 A3,16 D4,16 A3,16 F3,16',
      'C#3,16 A2,16 C#3,16 E3,16 G3,16 Bb3,16 G3,16 E3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 76',
    upper: ['R,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C#3,16 A2,16 C#3,16 E3,16 G3,16 Bb3,16 G3,16 E3,16',
      'D3,16 A2,16 D3,16 F3,16 A3,16 D4,16 A3,16 F3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 77',
    upper: ['R,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D3,16 A2,16 D3,16 F3,16 A3,16 D4,16 A3,16 F3,16',
      'E3,16 C#3,16 E3,16 G3,16 Bb3,16 C#4,16 Bb3,16 G3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 78',
    upper: [
      'R,2.',
      'D4,16 F4,16 D4,16 R,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'E3,16 C#3,16 E3,16 G3,16 Bb3,16 C#4,16 Bb3,16 G3,16',
      'F3,16 D3,16 F3,16 A3,16 R,8. A3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 79',
    upper: [
      'R,4 D4,16 F4,16 D4,16 R,2',
      'R,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F3,16 D3,16 F3,16 A3,16 R,8. A3,16',
      'E3,16 C#3,16 E3,16 G3,16 Bb3,16 C#4,16 Bb3,16 G3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 80',
    upper: [
      'R,2.',
      'D4,16 F4,16 D4,16 R,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'E3,16 C#3,16 E3,16 G3,16 Bb3,16 C#4,16 Bb3,16 G3,16',
      'F3,16 D3,16 F3,16 A3,16 R,8. A3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 81',
    upper: [
      'R,4 D4,16 F4,16 D4,16 R,4',
      'R,16 C#4,16 E4,16 C#4,16 Bb3,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F3,16 D3,16 F3,16 A3,16 R,8. A3,16',
      'G3,16 E3,16 G3,16 Bb3,16 R,4'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 82',
    upper: [
      'R,4 C#4,16 E4,16 C#4,16 Bb3,16',
      'R,4 D4,16 F4,16 D4,16 R,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'G3,16 E3,16 G3,16 Bb3,16 R,4',
      'A3,16 F3,16 A3,16 C#4,16 R,8. A3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 83',
    upper: [
      'R,16 D4,16 Bb3,16 R,2.',
      'R,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Bb3,16 R,8 G3,16 F3,16 A3,16 F3,16 D3,16',
      'A2,16 D3,16 A2,16 F2,16 D2,16 D3,16 C#3,16 B2,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 84',
    upper: ['R,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C#3,16 Bb3,16 A3,16 G3,16 F3,16 G3,16 F3,16 E3,16',
      'D3,16 Bb3,16 A3,16 G3,16 F3,16 G3,16 F3,16 E3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 85',
    upper: [
      'R,4 R,16 F4,16 E4,16 D4,16',
      'A4,16 R,4 E5,16 D5,16 C#5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D3,16 E3,32 F3,32 G3,32 A3,32 B3,32 C#4,32 D4,16 R,8.',
      'A3,16 B3,32 C#4,32 D4,32 E4,32 F4,32 G4,32 A4,16 G4,16 F4,16 E4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 86',
    upper: [
      'D5,16 Eb5,32 D5,32 C5,32 Bb4,32 A4,32 G4,32 F#4,8 A4,4',
      'G4,8 C5,8 B4,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F4,8 R,8. Eb4,16 D4,16 C4,16',
      'Bb3,8 B3,8 C4,8 G4,8'
    ],
    lower_2: ['R,1'],
    pedal: [
      'R,2',
      'R,16 G3,16 F3,16 G3,16 Eb3,16 G3,16 D3,16 G3,16'
    ]
  },
  {
    label: '# Measure 87',
    upper: [
      'Eb5,8 D5,8 Eb5,8 B4,8',
      'C5,8 B4,8 C5,8 D5,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: ['G4,1'],
    lower_2: ['R,1'],
    pedal: [
      'C3,16 G3,16 B2,16 G3,16 C3,16 G3,16 D3,16 G3,16',
      'Eb3,16 G3,16 G2,16 G3,16 A2,16 G3,16 B2,16 G3,16'
    ]
  },
  {
    label: '# Measure 88',
    upper: [
      'Eb5,8 D5,8 Eb5,8 F5,8',
      'G5,2'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'G4,2',
      'G4,16 G4,16 F4,16 G4,16 Eb4,16 G4,16 D4,16 G4,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'C3,16 G3,16 B2,16 G3,16 C3,16 G3,16 D3,16 G3,16',
      'Eb3,8 D3,8 C3,8 B2,8'
    ]
  },
  {
    label: '# Measure 89',
    upper: ['G5,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C4,16 G4,16 B3,16 G4,16 C4,16 G4,16 D4,16 G4,16',
      'Eb4,16 G4,16 G3,16 G4,16 A3,16 G4,16 B3,16 G4,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'C3,8 D3,8 Eb3,8 F3,8',
      'G3,8 B2,8 C3,8 D3,8'
    ]
  },
  {
    label: '# Measure 90',
    upper: [
      'G5,2',
      'G5,16 G5,16 F5,16 G5,16 Eb5,16 F5,16 D5,16 Eb5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C4,16 G4,16 B3,16 G4,16 C4,16 G4,16 D4,16 D4,16',
      'Eb4,8 D4,8 G4,16 Ab4,16 F4,16 G4,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'Eb3,8 D3,8 Eb3,8 F3,8',
      'G3,8 B2,8 C3,8 D3,8'
    ]
  },
  {
    label: '# Measure 91',
    upper: [
      'C5,16 F5,16 Eb5,16 F5,16 D5,16 Eb5,16 C5,16 D5,16',
      'Bb4,16 Eb5,16 D5,16 Eb5,16 C5,16 D5,16 Bb4,16 C5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Eb4,8 C4,8 F4,16 G4,16 Eb4,16 F4,16',
      'D4,8 Bb3,8 Eb4,16 F4,16 D4,16 Eb4,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'Eb3,8 A2,8 Bb2,8 C3,8',
      'D3,8 G2,8 A2,8 Bb2,8'
    ]
  },
  {
    label: '# Measure 92',
    upper: [
      'A4,16 D5,16 C5,16 D5,16 Bb4,16 C5,16 A4,16 Bb4,16',
      'G4,16 Bb4,16 A4,16 Bb4,16 C5,16 Bb4,16 A4,16 G4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C4,8 F#4,8 G4,16 A4,16 F4,16 G4,16',
      'Eb4,16 G4,16 F#4,16 G4,16 A4,16 G4,16 F#4,16 E4,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'C3,8 D3,8 G3,8 D3,8',
      'Eb3,8 Bb2,8 A2,8 C3,8'
    ]
  },
  {
    label: '# Measure 93',
    upper: [
      'F#4,8 A4,8 D5,16 G4,16 C5,16 F#4,16',
      'Bb4,16 G4,16 D5,16 A4,16 Bb4,16 G4,16 A4,16 F#4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'R,16 D4,16 C4,16 D4,16 Bb3,16 D4,16 A3,16 D4,16',
      'G3,16 D4,16 F#3,16 D4,16 G3,16 D4,16 A3,16 D4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['D3,1']
  },
  {
    label: '# Measure 94',
    upper: [
      'G4,16 D5,16 F#4,16 D5,16 G4,16 D5,16 A4,16 D5,16',
      'Bb4,16 G4,16 D5,16 A4,16 Bb4,16 G4,16 C5,16 A4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Bb3,16 D4,16 D3,16 D4,16 E3,16 D4,16 F#3,16 D4,16',
      'G3,16 D4,16 F#3,16 D4,16 G3,16 D4,16 A3,16 D4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['D3,1']
  },
  {
    label: '# Measure 95',
    upper: [
      'D5,16 C5,16 Bb4,16 A4,16 Bb4,16 A4,16 Bb4,16 G4,16',
      'A4,16 Bb4,16 C5,16 D5,16 Eb5,16 D5,16 C5,16 D5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Bb3,8 A3,8 G3,2',
      'F#3,4'
    ],
    lower_2: ['R,1'],
    pedal: [
      'D3,4 R,8 G2,8',
      'C3,8 A2,8 D3,8 D2,8'
    ]
  },
  {
    label: '# Measure 96',
    upper: [
      'Bb4,16 C5,16 A4,16 Bb4,16 G4,8 B4,8',
      'C5,16 Eb5,16 F5,16 G5,16 Ab5,16 G5,16 F5,16 G5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'G3,8 A3,8 Bb3,16 A3,16 G3,16 F3,16',
      'Eb3,8 Eb4,8 D4,4'
    ],
    lower_2: ['R,1'],
    pedal: [
      'G2,4 R,8 G2,8',
      'C3,4. B2,8'
    ]
  },
  {
    label: '# Measure 97',
    upper: [
      'Eb5,16 F5,16 D5,16 Eb5,16 C5,8 Bb4,8',
      'A4,8 Bb4,4 A4,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C4,8 D4,8 Eb4,16 F4,16 D4,16 Eb4,16',
      'C4,16 Eb4,16 D4,16 F4,16 G4,16 F4,16 Eb4,16 F4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['C3,4 R,2.']
  },
  {
    label: '# Measure 98',
    upper: [
      'A4,8 G4,4 F#4,8',
      'F4,8 Eb4,4 D4,16 Bb4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D4,16 Bb3,16 Eb4,16 D4,16 C#4,16 A3,16 D4,16 C4,16',
      'B3,16 G3,16 C4,16 Bb3,16 A3,16 F3,16 Bb3,16 D4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 99',
    upper: [
      'A4,16 Bb4,16 A4,16 G4,16 F#4,16 Eb5,16 D5,16 C5,16',
      'Bb4,16 A5,16 G5,16 F#5,16 G5,8. F5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C4,16 D4,16 C4,16 Bb3,16 A3,16 C4,16 Bb3,16 A3,16',
      'G3,16 C4,16 Bb3,16 A3,16 Bb3,16 C4,16 Bb3,16 A3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 100',
    upper: [
      'Eb5,16 F5,16 D5,16 Eb5,16 C#5,4',
      'D5,4 C5,4'
    ],
    upper_2: [
      'R,4 R,16 Bb4,16 A4,16 G4,16',
      'A4,4 F#4,4'
    ],
    upper_3: ['R,1'],
    lower: [
      'G3,16 A3,16 F3,16 G3,16 E3,4',
      'F#3,4 D4,16 C4,16 Bb3,16 A3,16'
    ],
    lower_2: [
      'R,2',
      'R,16 Eb4,16 D4,16 C4,16 D3,4'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 101',
    upper: [
      'Bb4,4 A4,8 C#5,8',
      'D5,8 E5,8 F5,4'
    ],
    upper_2: [
      'G4,16 F4,16 Eb4,16 D4,16 C#4,8 E4,8',
      'F4,8 G4,8 A4,16 G4,16 D5,8'
    ],
    upper_3: [
      'R,2.',
      'R,8 A4,16 F4,16'
    ],
    lower: [
      'G3,4 A3,16 Bb3,16 A3,16 G3,16',
      'F3,16 G3,16 E3,16 A3,16 D3,4'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 102',
    upper: [
      'E5,2',
      'D5,4. F5,8'
    ],
    upper_2: [
      'D5,4 C#5,4',
      'A4,16 Bb4,16 G4,16 A4,16 F4,8 A4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'G4,16 A4,16 G4,16 A4,16 Bb4,16 A4,16 G4,16 A4,16',
      'F4,16 G4,16 E4,16 F4,16 D4,16 C4,16 Bb3,16 A3,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 103',
    upper: [
      'G5,8 D5,8 C#5,8 D5,8',
      'E5,8 D5,8 C#5,8 D5,8'
    ],
    upper_2: [
      'G4,8 A4,8 G4,8 F4,8',
      'G4,8 F4,8 E4,8 A4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'Bb3,16 A3,16 G3,16 F3,16 E3,16 F3,16 E3,16 D3,16',
      'C#3,16 A2,16 D3,16 A2,16 E3,16 A2,16 F3,16 A2,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 104',
    upper: [
      'E5,8 D5,8 C#5,8 D5,8',
      'E5,8 G5,8 F5,8 D5,8'
    ],
    upper_2: [
      'Bb4,8 A4,8 G4,8 F4,8',
      'A4,8 E5,8 D5,8 A4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'G3,16 A2,16 F3,16 A2,16 E3,16 A2,16 D3,16 A2,16',
      'C#3,16 A3,16 A2,16 A3,16 D3,16 A3,16 F3,16 D4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 105',
    upper: [
      'Bb4,8 E5,8 D5,8 D5,8',
      'C#5,4 D5,8 E5,8'
    ],
    upper_2: [
      'G4,8 G4,8 A4,8 F4,8',
      'R,2'
    ],
    upper_3: ['R,1'],
    lower: [
      'F3,16 D4,16 E3,16 C#4,16 F3,16 D4,16 D3,16 D4,16',
      'E4,16 A4,16 G4,16 A4,16 F4,16 A4,16 E4,16 A4,16'
    ],
    lower_2: [
      'R,2',
      'A3,2'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 106',
    upper: [
      'F5,8 E5,8 F5,8 C#5,8',
      'D5,8 C#5,8 D5,8 E5,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D4,16 A4,16 C#4,16 A4,16 D4,16 A4,16 E4,16 A4,16',
      'F4,16 A4,16 A3,4.'
    ],
    lower_2: [
      'A3,2',
      'A3,8 R,16 A4,16 B3,16 A4,16 C#4,16 A4,16'
    ],
    pedal: ['R,1']
  },
  {
    label: '# Measure 107',
    upper: [
      'F5,8 E5,8 F5,8 G5,8',
      'A5,16 Bb5,16 G5,16 A5,16 F5,16 G5,16 E5,16 F5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D4,16 A4,16 C#4,16 A4,16 D4,16 A4,16 E4,16 A4,16',
      'F4,8 E4,8 D4,8 G4,8'
    ],
    lower_2: ['A3,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 108',
    upper: [
      'D5,16 A4,16 C#5,16 A4,16 D5,16 A4,16 E5,16 A4,16',
      'F5,16 A4,16 E5,16 A4,16 F5,16 A4,16 G5,16 A4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F4,8 E4,8 F4,8 C#4,8',
      'D4,8 C#4,8 D4,8 B3,8'
    ],
    lower_2: ['A3,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 109',
    upper: [
      'A5,16 A4,16 E5,16 A4,16 F5,16 A4,16 G5,16 A4,16',
      'A5,4 R,4'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C#4,8 G4,8 F4,8 D4,8',
      'C#4,4 R,4'
    ],
    lower_2: [
      'A3,2.',
      'R,4'
    ],
    pedal: [
      'R,2',
      'R,16 A3,16 G3,16 A3,16 F3,16 A3,16 E3,16 A3,16'
    ]
  },
  {
    label: '# Measure 110',
    upper: ['R,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    pedal: [
      'D3,16 A3,16 C#3,16 A3,16 D3,16 A3,16 E3,16 A3,16',
      'F3,16 A3,16 A2,16 A3,16 B2,16 A3,16 C#3,16 A3,16'
    ]
  },
  {
    label: '# Measure 111',
    upper: [
      'R,2',
      'R,16 E5,16 D5,16 C#5,16 D5,8 R,16 F5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'R,2',
      'R,16 G4,16 F4,16 E4,16 F4,16 C#4,16 D4,8'
    ],
    lower_2: ['R,1'],
    pedal: [
      'D3,16 A3,16 C#3,16 A3,16 D3,16 A3,16 E3,16 A3,16',
      'F3,4 R,8 F3,8'
    ]
  },
  {
    label: '# Measure 112',
    upper: [
      'E5,16 F5,16 G5,16 A5,16 Bb5,16 A5,16 G5,16 A5,16',
      'F5,8 E5,8 D5,16 E5,16 F5,16 Eb5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D4,4 C#4,4',
      'D4,16 A4,16 B4,16 C#5,16 D5,8 C5,8'
    ],
    lower_2: ['R,1'],
    pedal: [
      'G3,8 E3,8 A3,8 A2,8',
      'D3,4 R,8 A2,8'
    ]
  },
  {
    label: '# Measure 113',
    upper: [
      'D5,16 C5,16 Bb4,16 A4,16 G4,16 A4,16 Bb4,16 C5,16',
      'A4,4 R,8 C5,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F4,4. Eb4,8.',
      'C4,16 A3,16 F3,16 A3,16 C4,16 Eb4,16 C4,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'Bb2,8 G2,8 C3,8 C2,8',
      'F2,4 R,8 A2,8'
    ]
  },
  {
    label: '# Measure 114',
    upper: [
      'C5,8 Bb4,8 R,8 G5,8',
      'Eb5,16 F5,16 D5,16 Eb5,16 C5,16 Bb4,16 A4,16 G4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'D4,16 Bb3,16 G3,16 D3,16 G3,16 Bb3,16 D4,16 G4,16',
      'C4,16 D4,16 Bb3,16 C4,16 A3,16 G3,16 F#3,16 E3,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'Bb2,4 R,8 Bb2,8',
      'C3,4 R,8 A2,8'
    ]
  },
  {
    label: '# Measure 115',
    upper: ['A4,4 R,2.'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F#3,16 D3,16 F#3,16 G3,16 A3,16 D4,16 A3,16 G3,16',
      'F#3,16 D3,16 F#3,16 G3,16 A3,16 D4,16 A3,16 F#3,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'D3,4 R,4',
      'D3,4 R,4'
    ]
  },
  {
    label: '# Measure 116',
    upper: ['R,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'G3,16 D3,16 G3,16 A3,16 Bb3,16 D4,16 Bb3,16 A3,16',
      'G3,16 D3,16 G3,16 A3,16 Bb3,16 D4,16 C4,16 Bb3,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'D3,4 R,4',
      'D3,4 R,4'
    ]
  },
  {
    label: '# Measure 117',
    upper: [
      'R,4 C4,16 Eb4,16 C4,16 Bb3,16',
      'R,4 C4,16 Eb4,16 C4,16 Bb3,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'A3,16 F#3,16 A3,16 Bb3,16 R,4',
      'A3,16 F#3,16 A3,16 Bb3,16 R,4'
    ],
    lower_2: ['R,1'],
    pedal: [
      'D3,4 R,4',
      'D3,4 R,4'
    ]
  },
  {
    label: '# Measure 118',
    upper: [
      'R,4 G4,16 Bb4,16 G4,16 D4,16',
      'R,4 G4,16 Bb4,16 G4,16 D4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'A3,16 Bb3,16 D4,16 F#4,16 R,4',
      'Bb3,16 G3,16 Bb3,16 D4,16 R,4'
    ],
    lower_2: ['R,1'],
    pedal: [
      'D3,4 R,4',
      'D3,4 R,4'
    ]
  },
  {
    label: '# Measure 119',
    upper: [
      'R,4 F#4,16 A4,16 F#4,16 Eb4,16',
      'R,4 F#4,16 A4,16 F#4,16 Eb4,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'C4,16 A3,16 C4,16 Eb4,16 R,4',
      'C4,16 A3,16 C4,16 Eb4,16 R,4'
    ],
    lower_2: ['R,1'],
    pedal: [
      'D3,4 R,4',
      'D3,4 R,4'
    ]
  },
  {
    label: '# Measure 120',
    upper: [
      'D4,8 R,8 D5,8 C5,8',
      'Bb4,4 C5,8 D5,8'
    ],
    upper_2: [
      'R,4 G4,8 F#4,8',
      'G4,4 G4,8 B4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'F#3,8 R,8 G3,8 A3,8',
      'Bb3,4 Eb4,8 B3,8'
    ],
    lower_2: ['R,1'],
    pedal: [
      'R,16 D3,16 C3,16 D3,16 Bb2,16 D3,16 A2,16 D3,16',
      'G2,16 G3,16 F3,16 G3,16 Eb3,16 G3,16 D3,16 G3,16'
    ]
  },
  {
    label: '# Measure 121',
    upper: [
      'Eb5,4 F5,8 G5,8',
      'A5,4 F5,8 Eb5,8'
    ],
    upper_2: [
      'C5,4 C5,8 E5,8',
      'F5,4 Bb4,8 A4,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'G3,4 C4,8 Bb3,8',
      'A3,4 Bb3,8 C4,8'
    ],
    lower_2: ['R,1'],
    pedal: [
      'C3,16 C3,16 Bb2,16 C3,16 A2,16 C3,16 G2,16 C3,16',
      'F2,16 F3,16 Eb3,16 F3,16 D3,16 F3,16 C3,16 F3,16'
    ]
  },
  {
    label: '# Measure 122',
    upper: [
      'D5,16 Eb5,16 D5,16 C5,16 Bb4,16 C5,16 Bb4,16 A4,16',
      'G4,16 C5,16 Bb4,16 A4,16 G4,16 A4,16 G4,16 F#4,16'
    ],
    upper_2: [
      'Bb4,8 R,2.',
      'R,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'D4,16 G4,16 F4,16 Eb4,16 D4,16 Eb4,16 D4,16 C4,16',
      'Bb3,16 Eb4,16 D4,16 C4,16 Bb3,16 C4,16 Bb3,16 A3,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'Bb2,8 Eb3,8 F3,8 F2,8',
      'G2,8 C3,8 D3,8 D2,8'
    ]
  },
  {
    label: '# Measure 123',
    upper: [
      'G4,16 F4,16 E4,16 D4,16 C#4,8 E4,8',
      'F4,16 G4,16 A4,16 B4,16 C#5,16 D5,16 E5,16 F5,16'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Bb3,16 A3,16 G3,16 F3,16 E3,8 G3,8',
      'A3,16 B3,16 C#4,16 D4,16 E4,16 F4,16 G4,16 A4,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'G2,4 R,16 A2,16 G2,16 A2,16',
      'F2,8 D2,8 A2,4'
    ]
  },
  {
    label: '# Measure 124',
    upper: [
      'G5,8 F5,16 E5,16 D5,8 C#5,8',
      'D5,8 E5,8 F5,8 G5,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'Bb4,8 A4,16 G4,16 F4,16 A4,16 E4,16 A4,16',
      'D4,16 A4,16 C#4,16 A4,16 D4,16 A4,16 E4,16 A4,16'
    ],
    lower_2: ['R,1'],
    pedal: ['D2,1']
  },
  {
    label: '# Measure 125',
    upper: [
      'A5,8 C#5,8 D5,8 E5,8',
      'F5,8 E5,8 F5,8 D5,8'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'F4,16 A4,16 A3,16 A4,16 B3,16 A4,16 C#4,16 A4,16',
      'D4,16 A4,16 C#4,16 A4,16 D4,16 A4,16 B3,16 A4,16'
    ],
    lower_2: ['R,1'],
    pedal: [
      'D2,2',
      'R,4. D3,8'
    ]
  },
  {
    label: '# Measure 126',
    upper: [
      'E5,8 D5,8 D5,8 C#5,8',
      'D5,8 F5,8 E5,4'
    ],
    upper_2: [
      'R,8 A4,8 Bb4,8 A4,8',
      'A4,8 D5,8 D5,8 C5,8'
    ],
    upper_3: ['R,1'],
    lower: [
      'C#4,8 D4,8 G4,8 E4,8',
      'F4,8 A4,8 Bb4,8 A4,8'
    ],
    lower_2: ['R,1'],
    pedal: [
      'A2,8 F2,8 G2,8 A2,8',
      'F2,8 D2,8 G2,8 A2,8'
    ]
  }
];

// Single source of truth for the tempo: the helper builds the TEMPO line in
// MUSIC_BACH_NOTATION from this and the measure timeline uses it too.
var MUSIC_BACH_BPM = 120;

var MUSIC_BACH_MEASURE_MAP = BachScoreHelpers.buildMeasureMap(FUGUE_TRACKS, FUGUE_MEASURES, MUSIC_BACH_BPM);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_MEASURE_MAP = MUSIC_BACH_MEASURE_MAP;
}

var MUSIC_BACH_NOTATION = BachScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue in D minor, BWV 565 - Fugue (measures 30-126)',
  '# Measures are stored chronologically below and emitted as synchronized tracks.'
], MUSIC_BACH_BPM, FUGUE_TRACKS, FUGUE_MEASURES);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_NOTATION = MUSIC_BACH_NOTATION;
}

// ---- Section 2: Recitativo (measures 127-129, 90 bpm) ----

var FUGUE_TRACKS_2 = {
  upper: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 1.'
  },
  upper_2: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 2.'
  },
  upper_3: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 3.'
  },
  lower: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 1.'
  },
  lower_2: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 2.'
  },
  lower_3: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 3.'
  },
  pedal: {
    instrument: 'organ',
    header: '# Pedal, layer 1.'
  }
};

var FUGUE_MEASURES_2 = [
  {
    label: '# Measure 127',
    upper: [
      'D5,2',
      'R,32 F5,32 G5,32 A5,32 Bb5,32 A4,32 Bb4,32 C5,32 D5,32 C5,32 D5,32 Eb5,32 F5,32 F4,32 G4,32 A4,32'
    ],
    upper_2: [
      'Bb4,2',
      'R,2'
    ],
    upper_3: [
      'F4,2',
      'R,2'
    ],
    lower: [
      'D4,2',
      'R,2'
    ],
    lower_2: [
      'Bb3,2',
      'R,2'
    ],
    lower_3: [
      'F3,2',
      'R,2'
    ],
    pedal: [
      'Bb2,2',
      'R,2'
    ]
  },
  {
    label: '# Measure 128',
    upper: [
      'Bb4,32 A4,32 Bb4,32 C5,32 D5,32 A4,32 G4,32 F4,32 Eb4,32 G4,32 A4,32 Bb4,32 C5,32 G4,32 F4,32 Eb4,32',
      'D4,32 F4,32 G4,32 A4,32 Bb4,32 R,8 C4,32 D4,32 Eb4,32 F4,32 R,16.'
    ],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: [
      'R,2',
      'R,8 R,32 A3,32 Bb3,32 C4,32 D4,32 R,8 F3,32 G3,32 A3,32'
    ],
    lower_2: ['R,1'],
    lower_3: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 129',
    upper: [
      'R,4 R,32 Bb3,32 C4,32 D4,32 Eb4,32 R,8',
      'C4,32 D4,32 E4,32 F#4,32 Eb4,32 D4,32 C4,32 Bb3,32 F#4,32 G4,32 A4,32 Bb4,8'
    ],
    upper_2: [
      'R,2.',
      'R,8 R,32 C5,32 D5,32 G4,32'
    ],
    upper_3: ['R,1'],
    lower: [
      'Bb3,32 A3,32 Bb3,32 C4,32 D4,32 C4,32 Bb3,32 A3,32 G3,32 R,8 D4,32 C4,32 Bb3,32',
      'A3,32 R,4. R,16.'
    ],
    lower_2: ['R,1'],
    lower_3: ['R,1'],
    pedal: ['R,1']
  }
];

// Single source of truth for the tempo: the helper builds the TEMPO line in
// MUSIC_BACH_NOTATION_2 from this and the measure timeline uses it too.
var MUSIC_BACH_BPM_2 = 90;

var MUSIC_BACH_MEASURE_MAP_2 = BachScoreHelpers.buildMeasureMap(FUGUE_TRACKS_2, FUGUE_MEASURES_2, MUSIC_BACH_BPM_2);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_MEASURE_MAP_2 = MUSIC_BACH_MEASURE_MAP_2;
}

var MUSIC_BACH_NOTATION_2 = BachScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue in D minor, BWV 565 - Recitativo (measures 127-129)',
  '# Measures are stored chronologically below and emitted as synchronized tracks.'
], MUSIC_BACH_BPM_2, FUGUE_TRACKS_2, FUGUE_MEASURES_2);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_NOTATION_2 = MUSIC_BACH_NOTATION_2;
}

// ---- Section 3: Adagissimo (measures 130-132, 68 bpm) ----

var FUGUE_TRACKS_3 = {
  upper: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 1.'
  },
  upper_2: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 2.'
  },
  upper_3: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 3.'
  },
  upper_4: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 4.'
  },
  lower: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 1.'
  },
  lower_2: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 2.'
  },
  lower_3: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 3.'
  },
  pedal: {
    instrument: 'organ',
    header: '# Pedal, layer 1.'
  }
};

var FUGUE_MEASURES_3 = [
  {
    label: '# Measure 130',
    upper: [
      'E5,2.',
      'D5,4'
    ],
    upper_2: [
      'Bb4,2.',
      'A4,4'
    ],
    upper_3: [
      'G4,2.',
      'F4,4'
    ],
    upper_4: [
      'E4,2.',
      'R,4'
    ],
    lower: [
      'C#4,2.',
      'D4,4'
    ],
    lower_2: ['R,1'],
    lower_3: ['R,1'],
    pedal: [
      'C#3,2',
      'F3,4. D3,8'
    ]
  },
  {
    label: '# Measure 131',
    upper: [
      'D5,2',
      'R,2'
    ],
    upper_2: [
      'B4,2',
      'R,2'
    ],
    upper_3: [
      'F4,2',
      'R,2'
    ],
    upper_4: [
      'D4,2',
      'R,2'
    ],
    lower: [
      'B3,2',
      'R,2'
    ],
    lower_2: ['R,1'],
    lower_3: ['R,1'],
    pedal: [
      'G#2,2',
      'R,16 G#3,16 B3,16 F3,16 G#3,16 D3,16 F3,16 B2,16'
    ]
  },
  {
    label: '# Measure 132',
    upper: [
      'R,4. D5,8',
      'C5,2'
    ],
    upper_2: [
      'R,4. B4,8',
      'A4,4. G4,16 F4,16'
    ],
    upper_3: [
      'R,4. G#4,8',
      'E4,2'
    ],
    upper_4: [
      'R,4. E4,8',
      'R,2'
    ],
    lower: [
      'R,4. B3,8',
      'C4,2'
    ],
    lower_2: [
      'R,4. G#3,8',
      'A3,2'
    ],
    lower_3: [
      'R,4. E3,8',
      'E3,2'
    ],
    pedal: ['D3,16 G#2,16 A2,8 E2,2.']
  }
];

// Single source of truth for the tempo: the helper builds the TEMPO line in
// MUSIC_BACH_NOTATION_3 from this and the measure timeline uses it too.
var MUSIC_BACH_BPM_3 = 68;

var MUSIC_BACH_MEASURE_MAP_3 = BachScoreHelpers.buildMeasureMap(FUGUE_TRACKS_3, FUGUE_MEASURES_3, MUSIC_BACH_BPM_3);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_MEASURE_MAP_3 = MUSIC_BACH_MEASURE_MAP_3;
}

var MUSIC_BACH_NOTATION_3 = BachScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue in D minor, BWV 565 - Adagissimo (measures 130-132)',
  '# Measures are stored chronologically below and emitted as synchronized tracks.'
], MUSIC_BACH_BPM_3, FUGUE_TRACKS_3, FUGUE_MEASURES_3);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_NOTATION_3 = MUSIC_BACH_NOTATION_3;
}

// ---- Section 4: Presto (measures 133-135, 80 bpm) ----

var FUGUE_TRACKS_4 = {
  upper: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 1.'
  },
  upper_2: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 2.'
  },
  lower: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 1.'
  },
  lower_2: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 2.'
  },
  lower_3: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 3.'
  },
  pedal: {
    instrument: 'organ',
    header: '# Pedal, layer 1.'
  }
};

var FUGUE_MEASURES_4 = [
  {
    label: '# Measure 133',
    upper: [
      'C5,2',
      'R,32 G4,32 F4,32 G4,32 E4,32 E4,32 D4,32 E4,32 C4,32 A4,32 G4,32 A4,32 F4,32 F4,32 E4,32 F4,32'
    ],
    upper_2: [
      'E4,2',
      'R,2'
    ],
    lower: [
      'C4,2',
      'R,2'
    ],
    lower_2: [
      'G3,2',
      'R,2'
    ],
    lower_3: [
      'E3,2',
      'R,2'
    ],
    pedal: [
      'E2,2',
      'R,2'
    ]
  },
  {
    label: '# Measure 134',
    upper: [
      'D4,32 B4,32 A4,32 B4,32 G4,32 G4,32 F4,32 G4,32 E4,32 C5,32 B4,32 C5,32 A4,32 D5,32 C5,32 D5,32',
      'B4,32 E5,32 D5,32 E5,32 C5,32 F5,32 E5,32 F5,32 D5,32 G5,32 F5,32 G5,32 E5,32 C5,32 B4,32 C5,32'
    ],
    upper_2: ['R,1'],
    lower: ['R,1'],
    lower_2: ['R,1'],
    lower_3: ['R,1'],
    pedal: ['R,1']
  },
  {
    label: '# Measure 135',
    upper: [
      'A4,32 D5,32 C5,32 D5,32 B4,32 G#4,32 F#4,32 G#4,32 E4,32 C5,32 B4,32 C5,32 A4,32 F4,32 E4,32 F4,32',
      'D4,32 B4,32 A4,32 B4,32 C4,32 A4,32 G4,32 A4,32 B3,32 G#4,32 F#4,32 G#4,32 E4,32 R,16.'
    ],
    upper_2: ['R,1'],
    lower: [
      'R,2.',
      'R,8 R,32 C4,32 B3,32 A3,32'
    ],
    lower_2: ['R,1'],
    lower_3: ['R,1'],
    pedal: ['R,1']
  }
];

// Single source of truth for the tempo: the helper builds the TEMPO line in
// MUSIC_BACH_NOTATION_4 from this and the measure timeline uses it too.
var MUSIC_BACH_BPM_4 = 80;

var MUSIC_BACH_MEASURE_MAP_4 = BachScoreHelpers.buildMeasureMap(FUGUE_TRACKS_4, FUGUE_MEASURES_4, MUSIC_BACH_BPM_4);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_MEASURE_MAP_4 = MUSIC_BACH_MEASURE_MAP_4;
}

var MUSIC_BACH_NOTATION_4 = BachScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue in D minor, BWV 565 - Presto (measures 133-135)',
  '# Measures are stored chronologically below and emitted as synchronized tracks.'
], MUSIC_BACH_BPM_4, FUGUE_TRACKS_4, FUGUE_MEASURES_4);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_NOTATION_4 = MUSIC_BACH_NOTATION_4;
}

// ---- Section 5: Adagio Vivace (measures 136-140, 83 bpm) ----

var FUGUE_TRACKS_5 = {
  upper: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 1.'
  },
  upper_2: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 2.'
  },
  upper_3: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 3.'
  },
  upper_4: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 4.'
  },
  lower: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 1.'
  },
  pedal: {
    instrument: 'organ',
    header: '# Pedal, layer 1.'
  }
};

var FUGUE_MEASURES_5 = [
  {
    label: '# Measure 136',
    upper: [
      'R,32 D4,32 C4,32 B3,32 R,32 E4,32 D4,32 C4,32 R,32 F4,32 E4,32 D4,32 R,32 G4,32 F4,32 E4,32',
      'D4,32 A4,32 G4,32 F4,32 E4,32 G4,32 A4,32 B4,32 C5,4'
    ],
    upper_2: [
      'R,2.',
      'R,8 G4,8'
    ],
    upper_3: [
      'R,2.',
      'R,8 E4,8'
    ],
    upper_4: [
      'R,2.',
      'R,8 C4,8'
    ],
    lower: [
      'G#3,32 R,16. A3,32 R,16. B3,32 R,16. C4,32 R,4.',
      'R,16. G3,8'
    ],
    pedal: [
      'R,2.',
      'R,8 E3,8'
    ]
  },
  {
    label: '# Measure 137',
    upper: [
      'C#5,8 R,32 C#4,32 E4,32 A4,32 C#5,8 C#5,8',
      'D5,8 R,32 D4,32 F4,32 A4,32 D5,8 D5,8'
    ],
    upper_2: [
      'A4,8 R,4 A4,8',
      'A4,8 R,4 A4,8'
    ],
    upper_3: [
      'E4,8 R,4 E4,8',
      'F4,8 R,4 F4,8'
    ],
    upper_4: ['R,1'],
    lower: [
      'A3,8 A3,32 R,8. R,32 A3,8',
      'A3,8 A3,32 R,8. R,32 A3,8'
    ],
    pedal: [
      'G3,8 R,4 G3,8',
      'F3,8 R,4 F3,8'
    ]
  },
  {
    label: '# Measure 138',
    upper: [
      'B4,8 R,16 D4,32 G4,32 B4,8 B4,8',
      'C5,8 R,32 C4,32 E4,32 G4,32 C5,8 C5,8'
    ],
    upper_2: [
      'G4,8 R,4 G4,8',
      'G4,8 R,4 G4,8'
    ],
    upper_3: [
      'D4,8 R,4 D4,8',
      'E4,8 R,4 E4,8'
    ],
    upper_4: ['R,1'],
    lower: [
      'B3,8 G3,32 B3,32 R,8. G3,8',
      'G3,8 G3,32 R,8. R,32 G3,8'
    ],
    pedal: [
      'F3,8 R,4 F3,8',
      'E3,8 R,4 E3,8'
    ]
  },
  {
    label: '# Measure 139',
    upper: [
      'A4,8 R,16 C4,32 F4,32 A4,8 A4,8',
      'Bb4,8 R,16 D4,32 F4,32 Bb4,8 Bb4,8'
    ],
    upper_2: [
      'F4,8 R,4 F4,8',
      'F4,8 R,4 F4,8'
    ],
    upper_3: [
      'C4,8 R,4 C4,8',
      'D4,8 R,4 D4,8'
    ],
    upper_4: ['R,1'],
    lower: [
      'A3,8 F3,32 A3,32 R,8. F3,8',
      'F3,8 F3,32 Bb3,32 R,8. F3,8'
    ],
    pedal: [
      'E3,8 R,4 E3,8',
      'D3,8 R,4 D3,8'
    ]
  },
  {
    label: '# Measure 140',
    upper: [
      'Bb4,8 R,16. C#4,32 Bb4,8 Bb4,8',
      'A4,8 R,16 D4,32 F#4,32 A4,8 A4,8'
    ],
    upper_2: [
      'G4,8 R,4 G4,8',
      'F#4,8 R,4 F#4,8'
    ],
    upper_3: [
      'E4,8 R,4 E4,8',
      'D4,8 R,4 D4,8'
    ],
    upper_4: [
      'R,4. C#4,8',
      'R,2'
    ],
    lower: [
      'E3,8 E3,32 G3,32 Bb3,32 R,8 R,32 E3,8',
      'F#3,8 D3,32 A3,32 R,8. F#3,8'
    ],
    pedal: [
      'C#3,8 R,4 C#3,8',
      'C3,8 R,4 C3,8'
    ]
  }
];

// Single source of truth for the tempo: the helper builds the TEMPO line in
// MUSIC_BACH_NOTATION_5 from this and the measure timeline uses it too.
var MUSIC_BACH_BPM_5 = 83;

var MUSIC_BACH_MEASURE_MAP_5 = BachScoreHelpers.buildMeasureMap(FUGUE_TRACKS_5, FUGUE_MEASURES_5, MUSIC_BACH_BPM_5);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_MEASURE_MAP_5 = MUSIC_BACH_MEASURE_MAP_5;
}

var MUSIC_BACH_NOTATION_5 = BachScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue in D minor, BWV 565 - Adagio Vivace (measures 136-140)',
  '# Measures are stored chronologically below and emitted as synchronized tracks.'
], MUSIC_BACH_BPM_5, FUGUE_TRACKS_5, FUGUE_MEASURES_5);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_NOTATION_5 = MUSIC_BACH_NOTATION_5;
}

// ---- Section 6: Molto Adagio (measures 141-143, 60 bpm) ----

var FUGUE_TRACKS_6 = {
  upper: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 1.'
  },
  upper_2: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 2.'
  },
  upper_3: {
    instrument: 'organ',
    header: '# Upper manual (RH staff), layer 3.'
  },
  lower: {
    instrument: 'organ',
    header: '# Lower manual (LH staff), layer 1.'
  },
  pedal: {
    instrument: 'organ',
    header: '# Pedal, layer 1.'
  },
  pedal_2: {
    instrument: 'organ',
    header: '# Pedal, layer 2.'
  }
};

var FUGUE_MEASURES_6 = [
  {
    label: '# Measure 141',
    upper: [
      'A4,4 G4,2',
      'F4,4'
    ],
    upper_2: [
      'D4,2',
      'E4,4 D4,4'
    ],
    upper_3: [
      'Bb3,2',
      'C#4,4 R,4'
    ],
    lower: [
      'G3,2',
      'Bb3,4 A3,4'
    ],
    pedal: [
      'G2,4 Bb2,4',
      'E2,4 F2,4'
    ],
    pedal_2: ['R,1']
  },
  {
    label: '# Measure 142',
    upper: [
      'E4,2',
      'D4,2'
    ],
    upper_2: [
      'D4,4 C4,2',
      'Bb3,4'
    ],
    upper_3: ['R,1'],
    lower: [
      'A3,2',
      'F3,4 G3,4'
    ],
    pedal: [
      'A2,2',
      'Bb2,4 G2,4'
    ],
    pedal_2: ['R,1']
  },
  {
    label: '# Measure 143',
    upper: ['D4,1'],
    upper_2: ['A3,1'],
    upper_3: ['R,1'],
    lower: ['F3,1'],
    pedal: ['D3,1'],
    pedal_2: ['D2,1']
  },
  {
    label: '# Measure 143',
    upper: ['R,1'],
    upper_2: ['R,1'],
    upper_3: ['R,1'],
    lower: ['R,1'],
    pedal: ['R,1'],
    pedal_2: ['R,1']
  }
];

// Single source of truth for the tempo: the helper builds the TEMPO line in
// MUSIC_BACH_NOTATION_6 from this and the measure timeline uses it too.
var MUSIC_BACH_BPM_6 = 60;

var MUSIC_BACH_MEASURE_MAP_6 = BachScoreHelpers.buildMeasureMap(FUGUE_TRACKS_6, FUGUE_MEASURES_6, MUSIC_BACH_BPM_6);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_MEASURE_MAP_6 = MUSIC_BACH_MEASURE_MAP_6;
}

var MUSIC_BACH_NOTATION_6 = BachScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue in D minor, BWV 565 - Molto Adagio (measures 141-143)',
  '# Measures are stored chronologically below and emitted as synchronized tracks.'
], MUSIC_BACH_BPM_6, FUGUE_TRACKS_6, FUGUE_MEASURES_6);

if (typeof window !== 'undefined') {
  window.MUSIC_BACH_NOTATION_6 = MUSIC_BACH_NOTATION_6;
}

// CommonJS export for parser and timing checks outside the browser.
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    MUSIC_BACH_NOTATION: MUSIC_BACH_NOTATION,
    MUSIC_BACH_MEASURE_MAP: MUSIC_BACH_MEASURE_MAP,
    MUSIC_BACH_NOTATION_2: MUSIC_BACH_NOTATION_2,
    MUSIC_BACH_MEASURE_MAP_2: MUSIC_BACH_MEASURE_MAP_2,
    MUSIC_BACH_NOTATION_3: MUSIC_BACH_NOTATION_3,
    MUSIC_BACH_MEASURE_MAP_3: MUSIC_BACH_MEASURE_MAP_3,
    MUSIC_BACH_NOTATION_4: MUSIC_BACH_NOTATION_4,
    MUSIC_BACH_MEASURE_MAP_4: MUSIC_BACH_MEASURE_MAP_4,
    MUSIC_BACH_NOTATION_5: MUSIC_BACH_NOTATION_5,
    MUSIC_BACH_MEASURE_MAP_5: MUSIC_BACH_MEASURE_MAP_5,
    MUSIC_BACH_NOTATION_6: MUSIC_BACH_NOTATION_6,
    MUSIC_BACH_MEASURE_MAP_6: MUSIC_BACH_MEASURE_MAP_6
  };
}
