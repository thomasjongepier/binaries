// postfx.js - bloom and CRT display filters.
//
// Game.PostFx.bloom(rctx): additive glow on top of the already-drawn frame
// (rctx.canvas: the 320x200 buffer in pixel mode, the main bitmap otherwise).
// The frame is copied to a quarter-size canvas and drawn back blurred with
// 'lighter' at alpha 0.35 (blurred at quarter size), so crisp pixels stay underneath. Without
// ctx.filter support the glow is a plain smoothed upscale (no blur).
// Game.PostFx.crt(mctx, pixelMode): scanlines + radial vignette, cached in an
// overlay canvas and stamped once per frame onto the main canvas.
(function () {
  'use strict';

  window.Game = window.Game || {};

  var LOGICAL_W = 640;
  var BUF_H = 200;
  var BLOOM_ALPHA = 0.35;
  var BLUR_LOGICAL = 6; // blur radius in logical px (3px at buffer res)
  var PIXEL_SCANLINE_ALPHA = 0.25;
  var CLASSIC_SCANLINE_ALPHA = 0.15;
  var VIGNETTE_ALPHA = 0.45;

  function makeCanvas(w, h) {
    if (typeof document === 'undefined' || !document || typeof document.createElement !== 'function') { return null; }
    try {
      var c = document.createElement('canvas');
      if (!c || typeof c.getContext !== 'function') { return null; }
      c.width = w;
      c.height = h;
      return c;
    } catch (e) {
      return null;
    }
  }

  // Checked once at load: does the 2D context honour ctx.filter?
  var filterSupported = false;
  (function () {
    var c = makeCanvas(1, 1);
    var cx = c ? c.getContext('2d') : null;
    if (cx && 'filter' in cx) {
      try {
        cx.filter = 'blur(1px)';
        filterSupported = cx.filter === 'blur(1px)';
      } catch (e) {
        filterSupported = false;
      }
    }
  })();

  function setting(key) {
    var S = window.Game.Settings;
    return !!(S && S.get && S.get(key));
  }

  var small = null;
  var sctx = null;

  function bloom(rctx) {
    if (!rctx || !rctx.canvas || !setting('bloom') || setting('reduceMotion')) { return; }
    var src = rctx.canvas;
    var w = src.width;
    var h = src.height;
    var sw = Math.max(1, Math.round(w / 4));
    var sh = Math.max(1, Math.round(h / 4));
    if (!small) {
      small = makeCanvas(sw, sh);
      sctx = small ? small.getContext('2d') : null;
      if (!sctx) { small = null; return; }
    }
    if (small.width !== sw) { small.width = sw; }
    if (small.height !== sh) { small.height = sh; }
    sctx.setTransform(1, 0, 0, 1, 0, 0);
    sctx.globalCompositeOperation = 'copy';
    sctx.imageSmoothingEnabled = true;
    // Blur here, at quarter size (16x fewer pixels than blurring the upscaled
    // result on the main bitmap); the upscale below is then a plain draw.
    if (filterSupported) { sctx.filter = 'blur(' + (BLUR_LOGICAL * w / LOGICAL_W * sw / w) + 'px)'; }
    sctx.drawImage(src, 0, 0, w, h, 0, 0, sw, sh);
    if (filterSupported) { sctx.filter = 'none'; }
    sctx.globalCompositeOperation = 'source-over';

    rctx.save();
    rctx.setTransform(1, 0, 0, 1, 0, 0);
    rctx.globalCompositeOperation = 'lighter';
    rctx.globalAlpha = BLOOM_ALPHA;
    rctx.imageSmoothingEnabled = true;
    rctx.drawImage(small, 0, 0, sw, sh, 0, 0, w, h);
    rctx.restore();
  }

  var overlay = null;
  var overlayKey = '';

  function buildOverlay(w, h, pixelMode) {
    if (!overlay) { overlay = makeCanvas(w, h); }
    if (!overlay) { return false; }
    var cx = overlay.getContext('2d');
    if (!cx) { overlay = null; return false; }
    overlay.width = w; // also clears
    overlay.height = h;
    if (pixelMode) {
      // One scanline per buffer row: darken the lower half of each row.
      var rh = h / BUF_H;
      cx.fillStyle = 'rgba(0,0,0,' + PIXEL_SCANLINE_ALPHA + ')';
      for (var r = 0; r < BUF_H; r++) {
        var y0 = Math.round(r * rh + rh / 2);
        var y1 = Math.round((r + 1) * rh);
        cx.fillRect(0, y0, w, Math.max(1, y1 - y0));
      }
    } else {
      // 1 logical px dark line every 2 logical px.
      var s = w / LOGICAL_W;
      cx.fillStyle = 'rgba(0,0,0,' + CLASSIC_SCANLINE_ALPHA + ')';
      for (var y = 0; y < h; y += 2 * s) {
        cx.fillRect(0, Math.round(y), w, Math.max(1, Math.round(s)));
      }
    }
    // Radial vignette (the one allowed gradient).
    var g = cx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.sqrt(w * w + h * h) / 2);
    g.addColorStop(0, 'rgba(0,0,0,0)');
    g.addColorStop(1, 'rgba(0,0,0,' + VIGNETTE_ALPHA + ')');
    cx.fillStyle = g;
    cx.fillRect(0, 0, w, h);
    return true;
  }

  function crt(mctx, pixelMode) {
    if (!mctx || !mctx.canvas || !setting('crt')) { return; }
    var w = mctx.canvas.width;
    var h = mctx.canvas.height;
    var key = w + 'x' + h + (pixelMode ? 'p' : 'c');
    if (key !== overlayKey || !overlay) {
      if (!buildOverlay(w, h, !!pixelMode)) { return; }
      overlayKey = key;
    }
    mctx.save();
    mctx.setTransform(1, 0, 0, 1, 0, 0);
    mctx.globalCompositeOperation = 'source-over';
    mctx.globalAlpha = 1;
    mctx.drawImage(overlay, 0, 0);
    mctx.restore();
  }

  window.Game.PostFx = {
    bloom: bloom,
    crt: crt,
    isFilterSupported: function () { return filterSupported; }
  };
})();
