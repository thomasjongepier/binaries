// Spelunker - ship stamina resource.
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so main.js can call Stamina.update each frame,
// following the same getter/setter pattern as collision.js's shield.
//
// Drain trigger: ship.js has no dedicated "boost" input (Left/Right only
// scale scroll speed, not thrust intensity), so stamina drains at a small
// constant rate whenever the ship is actively thrusting - i.e. any
// movement key is held OR the mouse is driving the ship (see
// Game.Ship.isThrusting()) - and regenerates when idle.
//
// Depletion effect: once stamina hits 0, Game.Stamina.getMultiplier()
// returns a reduced value (halved thrust) that ship.js multiplies its
// keyboard acceleration by, until stamina recovers above a small
// hysteresis threshold - this avoids the multiplier flickering on/off
// every frame right at the 0 boundary.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('stamina.js requires window.Game to be set up by main.js first');
  }

  // ---- Tuning constants (relocated to Game.Balance.stamina in config.js) ----
  var MAX_STAMINA = Game.Balance.stamina.MAX_STAMINA;
  var DRAIN_RATE = Game.Balance.stamina.DRAIN_RATE;
  var REGEN_RATE = Game.Balance.stamina.REGEN_RATE;
  var RECOVER_THRESHOLD = Game.Balance.stamina.RECOVER_THRESHOLD;
  var DEPLETED_MULTIPLIER = Game.Balance.stamina.DEPLETED_MULTIPLIER;

  var stamina = MAX_STAMINA;
  var depleted = false; // true once stamina has hit 0, until it recovers past RECOVER_THRESHOLD

  function clamp(v, min, max) {
    return v < min ? min : (v > max ? max : v);
  }

  function reset() {
    stamina = MAX_STAMINA;
    depleted = false;
  }

  function drain(amount) {
    stamina = clamp(stamina - amount, 0, MAX_STAMINA);
    if (stamina <= 0) {
      if (!depleted && Game.Audio && Game.Audio.playGasp) {
        Game.Audio.playGasp(); // once per depletion (flag stays set until recovery)
      }
      depleted = true;
    }
  }

  function restore(amount) {
    stamina = clamp(stamina + amount, 0, MAX_STAMINA);
  }

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    var thrusting = (Game.Ship && Game.Ship.isThrusting) ? Game.Ship.isThrusting() : false;

    if (thrusting) {
      drain(DRAIN_RATE * dt);
    } else {
      restore(REGEN_RATE * dt);
    }

    if (depleted && stamina > RECOVER_THRESHOLD) {
      depleted = false;
    }
  }

  function getStamina() {
    return stamina;
  }

  function getMaxStamina() {
    return MAX_STAMINA;
  }

  function getMultiplier() {
    return depleted ? DEPLETED_MULTIPLIER : 1;
  }

  Game.Stamina = {
    update: update,
    reset: reset,
    getStamina: getStamina,
    getMaxStamina: getMaxStamina,
    drain: drain,
    restore: restore,
    getMultiplier: getMultiplier
  };
})();
