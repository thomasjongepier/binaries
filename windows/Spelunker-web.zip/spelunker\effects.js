// Spelunker - short-lived visual feedback effects (hazard-hit screen flash,
// discovery-collected pulse ring). Vanilla JS, no build tools, no
// dependencies. Attaches to window.Game (created by main.js) so main.js can
// call Effects.update/render/reset each frame, following the same
// Game.<Name> = {update, render, reset} convention as stamina.js/hazards.js.
//
// This is intentionally a separate module from hazards.js/pickup.js rather
// than each module tracking its own flash: both hazards.js (collapse/gas)
// and pickup.js (crystal/fossil) need a "trigger a decaying visual effect"
// primitive, and centralizing it here avoids duplicating timer/decay/render
// logic in two unrelated files. hazards.js and pickup.js call into this
// module's trigger functions at the moment of their own event (hazard
// damage / pickup collection) rather than this module polling for those
// events itself.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('effects.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;

  // ---- Hazard screen-flash state ----
  // A single active flash at a time is sufficient for this game's hazard
  // cadence (hazards.js cooldowns keep triggers well separated), so one
  // timer/color pair covers both collapse and gas; a fresh trigger simply
  // overwrites the previous one (which by that point in practice has almost
  // certainly already faded, given cooldown durations of 3-4s vs a flash
  // duration below of well under 1s).
  var FLASH_DURATION = 0.4; // seconds for the flash to fade from full to none
  var flashTimer = 0; // seconds remaining in the current flash
  var flashColor = null; // 'rgba(r,g,b,' prefix, alpha appended per-frame

  // Collapse: red-ish flash. Gas: sickly-green flash. Distinct from each
  // other and from the discovery pulse's gold/white below. Colours come from
  // the theme's hazardCollapse / hazardGas ramps (middle shade).
  var FLASH_MAX_ALPHA = 0.35;

  // Reduce-motion caps the flash alpha so it cannot strobe.
  var REDUCED_FLASH_MAX_ALPHA = 0.25;
  function flashMaxAlpha() {
    var S = Game.Settings;
    if (S && S.get && S.get('reduceMotion')) {
      return Math.min(FLASH_MAX_ALPHA, REDUCED_FLASH_MAX_ALPHA);
    }
    return FLASH_MAX_ALPHA;
  }

  function flashHazard(kind) {
    flashTimer = FLASH_DURATION;
    flashColor = Game.Theme.rgb(Game.Theme.ramp(kind === 'gas' ? 'hazardGas' : 'hazardCollapse')[1]);
  }

  // ---- Discovery pulse-ring state ----
  // Multiple pulses can be in flight at once (e.g. two discoveries collected
  // in quick succession at different points on screen), so these are tracked
  // as a list of independent, short-lived ring effects rather than a single
  // shared timer.
  var PULSE_DURATION = 0.4; // seconds for the ring to expand and fade out
  var PULSE_MAX_RADIUS = 34; // px, expanding from 0 at spawn to this at end
  var pulses = []; // each: { x, y, timer } - timer counts down from PULSE_DURATION

  function pulseDiscovery(x, y) {
    pulses.push({ x: x, y: y, timer: PULSE_DURATION });
  }

  // ---- Score pop-ups ----
  var POP_DURATION = 0.6; // seconds to fade out
  var POP_RISE = 16; // px drifted upward over the lifetime
  var pops = []; // each: { text, x, y, timer }

  function popText(text, x, y) {
    pops.push({ text: String(text), x: x, y: y, timer: POP_DURATION });
  }

  function reset() {
    pops = [];
    flashTimer = 0;
    flashColor = null;
    pulses = [];
  }

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    if (flashTimer > 0) {
      flashTimer = Math.max(0, flashTimer - dt);
    }

    for (var k = pops.length - 1; k >= 0; k--) {
      pops[k].timer -= dt;
      if (pops[k].timer <= 0) pops.splice(k, 1);
    }

    for (var i = pulses.length - 1; i >= 0; i--) {
      pulses[i].timer -= dt;
      if (pulses[i].timer <= 0) {
        pulses.splice(i, 1);
      }
    }
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    // Discovery pulses are drawn first (over the scene, under the flash
    // overlay and HUD), then the hazard flash last as a full-canvas overlay
    // so it reads as a screen-wide reaction to damage rather than being
    // hidden beneath any other gameplay element.
    for (var i = 0; i < pulses.length; i++) {
      var p = pulses[i];
      var t = 1 - (p.timer / PULSE_DURATION); // 0 at spawn -> 1 at end
      var radius = PULSE_MAX_RADIUS * t;
      var alpha = 1 - t;

      ctx.save();
      ctx.strokeStyle = 'rgba(' + Game.Theme.rgb(Game.Theme.ramp('fossil')[3]) + ',' + alpha.toFixed(3) + ')'; // gold
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
      ctx.stroke();

      // Inner white ring, slightly smaller and fainter, for a brighter core.
      ctx.strokeStyle = 'rgba(' + Game.Theme.rgb(Game.Theme.ramp('ui')[3]) + ',' + (alpha * 0.8).toFixed(3) + ')';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(p.x, p.y, radius * 0.6, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    for (var j = 0; j < pops.length; j++) {
      var pp = pops[j];
      var pt = 1 - pp.timer / POP_DURATION;
      ctx.save();
      ctx.globalAlpha = Math.max(0, 1 - pt);
      var py = pp.y - POP_RISE * pt;
      if (Game.Font && Game.Font.draw) {
        Game.Font.draw(ctx, pp.text, pp.x, py, { role: 'hud', css: 'bold 14px monospace', color: Game.Theme.rgb ? 'rgb(' + Game.Theme.rgb(Game.Theme.ramp('ui')[3]) + ')' : '#fff', align: 'center', baseline: 'middle' });
      } else {
        ctx.font = 'bold 14px monospace';
        ctx.fillStyle = '#fff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(pp.text, pp.x, py);
      }
      ctx.restore();
    }

    if (flashTimer > 0 && flashColor) {
      var flashAlpha = flashMaxAlpha() * (flashTimer / FLASH_DURATION);
      ctx.save();
      ctx.fillStyle = 'rgba(' + flashColor + ',' + flashAlpha.toFixed(3) + ')';
      ctx.fillRect(0, 0, Game.W, Game.H);
      ctx.restore();
    }
  }

  Game.Effects = {
    update: update,
    render: render,
    reset: reset,
    flashHazard: flashHazard,
    flashMaxAlpha: flashMaxAlpha,
    pulseDiscovery: pulseDiscovery,
    popText: popText
  };
})();
