// Spelunker - ship vs enemy collision detection, lives, and crash handling.
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so main.js can call Collision.update/render each
// frame, following the same pattern as cave.js/ship.js.
//
// Note: cave-wall collisions are NOT handled here - ship.js's own update(dt)
// physically bounces the ship off the cave walls every frame, so there is no
// "wall crash" concept for this module to detect.
//
// One-shot-per-collision strategy (chosen for simplicity/robustness):
//   On first detecting an enemy overlap we decrement lives, start a brief
//   red "crash flash" render timer, and reposition the ship to a safe
//   mid-canvas y via Game.Ship.reset(). We then start an
//   INVULNERABLE_DURATION window during which collision checks are skipped
//   entirely. Because the ship is moved away from the enemy AND checks are
//   suspended for that window, a single continuous overlap can never cause
//   more than one decrement - there's no need for a separate "still
//   touching" flag since the reposition + timed grace period guarantees the
//   ship is clear of the enemy by the time checks resume.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('collision.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;
  function palette() { return Game.Theme.get(); }

  // ---- Tuning constants ----
  var DEFAULT_LIVES = 3;
  var INVULNERABLE_DURATION = 1.5; // seconds of post-crash grace period
  var CRASH_FLASH_DURATION = 0.4; // seconds the red flash overlay is shown
  var MAX_SHIELD = 100;
  var WALL_SHIELD_DAMAGE = 10;
  var OBSTACLE_SHIELD_DAMAGE = 50;

  var lives = DEFAULT_LIVES;
  var invulnerableTimer = 0; // seconds remaining; > 0 means checks are skipped
  var crashFlashTimer = 0; // seconds remaining; > 0 means draw the flash overlay
  var gameOver = false;
  var shield = MAX_SHIELD;
  var damageMult = 1; // difficulty preset, read in reset()

  function reset() {
    var D = Game.Difficulty;
    lives = (D && D.livesFor) ? D.livesFor(DEFAULT_LIVES) : DEFAULT_LIVES;
    damageMult = (D && D.damageFactor) ? D.damageFactor() : 1;
    invulnerableTimer = 0;
    crashFlashTimer = 0;
    gameOver = false;
    shield = MAX_SHIELD;
  }

  function damageShield(amount) {
    // Hazards can still be processed later in the same frame as a crash. Do
    // not let them consume another life during the grace period or after the
    // game has ended.
    if (gameOver || invulnerableTimer > 0) {
      return;
    }
    amount = amount * damageMult;
    if (shield - amount <= 0) {
      shield = MAX_SHIELD;
      triggerCrash();
    } else {
      shield -= amount;
    }
  }

  function restoreShield(amount) {
    shield = Math.min(MAX_SHIELD, shield + amount);
  }

  function triggerCrash() {
    if (gameOver || invulnerableTimer > 0) {
      return;
    }
    if (Game.Audio && Game.Audio.playCrashSound) {
      Game.Audio.playCrashSound();
    }

    if (Game.Camera && Game.Camera.shake) {
      Game.Camera.shake(8, 0.3);
    }
    if (Game.Camera && Game.Camera.hitStop) {
      Game.Camera.hitStop(0.07);
    }

    lives -= 1;
    crashFlashTimer = CRASH_FLASH_DURATION;
    invulnerableTimer = INVULNERABLE_DURATION;

    // Move the ship back to the vertical center of the actual cave gap at
    // its current world-x, so it is clear of the walls once the
    // invulnerability window ends. Deliberately NOT Game.Ship.reset(): that
    // repositions to a fixed canvas-relative y meant for full-game-reset
    // (title->playing/restart), which is not guaranteed to be inside the
    // gap mid-game since the gap center wanders (see cave.js). This must be
    // called before the ship's world-x changes (it hasn't at this point in
    // the frame - collision.js's update() only reads position, cave.js's
    // scrollX advances independently in its own update()), so this reflects
    // the ship's world-x at the moment of the crash.
    if (Game.Ship && Game.Ship.recenterInGap) {
      Game.Ship.recenterInGap();
    } else if (Game.Ship && Game.Ship.reset) {
      Game.Ship.reset();
    }

    if (lives <= 0) {
      lives = 0;
      gameOver = true;
      if (Game.setState && Game.STATES) {
        Game.setState(Game.STATES.GAMEOVER);
      }
    }
  }

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    if (crashFlashTimer > 0) {
      crashFlashTimer = Math.max(0, crashFlashTimer - dt);
    }

    if (gameOver) {
      return;
    }

    if (invulnerableTimer > 0) {
      invulnerableTimer = Math.max(0, invulnerableTimer - dt);
      return; // skip collision checks entirely during the grace period
    }

    if (!Game.Ship || !Game.Ship.getPosition) {
      return;
    }

    var pos = Game.Ship.getPosition();
    // Read the real exported radius from ship.js; the `|| 10` is only a
    // defensive fallback in case Game.Ship somehow isn't loaded yet.
    var radius = (Game.Ship && Game.Ship.SHIP_RADIUS) || 10;

    // ---- Ship vs enemy ----
    // Kept here (rather than in enemy.js) so all "what counts as a crash"
    // and lives/invulnerability logic stays centralized in one owner.
    // enemy.js only tracks/renders enemy positions via getAll().
    if (Game.Enemies && Game.Enemies.getAll) {
      var enemies = Game.Enemies.getAll();
      // enemy.js does not currently expose its ENEMY_RADIUS as a documented
      // API, but does attach it to Game.Enemies for convenience; fall back
      // to the known value (12) here in case that ever changes, matching
      // the same fallback pattern used above for the ship's radius.
      var enemyRadius = (Game.Enemies && Game.Enemies.ENEMY_RADIUS) || 12;
      for (var i = 0; i < enemies.length; i++) {
        var enemy = enemies[i];
        var dx = pos.worldX - enemy.worldX;
        var dy = pos.y - enemy.y;
        var hitRadius = radius + enemyRadius;
        if ((dx * dx + dy * dy) <= (hitRadius * hitRadius)) {
          if (Game.Enemies && Game.Enemies.explode) {
            Game.Enemies.explode(enemy);
          }
          if (Game.Ship && Game.Ship.triggerHitFlash) {
            Game.Ship.triggerHitFlash();
          }
          damageShield(OBSTACLE_SHIELD_DAMAGE);
          break;
        }
      }
    }
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    if (crashFlashTimer > 0) {
      ctx.save();
      ctx.globalAlpha = 0.5;
      ctx.fillStyle = palette().RED;
      ctx.fillRect(0, 0, Game.W, Game.H);
      ctx.restore();
    }
  }

  function getLives() {
    return lives;
  }

  function isGameOver() {
    return gameOver;
  }

  function getShield() {
    return shield;
  }

  function getMaxShield() {
    return MAX_SHIELD;
  }

  Game.Collision = {
    update: update,
    render: render,
    reset: reset,
    getLives: getLives,
    isGameOver: isGameOver,
    getShield: getShield,
    getMaxShield: getMaxShield,
    damageShield: damageShield,
    restoreShield: restoreShield,
    WALL_SHIELD_DAMAGE: WALL_SHIELD_DAMAGE
  };
})();
