// Spelunker - swaying vines (campaign mechanic 'vines').
// Vanilla JS, no build tools. Attaches to window.Game.
//
// A vine is a soft obstacle anchored on the cave ceiling or floor at a fixed
// world-x. It reaches toward the middle of the cave (never more than 60% of
// the local gap, so the cave stays passable) and its tip sways on a sine.
// Touching it costs a little shield and slows the ship once per vine per
// second; a projectile cuts it. Vines only exist while Levels.unlocked('vines')
// and use their own random stream, so locked/endless runs are unaffected.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('vines.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;

  // ---- Tuning ----
  var SPAWN_INTERVAL_MIN = 3.5; // seconds, scaled by Difficulty.spawnFactor()
  var SPAWN_INTERVAL_MAX = 6;
  var MAX_VINES = 6;
  var LEN_MIN = 40; // px
  var LEN_MAX = 110;
  var MAX_GAP_FRACTION = 0.6; // length never exceeds this share of the local gap
  var MIN_FREE_GAP = 44; // px of open cave that must remain beside a vine
  var MIN_LENGTH = 24; // floor for the length cap
  var SWAY_MIN = 6; // px, tip amplitude
  var SWAY_MAX = 14;
  var PERIOD_MIN = 2; // seconds per full sway
  var PERIOD_MAX = 3.5;
  var SEGMENTS = 7; // polyline segments per vine
  var THICKNESS = 6; // px, collision half-width is THICKNESS / 2
  var ANCHOR_INSET = 2; // px the anchor sinks into the rock
  var HIT_COOLDOWN = 1.0; // seconds between hits from the same vine
  var HIT_DAMAGE = 3;
  var HIT_SLOW = 0.5; // ship velocity multiplier per hit
  var PROJECTILE_RADIUS = 4;
  var CUT_SCORE = 10;
  var CULL_SCREEN_X = -60;
  var SPAWN_AHEAD_BUFFER = (Game.Cave && Game.Cave.SEGMENT_SPACING) || 40;

  var vines = []; // each: { worldX, anchorY, dir, length, sway, period, phase, age, hitCd }
  var spawnTimer = -1; // < 0 means "roll on the next unlocked update"

  function stream() { return Game.Random.stream('vines'); }

  function isUnlocked() {
    return !!(Game.Levels && Game.Levels.unlocked && Game.Levels.unlocked('vines'));
  }
  function spawnsEnabled() {
    return !(Game.Levels && Game.Levels.spawnsEnabled) || Game.Levels.spawnsEnabled();
  }
  function invulnerable() {
    return !!(Game.Levels && Game.Levels.playerInvulnerable && Game.Levels.playerInvulnerable());
  }
  function scrollX() {
    return (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;
  }

  function rollTimer() {
    var f = (Game.Difficulty && Game.Difficulty.spawnFactor) ? Game.Difficulty.spawnFactor() : 1;
    spawnTimer = stream().range(SPAWN_INTERVAL_MIN, SPAWN_INTERVAL_MAX) * f;
  }

  function reset() {
    vines = [];
    spawnTimer = -1;
  }

  // Sway offset (px) of a vine's tip at its current age.
  function tipOffset(v) {
    return v.sway * Math.sin(2 * Math.PI * v.age / v.period + v.phase);
  }

  // Position of point i (0 = anchor .. SEGMENTS = tip) in world coordinates.
  // The bend grows with the square of the distance from the anchor.
  var pt = { x: 0, y: 0 };
  function pointAt(v, i, off) {
    var t = i / SEGMENTS;
    pt.x = v.worldX + off * t * t;
    pt.y = v.anchorY + v.dir * v.length * t;
    return pt;
  }

  // Distance squared from (px, py) to segment (ax, ay)-(bx, by).
  function distSqToSegment(px, py, ax, ay, bx, by) {
    var dx = bx - ax, dy = by - ay;
    var len2 = dx * dx + dy * dy;
    var u = len2 > 0 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0;
    u = u < 0 ? 0 : (u > 1 ? 1 : u);
    var cx = ax + u * dx - px, cy = ay + u * dy - py;
    return cx * cx + cy * cy;
  }

  // True if a circle at world (x, y) with radius r touches the vine.
  function hitTest(v, x, y, r) {
    var off = tipOffset(v);
    var reach = r + THICKNESS / 2;
    var p = pointAt(v, 0, off);
    var ax = p.x, ay = p.y;
    for (var i = 1; i <= SEGMENTS; i++) {
      p = pointAt(v, i, off);
      if (distSqToSegment(x, y, ax, ay, p.x, p.y) <= reach * reach) { return true; }
      ax = p.x; ay = p.y;
    }
    return false;
  }

  function leafBurst(v, count) {
    if (!Game.Particles || !Game.Particles.emit) { return; }
    var off = tipOffset(v);
    var p = pointAt(v, SEGMENTS >> 1, off);
    Game.Particles.emit(p.x - scrollX(), p.y, { count: count, speed: { min: 20, max: 90 },
      life: { min: 0.3, max: 0.7 }, size: { min: 1, max: 2 }, ramp: 'vine', gravity: 80 });
  }

  // Cap: at most 60% of the gap, and always leave >= MIN_FREE_GAP px free.
  function maxLength(gap) {
    return Math.max(MIN_LENGTH, Math.min(gap * MAX_GAP_FRACTION, gap - MIN_FREE_GAP));
  }

  function spawn() {
    if (vines.length >= MAX_VINES || !Game.Cave || !Game.Cave.getCaveBoundsAtX) { return; }
    var s = stream();
    var worldX = scrollX() + Game.W + SPAWN_AHEAD_BUFFER;
    var b = Game.Cave.getCaveBoundsAtX(worldX);
    var gap = b.bottom - b.top;
    var fromCeiling = s.next() < 0.5;
    var len = Math.min(s.range(LEN_MIN, LEN_MAX), maxLength(gap));
    var period = s.range(PERIOD_MIN, PERIOD_MAX);
    vines.push({
      worldX: worldX,
      anchorY: (fromCeiling ? b.top : b.bottom) + (fromCeiling ? -ANCHOR_INSET : ANCHOR_INSET),
      dir: fromCeiling ? 1 : -1,
      length: len,
      sway: s.range(SWAY_MIN, SWAY_MAX),
      period: period,
      phase: s.next() * Math.PI * 2,
      age: 0,
      hitCd: 0
    });
  }

  function update(dt) {
    if (!(dt > 0)) { return; }

    if (isUnlocked() && spawnsEnabled()) {
      if (spawnTimer < 0) { rollTimer(); }
      spawnTimer -= dt;
      if (spawnTimer <= 0) {
        spawn();
        rollTimer();
      }
    }

    var sx = scrollX();
    var i, v;
    for (i = 0; i < vines.length; i++) {
      v = vines[i];
      v.age += dt;
      if (v.hitCd > 0) { v.hitCd -= dt; }
    }

    // Projectiles (screen-space) cut vines; the projectile is consumed.
    var projectiles = (Game.Projectiles && Game.Projectiles.getAll) ? Game.Projectiles.getAll() : null;
    if (projectiles) {
      for (i = vines.length - 1; i >= 0; i--) {
        v = vines[i];
        for (var pi = projectiles.length - 1; pi >= 0; pi--) {
          if (hitTest(v, projectiles[pi].x + sx, projectiles[pi].y, PROJECTILE_RADIUS)) {
            projectiles.splice(pi, 1);
            leafBurst(v, 12);
            vines.splice(i, 1);
            if (Game.Score && Game.Score.addDiscovery) { Game.Score.addDiscovery(CUT_SCORE); }
            break;
          }
        }
      }
    }

    // Ship contact: one soft hit per vine per HIT_COOLDOWN.
    if (Game.Ship && Game.Ship.getPosition && !invulnerable()) {
      var pos = Game.Ship.getPosition();
      var radius = Game.Ship.SHIP_RADIUS || 10;
      for (i = 0; i < vines.length; i++) {
        v = vines[i];
        if (v.hitCd > 0 || !hitTest(v, pos.worldX, pos.y, radius)) { continue; }
        v.hitCd = HIT_COOLDOWN;
        if (Game.Collision && Game.Collision.damageShield) { Game.Collision.damageShield(HIT_DAMAGE); }
        if (Game.Ship.scaleVelocity) { Game.Ship.scaleVelocity(HIT_SLOW); }
        leafBurst(v, 6);
      }
    }

    for (i = vines.length - 1; i >= 0; i--) {
      if (vines[i].worldX - sx < CULL_SCREEN_X) { vines.splice(i, 1); }
    }
  }

  function snapV(P, n) { return P && P.snap ? P.snap(n) : n; }

  function render(rctx) {
    ctx = rctx || Game.ctx;
    if (!vines.length) { return; }
    var T = Game.Theme;
    var r = (T && T.ramp) ? T.ramp('vine') : ['#1F6B2A', '#3FA83A', '#7BD14A', '#B6F27A'];
    var P = Game.Pixel;
    var sx = scrollX();
    ctx.save();
    ctx.lineCap = 'butt';
    ctx.lineJoin = 'round';
    for (var i = 0; i < vines.length; i++) {
      var v = vines[i];
      var screenX = v.worldX - sx;
      if (screenX < -40 || screenX > Game.W + 40) { continue; }
      var off = tipOffset(v);
      var k, p, x0, y0, x1, y1;
      // Pale outline then lime stem: reads as a bright foreground hazard even
      // outside the lamp, unlike the dim scenery vines in the background.
      for (var pass = 0; pass < 2; pass++) {
        ctx.strokeStyle = pass === 0 ? r[3] : r[2];
        ctx.lineWidth = pass === 0 ? 10 : 6;
        ctx.beginPath();
        for (k = 0; k <= SEGMENTS; k++) {
          p = pointAt(v, k, off);
          x1 = snapV(P, p.x - sx);
          y1 = snapV(P, p.y);
          if (k === 0) { ctx.moveTo(x1, y1); } else { ctx.lineTo(x1, y1); }
        }
        ctx.stroke();
      }
      // Leaves: alternating blobs along the stem.
      for (k = 1; k <= SEGMENTS; k++) {
        p = pointAt(v, k, off);
        x0 = snapV(P, p.x - sx);
        y0 = snapV(P, p.y);
        ctx.fillStyle = (k & 2) ? r[3] : r[2];
        ctx.fillRect((k & 1) ? x0 - 12 : x0 + 4, y0 - 3, 8, 6);
      }
      // Tip bulb with a pulsing warm glow.
      p = pointAt(v, SEGMENTS, off);
      var tx = snapV(P, p.x - sx), ty = snapV(P, p.y);
      ctx.globalAlpha = 0.3 + 0.25 * (0.5 + 0.5 * Math.sin(v.age * 5));
      ctx.fillStyle = r[3];
      ctx.fillRect(tx - 9, ty - 9, 18, 18);
      ctx.globalAlpha = 1;
      ctx.fillStyle = r[3];
      ctx.fillRect(tx - 5, ty - 5, 10, 10);
      ctx.fillStyle = r[1];
      ctx.fillRect(tx - 2, ty - 2, 4, 4);
    }
    ctx.restore();
  }

  function getAll() { return vines; }

  Game.Vines = {
    update: update,
    render: render,
    reset: reset,
    getAll: getAll,
    hitTest: hitTest,
    tipOffset: tipOffset,
    maxLength: maxLength,
    MAX_VINES: MAX_VINES,
    HIT_COOLDOWN: HIT_COOLDOWN,
    HIT_DAMAGE: HIT_DAMAGE
  };
})();
