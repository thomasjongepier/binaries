// theme.js - runtime-switchable colour themes (classic C64 and modern 16-bit).
//
// Loaded after main.js. Other modules read colours at draw time through
// Game.Theme.get() / Game.Theme.ramp(name), so Game.Theme.set(name) takes
// effect on the next frame. Sprite/tile caches should compare
// Game.Theme.version() to know when to rebuild.
(function () {
  'use strict';

  window.Game = window.Game || {};

  // ---- Classic: the exact 16 C64 colours (formerly PALETTE in main.js) ----
  var C = {
    BLACK: '#000000',
    WHITE: '#FFFFFF',
    RED: '#883932',
    CYAN: '#67B6BD',
    PURPLE: '#8B3F96',
    GREEN: '#55A049',
    BLUE: '#40318D',
    YELLOW: '#BFCE72',
    ORANGE: '#8B5429',
    BROWN: '#574200',
    LIGHT_RED: '#B86962',
    DARK_GREY: '#505050',
    GREY: '#787878',
    LIGHT_GREEN: '#94E089',
    LIGHT_BLUE: '#7869C4',
    LIGHT_GREY: '#9F9F9F'
  };

  // Classic ramps use only C64 colours (repeats allowed), dark to light, with
  // one deliberate exception: fossil[3] is the discovery-pulse gold #FFD700,
  // which the classic pulse ring has always used and which is not a C64 colour.
  var CLASSIC_RAMPS = {
    rock: [C.DARK_GREY, C.DARK_GREY, C.GREY, C.GREY, C.LIGHT_GREY],
    rockHot: [C.BROWN, C.BROWN, C.ORANGE, C.ORANGE, C.LIGHT_RED],
    backdrop: [C.BLACK, C.BLACK, C.BLUE, C.BLUE],
    hull: [C.DARK_GREY, C.GREY, C.LIGHT_GREY, C.WHITE],
    cockpit: [C.LIGHT_BLUE, C.CYAN, C.CYAN],
    fire: [C.RED, C.ORANGE, C.LIGHT_RED, C.YELLOW, C.WHITE],
    enemy: [C.PURPLE, C.PURPLE, C.LIGHT_BLUE, C.LIGHT_RED],
    enemyFast: [C.GREEN, C.GREEN, C.CYAN, C.LIGHT_GREEN],
    enemyWeave: [C.BROWN, C.ORANGE, C.LIGHT_RED, C.YELLOW],
    enemySnake: [C.BLUE, C.CYAN, C.YELLOW, C.WHITE],
    enemySwarm: [C.PURPLE, C.LIGHT_RED, C.YELLOW, C.WHITE],
    ghost: [C.BLUE, C.CYAN, C.WHITE, C.WHITE],
    vine: [C.GREEN, C.LIGHT_GREEN, C.LIGHT_GREEN, C.YELLOW],
    boulder: [C.BROWN, C.GREY, C.LIGHT_GREY, C.WHITE],
    boulderWarn: [C.RED, C.ORANGE, C.YELLOW, C.WHITE],
    dragon: [C.GREEN, C.LIGHT_GREEN, C.YELLOW, C.WHITE],
    gravity: [C.BLUE, C.PURPLE, C.CYAN, C.WHITE],
    ammo: [C.BLUE, C.LIGHT_BLUE, C.LIGHT_BLUE, C.CYAN],
    shield: [C.GREEN, C.GREEN, C.LIGHT_GREEN, C.LIGHT_GREEN],
    crystal: [C.LIGHT_BLUE, C.CYAN, C.CYAN, C.WHITE],
    fossil: [C.BROWN, C.ORANGE, C.YELLOW, '#FFD700'],
    ui: [C.DARK_GREY, C.LIGHT_GREY, C.YELLOW, C.WHITE],
    hazardCollapse: [C.BROWN, C.RED, C.LIGHT_RED],
    hazardGas: [C.DARK_GREY, C.GREEN, C.LIGHT_GREEN]
  };

  // ---- Modern: RGB555 ramps, each colour given as 5-bit [r, g, b] steps ----
  function hex555(t) {
    var s = '#';
    for (var i = 0; i < 3; i++) {
      var h = Math.round(t[i] * 255 / 31).toString(16).toUpperCase();
      s += h.length < 2 ? '0' + h : h;
    }
    return s;
  }

  var MODERN_STEPS = {
    rock: [[4, 4, 8], [8, 8, 13], [12, 12, 18], [16, 16, 23], [21, 21, 27]],
    rockHot: [[6, 2, 1], [11, 5, 2], [16, 8, 3], [21, 12, 4], [26, 17, 6]],
    backdrop: [[0, 0, 2], [1, 2, 5], [2, 5, 8], [3, 8, 11]],
    hull: [[10, 12, 16], [15, 18, 23], [21, 24, 28], [29, 30, 31]],
    cockpit: [[2, 12, 16], [4, 19, 24], [8, 25, 30]],
    fire: [[14, 2, 2], [24, 4, 3], [31, 15, 2], [31, 26, 6], [31, 30, 24]],
    enemy: [[8, 2, 12], [13, 4, 18], [19, 6, 24], [26, 12, 29]],
    enemyFast: [[1, 10, 10], [3, 16, 15], [7, 22, 20], [16, 29, 25]],
    enemyWeave: [[14, 4, 5], [22, 8, 9], [29, 14, 13], [31, 22, 19]],
    enemySnake: [[2, 14, 16], [7, 29, 27], [31, 25, 4], [31, 31, 22]],
    enemySwarm: [[14, 2, 14], [28, 6, 26], [31, 27, 4], [31, 31, 24]],
    ghost: [[3, 6, 16], [17, 28, 30], [25, 31, 31], [31, 31, 31]],
    vine: [[6, 16, 5], [14, 24, 6], [22, 30, 9], [28, 31, 16]],
    boulder: [[8, 5, 3], [14, 10, 6], [21, 17, 12], [28, 25, 19]],
    boulderWarn: [[28, 4, 3], [31, 15, 2], [31, 26, 6], [31, 31, 28]],
    dragon: [[2, 11, 7], [5, 22, 14], [30, 24, 5], [28, 31, 22]],
    gravity: [[5, 3, 16], [12, 8, 26], [8, 22, 30], [24, 30, 31]],
    ammo: [[3, 5, 16], [5, 10, 23], [9, 17, 28], [17, 24, 31]],
    shield: [[2, 10, 4], [5, 17, 7], [10, 24, 11], [19, 30, 18]],
    crystal: [[3, 13, 17], [7, 20, 25], [13, 26, 30], [22, 31, 31]],
    fossil: [[10, 6, 1], [17, 12, 2], [24, 19, 3], [30, 26, 10]],
    ui: [[6, 8, 11], [14, 16, 20], [24, 25, 26], [31, 30, 27]],
    hazardCollapse: [[12, 3, 3], [20, 6, 5], [28, 11, 8]],
    hazardGas: [[3, 12, 4], [8, 19, 7], [16, 27, 12]]
  };

  var MODERN_RAMPS = {};
  Object.keys(MODERN_STEPS).forEach(function (name) {
    MODERN_RAMPS[name] = MODERN_STEPS[name].map(hex555);
  });
  var R = MODERN_RAMPS;

  // Every legacy PALETTE key still exists in modern, mapped to a ramp entry.
  var MODERN_PALETTE = {
    BLACK: R.backdrop[0],
    WHITE: R.ui[3],
    RED: R.hazardCollapse[1],
    CYAN: R.cockpit[2],
    PURPLE: R.enemy[2],
    GREEN: R.shield[1],
    BLUE: R.ammo[0],
    YELLOW: R.fire[3],
    ORANGE: R.fire[2],
    BROWN: R.rockHot[1],
    LIGHT_RED: R.hazardCollapse[2],
    DARK_GREY: R.rock[1],
    GREY: R.rock[2],
    LIGHT_GREEN: R.shield[3],
    LIGHT_BLUE: R.ammo[2],
    LIGHT_GREY: R.hull[2]
  };

  // Font map: role -> bitmap face name ('small'/'large', see font.js) or a CSS
  // canvas font string. Game.Font.draw falls back to fillText for CSS strings.
  var CLASSIC_FONTS = {
    title: 'bold 44px monospace',
    hud: 'bold 14px monospace',
    body: 'bold 16px monospace'
  };
  var MODERN_FONTS = { title: 'large', hud: 'small', body: 'small' };

  function build(name, pal, ramps, pixelMode, fonts) {
    var o = {};
    Object.keys(pal).forEach(function (k) { o[k] = pal[k]; });
    o.pixelMode = pixelMode;
    return { name: name, palette: o, ramps: ramps, fonts: fonts };
  }

  var THEMES = {
    classic: build('classic', C, CLASSIC_RAMPS, false, CLASSIC_FONTS),
    modern: build('modern', MODERN_PALETTE, MODERN_RAMPS, true, MODERN_FONTS)
  };

  // ---- High contrast: blue and orange replace red and green for hazard,
  // enemy-variant and pickup states. Overlays whichever theme is active. ----
  var HIGH_CONTRAST_RAMPS = {
    enemyFast: ['#B34A00', '#FF8C1A', '#FFB84D', '#FFE0A8'],
    enemyWeave: ['#3E1A66', '#8F4FD8', '#C9A0FF', '#F1E4FF'],
    enemySnake: ['#0B3D6B', '#2FA4E0', '#F5E663', '#FFFBD0'],
    enemySwarm: ['#5A1A7A', '#E65CFF', '#FFE14D', '#FFFFFF'],
    ghost: ['#0B2A5C', '#BFEFFF', '#EAFBFF', '#FFFFFF'],
    shield: ['#0A2FA0', '#1E5BFF', '#5C8CFF', '#A8C4FF'],
    boulderWarn: ['#B38A00', '#FFD21A', '#FFF07A', '#FFFFFF'],
    dragon: ['#0B3D5C', '#27B5C9', '#F5C842', '#FFFBD0'],
    gravity: ['#2A1A7A', '#7A5CFF', '#2FD0E0', '#E8FBFF'],
    hazardCollapse: ['#7A3300', '#FF8C1A', '#FFC266'],
    hazardGas: ['#0A2FA0', '#1E5BFF', '#7AA2FF']
  };
  var highContrast = false;

  var active = THEMES.classic;
  var versionCounter = 0;
  var warned = {};

  function get() {
    return active.palette;
  }

  function ramp(name) {
    var r = (highContrast && HIGH_CONTRAST_RAMPS[name]) || active.ramps[name];
    if (!r) {
      if (!warned[name]) {
        warned[name] = true;
        if (typeof console !== 'undefined' && console.warn) {
          console.warn('Game.Theme.ramp: unknown ramp "' + name + '", using "ui"');
        }
      }
      r = active.ramps.ui;
    }
    if (name === 'rock' && window.Game.Biomes && window.Game.Biomes.rockRamp) {
      return window.Game.Biomes.rockRamp(r);
    }
    return r;
  }

  function font(role) {
    return active.fonts[role] || active.fonts.body;
  }

  function set(name) {
    active = THEMES[name] || THEMES.classic;
    versionCounter++;
    return active.name;
  }

  function setHighContrast(on) {
    on = !!on;
    if (on !== highContrast) {
      highContrast = on;
      versionCounter++;
    }
    return highContrast;
  }

  function isHighContrast() {
    return highContrast;
  }

  function current() {
    return active.name;
  }

  function version() {
    var B = window.Game.Biomes;
    return versionCounter + (B && B.version ? B.version() : 0);
  }

  // '#RRGGBB' -> 'r,g,b' for building rgba() strings.
  function rgb(hex) {
    var n = parseInt(hex.slice(1), 16);
    return ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255);
  }

  window.Game.Theme = {
    get: get,
    ramp: ramp,
    font: font,
    set: set,
    setHighContrast: setHighContrast,
    isHighContrast: isHighContrast,
    HIGH_CONTRAST_RAMPS: HIGH_CONTRAST_RAMPS,
    current: current,
    version: version,
    rgb: rgb,
    // Exposed for tests/tools: names of all themes.
    names: function () { return Object.keys(THEMES); }
  };

  // Follow the stored highContrast setting.
  (function () {
    var S = window.Game.Settings;
    if (S && S.get) { setHighContrast(S.get('highContrast')); }
    if (S && S.onChange) {
      S.onChange(function (key) { if (key === 'highContrast') { setHighContrast(S.get('highContrast')); } });
    }
  })();

  // Compatibility alias: the classic palette.
  window.Game.PALETTE = THEMES.classic.palette;
})();
