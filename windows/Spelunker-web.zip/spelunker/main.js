// Spelunker - C64-style cave-flyer scaffold
// Vanilla JS, no build tools, no dependencies.

(function () {
  'use strict';

  // Colours come from Game.Theme (theme.js), read at draw time.
  function palette() { return window.Game.Theme.get(); }

  var canvas = document.getElementById('game');
  var ctx = canvas.getContext('2d');

  // Shared namespace so other classic (non-module) scripts, e.g. cave.js,
  // can read canvas/ctx/PALETTE and register per-frame hooks without any
  // <script type="module">/import-export machinery (which would break
  // the plain file:// requirement in some browsers).
  window.Game = window.Game || {};
  window.Game.canvas = canvas;
  window.Game.ctx = ctx;

  // Logical play-field size. All gameplay and layout code works in these
  // coordinates (read Game.W / Game.H, never canvas.width / canvas.height).
  // The canvas BITMAP is larger on hi-DPI screens (see applyBitmapSize), and
  // its on-screen CSS size scales to fit the window (see style.css), so
  // canvas.width/height must not be used as a logical size anywhere.
  var W = 640;
  var H = 400;
  var MAX_DPR = 3; // cap the bitmap scale so a 4x/5x display can't balloon memory
  window.Game.W = W;
  window.Game.H = H;

  // Current bitmap scale (bitmap pixels per logical pixel).
  var dpr = 1;

  // Size the bitmap to the logical field times the device pixel ratio. Only
  // touches canvas.width/height when the dpr actually changed (assigning them
  // clears the bitmap, and resets the context transform, even to the same
  // value). Called once at startup and again from render() whenever the
  // effective dpr changes (browser zoom, window dragged to another monitor).
  // Game state is untouched; the next frame simply repaints the whole field.
  // Ultrahigh needs at least a 2x bitmap so the 4x art has pixels to land on.
  function targetDpr() {
    var d = Math.min(window.devicePixelRatio || 1, MAX_DPR);
    var S = window.Game && window.Game.Settings;
    if (S && S.get && S.get('resolution') === 'ultrahigh') { d = Math.max(d, 2); }
    return d;
  }

  function applyBitmapSize() {
    var nextDpr = targetDpr();
    var bw = Math.round(W * nextDpr);
    var bh = Math.round(H * nextDpr);
    if (canvas.width !== bw) {
      canvas.width = bw;
    }
    if (canvas.height !== bh) {
      canvas.height = bh;
    }
    dpr = nextDpr;
  }
  applyBitmapSize();

  // Simple state machine skeleton
  var STATES = {
    TITLE: 'title',
    PLAYING: 'playing',
    GAMEOVER: 'gameover',
    OPTIONS: 'options',
    HIGHSCORES: 'highscores',
    CODEX: 'codex'
  };

  var state = STATES.TITLE;
  window.Game.STATES = STATES;
  window.Game.getState = function () { return state; };
  // Exposed so other scripts (e.g. collision.js) can drive the state
  // machine (playing -> gameover) without a parallel state machine.
  window.Game.setState = function (next) { setState(next); };

  function stateBg(s) {
    var P = window.Game.Theme.get();
    if (s === 'title') return P.BLUE;
    if (s === 'gameover') return P.RED;
    return P.BLACK;
  }

  // Snapshot of the score at the moment 'gameover' is entered. Note: reading
  // Game.Enemies.getScore() live during the 'gameover' state turns out to be
  // safe too, since Enemies.reset() is only invoked from setState() on the
  // transition INTO 'playing' (see below), never on the transition into
  // 'gameover' - so the score is not zeroed while 'gameover' is showing.
  // We still snapshot at the transition for clarity/robustness, so the
  // gameover screen's displayed score can never change no matter what else
  // happens to Enemies' internal state while the gameover screen is up.
  var finalScore = 0;
  var finalBreakdown = null; // Score.getBreakdown() snapshot, frozen at GAMEOVER

  // Snapshot of this run's discovery tally (count + point value), taken at
  // the same 'gameover' transition as finalScore above and for the same
  // reason: Pickups.reset() only runs on the transition INTO 'playing', so
  // these values are frozen for as long as the gameover screen is up.
  var finalDiscoveryCount = 0;
  var finalDiscoveryScore = 0;
  var gameOverT = 0;          // value of `elapsed` at GAMEOVER entry (drives the count-up)
  var finalHighScore = false; // C9 qualification, when Game.HighScores exists
  var finalFinds = null;      // codex variants found this run
  var finalBiomes = null;     // biomes reached, when Game.Biomes exists

  // Single shared reset-and-transition-to-playing path, used for both
  // TITLE -> PLAYING and GAMEOVER -> PLAYING so there is exactly one place
  // that resets subsystem state (no parallel/duplicated reset logic).
  var finalLevel = 1;       // campaign level reached (snapshot at GAMEOVER entry)
  var finalCampaign = false; // run was a campaign run
  var finalVictory = false; // campaign completed (snapshot at GAMEOVER entry)

  function resetSubsystemsAndStartPlaying(prevState) {
    // Daily cave: seeds (or re-randomises) the random streams before any reset.
    if (window.Game.Daily && window.Game.Daily.prepareRun) {
      window.Game.Daily.prepareRun(prevState);
    }
    if (window.Game.Ship && window.Game.Ship.reset) {
      window.Game.Ship.reset();
    }
    if (window.Game.Collision && window.Game.Collision.reset) {
      window.Game.Collision.reset();
    }
    if (window.Game.Projectiles && window.Game.Projectiles.reset) {
      window.Game.Projectiles.reset();
    }
    if (window.Game.Score && window.Game.Score.reset) {
      window.Game.Score.reset();
    }
    if (window.Game.Biomes && window.Game.Biomes.reset) {
      window.Game.Biomes.reset();
    }
    if (window.Game.Levels) {
      finalVictory = false;
      if (window.Game.LevelScreen && window.Game.LevelScreen.reset) {
        window.Game.LevelScreen.reset();
      }
      if (window.Game.Mode === 'campaign') {
        window.Game.Levels.startCampaign(window.Game.Levels.startLevel || 1);
      } else {
        window.Game.Levels.stop();
      }
    }
    if (window.Game.Enemies && window.Game.Enemies.reset) {
      window.Game.Enemies.reset();
    }
    if (window.Game.Pickups && window.Game.Pickups.reset) {
      window.Game.Pickups.reset();
    }
    if (window.Game.Stamina && window.Game.Stamina.reset) {
      window.Game.Stamina.reset();
    }
    if (window.Game.Cave && window.Game.Cave.reset) {
      window.Game.Cave.reset();
    }
    if (window.Game.Hazards && window.Game.Hazards.reset) {
      window.Game.Hazards.reset();
    }
    if (window.Game.Vines && window.Game.Vines.reset) {
      window.Game.Vines.reset();
    }
    if (window.Game.Boulders && window.Game.Boulders.reset) {
      window.Game.Boulders.reset();
    }
    if (window.Game.Dragon && window.Game.Dragon.reset) {
      window.Game.Dragon.reset();
    }
    if (window.Game.Gravity && window.Game.Gravity.reset) {
      window.Game.Gravity.reset();
    }
    if (window.Game.Effects && window.Game.Effects.reset) {
      window.Game.Effects.reset();
    }
    if (window.Game.Particles && window.Game.Particles.reset) {
      window.Game.Particles.reset();
    }
    if (window.Game.Camera && window.Game.Camera.reset) {
      window.Game.Camera.reset();
    }
  }

  // Pause flag, deliberately separate from the STATES machine so title and
  // game-over logic are untouched. Only meaningful while state === PLAYING.
  var paused = false;
  window.Game.isPaused = function () { return paused; };

  // Options opened from the pause screen (O). The game stays in PLAYING (so
  // nothing resets); settings-screen.js treats this like STATES.OPTIONS and
  // calls closePausedOptions() on Esc to return to the pause screen.
  var pausedOptions = false;
  window.Game.isPausedOptions = function () { return paused && pausedOptions; };
  window.Game.closePausedOptions = function () {
    if (!pausedOptions) {
      return;
    }
    pausedOptions = false;
    if (window.Game.Audio && window.Game.Audio.stopMusicPreview) {
      window.Game.Audio.stopMusicPreview();
    }
  };

  // Keys whose keyup the browser will never deliver once the window loses
  // focus. ship.js tracks them from keydown/keyup only, so on a blur/hidden
  // pause we feed it synthetic keyups; otherwise a key released while away
  // would stay "held" forever. A manual (P/Esc) pause does NOT do this: real
  // keyups keep arriving (ship.js's keyup listener is not gated), so keys held
  // through the pause stay correct and keep thrusting on resume.
  var MOVE_KEYS = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 's'];
  function releaseMovementKeys() {
    if (typeof KeyboardEvent !== 'function') {
      return;
    }
    var list = MOVE_KEYS;
    var C = window.Game.Controls;
    if (C && C.eventKeysFor) {
      list = [].concat(C.eventKeysFor('up'), C.eventKeysFor('down'), C.eventKeysFor('left'), C.eventKeysFor('right'));
    }
    for (var i = 0; i < list.length; i++) {
      window.dispatchEvent(new KeyboardEvent('keyup', { key: list[i] }));
    }
  }

  function pauseGame(focusLost) {
    if (state !== STATES.PLAYING) {
      return;
    }
    if (paused) {
      // Already paused (e.g. P, then alt-tab): keyups may still be lost.
      if (focusLost) {
        releaseMovementKeys();
      }
      return;
    }
    paused = true;
    // Stop (not suspend) the music: the playlist advances on a wall-clock
    // setTimeout, which AudioContext.suspend() would not pause. stopMusic()
    // also cancels a pending inter-song gap timer, so pausing during the
    // 3-second gap cannot start the next song early. currentSongIndex is kept.
    if (window.Game.Audio && window.Game.Audio.stopMusic) {
      window.Game.Audio.stopMusic();
    }
    stopLoopedSfx();
    if (focusLost) {
      releaseMovementKeys();
    }
  }

  function resumeGame() {
    if (state !== STATES.PLAYING || !paused || pausedOptions) {
      return;
    }
    paused = false;
    // Restart the current song from its beginning.
    if (window.Game.Audio && window.Game.Audio.startMusic) {
      window.Game.Audio.startMusic();
    }
    if (window.Game.Audio && window.Game.Audio.startEngine) {
      window.Game.Audio.startEngine();
    }
  }

  // Looped effects (thrust engine, low-shield heartbeat) stop on pause, game
  // over and leaving PLAYING.
  function stopLoopedSfx() {
    if (window.Game.Audio && window.Game.Audio.stopEngine) {
      window.Game.Audio.stopEngine();
    }
    if (window.Game.Audio && window.Game.Audio.setLowShieldWarning) {
      window.Game.Audio.setLowShieldWarning(false);
    }
  }

  // Per-frame audio state for PLAYING: engine throttle and the low-shield
  // heartbeat (shield below 25% of max).
  function updateLoopedSfx() {
    var G = window.Game;
    if (G.Audio && G.Audio.setEngine && G.Ship && G.Ship.isThrusting && G.Ship.getVelocity) {
      var throttle = 0.05;
      if (G.Ship.isThrusting()) {
        var t = Math.abs(G.Ship.getVelocity()) / (G.Ship.MAX_SPEED || 220);
        throttle = Math.min(1, Math.max(0.3, t));
      }
      G.Audio.setEngine(throttle);
    }
    if (G.Audio && G.Audio.setLowShieldWarning && G.Collision && G.Collision.getShield && G.Collision.getMaxShield) {
      var max = G.Collision.getMaxShield() || 100;
      G.Audio.setLowShieldWarning(G.Collision.getShield() / max < 0.25);
    }
  }

  function setState(next) {
    var prev = state;
    if (next === STATES.GAMEOVER && prev !== STATES.GAMEOVER) {
      // Snapshot the score before anything can reset it.
      finalScore = (window.Game.Score && window.Game.Score.total) ? window.Game.Score.total() : finalScore;
      finalBreakdown = (window.Game.Score && window.Game.Score.getBreakdown) ? window.Game.Score.getBreakdown() : finalBreakdown;
      finalDiscoveryCount = (window.Game.Pickups && window.Game.Pickups.getDiscoveryCount) ? window.Game.Pickups.getDiscoveryCount() : finalDiscoveryCount;
      finalDiscoveryScore = (window.Game.Pickups && window.Game.Pickups.getScore) ? window.Game.Pickups.getScore() : finalDiscoveryScore;
      // Game-over screen extras: count-up clock, high-score flag, biomes.
      gameOverT = elapsed;
      finalVictory = !!(window.Game.Levels && window.Game.Levels.campaignActive && window.Game.Levels.campaignActive() &&
        window.Game.Levels.phase() === 'finished');
      finalCampaign = window.Game.Mode === 'campaign';
      var lvNow = window.Game.Levels && window.Game.Levels.level ? window.Game.Levels.level() : null;
      finalLevel = finalVictory && window.Game.Levels.count ? window.Game.Levels.count() : (lvNow || 1);
      if (window.Game.Daily && window.Game.Daily.recordScore) window.Game.Daily.recordScore(finalScore);
      finalHighScore = !!(window.Game.HighScores && window.Game.HighScores.qualifies && window.Game.HighScores.qualifies(finalScore));
      finalBiomes = (window.Game.Biomes && window.Game.Biomes.getReached) ? window.Game.Biomes.getReached() : null;
      finalFinds = (window.Game.Codex && window.Game.Codex.runFinds) ? window.Game.Codex.runFinds() : null;
      // Qualifying score: open the initials entry (blocks restart until Enter).
      if (window.Game.HighScores && window.Game.HighScores.beginEntry) {
        window.Game.HighScores.beginEntry({
          score: finalScore,
          distance: finalBreakdown ? finalBreakdown.distancePoints : 0,
          kills: finalBreakdown ? finalBreakdown.kills : 0,
          level: finalLevel,
          finished: finalVictory
        }, 400);
      }
    }
    state = next;
    if ((next === STATES.GAMEOVER || next === STATES.TITLE) && window.Game.Levels && window.Game.Levels.stop) {
      window.Game.Levels.stop();
    }
    // Pause only ever applies within PLAYING; any state change clears it.
    paused = false;
    window.Game.closePausedOptions();
    if (next === STATES.PLAYING && prev !== STATES.PLAYING) {
      resetSubsystemsAndStartPlaying(prev);
      if (window.Game.Audio && window.Game.Audio.startMusic) {
        window.Game.Audio.startMusic();
      }
      if (window.Game.Audio && window.Game.Audio.startEngine) {
        window.Game.Audio.startEngine();
      }
    }
    if (prev === STATES.OPTIONS && next !== STATES.PLAYING &&
        window.Game.Audio && window.Game.Audio.stopMusicPreview) {
      window.Game.Audio.stopMusicPreview(); // leaving the options menu ends a menu-started preview
    }
    if (prev === STATES.PLAYING && next !== STATES.PLAYING) {
      if (window.Game.Audio && window.Game.Audio.stopMusic) {
        window.Game.Audio.stopMusic();
      }
      stopLoopedSfx();
    }
  }

  // Input handling: any keydown or click on canvas during 'title' or
  // 'gameover' -> 'playing' (restart reuses the exact same transition/reset
  // path as the initial title-screen start).
  //
  // stopImmediatePropagation() on a TITLE/GAMEOVER -> PLAYING transition is
  // required here because projectile.js registers its own 'keydown' listener
  // on window (for Space-to-fire) AFTER this one (script load order: main.js
  // then ... then projectile.js). Listeners on the same target for the same
  // event type run synchronously in registration order, so without this
  // call, the very keydown that starts/restarts the game would immediately
  // reach projectile.js's handler with Game.getState() already flipped to
  // 'playing' (this setState() call above happens synchronously before
  // control returns to the dispatcher), causing a spurious shot to fire on
  // the same keypress that started the game. stopImmediatePropagation() only
  // suppresses *other listeners on this same event*, so a second, later
  // keydown (a genuinely separate event) is completely unaffected and fires
  // normally. This has no effect on the 'click' path: projectile.js listens
  // for 'mousedown' on canvas, a different event type than 'click', so there
  // is no ordering collision there and nothing to suppress.
  function handleStart(event) {
    // The title menu (menu.js) consumes navigation/activation keys and clicks
    // on its items; anything else falls through and starts the game.
    if (state === STATES.TITLE && event && window.Game.Menu) {
      var M = window.Game.Menu;
      var used = event.type === 'click' ? M.handleClick(event) : M.handleKey(event);
      if (used) {
        if (typeof event.preventDefault === 'function' && event.type !== 'click') {
          event.preventDefault();
        }
        if (typeof event.stopImmediatePropagation === 'function') {
          event.stopImmediatePropagation();
        }
        return;
      }
    } else if (state === STATES.TITLE && event && (event.key === 'o' || event.key === 'O')) {
      // Fallback when menu.js is absent: O opens the settings screen.
      setState(STATES.OPTIONS);
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
      return;
    }
    // Initials entry owns every key and click on the game-over screen.
    if (state === STATES.GAMEOVER && window.Game.HighScores && window.Game.HighScores.isEntering &&
        window.Game.HighScores.isEntering()) {
      if (event && event.type !== 'click' && window.Game.HighScores.handleEntryKey(event)) {
        if (typeof event.preventDefault === 'function') {
          event.preventDefault();
        }
      }
      if (event && typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
      return;
    }
    // Level-clear screen: Enter / Space / fire advance to the next level. The
    // key is swallowed while the screen shows so it never fires a shot.
    if (state === STATES.PLAYING && !paused && event && event.type === 'keydown' &&
        window.Game.LevelScreen && (window.Game.LevelScreen.isShowing() || window.Game.LevelScreen.isVictoryShowing())) {
      var LC = window.Game.Controls;
      if (event.key === 'Enter' || event.key === ' ' || event.code === 'Space' ||
          (LC && LC.matches && LC.matches(event, 'fire'))) {
        if (!event.repeat) { window.Game.LevelScreen.handleConfirm(); }
        if (typeof event.preventDefault === 'function') { event.preventDefault(); }
        if (typeof event.stopImmediatePropagation === 'function') { event.stopImmediatePropagation(); }
        return;
      }
    }
    if (state === STATES.TITLE || state === STATES.GAMEOVER) {
      setState(STATES.PLAYING);
      if (event && typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
    }
  }

  // F3 toggles a timing overlay (script ms per frame for update and render).
  // Off by default; nothing is measured while it is off. Game.Perf exposes the
  // rolling samples for headless measurement.
  var perfOn = false;
  var PERF_N = 120;
  var perfUpdate = [];
  var perfRender = [];
  function recordPerf(u, r) {
    perfUpdate.push(u);
    perfRender.push(r);
    if (perfUpdate.length > PERF_N) { perfUpdate.shift(); perfRender.shift(); }
  }
  function perfStat(arr) {
    if (!arr.length) { return { median: 0, p95: 0 }; }
    var a = arr.slice().sort(function (x, y) { return x - y; });
    return { median: a[Math.floor(a.length / 2)], p95: a[Math.min(a.length - 1, Math.floor(a.length * 0.95))] };
  }
  function renderPerfOverlay() {
    var c = canvas.getContext('2d');
    var u = perfStat(perfUpdate);
    var r = perfStat(perfRender);
    c.save();
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.fillStyle = 'rgba(0, 0, 0, 0.7)';
    c.fillRect(W - 232, 2, 230, 34);
    c.fillStyle = '#00FF00';
    c.font = '11px monospace';
    c.textAlign = 'left';
    c.textBaseline = 'top';
    c.fillText('UPD ' + u.median.toFixed(2) + ' p95 ' + u.p95.toFixed(2) + ' ms', W - 228, 6);
    c.fillText('RND ' + r.median.toFixed(2) + ' p95 ' + r.p95.toFixed(2) + ' ms', W - 228, 20);
    c.restore();
  }
  window.Game.Perf = {
    isOn: function () { return perfOn; },
    setCapacity: function (n) { PERF_N = Math.max(1, n | 0); },
    setOn: function (on) { perfOn = !!on; perfUpdate.length = 0; perfRender.length = 0; },
    samples: function () { return { update: perfUpdate.slice(), render: perfRender.slice() }; }
  };

  window.addEventListener('keydown', function (e) {
    if (e && e.key === 'F3' && !e.repeat) {
      window.Game.Perf.setOn(!perfOn);
      if (e.preventDefault) { e.preventDefault(); }
    }
    if (e && e.key === 'F3' && e.stopImmediatePropagation) { e.stopImmediatePropagation(); }
  });

  // Left click on the clear/victory overlay confirms. Registered before
  // projectile.js's mousedown listener so stopImmediatePropagation keeps the
  // press from firing a shot; the trailing 'click' only calls resumeGame(),
  // a no-op unless paused.
  canvas.addEventListener('mousedown', function (event) {
    if (state !== STATES.PLAYING || paused) { return; }
    var LS = window.Game.LevelScreen;
    if (LS && LS.handlePointerDown && LS.handlePointerDown(event)) {
      if (typeof event.stopImmediatePropagation === 'function') { event.stopImmediatePropagation(); }
    }
  });
  window.addEventListener('keydown', handleStart);
  canvas.addEventListener('click', handleStart);

  // P / Escape toggle pause while playing. Registered after handleStart and
  // before projectile.js (script order). stopImmediatePropagation keeps the
  // toggling key from reaching later keydown listeners (e.g. projectile.js),
  // the same pattern handleStart documents above. Auto-repeat is ignored so a
  // held P does not flicker the pause state.
  function handlePauseKey(event) {
    if (state !== STATES.PLAYING) {
      return;
    }
    var C = window.Game.Controls;
    var isPause = (C && C.matches) ? C.matches(event, 'pause')
      : (event.key === 'p' || event.key === 'P' || event.key === 'Escape');
    if (paused && pausedOptions) {
      return; // the options screen owns the keys (Esc goes back to the pause screen)
    }
    if (paused && (event.key === 'o' || event.key === 'O')) {
      if (!event.repeat) {
        pausedOptions = true;
      }
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }
      return;
    }
    if (!isPause) {
      return;
    }
    if (!event.repeat) {
      if (paused) {
        resumeGame();
      } else {
        pauseGame(false);
      }
    }
    if (typeof event.stopImmediatePropagation === 'function') {
      event.stopImmediatePropagation();
    }
  }
  window.addEventListener('keydown', handlePauseKey);

  // Click on the canvas resumes (never auto-resume on focus). The click is
  // preceded by a mousedown, which projectile.js ignores because the game is
  // still paused at that point, so resuming never fires a shot.
  canvas.addEventListener('click', function () { resumeGame(); });

  window.addEventListener('blur', function () { pauseGame(true); });
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) {
      pauseGame(true);
    }
  });

  // Gamepad: polled every frame (even while paused, so Start can resume).
  // A confirms on title/gameover and fires while playing; Start toggles pause.
  function pollGamepad() {
    var pad = window.Game.Gamepad;
    if (!pad || !pad.poll) {
      return;
    }
    pad.poll();
    var confirm = pad.consumeConfirm();
    var start = pad.consumeStart();
    if (state === STATES.GAMEOVER && window.Game.HighScores && window.Game.HighScores.isEntering &&
        window.Game.HighScores.isEntering()) {
      if (confirm || start) {
        window.Game.HighScores.confirmEntry();
      }
      return;
    }
    if (state === STATES.TITLE || state === STATES.GAMEOVER) {
      if (confirm || start) {
        setState(STATES.PLAYING);
      }
      return;
    }
    if (state === STATES.PLAYING) {
      if (start) {
        if (paused && pausedOptions) {
          window.Game.closePausedOptions();
        } else if (paused) {
          resumeGame();
        } else {
          pauseGame(false);
        }
        return;
      }
      if (!paused && window.Game.LevelScreen && (window.Game.LevelScreen.isShowing() || window.Game.LevelScreen.isVictoryShowing())) {
        // Gamepad A advances the level-clear screen; fire never shoots here.
        if (confirm) { window.Game.LevelScreen.handleConfirm(); }
        return;
      }
      if (!paused && pad.isFireHeld() && window.Game.Projectiles && window.Game.Projectiles.tryFire) {
        window.Game.Projectiles.tryFire();
      }
    }
  }

  function isAttractState() {
    return state === STATES.TITLE || state === STATES.OPTIONS;
  }

  function update(dt) {
    pollGamepad();
    if (paused) {
      return;
    }
    // Hit-stop freezes the world; camera timers still advance so it ends.
    var frozen = !!(window.Game.Camera && window.Game.Camera.isFrozen && window.Game.Camera.isFrozen());
    if (window.Game.Camera && window.Game.Camera.update) {
      window.Game.Camera.update(dt);
    }
    if (frozen) {
      return;
    }
    // Attract mode: the cave scrolls and an autopilot ship flies it behind the
    // title menu and the options screen. No collision, enemies or scoring.
    var attract = isAttractState();
    if (window.Game.Ship && window.Game.Ship.setAutopilot) {
      window.Game.Ship.setAutopilot(attract);
    }
    if (attract) {
      if (window.Game.Cave && window.Game.Cave.update) {
        window.Game.Cave.update(dt);
      }
      if (window.Game.Ship && window.Game.Ship.update) {
        window.Game.Ship.update(dt);
      }
      if (window.Game.Particles && window.Game.Particles.update) {
        window.Game.Particles.update(dt);
      }
      return;
    }
    if (state === STATES.PLAYING) {
      if (window.Game.Cave && window.Game.Cave.update) {
        window.Game.Cave.update(dt);
      }
      if (window.Game.Score && window.Game.Score.update && window.Game.Cave && window.Game.Cave.getScrollX) {
        window.Game.Score.update(window.Game.Cave.getScrollX(), dt);
      }
      if (window.Game.Biomes && window.Game.Biomes.update) {
        window.Game.Biomes.update(dt);
      }
      if (window.Game.Audio && window.Game.Audio.syncWorldMusic) {
        window.Game.Audio.syncWorldMusic();
      }
      if (window.Game.Lighting && window.Game.Lighting.update) {
        window.Game.Lighting.update(dt);
      }
      if (window.Game.Levels && window.Game.Levels.campaignActive()) {
        window.Game.Levels.update(dt);
        // 'cleared' waits for the level-clear screen (level-screen.js) to advance.
        // 'finished' waits for the victory overlay's confirm (-> GAMEOVER).
      }
      if (window.Game.LevelScreen && window.Game.LevelScreen.update) {
        window.Game.LevelScreen.update(dt);
      }
      if (window.Game.Stamina && window.Game.Stamina.update) {
        window.Game.Stamina.update(dt);
      }
      if (window.Game.Ship && window.Game.Ship.update) {
        window.Game.Ship.update(dt);
      }
      if (window.Game.Collision && window.Game.Collision.update) {
        window.Game.Collision.update(dt);
      }
      // Collision can transition the game to GAMEOVER. Stop this frame so
      // later systems cannot mutate state after the transition.
      if (state !== STATES.PLAYING) {
        return;
      }
      updateLoopedSfx();
      if (window.Game.Projectiles && window.Game.Projectiles.update) {
        window.Game.Projectiles.update(dt);
      }
      // Enemies is updated after Collision so that a ship-vs-enemy crash
      // this frame (checked inside Collision.update, which reads
      // Enemies.getAll()) sees each enemy's position as of the END of the
      // previous frame - consistent with how Collision already checks the
      // ship against cave bounds before Cave has re-generated this frame's
      // new geometry. Enemies is updated after Projectiles so that
      // enemy-vs-projectile hits this frame use projectile positions
      // already advanced for this frame.
      if (window.Game.Enemies && window.Game.Enemies.update) {
        window.Game.Enemies.update(dt);
      }
      if (window.Game.Vines && window.Game.Vines.update) {
        window.Game.Vines.update(dt);
      }
      if (window.Game.Boulders && window.Game.Boulders.update) {
        window.Game.Boulders.update(dt);
      }
      if (window.Game.Dragon && window.Game.Dragon.update) {
        window.Game.Dragon.update(dt);
      }
      if (window.Game.Gravity && window.Game.Gravity.update) {
        window.Game.Gravity.update(dt);
      }
      if (window.Game.Pickups && window.Game.Pickups.update) {
        window.Game.Pickups.update(dt);
      }
      if (window.Game.Hazards && window.Game.Hazards.update) {
        window.Game.Hazards.update(dt);
      }
      if (window.Game.Effects && window.Game.Effects.update) {
        window.Game.Effects.update(dt);
      }
      if (window.Game.Particles && window.Game.Particles.update) {
        window.Game.Particles.update(dt);
      }
    }
  }

  // Elapsed time accumulator, used to drive the title/gameover prompt blink.
  var elapsed = 0;
  var BLINK_PERIOD = 1.0; // seconds for a full on/off cycle
  var BLINK_ON_FRACTION = 0.5; // fraction of the period the prompt is visible

  function isBlinkVisible() {
    var phase = elapsed % BLINK_PERIOD;
    return phase < (BLINK_PERIOD * BLINK_ON_FRACTION);
  }

  // role/scale pick the bitmap face in themes that use one (modern); classic
  // keeps the CSS font string passed in `font`.
  function drawCenteredText(text, y, font, color, role, scale) {
    if (window.Game.Font && window.Game.Font.draw) {
      window.Game.Font.draw(ctx, text, W / 2, y, {
        role: role || 'body', css: font, color: color,
        align: 'center', baseline: 'middle', scale: scale || 1
      });
      return;
    }
    ctx.save();
    ctx.font = font;
    ctx.fillStyle = color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, W / 2, y);
    ctx.restore();
  }

  // Cave, autopilot ship and thruster particles, dimmed so menu text reads.
  function renderAttractBackdrop(rctx) {
    var G = window.Game;
    if (!(G.Cave && G.Cave.render && G.Ship && G.Ship.render)) {
      rctx.fillStyle = stateBg('title');
      rctx.fillRect(0, 0, W, H);
      return;
    }
    G.Cave.render(rctx);
    G.Ship.render(rctx);
    if (G.Particles && G.Particles.render) {
      G.Particles.render(rctx);
    }
    rctx.save();
    rctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    rctx.fillRect(0, 0, W, H);
    rctx.restore();
  }

  function renderTitle() {
    renderAttractBackdrop(ctx);

    if (window.Game.Menu && window.Game.Menu.render) {
      window.Game.Menu.render(ctx, { blink: isBlinkVisible(), t: elapsed });
      return;
    }
    drawCenteredText('CAVE RAIDER', 100, 'bold 44px monospace', palette().YELLOW, 'title', 2);
    if (isBlinkVisible()) {
      drawCenteredText('PRESS ANY KEY OR CLICK TO START', H / 2 + 30, 'bold 16px monospace', palette().WHITE);
    }
    drawCenteredText('O: OPTIONS', H / 2 + 70, 'bold 16px monospace', palette().LIGHT_GREY || palette().WHITE);
  }

  function renderGameOver() {
    ctx.fillStyle = stateBg('gameover');
    ctx.fillRect(0, 0, W, H);

    if (window.Game.GameOverScreen && window.Game.GameOverScreen.render) {
      var bd = finalBreakdown || { total: finalScore };
      window.Game.GameOverScreen.render(ctx, {
        W: W, H: H, breakdown: bd, t: elapsed - gameOverT, blink: isBlinkVisible(),
        highScore: finalHighScore, palette: palette(), biomes: finalBiomes, finds: finalFinds,
        victory: finalVictory, campaign: finalCampaign, level: finalLevel
      });
      return;
    }
    drawCenteredText('GAME OVER', H / 2 - 60, 'bold 44px monospace', palette().YELLOW, 'title', 2);
    drawCenteredText('SCORE: ' + finalScore, H / 2 - 10, 'bold 20px monospace', palette().WHITE, 'body', 2);
    drawCenteredText('DISCOVERIES: ' + finalDiscoveryCount + ' (+' + finalDiscoveryScore + ' PTS)', H / 2 + 20, 'bold 16px monospace', palette().GREEN);

    if (isBlinkVisible()) {
      drawCenteredText('PRESS ANY KEY OR CLICK TO RESTART', H / 2 + 60, 'bold 16px monospace', palette().WHITE);
    }
  }

  function renderHud() {
    var score = (window.Game.Score && window.Game.Score.total) ? window.Game.Score.total() : 0;
    var lives = (window.Game.Collision && window.Game.Collision.getLives) ? window.Game.Collision.getLives() : 0;
    var ammo = (window.Game.Projectiles && window.Game.Projectiles.getAmmo) ? window.Game.Projectiles.getAmmo() : 0;
    var shield = (window.Game.Collision && window.Game.Collision.getShield) ? window.Game.Collision.getShield() : 0;
    var maxShield = (window.Game.Collision && window.Game.Collision.getMaxShield) ? window.Game.Collision.getMaxShield() : 0;
    var stamina = (window.Game.Stamina && window.Game.Stamina.getStamina) ? window.Game.Stamina.getStamina() : 0;
    var maxStamina = (window.Game.Stamina && window.Game.Stamina.getMaxStamina) ? window.Game.Stamina.getMaxStamina() : 0;

    var measureProgress = (window.Game.Audio && window.Game.Audio.getMeasureProgress) ? window.Game.Audio.getMeasureProgress() : null;
    var comboNow = (window.Game.Score && window.Game.Score.getCombo) ? window.Game.Score.getCombo() : 0;

    if (window.Game.Hud && window.Game.Hud.draw) {
      window.Game.Hud.draw(ctx, {
        score: score, combo: comboNow, lives: lives, ammo: ammo,
        shield: shield, maxShield: maxShield, stamina: stamina, maxStamina: maxStamina,
        measureProgress: measureProgress
      }, W, H);
    }
  }

  function renderPausedOverlay() {
    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
    drawCenteredText('PAUSED', H / 2 - 20, 'bold 44px monospace', palette().YELLOW, 'title', 2);
    drawCenteredText('P or Esc to resume', H / 2 + 24, 'bold 16px monospace', palette().WHITE);
    drawCenteredText('O: OPTIONS', H / 2 + 52, 'bold 16px monospace', palette().LIGHT_GREY || palette().WHITE);
  }

  function render() {
    // Re-fit the bitmap if the device pixel ratio changed (browser zoom or a
    // monitor change). The CSS size follows the window by itself (style.css),
    // so a plain window resize needs no work here. Assigning canvas.width /
    // height resets the context transform, hence the unconditional
    // setTransform below, which runs after any resize and every frame so all
    // draw code can keep using logical 640x400 coordinates.
    if (targetDpr() !== dpr) {
      applyBitmapSize();
    }
    var mainCtx = canvas.getContext('2d');
    ctx = mainCtx;
    var theme = window.Game.Theme.get();
    var usePixel = !!(theme && theme.pixelMode) && window.Game.Pixel && window.Game.Pixel.beginFrame &&
      (!window.Game.Pixel.enabled || window.Game.Pixel.enabled());
    if (usePixel) {
      var bctx = window.Game.Pixel.beginFrame(mainCtx);
      if (bctx) {
        ctx = bctx;
      } else {
        usePixel = false;
      }
    }
    if (!usePixel) {
      mainCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    renderScene(ctx);
    if (usePixel) {
      window.Game.Pixel.endFrame(mainCtx);
      if (window.Game.PostFx && window.Game.PostFx.crt) {
        window.Game.PostFx.crt(mainCtx, true);
      }
      ctx = mainCtx;
    }
  }

  function renderScene(rctx) {
    if (state === STATES.PLAYING) {
      // Screen shake moves the world only; Hazards/Effects overlays, HUD and
      // pause overlay below stay put.
      var camOff = (window.Game.Camera && window.Game.Camera.offset) ? window.Game.Camera.offset() : null;
      rctx.save();
      if (camOff && (camOff.x || camOff.y)) {
        rctx.translate(camOff.x, camOff.y);
      }
      if (window.Game.Cave && window.Game.Cave.render) {
        window.Game.Cave.render(rctx);
      }
      if (window.Game.Ship && window.Game.Ship.render) {
        window.Game.Ship.render(rctx);
      }
      if (window.Game.Collision && window.Game.Collision.render) {
        window.Game.Collision.render(rctx);
      }
      if (window.Game.Projectiles && window.Game.Projectiles.render) {
        window.Game.Projectiles.render(rctx);
      }
      if (window.Game.Vines && window.Game.Vines.render) {
        window.Game.Vines.render(rctx);
      }
      if (window.Game.Enemies && window.Game.Enemies.render) {
        window.Game.Enemies.render(rctx);
      }
      if (window.Game.Particles && window.Game.Particles.render) {
        window.Game.Particles.render(rctx);
      }
      if (window.Game.Pickups && window.Game.Pickups.render) {
        window.Game.Pickups.render(rctx);
      }
      // Headlamp darkness goes over the scene only; hazard warnings, the
      // effects flash and the HUD below stay fully lit.
      if (window.Game.PostFx && window.Game.PostFx.bloom) {
        window.Game.PostFx.bloom(rctx);
      }
      if (window.Game.Lighting && window.Game.Lighting.render) {
        window.Game.Lighting.render(rctx);
      }
      rctx.restore();
      // Boulders and their telegraph markers sit above the headlamp darkness so
      // the threat and the warning are never dimmed.
      if (window.Game.Boulders && window.Game.Boulders.render) {
        window.Game.Boulders.render(rctx);
      }
      if (window.Game.Boulders && window.Game.Boulders.renderWarning) {
        window.Game.Boulders.renderWarning(rctx);
      }
      // The dragon and its telegraph are likewise drawn above the darkness.
      if (window.Game.Dragon && window.Game.Dragon.render) {
        window.Game.Dragon.render(rctx);
      }
      if (window.Game.Dragon && window.Game.Dragon.renderWarning) {
        window.Game.Dragon.renderWarning(rctx);
      }
      // Gravity-zone field, also above the darkness.
      if (window.Game.Gravity && window.Game.Gravity.render) {
        window.Game.Gravity.render(rctx);
      }
      if (window.Game.Enemies && window.Game.Enemies.renderSwarm) {
        window.Game.Enemies.renderSwarm(rctx);
      }
      if (window.Game.Enemies && window.Game.Enemies.renderGhosts) {
        window.Game.Enemies.renderGhosts(rctx);
      }
      if (window.Game.Hazards && window.Game.Hazards.render) {
        window.Game.Hazards.render(rctx);
      }
      if (window.Game.Effects && window.Game.Effects.render) {
        // Drawn after Hazards' warning text but before the HUD, so the
        // hazard-flash overlay and discovery pulses sit over the scene
        // without covering the HUD readouts.
        window.Game.Effects.render(rctx);
      }
      // HUD is drawn last so it overlays the gameplay elements rendered
      // above, rather than being drawn underneath/hidden by them.
      if (window.Game.PostFx && window.Game.PostFx.crt && rctx === canvas.getContext('2d')) {
        window.Game.PostFx.crt(rctx, false);
      }
      renderHud();
      if (window.Game.LevelScreen && window.Game.LevelScreen.render) {
        window.Game.LevelScreen.render(rctx);
      }
      if (paused && pausedOptions && window.Game.SettingsScreen && window.Game.SettingsScreen.render) {
        window.Game.SettingsScreen.render(rctx, { overlay: true });
      } else if (paused) {
        renderPausedOverlay();
      }
      return;
    }
    if (state === STATES.TITLE) {
      renderTitle();
      return;
    }
    if (state === STATES.GAMEOVER) {
      renderGameOver();
      if (window.Game.HighScores && window.Game.HighScores.renderEntry) {
        window.Game.HighScores.renderEntry(ctx, isBlinkVisible());
      }
      return;
    }
    if (state === STATES.HIGHSCORES && window.Game.HighScores && window.Game.HighScores.render) {
      window.Game.HighScores.render(ctx);
      return;
    }
    if (state === STATES.CODEX && window.Game.Codex && window.Game.Codex.render) {
      window.Game.Codex.render(ctx);
      return;
    }
    if (state === STATES.OPTIONS && window.Game.SettingsScreen && window.Game.SettingsScreen.render) {
      renderAttractBackdrop(ctx);
      window.Game.SettingsScreen.render(ctx, { overlay: true });
      return;
    }
    var bg = stateBg(state);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);
  }

  var lastTime = 0;
  // Cap the per-frame delta so a backgrounded/suspended tab resuming with a
  // huge rAF gap can't tunnel the ship/projectiles through cave walls, cause
  // cave.js to generate a massive number of ahead-segments in one frame, or
  // produce large visible jumps in scroll/spawn timers. 1/15s (~66.7ms, i.e.
  // no slower than ~15fps worth of simulated time) is a middle-ground cap:
  // small enough to keep collision checks and generation bounded, large
  // enough to never affect normal 60fps (~0.0167s) or typical dips (~0.033s).
  var MAX_DT = 1 / 15;

  function loop(timestamp) {
    var dt = lastTime ? (timestamp - lastTime) / 1000 : 0;
    dt = Math.min(dt, MAX_DT);
    lastTime = timestamp;
    elapsed += dt;

    if (perfOn) {
      var t0 = performance.now();
      update(dt);
      var t1 = performance.now();
      render();
      recordPerf(t1 - t0, performance.now() - t1);
      renderPerfOverlay();
    } else {
      update(dt);
      render();
    }

    requestAnimationFrame(loop);
  }

  requestAnimationFrame(loop);
})();
