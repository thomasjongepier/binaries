// Spelunker - player ship.
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so main.js can call Ship.update/render each frame,
// following the same pattern as cave.js.
//
// World-position convention:
//   The cave scrolls horizontally under a stationary camera (see cave.js's
//   `scrollX`). The ship is kept at a FIXED screen-x (SHIP_SCREEN_X) at all
//   times; its "world x" is simply `scrollX + SHIP_SCREEN_X` (useful for
//   future collision queries via Game.Cave.getCaveBoundsAtX). Vertically,
//   cave.js's wall bounds are already expressed directly in canvas/screen y
//   (they are not affected by any vertical scroll), so the ship's y is just
//   a plain screen/world y - no separate conversion needed. This keeps the
//   ship visible at all times and matches the classic cave-flyer feel.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('ship.js requires window.Game to be set up by main.js first');
  }

  var canvas = Game.canvas;
  var ctx = Game.ctx;
  function palette() { return Game.Theme.get(); }

  // ---- Tuning constants ----
  var SHIP_SCREEN_X = 100; // fixed screen-x position of the ship
  var SHIP_RADIUS = 10; // rough half-size, used for clamping/rendering
  var MAX_SPEED = 220; // px/sec, vertical speed cap
  var ACCEL = 900; // px/sec^2 applied while a key is held
  var DAMPING = 6; // 1/sec, how fast velocity decays when no key is held
  var MOUSE_LERP_SPEED = 8; // 1/sec, how fast the ship eases toward mouse target
  var MOUSE_IDLE_TIMEOUT = 150; // ms, how recently the mouse must have moved for isThrusting() to count it as active thrust (see spelunker-4rx)
  var BOUNCE_DAMPING = 0.45; // velocity retained (reflected+damped) on cave-wall bounce
  var HIT_FLASH_DURATION = 0.3; // seconds, how long the hull flashes white after a hit
  var WALL_HIT_COOLDOWN = 0.5; // seconds between wall-touch shield-damage triggers

  // Scroll-speed-multiplier tuning (Left/Right arrow keys). This is a
  // separate control axis from vertical movement: Left/Right never touch
  // mouseTargetY/vy/y, they only affect a multiplier read by cave.js each
  // frame to scale SCROLL_SPEED.
  var SPEED_MULT_MIN = 0.4; // Left (braking) eases down toward this
  var SPEED_MULT_MAX = 1.75; // Right (accelerating) eases up toward this
  var SPEED_MULT_BASE = 1.0; // resting value when neither key is held
  var SPEED_MULT_EASE_RATE = 2; // 1/sec, ease rate toward the current target

  // Input scheme:
  //  Keyboard: ArrowUp/W accelerates upward, ArrowDown/S accelerates downward.
  //            ArrowLeft brakes (eases scroll speed down), ArrowRight
  //            accelerates (eases scroll speed up) - a separate horizontal
  //            control axis that affects cave scroll speed, not ship y.
  //  Mouse:    moving the mouse over the canvas sets a target y that the ship
  //            smoothly eases toward (lerp), independent of the keyboard.
  //            Using the mouse cancels any residual keyboard velocity input
  //            naturally because both write to the same vy/y each frame; in
  //            practice a player uses one or the other.
  var keys = { up: false, down: false, left: false, right: false };
  var mouseTargetY = null; // null until the player has moved the mouse at least once
  var lastMouseMoveTime = -Infinity; // ms timestamp of the last mousemove; used only to decide
                                      // whether the mouse counts as "actively thrusting" for
                                      // stamina drain (see isThrusting()) - does NOT affect
                                      // position-following, which is driven by mouseTargetY alone.
  var speedMultiplier = SPEED_MULT_BASE;

  // Remappable keys via Game.Controls; legacy hard-coded keys if it is absent.
  function isAction(e, action, legacy) {
    var C = Game.Controls;
    if (C && C.matches) { return C.matches(e, action); }
    return legacy.indexOf(e.key) >= 0;
  }
  var LEGACY_UP = ['ArrowUp', 'w', 'W'];
  var LEGACY_DOWN = ['ArrowDown', 's', 'S'];

  function onKeyDown(e) {
    if (isAction(e, 'up', LEGACY_UP)) {
      keys.up = true;
      mouseTargetY = null; // hand control back to keyboard
    } else if (isAction(e, 'down', LEGACY_DOWN)) {
      keys.down = true;
      mouseTargetY = null; // hand control back to keyboard
    } else if (isAction(e, 'left', ['ArrowLeft'])) {
      keys.left = true;
      // Note: deliberately does NOT touch mouseTargetY - Left/Right control
      // scroll speed, a different axis from vertical position, so they must
      // not hand control back from mouse to keyboard.
    } else if (isAction(e, 'right', ['ArrowRight'])) {
      keys.right = true;
    }
  }

  function onKeyUp(e) {
    if (isAction(e, 'up', LEGACY_UP)) {
      keys.up = false;
    } else if (isAction(e, 'down', LEGACY_DOWN)) {
      keys.down = false;
    } else if (isAction(e, 'left', ['ArrowLeft'])) {
      keys.left = false;
    } else if (isAction(e, 'right', ['ArrowRight'])) {
      keys.right = false;
    }
  }

  // Shared by mouse and touch: clientY -> target y in logical play-field units.
  function setPointerClientY(clientY) {
    var rect = canvas.getBoundingClientRect();
    // Map CSS pixels inside the canvas's on-screen rect to LOGICAL play-field
    // y (0..Game.H). Must use Game.H, not canvas.height: canvas.height is the
    // hi-DPI bitmap height and would over-scale the target by devicePixelRatio.
    var scaleY = Game.H / rect.height;
    mouseTargetY = (clientY - rect.top) * scaleY;
    lastMouseMoveTime = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  }

  function onMouseMove(e) {
    setPointerClientY(e.clientY);
  }

  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);
  canvas.addEventListener('mousemove', onMouseMove);

  function clamp(v, min, max) {
    return v < min ? min : (v > max ? max : v);
  }

  // ---- Sprites (16-bit look). Each char is one buffer pixel (2x2 logical). ----
  // Ship: 16x10, facing right. o = hull outline, l/m/d = hull light/mid/dark,
  // k/c/h = cockpit dark/body/highlight. Frame 0 level, 1 nose up, 2 nose down;
  // the nose/right half (columns >= TILT_COL) is shifted one pixel for tilt.
  var TILT_COL = 9;
  var SHIP_LEVEL = [
    '..oo............',
    '..olooooo.......',
    '.ollllllloooo...',
    'ollmmmmmmmmmmoo.',
    'olmmmhhcmmmmmmmo',
    'oddddkcckddddooo',
    '.oddddddddddoo..',
    '..ooddddddoo....',
    '....oooooo......',
    '................'
  ];
  function shiftRight(rows, dy) {
    var out = [];
    var h = rows.length;
    var w = rows[0].length;
    for (var r = 0; r < h; r++) {
      var line = '';
      for (var x = 0; x < w; x++) {
        var srcRow = x >= TILT_COL ? r + dy : r;
        line += (srcRow >= 0 && srcRow < h) ? rows[srcRow].charAt(x) : '.';
      }
      out.push(line);
    }
    return out;
  }
  // Flame: 10x4, tail at the right edge. Frames 0-2 idle (short), 3-5
  // thrusting (longer). a..d = fire ramp 1..4.
  var FLAME_FRAMES = [
    ['........ab', '.......abc', '.......abc', '........ab'],
    ['.......aab', '......abbc', '......abbc', '.......aab'],
    ['........ab', '.......abc', '......abcc', '.......abc'],
    ['....aabbcc', '..aabbccdd', '..aabbccdd', '....aabbcc'],
    ['...aabbbcc', '.aabbbccdd', '.aabbbccdd', '...aabbbcc'],
    ['.....abbcc', '..aabbcccd', '...abbccdd', '....aabbcc']
  ];
  var FLAME_IDLE_FRAMES = 3;
  var FLAME_FPS = 12;
  var TILT_VY_THRESHOLD = 40; // px/sec; |vy| at or below this shows the level frame

  if (Game.Sprite && Game.Sprite.define) {
    Game.Sprite.define('ship', {
      w: 16, h: 10,
      map: {
        o: 'hull:0', d: 'hull:1', m: 'hull:2', l: 'hull:3',
        k: 'cockpit:0', c: 'cockpit:1', h: 'cockpit:2'
      },
      frames: [SHIP_LEVEL, shiftRight(SHIP_LEVEL, 1), shiftRight(SHIP_LEVEL, -1)]
    });
    Game.Sprite.define('flame', {
      w: 10, h: 4,
      map: { a: 'fire:1', b: 'fire:2', c: 'fire:3', d: 'fire:4' },
      frames: FLAME_FRAMES
    });
  }

  // Frame 0 level, 1 nose up (vy negative = moving up), 2 nose down.
  function frameForVelocity(v) {
    if (v < -TILT_VY_THRESHOLD) { return 1; }
    if (v > TILT_VY_THRESHOLD) { return 2; }
    return 0;
  }

  // ---- Thruster particles ----
  var EMIT_MAX_RATE = 40; // particles/sec cap
  var EMIT_IDLE_THROTTLE = 0.15;
  var TAIL_OFFSET_X = 16; // logical px from ship centre to the tail

  // ---- Shield ring ----
  var SHIELD_RING_R = 9; // buffer px (18 logical); wide enough to clear the 16 px hull
  var SHIELD_SEGMENT = 4; // bright pixels
  var SHIELD_ROT_SPEED = 14; // ring pixels per second
  var SHIELD_BLINK_HZ = 4;
  var SHIELD_LOW = 0.25;
  var HIT_RING_STEPS = 3;
  var HIT_RING_STEP_PX = 2; // buffer px added per step

  var y = Game.H / 2;
  var vy = 0;
  // Gravity-zone pull (gravity.js). Keyboard/gamepad: ay is added to vy, so
  // holding the opposite key (ACCEL 900) always wins. Mouse (direct target
  // following): the pull nudges y by ay * MOUSE_PULL_TIME * dt px, the running
  // total capped at +-PULL_CAP px and relaxing at the mouse-follow rate, so
  // the cursor can never be pinned off-target by more than PULL_CAP.
  var MOUSE_PULL_TIME = 0.1; // s
  var PULL_CAP = 24; // px
  var pullOffset = 0;
  var hitFlashTimer = 0;
  var wallHitCooldown = 0;
  var hidden = false;
  // Attract-mode autopilot (title/options backdrop): the ship follows the gap
  // centre through the mouse-follow path, takes no wall damage, shows no shield.
  var autopilot = false;
  var hitRingTimer = 0; // seconds left of the expanding hit ring
  var animTime = 0; // seconds, drives flame/shield animation
  var emitAccum = 0;
  var iceAccum = 0;
  var ringCache = {};

  var DRIFT_MAX = 0.8; // clamp: never fully frictionless
  var ICE_MIN_SPEED = 60; // px/sec, below this no ice trail
  var ICE_INTERVAL = 0.08; // sec between ice sparkles

  // Level drift knob (ice): 0 outside an active campaign 'playing'/'cleared'/
  // 'finished' state. Scales down the release damping only; ACCEL is untouched.
  function driftAmount() {
    var L = Game.Levels;
    if (!L || !L.campaignActive || !L.campaignActive()) { return 0; }
    var ph = L.phase ? L.phase() : 'playing';
    if (ph !== 'playing' && ph !== 'cleared' && ph !== 'finished') { return 0; }
    var lv = L.current ? L.current() : null;
    var d = lv && typeof lv.drift === 'number' ? lv.drift : 0;
    return d > DRIFT_MAX ? DRIFT_MAX : (d > 0 ? d : 0);
  }

  function reset() {
    y = Game.H / 2;
    vy = 0;
    keys.up = false;
    keys.down = false;
    keys.left = false;
    keys.right = false;
    mouseTargetY = null;
    lastMouseMoveTime = -Infinity;
    speedMultiplier = SPEED_MULT_BASE;
    hitFlashTimer = 0;
    wallHitCooldown = 0;
    hidden = false;
    autopilot = false;
    emitAccum = 0;
    iceAccum = 0;
    pullOffset = 0;
  }

  function setAutopilot(on) {
    on = !!on;
    if (on === autopilot) { return; }
    autopilot = on;
    // Hand control back cleanly: drop the autopilot's target and any velocity.
    mouseTargetY = null;
    lastMouseMoveTime = -Infinity;
    vy = 0;
  }

  function triggerHitFlash() {
    hitFlashTimer = HIT_FLASH_DURATION;
    hitRingTimer = HIT_FLASH_DURATION;
  }

  // Cave-wall contact. dir is +1 for the ceiling (sparks fly down), -1 for the
  // floor. Sparks fly every contact frame so a ship dragging along the rock
  // visibly scrapes; the damaging hit (flash, ring, shake, sound, shield) is
  // rate-limited by wallHitCooldown.
  function wallImpact(wallY, dir, strength) {
    if (autopilot) { return; }
    var P = Game.Particles;
    var hit = wallHitCooldown <= 0;
    if (P && P.emit) {
      P.emit(SHIP_SCREEN_X, wallY, {
        count: hit ? 8 + Math.round(strength * 8) : 1,
        angle: dir > 0 ? Math.PI / 2 : -Math.PI / 2, spread: 2.2,
        speed: { min: 30, max: 60 + strength * 120 },
        life: { min: 0.15, max: 0.4 }, size: { min: 1, max: 2 },
        ramp: 'fire', gravity: 160 * dir
      });
    }
    if (!hit) { return; }
    // Overlay phases: sparks only, no damage-looking flash/shake/sound.
    if (Game.Levels && Game.Levels.playerInvulnerable && Game.Levels.playerInvulnerable()) { return; }
    triggerHitFlash();
    if (Game.Camera && Game.Camera.shake) { Game.Camera.shake(2 + strength * 3, 0.15); }
    if (Game.Audio && Game.Audio.playWallScrape) { Game.Audio.playWallScrape(strength); }
    if (Game.Collision && Game.Collision.damageShield) {
      Game.Collision.damageShield(Game.Collision.WALL_SHIELD_DAMAGE);
    }
    wallHitCooldown = WALL_HIT_COOLDOWN;
  }

  // Crash-recovery reposition: unlike reset() (full new-game reset, used on
  // title->playing/restart, where there's no meaningful "current world-x"
  // yet), this repositions the ship to the vertical center of the actual
  // cave gap at its CURRENT world-x. This matters because the cave's gap
  // center wanders (random-walk + sine, see cave.js), so a fixed
  // canvas-relative y is not guaranteed to be clear of the walls at every
  // world-x - using a stale/fixed y here could immediately re-trigger a
  // crash once the post-crash invulnerability window ends. Velocity/input
  // state is cleared the same way reset() does, but horizontal/world-x
  // tracking (which lives in cave.js's scrollX, not here) is left
  // untouched.
  function recenterInGap() {
    var worldX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() + SHIP_SCREEN_X : SHIP_SCREEN_X;
    if (Game.Cave && Game.Cave.getCaveBoundsAtX) {
      var bounds = Game.Cave.getCaveBoundsAtX(worldX);
      y = (bounds.top + bounds.bottom) / 2;
    } else {
      y = Game.H / 2;
    }
    vy = 0;
    keys.up = false;
    keys.down = false;
    keys.left = false;
    keys.right = false;
    mouseTargetY = null;
    lastMouseMoveTime = -Infinity;
    pullOffset = 0;
  }

  function levelEnded() {
    return !!(Game.Levels && Game.Levels.levelEnded && Game.Levels.levelEnded());
  }

  // Level end: stop dead where the ship is (no velocity, no gravity pull).
  function holdStill() {
    vy = 0;
    pullOffset = 0;
  }

  function applyPull(ay, dt) {
    if (!(dt > 0) || !ay || levelEnded()) { return; }
    if (mouseTargetY !== null) {
      var next = clamp(pullOffset + ay * MOUSE_PULL_TIME * dt, -PULL_CAP, PULL_CAP);
      y += next - pullOffset;
      pullOffset = next;
    } else {
      vy = clamp(vy + ay * dt, -MAX_SPEED, MAX_SPEED);
    }
  }

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    hitFlashTimer = Math.max(0, hitFlashTimer - dt);
    hitRingTimer = Math.max(0, hitRingTimer - dt);
    animTime += dt;
    wallHitCooldown = Math.max(0, wallHitCooldown - dt);
    pullOffset -= pullOffset * Math.min(1, MOUSE_LERP_SPEED * dt);

    // Level cleared/finished: hold still mid air; all input is ignored.
    if (levelEnded()) {
      vy = 0;
      pullOffset = 0;
      speedMultiplier += (SPEED_MULT_BASE - speedMultiplier) * Math.min(1, SPEED_MULT_EASE_RATE * dt);
      emitThrusterParticles(dt);
      return;
    }

    // Gamepad: the stick takes over from the mouse (like the keys do).
    var pad = Game.Gamepad;
    var stickY = (pad && pad.getAxisY) ? pad.getAxisY() : 0;
    var padSpeedDir = (pad && pad.getSpeedDir) ? pad.getSpeedDir() : 0;
    if (autopilot) {
      stickY = 0;
      padSpeedDir = 0;
      if (Game.Cave && Game.Cave.getCaveBoundsAtX) {
        var apX = (Game.Cave.getScrollX ? Game.Cave.getScrollX() : 0) + SHIP_SCREEN_X;
        var apB = Game.Cave.getCaveBoundsAtX(apX);
        mouseTargetY = (apB.top + apB.bottom) / 2;
      } else {
        mouseTargetY = Game.H / 2;
      }
    }
    if (stickY !== 0) {
      mouseTargetY = null;
    }

    if (mouseTargetY !== null) {
      // Mouse control: ease y toward the target (independent of keyboard).
      var t = clamp(MOUSE_LERP_SPEED * dt, 0, 1);
      y += (mouseTargetY - y) * t;
      vy = (mouseTargetY - y); // rough velocity estimate, used only for tilt
    } else {
      // Keyboard control: accelerate based on held keys, decelerate otherwise.
      var accel = 0;
      if (keys.up) {
        accel -= ACCEL;
      }
      if (keys.down) {
        accel += ACCEL;
      }
      accel += stickY * ACCEL; // stick down (+Y) accelerates downward

      if (accel !== 0) {
        var staminaMult = (Game.Stamina && Game.Stamina.getMultiplier) ? Game.Stamina.getMultiplier() : 1;
        vy += accel * staminaMult * dt;
      } else {
        // Exponential-ish damping toward zero when no key is held.
        // Drift (ice) lowers the damping so momentum persists; drift 0 is
        // exactly the original arithmetic. Mouse control (direct target
        // following above) is unaffected: drift applies to keyboard/gamepad.
        vy -= vy * Math.min(1, DAMPING * (1 - driftAmount()) * dt);
      }

      vy = clamp(vy, -MAX_SPEED, MAX_SPEED);
      y += vy * dt;
    }

    // Full clamp: ship can never leave the canvas vertically, regardless of
    // how extreme the input is (mouse target beyond bounds, sustained key
    // accel, etc). Wall-collision with the cave is a separate later task.
    y = clamp(y, SHIP_RADIUS, Game.H - SHIP_RADIUS);

    // Cave-wall clamp + bounce: runs unconditionally every frame (this file
    // has no knowledge of collision.js's post-crash invulnerability timer,
    // nor should it need any). If the cave module isn't available yet, skip
    // this step entirely and rely on the canvas clamp above.
    if (Game.Cave && Game.Cave.getCaveBoundsAtX) {
      var worldX = (Game.Cave.getScrollX) ? Game.Cave.getScrollX() + SHIP_SCREEN_X : SHIP_SCREEN_X;
      var bounds = Game.Cave.getCaveBoundsAtX(worldX);
      // Impact strength is read before the bounce reverses vy (wall scrape sound).
      var hitStrength = clamp(Math.abs(vy) / MAX_SPEED, 0, 1);
      if ((y - SHIP_RADIUS) < bounds.top) {
        y = bounds.top + SHIP_RADIUS;
        vy = -vy * BOUNCE_DAMPING;
        wallImpact(bounds.top, 1, hitStrength);
      } else if ((y + SHIP_RADIUS) > bounds.bottom) {
        y = bounds.bottom - SHIP_RADIUS;
        vy = -vy * BOUNCE_DAMPING;
        wallImpact(bounds.bottom, -1, hitStrength);
      }
    }

    // Scroll-speed multiplier: eases smoothly toward whichever target
    // applies (min while Left is held, max while Right is held, base
    // otherwise), matching the game's easing feel rather than snapping
    // instantly. If both are held, treat as neither (base target) to keep
    // the behavior simple/predictable.
    var speedTarget = SPEED_MULT_BASE;
    var wantLeft = !autopilot && (keys.left || padSpeedDir < 0);
    var wantRight = !autopilot && (keys.right || padSpeedDir > 0);
    if (wantLeft && !wantRight) {
      speedTarget = SPEED_MULT_MIN;
    } else if (wantRight && !wantLeft) {
      speedTarget = SPEED_MULT_MAX;
    }
    speedMultiplier += (speedTarget - speedMultiplier) * Math.min(1, SPEED_MULT_EASE_RATE * dt);

    emitThrusterParticles(dt);
    emitIceTrail(dt);
  }

  function emitIceTrail(dt) {
    if (hidden || !Game.Particles || !Game.Particles.emit) { return; }
    if (driftAmount() <= 0 || Math.abs(vy) <= ICE_MIN_SPEED) { iceAccum = 0; return; }
    iceAccum += dt;
    if (iceAccum < ICE_INTERVAL) { return; }
    iceAccum = 0;
    Game.Particles.emit(SHIP_SCREEN_X - TAIL_OFFSET_X, y, {
      angle: Math.PI, spread: 0.6, speed: { min: 15, max: 40 },
      life: { min: 0.3, max: 0.5 }, size: 1, color: '#bff4ff'
    });
  }

  function emitThrusterParticles(dt) {
    if (hidden || !Game.Particles || !Game.Particles.emit) { return; }
    var throttle = isThrusting() ? 1 : EMIT_IDLE_THROTTLE;
    emitAccum += EMIT_MAX_RATE * throttle * dt;
    // Never emit more than the cap allows for this step, even after a long dt.
    var allowed = Math.max(1, Math.ceil(EMIT_MAX_RATE * dt));
    var n = Math.min(Math.floor(emitAccum), allowed);
    emitAccum -= n;
    if (emitAccum > 1) { emitAccum = 1; } // drop backlog rather than burst later
    for (var i = 0; i < n; i++) {
      Game.Particles.emit(SHIP_SCREEN_X - TAIL_OFFSET_X, y, {
        angle: Math.PI, spread: 0.5, speed: { min: 50, max: 110 },
        life: { min: 0.2, max: 0.4 }, size: { min: 1, max: 2 }, ramp: 'fire'
      });
    }
  }

  // Buffer-pixel offsets of a circle outline, sorted by angle (cached per radius).
  function ringPoints(r) {
    if (ringCache[r]) { return ringCache[r]; }
    var pts = [];
    for (var py = -r - 1; py <= r + 1; py++) {
      for (var px = -r - 1; px <= r + 1; px++) {
        if (Math.abs(Math.sqrt(px * px + py * py) - r) < 0.5) {
          pts.push({ x: px, y: py, a: Math.atan2(py, px) });
        }
      }
    }
    pts.sort(function (p, q) { return p.a - q.a; });
    ringCache[r] = pts;
    return pts;
  }

  function snapPx(v) {
    return (Game.Pixel && Game.Pixel.snap) ? Game.Pixel.snap(v) : Math.round(v / 2) * 2;
  }

  function renderShield(c, cx, cy, ratio) {
    var T = Game.Theme;
    var ramp = T && T.ramp ? T.ramp('shield') : null;
    if (!ramp || !ramp.length) { return; }
    var n = ramp.length;
    var blinkOff = ratio < SHIELD_LOW && (Math.floor(animTime * SHIELD_BLINK_HZ * 2) % 2 === 1);
    if (blinkOff) { return; }

    // Disc: low-level Bayer dither, transparent / darkest shade.
    var pattern = (Game.Sprite && Game.Sprite.ditherPattern)
      ? Game.Sprite.ditherPattern(c, 'rgba(0,0,0,0)', ramp[0], 3) : null;
    if (pattern) {
      c.fillStyle = pattern;
      for (var row = -SHIELD_RING_R; row <= SHIELD_RING_R; row++) {
        var half = Math.floor(Math.sqrt(SHIELD_RING_R * SHIELD_RING_R - row * row));
        c.fillRect(cx - half * 2, cy + row * 2, (half * 2 + 1) * 2, 2);
      }
    }

    // Ring: shade follows the shield ratio; always one step below the segment.
    var idx = Math.min(Math.floor(ratio * (n - 1)), Math.max(0, n - 2));
    var pts = ringPoints(SHIELD_RING_R);
    var start = Math.floor(animTime * SHIELD_ROT_SPEED) % pts.length;
    for (var i = 0; i < pts.length; i++) {
      var inSeg = ((i - start + pts.length) % pts.length) < SHIELD_SEGMENT;
      c.fillStyle = inSeg ? ramp[n - 1] : ramp[idx];
      c.fillRect(cx + pts[i].x * 2, cy + pts[i].y * 2, 2, 2);
    }
  }

  function renderHitRing(c, cx, cy) {
    var T = Game.Theme;
    var ui = T && T.ramp ? T.ramp('ui') : null;
    if (!ui || !ui.length) { return; }
    var step = Math.min(HIT_RING_STEPS - 1,
      Math.floor((1 - hitRingTimer / HIT_FLASH_DURATION) * HIT_RING_STEPS));
    var pts = ringPoints(SHIELD_RING_R + 1 + step * HIT_RING_STEP_PX);
    c.fillStyle = ui[ui.length - 1];
    for (var i = 0; i < pts.length; i++) {
      c.fillRect(cx + pts[i].x * 2, cy + pts[i].y * 2, 2, 2);
    }
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    if (hidden) { return; }
    var S = Game.Sprite;
    var cx = snapPx(SHIP_SCREEN_X);
    var cy = snapPx(y);

    // Flame first so the hull overlaps its root.
    if (S && S.draw) {
      var thrusting = isThrusting();
      var flameFrame = Math.floor(animTime * FLAME_FPS) % FLAME_IDLE_FRAMES +
        (thrusting ? FLAME_IDLE_FRAMES : 0);
      S.draw(ctx, 'flame', flameFrame, SHIP_SCREEN_X - TAIL_OFFSET_X - 8, y);
      S.draw(ctx, 'ship', frameForVelocity(vy), SHIP_SCREEN_X, y,
        { flash: hitFlashTimer > 0 });
    }

    // Shield and hit ring: not tilted with the nose.
    if (!autopilot && Game.Collision && Game.Collision.getShield && Game.Collision.getMaxShield) {
      var shieldRatio = Game.Collision.getShield() / (Game.Collision.getMaxShield() || 100);
      if (shieldRatio > 0) {
        renderShield(ctx, cx, cy, clamp(shieldRatio, 0, 1));
      }
    }
    if (hitRingTimer > 0) {
      renderHitRing(ctx, cx, cy);
    }
  }

  function setHidden(h) { hidden = !!h; }
  function isHidden() { return hidden; }

  function getSpeedMultiplier() {
    return speedMultiplier;
  }

  // True whenever the ship is actively being driven (any movement key held,
  // or the mouse has moved recently). Used by stamina.js to decide when to
  // drain stamina.
  //
  // Note on the mouse branch: mouseTargetY only tracks "has the player ever
  // touched the mouse" (it's cleared solely by ArrowUp/Down keydown, per the
  // input-handoff design above), so treating mouseTargetY !== null as "mouse
  // thrusting" would latch stamina drain on permanently after a single mouse
  // touch, even once the player stops moving the mouse entirely (spelunker-4rx).
  // Instead, the mouse only counts as actively thrusting if it moved within
  // the last MOUSE_IDLE_TIMEOUT ms - this leaves mouseTargetY and the
  // position-following behavior in update() completely untouched.
  function isThrusting() {
    if (levelEnded()) { return false; }
    if (autopilot) {
      return true; // attract-mode flame burns bright; stamina does not run there
    }
    if (keys.up || keys.down || keys.left || keys.right) {
      return true;
    }
    if (mouseTargetY === null) {
      return false;
    }
    var now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    return (now - lastMouseMoveTime) <= MOUSE_IDLE_TIMEOUT;
  }

  function getPosition() {
    var scrollX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;
    return {
      worldX: scrollX + SHIP_SCREEN_X,
      screenX: SHIP_SCREEN_X,
      y: y
    };
  }

  Game.Ship = {
    update: update,
    render: render,
    reset: reset,
    setAutopilot: setAutopilot,
    setPointerClientY: setPointerClientY,
    isAutopilot: function () { return autopilot; },
    recenterInGap: recenterInGap,
    holdStill: holdStill,
    triggerHitFlash: triggerHitFlash,
    getPosition: getPosition,
    getSpeedMultiplier: getSpeedMultiplier,
    isThrusting: isThrusting,
    getVelocity: function () { return vy; },
    // Brief slow (e.g. vine contact): scales the current vertical velocity.
    scaleVelocity: function (f) { vy *= f; },
    // Gravity zone: vertical acceleration ay (px/s^2, + = down) over dt.
    applyPull: applyPull,
    PULL_CAP: PULL_CAP,
    driftAmount: driftAmount,
    MAX_SPEED: MAX_SPEED,
    frameForVelocity: frameForVelocity,
    setHidden: setHidden,
    isHidden: isHidden,
    TILT_VY_THRESHOLD: TILT_VY_THRESHOLD,
    EMIT_MAX_RATE: EMIT_MAX_RATE,
    SHIP_RADIUS: SHIP_RADIUS
  };
})();
