// menu.js - title-screen menu (STATES.TITLE): CAMPAIGN, ENDLESS, OPTIONS, HIGH SCORES, DAILY CAVE, CODEX.
// Left/Right on CAMPAIGN picks the start level (1..highest reached).
//
// main.js's handleStart asks Game.Menu.handleKey / handleClick first; they
// return true when the event was consumed by the menu (navigation, activation,
// disabled item). Anything else returns false and main.js starts the game, so
// the "any key" fast path is kept. Left/Right are consumed (no-ops) on the
// title so arrow keys never start the game.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  var W = 640;
  var TOP = 138;  // first row centre; the logo (centre y 86) ends ~y 115
  var SUB_H = 16; // extra row height for an item's sub line
  var SUB_DY = 16; // sub line centre below the label centre
  var PROMPT_GAP = 22; // prompt centre below the last row's bottom
  var ROW_H = 26;
  var HIT_HALF_W = 130;

  var selected = 0;
  var chosen = null; // level picked with Left/Right; null = continue at highest

  // Items. `enabled` is evaluated each time; `sub` is optional second line
  // text shown under the label.
  var items = [
    { id: 'start', label: 'CAMPAIGN',
      enabled: function () { return true; },
      sub: function () {
        var s = Game.Settings;
        var d = s && s.get ? s.get('difficulty') : null;
        return 'LEVEL ' + startLevel() + (typeof d === 'string' ? ' - ' + d.toUpperCase() : '');
      },
      run: function () { beginCampaign(); setState(Game.STATES.PLAYING); } },
    { id: 'endless', label: 'ENDLESS',
      enabled: function () { return true; },
      sub: function () { return 'NO LEVELS'; },
      run: function () { Game.Mode = 'endless'; setState(Game.STATES.PLAYING); } },
    { id: 'options', label: 'OPTIONS',
      enabled: function () { return true; },
      run: function () { setState(Game.STATES.OPTIONS); } },
    { id: 'highscores', label: 'HIGH SCORES',
      enabled: function () {
        return !!(Game.HighScores && Game.HighScores.list && Game.STATES && Game.STATES.HIGHSCORES);
      },
      run: function () { if (Game.HighScores.openView) Game.HighScores.openView(); setState(Game.STATES.HIGHSCORES); } },
    // Last so the positions of the items above stay stable.
    { id: 'daily', label: 'DAILY CAVE',
      enabled: function () { return !!(Game.Daily && Game.Daily.begin); },
      sub: function () {
        if (!Game.Daily) return '';
        var best = Game.Daily.getBest ? Game.Daily.getBest() : 0;
        return Game.Daily.label + (best ? ' - BEST ' + best : '');
      },
      run: function () { Game.Mode = 'endless'; Game.Daily.begin(); setState(Game.STATES.PLAYING); } },
    { id: 'codex', label: 'CODEX',
      enabled: function () { return !!(Game.Codex && Game.STATES && Game.STATES.CODEX); },
      sub: function () {
        if (!(Game.Codex && Game.Codex.foundIds && Game.Codex.variants)) return '';
        return Game.Codex.foundIds().length + '/' + Game.Codex.variants().length + ' FOUND';
      },
      run: function () { setState(Game.STATES.CODEX); } }
  ];

  function highest() {
    var L = Game.Levels;
    var h = L && L.highestReached ? L.highestReached() : 1;
    return typeof h === 'number' && h >= 1 ? Math.floor(h) : 1;
  }

  // Level the campaign entry will start: the chosen one clamped to 1..highest.
  function startLevel() {
    var h = highest();
    if (chosen === null) return h;
    return Math.max(1, Math.min(h, chosen));
  }

  function stepLevel(d) {
    chosen = Math.max(1, Math.min(highest(), startLevel() + d));
  }

  // Sets the mode/start level for a campaign run (also used by the any-key path).
  function beginCampaign() {
    Game.Mode = 'campaign';
    if (Game.Levels) Game.Levels.startLevel = startLevel();
  }

  function setState(s) {
    if (s && Game.setState) Game.setState(s);
  }

  function inTitle() {
    return !!(Game.STATES && Game.getState && Game.getState() === Game.STATES.TITLE);
  }

  function isEnabled(i) {
    return !!items[i] && !!items[i].enabled();
  }

  // Vertical layout: START has a sub line so the rows below it shift down.
  function rowY(i) {
    var y = TOP;
    for (var k = 0; k < i; k++) y += ROW_H + (hasSub(k) ? SUB_H : 0);
    return y;
  }
  function hasSub(i) {
    var it = items[i];
    return !!(it && it.sub && it.sub());
  }
  function menuBottom() {
    return rowY(items.length - 1) + ROW_H / 2;
  }

  function itemAt(y) {
    for (var i = 0; i < items.length; i++) {
      var top = rowY(i) - ROW_H / 2;
      var bottom = top + ROW_H + (hasSub(i) ? SUB_H : 0);
      if (y >= top && y < bottom) return i;
    }
    return -1;
  }

  function select(i) {
    var n = items.length;
    selected = ((i % n) + n) % n;
  }

  // dir +1/-1: move to the next enabled item (wraps); stays put if none.
  function move(dir) {
    var n = items.length;
    var i = selected;
    for (var k = 0; k < n; k++) {
      i = (i + dir + n) % n;
      if (isEnabled(i)) { selected = i; return; }
    }
  }

  function indexOf(id) {
    for (var i = 0; i < items.length; i++) if (items[i].id === id) return i;
    return -1;
  }

  function activate(i) {
    if (i < 0 || i >= items.length || !isEnabled(i)) return false;
    selected = i;
    items[i].run();
    return true;
  }

  var MODIFIERS = { Shift: 1, Control: 1, Alt: 1, Meta: 1, CapsLock: 1, AltGraph: 1 };

  // Returns true when the menu consumed the keydown (caller must not start).
  function handleKey(e) {
    if (!inTitle() || !e) return false;
    var k = e.key;
    if (MODIFIERS[k]) return true; // a bare modifier press is not "any key"
    if (k === 'ArrowUp') { move(-1); return true; }
    if (k === 'ArrowDown') { move(1); return true; }
    if (k === 'ArrowLeft' || k === 'ArrowRight') {
      if (items[selected] && items[selected].id === 'start') stepLevel(k === 'ArrowLeft' ? -1 : 1);
      return true;
    }
    if (k === 'Enter') {
      if (e.repeat) return true;
      activate(selected);
      return true;
    }
    if (k === 'o' || k === 'O') { activate(indexOf('options')); return true; }
    beginCampaign(); // any other key starts a campaign run
    return false;
  }

  // Map a mouse event to logical 640x400 coordinates (canvas is CSS-scaled).
  function logicalPoint(e) {
    var c = Game.canvas;
    if (!c || !c.getBoundingClientRect || !e) return null;
    var r = c.getBoundingClientRect();
    if (!r || !r.width || !r.height) return null;
    return { x: (e.clientX - r.left) * (Game.W || W) / r.width,
             y: (e.clientY - r.top) * (Game.H || 400) / r.height };
  }

  function hit(e) {
    var p = logicalPoint(e);
    if (!p) return -1;
    if (Math.abs(p.x - W / 2) > HIT_HALF_W) return -1;
    return itemAt(p.y);
  }

  function handleMove(e) {
    if (!inTitle()) return;
    var i = hit(e);
    if (i >= 0 && isEnabled(i)) selected = i;
  }

  // Returns true when the click landed on a menu item (activated or disabled).
  function handleClick(e) {
    if (!inTitle()) return false;
    var i = hit(e);
    if (i < 0) { beginCampaign(); return false; }
    if (items[i].id === 'start' && highest() > 1) {
      var p = logicalPoint(e);
      var q = HIT_HALF_W / 2;
      if (p && Math.abs(p.x - W / 2) > q) {
        selected = i;
        stepLevel(p.x < W / 2 ? -1 : 1);
        return true;
      }
    }
    activate(i);
    return true;
  }

  function palette() { return Game.Theme && Game.Theme.get ? Game.Theme.get() : null; }

  function text(ctx, str, x, y, color, role, scale, css) {
    if (Game.Font && Game.Font.draw) {
      Game.Font.draw(ctx, str, x, y, { role: role || 'body', css: css || 'bold 16px monospace',
        color: color, align: 'center', baseline: 'middle', scale: scale || 1 });
      return;
    }
    ctx.save();
    ctx.font = css || 'bold 16px monospace';
    ctx.fillStyle = color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(str, x, y);
    ctx.restore();
  }

  // Draws the menu items. opts: { blink } shows the prompt under the menu.
  function render(ctx, opts) {
    var P = palette();
    if (!ctx || !P) return;
    var grey = P.LIGHT_GREY || P.WHITE;
    var logoDrawn = !!(opts && opts.t !== undefined && Game.Logo && Game.Logo.draw && Game.Logo.draw(ctx, opts.t));
    if (!logoDrawn) text(ctx, 'CAVE RAIDER', W / 2, 100, P.YELLOW, 'title', 2, 'bold 44px monospace');
    for (var i = 0; i < items.length; i++) {
      var y = rowY(i);
      var on = isEnabled(i);
      var sel = i === selected && on;
      if (sel) {
        ctx.fillStyle = P.DARK_GREY || P.BLACK;
        ctx.fillRect(W / 2 - HIT_HALF_W, y - ROW_H / 2 + 2, HIT_HALF_W * 2, ROW_H - 4 + (hasSub(i) ? SUB_H : 0));
      }
      var col = !on ? (P.DARK_GREY || grey) : (sel ? P.YELLOW : P.WHITE);
      text(ctx, (sel ? '> ' : '') + items[i].label + (sel ? ' <' : ''), W / 2, y, col);
      if (hasSub(i)) {
        var sub = items[i].sub();
        if (items[i].id === 'start' && highest() > 1) sub = '< ' + sub + ' >';
        text(ctx, sub, W / 2, y + SUB_DY, on ? grey : col);
      }
    }
    if (opts && opts.blink) {
      text(ctx, 'PRESS ANY KEY OR CLICK TO START', W / 2, menuBottom() + PROMPT_GAP, P.WHITE);
    }
  }

  // Keyboard and click go through main.js's handleStart (ordering vs
  // projectile.js); only hover needs its own listener.
  if (Game.canvas && Game.canvas.addEventListener) {
    Game.canvas.addEventListener('mousemove', handleMove);
  }

  Game.Menu = {
    items: function () { return items.map(function (it) { return { id: it.id, label: it.label, enabled: it.enabled() }; }); },
    getSelected: function () { return selected; },
    select: select,
    rowY: rowY,
    menuBottom: menuBottom,
    activate: activate,
    handleKey: handleKey,
    handleClick: handleClick,
    handleMove: handleMove,
    render: render
  };
})();
