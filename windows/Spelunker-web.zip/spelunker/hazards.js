// Spelunker - cave-in ("collapse") hazard tied to the cave's difficulty zone
// system. Vanilla JS, no build tools, no dependencies. Attaches to
// window.Game (created by main.js) so main.js can call
// Hazards.update/render/reset each frame, following the same pattern as
// cave.js/collision.js/stamina.js.
//
// Design: while the cave's current difficulty zone is 'hard' (see cave.js's
// zoneType/getZoneType), each frame there is a small per-second probability
// of a "collapse" triggering. On trigger it deals a single, fixed amount of
// shield damage via Game.Collision.damageShield() (not continuous per-frame
// damage) and shows a brief on-screen warning message. A cooldown timer
// after every trigger guarantees the hazard cannot fire again until it
// expires, so a collapse can never repeat-damage across consecutive frames
// even though the eligibility check (being in a 'hard' zone) may remain true
// for many frames in a row.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('hazards.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;
  function palette() { return Game.Theme.get(); }

  // ---- Tuning constants ----
  // Chance per second (not per frame) of a collapse triggering while
  // eligible; scaled by dt each frame so the effective rate is independent
  // of framerate. 0.15/sec means roughly one trigger every ~6-7 seconds of
  // continuous hard-zone exposure on average - rare enough to not feel
  // constant, but a real threat over an extended hard zone.
  var TRIGGER_CHANCE_PER_SEC = Game.Balance.hazards.collapse.TRIGGER_CHANCE_PER_SEC;
  var COLLAPSE_SHIELD_DAMAGE = Game.Balance.hazards.collapse.SHIELD_DAMAGE;
  // Minimum time between triggers, regardless of zone eligibility. This is
  // the mechanism that makes the hazard a discrete, cooldown-gated event
  // rather than something that could fire on back-to-back frames.
  var COOLDOWN_DURATION = Game.Balance.hazards.collapse.COOLDOWN_DURATION; // seconds
  var WARNING_DURATION = Game.Balance.hazards.collapse.WARNING_DURATION; // seconds the on-screen warning text is shown

  var cooldownTimer = 0; // seconds remaining before another trigger is allowed
  var warningTimer = 0; // seconds remaining to show the warning message

  // ---- 'gas' hazard tuning ----
  // Gas pockets are the counterpart to collapses: they are gated on the
  // 'normal' zone (the opposite of collapse's 'hard'-zone gate), so the two
  // hazards are eligible in mutually exclusive stretches of the cave and
  // can never be "competing" for the same moment. Gas is a smaller, more
  // naggy hazard than collapse - lower damage, but a shorter cooldown so it
  // can recur more often.
  var GAS_TRIGGER_CHANCE_PER_SEC = Game.Balance.hazards.gas.TRIGGER_CHANCE_PER_SEC;
  var GAS_SHIELD_DAMAGE = Game.Balance.hazards.gas.SHIELD_DAMAGE;
  var GAS_COOLDOWN_DURATION = Game.Balance.hazards.gas.COOLDOWN_DURATION; // seconds
  var GAS_WARNING_DURATION = Game.Balance.hazards.gas.WARNING_DURATION; // seconds the on-screen warning text is shown

  var gasCooldownTimer = 0; // seconds remaining before another gas trigger is allowed
  var gasWarningTimer = 0; // seconds remaining to show the gas warning message

  // Biome scaling of trigger chance (Game.Balance values stay untouched).
  function biomeMult(type) {
    var m = (Game.Biomes && Game.Biomes.hazardMultiplier) ? Game.Biomes.hazardMultiplier(type) : 1;
    return (Game.Levels && Game.Levels.hazardKnob) ? m * Game.Levels.hazardKnob(type) : m;
  }

  function spawnsEnabled() {
    return !(Game.Levels && Game.Levels.spawnsEnabled) || Game.Levels.spawnsEnabled();
  }

  function reset() {
    cooldownTimer = 0;
    warningTimer = 0;
    gasCooldownTimer = 0;
    gasWarningTimer = 0;
  }

  function triggerCollapse() {
    Game.Collision.damageShield(COLLAPSE_SHIELD_DAMAGE);
    cooldownTimer = COOLDOWN_DURATION;
    warningTimer = WARNING_DURATION;
    if (Game.Camera && Game.Camera.shake) {
      Game.Camera.shake(4, 0.2);
    }
    if (Game.Effects && Game.Effects.flashHazard) {
      Game.Effects.flashHazard('collapse');
    }
    if (Game.Audio && Game.Audio.playHazardSound) {
      Game.Audio.playHazardSound('collapse');
    }
  }

  function triggerGas() {
    Game.Collision.damageShield(GAS_SHIELD_DAMAGE);
    gasCooldownTimer = GAS_COOLDOWN_DURATION;
    gasWarningTimer = GAS_WARNING_DURATION;
    if (Game.Effects && Game.Effects.flashHazard) {
      Game.Effects.flashHazard('gas');
    }
    if (Game.Audio && Game.Audio.playHazardSound) {
      Game.Audio.playHazardSound('gas');
    }
  }

  function updateCollapse(dt) {
    if (cooldownTimer > 0) {
      cooldownTimer = Math.max(0, cooldownTimer - dt);
      return; // still on cooldown - cannot trigger again yet
    }

    if (!Game.Cave || !Game.Cave.getZoneType || !Game.Collision || !Game.Collision.damageShield) {
      return;
    }

    // Only eligible to trigger while the cave is in its 'hard' difficulty
    // zone (see cave.js's zoneType/advanceZone).
    if (Game.Cave.getZoneType() !== 'hard') {
      return;
    }

    if (Game.Random.stream('hazards').next() < TRIGGER_CHANCE_PER_SEC * biomeMult('collapse') * dt) {
      triggerCollapse();
    }
  }

  function updateGas(dt) {
    if (gasCooldownTimer > 0) {
      gasCooldownTimer = Math.max(0, gasCooldownTimer - dt);
      return; // still on cooldown - cannot trigger again yet
    }

    if (!Game.Cave || !Game.Cave.getZoneType || !Game.Collision || !Game.Collision.damageShield) {
      return;
    }

    // Only eligible to trigger while the cave is in its 'normal' difficulty
    // zone - the opposite gate from collapse, so the two hazards operate in
    // mutually exclusive stretches of the cave and never fight over the
    // same eligibility window.
    if (Game.Cave.getZoneType() !== 'normal') {
      return;
    }

    if (Game.Random.stream('hazards').next() < GAS_TRIGGER_CHANCE_PER_SEC * biomeMult('gas') * dt) {
      triggerGas();
    }
  }

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    if (warningTimer > 0) {
      warningTimer = Math.max(0, warningTimer - dt);
    }
    if (gasWarningTimer > 0) {
      gasWarningTimer = Math.max(0, gasWarningTimer - dt);
    }

    // Level cleared/finished: no new hazard triggers.
    if (!spawnsEnabled()) {
      return;
    }
    updateCollapse(dt);
    updateGas(dt);
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    if (Game.Cave && Game.Cave.renderBanner) {
      Game.Cave.renderBanner(ctx);
    }
    if (Game.Biomes && Game.Biomes.renderBanner) {
      Game.Biomes.renderBanner(ctx);
    }
    if (warningTimer > 0) {
      if (Game.Font && Game.Font.draw) Game.Font.draw(ctx, 'CAVE-IN!', Game.W / 2, Game.H / 2 - 80, {
        role: 'title', css: 'bold 22px monospace', color: palette().RED,
        align: 'center', baseline: 'middle', scale: 1
      });
    }

    if (gasWarningTimer > 0) {
      // Rendered at a different vertical offset than the collapse warning
      // so the two messages never visually overlap even if both timers
      // happened to be active at once.
      if (Game.Font && Game.Font.draw) Game.Font.draw(ctx, 'TOXIC GAS!', Game.W / 2, Game.H / 2 - 40, {
        role: 'title', css: 'bold 22px monospace', color: palette().GREEN,
        align: 'center', baseline: 'middle', scale: 1
      });
    }
  }

  Game.Hazards = {
    update: update,
    render: render,
    reset: reset
  };
})();
