// Spelunker - player projectiles (fired by the ship).
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so main.js can call Projectiles.update/render each
// frame, following the same pattern as cave.js/ship.js/collision.js.
//
// Projectiles are tracked in plain screen-space: they spawn at the ship's
// current screen position and travel rightward at a constant speed until
// they leave the right edge of the canvas or exceed a max lifetime. They do
// not need to interact with cave scroll, so no world-x conversion is
// needed here.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('projectile.js requires window.Game to be set up by main.js first');
  }

  var canvas = Game.canvas;
  var ctx = Game.ctx;
  function palette() { return Game.Theme.get(); }

  // ---- Tuning constants ----
  var PROJECTILE_SPEED = 400; // px/sec, screen-space rightward speed
  var FIRE_COOLDOWN = 0.25; // seconds, minimum interval between shots
  var MAX_LIFETIME = 2; // seconds, backstop despawn timer
  // Rock collision: a hit whose angle to the wall surface is shallower than
  // RICOCHET_MAX_GRAZING (radians) may ricochet forward; steeper hits are a
  // pure impact. Chance falls linearly from RICOCHET_BASE_CHANCE (grazing 0)
  // to 0 at the threshold.
  var RICOCHET_MAX_GRAZING = 35 * Math.PI / 180;
  var RICOCHET_BASE_CHANCE = 0.9;
  var RICOCHET_SPEED_KEEP = 0.85;
  var MAX_BOUNCES = 3;
  var SLOPE_SAMPLE = 4; // px either side for the central-difference slope
  var MAX_STEP = 3; // px, max sub-step so fast bullets cannot tunnel
  var PROJECTILE_WIDTH = 8;
  var PROJECTILE_HEIGHT = 2;
  // Starting ammo: 25 shots. At the 0.25s cooldown that's a little over 6
  // seconds of sustained fire before running dry - enough to feel usable
  // during a run without feeling unlimited, while leaving room for the
  // future pickup-items task to meaningfully replenish it via addAmmo().
  var STARTING_AMMO = 14;

  var projectiles = []; // each: { x, y, vx, vy, bounces, age }
  var cooldownTimer = 0; // seconds remaining until next shot is allowed
  var ammo = STARTING_AMMO;

  function reset() {
    projectiles = [];
    cooldownTimer = 0;
    ammo = STARTING_AMMO;
  }

  function spawn() {
    if (!Game.Ship || !Game.Ship.getPosition) {
      return;
    }
    var pos = Game.Ship.getPosition();
    projectiles.push({
      x: pos.screenX,
      y: pos.y,
      vx: PROJECTILE_SPEED,
      vy: 0,
      bounces: 0,
      age: 0
    });
  }

  // Attempts to fire a projectile, subject to the cooldown, the current
  // game state, and available ammo. Only fires during 'playing' so stray
  // title/gameover input doesn't queue up a shot that appears the instant
  // play begins. Both the cooldown check and the ammo check must pass for
  // a shot to be fired; ammo is only decremented when a shot actually
  // spawns, so it never goes negative and a shot blocked purely by
  // cooldown never costs ammo.
  function tryFire() {
    if (!Game.getState || Game.getState() !== Game.STATES.PLAYING) {
      return;
    }
    if (Game.isPaused && Game.isPaused()) {
      return;
    }
    if (cooldownTimer > 0) {
      return;
    }
    if (ammo <= 0) {
      return;
    }
    spawn();
    ammo -= 1;
    cooldownTimer = FIRE_COOLDOWN;
    if (Game.Audio && Game.Audio.playFireSound) {
      Game.Audio.playFireSound();
    }
  }

  function onKeyDown(e) {
    var C = Game.Controls;
    var isFire = (C && C.matches) ? C.matches(e, 'fire')
      : (e.code === 'Space' || e.key === ' ' || e.key === 'Spacebar');
    if (isFire) {
      e.preventDefault();
      tryFire();
    }
  }

  function onFireClick() {
    tryFire();
  }

  window.addEventListener('keydown', onKeyDown);
  canvas.addEventListener('mousedown', onFireClick);

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    if (cooldownTimer > 0) {
      cooldownTimer = Math.max(0, cooldownTimer - dt);
    }

    for (var i = projectiles.length - 1; i >= 0; i--) {
      var p = projectiles[i];
      if (typeof p.vx !== 'number') { p.vx = PROJECTILE_SPEED; }
      if (typeof p.vy !== 'number') { p.vy = 0; }
      if (typeof p.bounces !== 'number') { p.bounces = 0; }
      p.age += dt;

      var dead = false;
      var dist = Math.sqrt(p.vx * p.vx + p.vy * p.vy) * dt;
      var steps = Math.max(1, Math.ceil(dist / MAX_STEP));
      for (var s = 0; s < steps && !dead; s++) {
        p.x += p.vx * dt / steps;
        p.y += p.vy * dt / steps;
        if (checkRock(p)) {
          dead = true;
        }
      }

      if (dead || !(isFinite(p.x) && isFinite(p.y)) || p.x > Game.W || p.age > MAX_LIFETIME) {
        projectiles.splice(i, 1);
      }
    }
  }

  function getBounds(worldX) {
    var b = Game.Cave.getCaveBoundsAtX(worldX);
    if (!b || !isFinite(b.top) || !isFinite(b.bottom)) {
      return null;
    }
    return b;
  }

  function effects(p, impact) {
    var pan = (Game.Audio && Game.Audio.panForX) ? Game.Audio.panForX(p.x) : undefined;
    if (Game.Particles && Game.Particles.emit) {
      if (impact) {
        Game.Particles.emit(p.x, p.y, { count: 8, speed: { min: 30, max: 100 },
          life: { min: 0.2, max: 0.5 }, size: { min: 1, max: 2 }, ramp: 'rock', gravity: 120 });
      } else {
        Game.Particles.emit(p.x, p.y, { count: 4, speed: { min: 40, max: 120 },
          life: { min: 0.1, max: 0.25 }, size: { min: 1, max: 1 }, ramp: 'fire' });
      }
    }
    if (impact) {
      if (Game.Camera && Game.Camera.shake) { Game.Camera.shake(1, 0.08); }
      if (Game.Audio && Game.Audio.playImpactSound) { Game.Audio.playImpactSound(pan); }
    } else if (Game.Audio && Game.Audio.playRicochetSound) {
      Game.Audio.playRicochetSound(pan);
    }
  }

  // Tests the bullet against cave rock. Returns true if the bullet is
  // destroyed (impact); on ricochet mutates velocity/position and returns false.
  function checkRock(p) {
    if (!Game.Cave || !Game.Cave.getCaveBoundsAtX || !Game.Cave.getScrollX) {
      return false;
    }
    var scrollX = Game.Cave.getScrollX() || 0;
    var wx = p.x + scrollX;
    var b = getBounds(wx);
    if (!b) { return false; }
    var isTop = p.y <= b.top;
    var isBottom = p.y >= b.bottom;
    if (!isTop && !isBottom) { return false; }

    var impact = function () { effects(p, true); return true; };
    if (p.bounces >= MAX_BOUNCES) { return impact(); }

    // Wall slope by central difference (world space, y down).
    var b1 = getBounds(wx - SLOPE_SAMPLE);
    var b2 = getBounds(wx + SLOPE_SAMPLE);
    if (!b1 || !b2) { return impact(); }
    var wallY1 = isTop ? b1.top : b1.bottom;
    var wallY2 = isTop ? b2.top : b2.bottom;
    var tx = 2 * SLOPE_SAMPLE;
    var ty = wallY2 - wallY1;
    var tl = Math.sqrt(tx * tx + ty * ty);
    if (!(tl > 0) || !isFinite(tl)) { return impact(); }
    tx /= tl; ty /= tl;
    // Inward normal: top rock is above, so the open cave is +y; bottom is -y.
    var nx = isTop ? -ty : ty;
    var ny = isTop ? tx : -tx;

    // World velocity would add the scroll speed; it is not exposed by
    // Game.Cave, so the screen-space velocity alone is used.
    var speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);
    if (!(speed > 0)) { return impact(); }
    var dot = p.vx * nx + p.vy * ny;
    if (dot >= 0) {
      // Already moving away from the wall (e.g. spawned inside rock): impact.
      return impact();
    }
    var grazing = Math.asin(Math.min(1, -dot / speed));
    if (grazing >= RICOCHET_MAX_GRAZING) { return impact(); }
    var chance = RICOCHET_BASE_CHANCE * (1 - grazing / RICOCHET_MAX_GRAZING);
    if (!(Math.random() < chance)) { return impact(); }

    var rvx = (p.vx - 2 * dot * nx) * RICOCHET_SPEED_KEEP;
    var rvy = (p.vy - 2 * dot * ny) * RICOCHET_SPEED_KEEP;
    if (!(rvx > 0) || !isFinite(rvx) || !isFinite(rvy)) { return impact(); }

    // Push out of the rock along the normal, back into the open cave.
    var wallY = isTop ? b.top : b.bottom;
    var depth = Math.abs(p.y - wallY) + 1;
    p.x += nx * depth;
    p.y += ny * depth;
    var nb = getBounds(p.x + scrollX);
    if (nb && (p.y <= nb.top || p.y >= nb.bottom)) { return impact(); }
    p.vx = rvx;
    p.vy = rvy;
    p.bounces += 1;
    effects(p, false);
    return false;
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    ctx.fillStyle = palette().WHITE;
    for (var i = 0; i < projectiles.length; i++) {
      var p = projectiles[i];
      if (!p.vy) {
        ctx.fillRect(p.x, p.y - PROJECTILE_HEIGHT / 2, PROJECTILE_WIDTH, PROJECTILE_HEIGHT);
      } else {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(Math.atan2(p.vy, p.vx));
        ctx.fillRect(0, -PROJECTILE_HEIGHT / 2, PROJECTILE_WIDTH, PROJECTILE_HEIGHT);
        ctx.restore();
      }
    }
  }

  function getAll() {
    return projectiles;
  }

  function getAmmo() {
    return ammo;
  }

  // Increases ammo by a whole, finite, nonnegative amount. Invalid input is
  // ignored so callers cannot corrupt the ammo state with NaN, Infinity,
  // fractions, or negative values.
  function addAmmo(n) {
    if (typeof n !== 'number' || !isFinite(n) || n < 0 || Math.floor(n) !== n) {
      return;
    }
    ammo += n;
  }

  Game.Projectiles = {
    update: update,
    render: render,
    reset: reset,
    tryFire: tryFire,
    getAll: getAll,
    getAmmo: getAmmo,
    addAmmo: addAmmo
  };
})();
