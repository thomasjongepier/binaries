// settings.js - persistent user settings (localStorage, defensive).
//
// Game.Settings.get(key) / set(key, value) / onChange(fn). Storage failures
// (missing, corrupt, throwing) never throw; defaults are used and set() still
// updates the in-memory values for the session.
(function () {
  'use strict';

  window.Game = window.Game || {};

  var STORAGE_KEY = 'spelunker.settings';

  var DEFAULTS = {
    theme: 'modern',
    resolution: 'retro',
    headlamp: true,
    bloom: true,
    crt: false,
    screenShake: true,
    hazardFlash: true,
    musicVolume: 0.8,
    sfxVolume: 1.0,
    musicTrack: 'playlist', // 'playlist' or a piece id (fugue, toccata, bwv914, bwv578); checked against Game.Audio.getMusicChoices()
    difficulty: 'normal',
    intensityLayer: false,
    reduceMotion: false,
    enemyShapes: true,
    highContrast: false,
    controls: {}
  };

  var values = {};
  var listeners = [];

  function getStorage() {
    try {
      return window.localStorage || null;
    } catch (e) {
      return null;
    }
  }

  var ENUMS = { resolution: ['retro', 'high', 'ultrahigh'] };

  function validType(key, v) {
    var t = typeof DEFAULTS[key];
    if (typeof v !== t) return false;
    if (ENUMS[key] && ENUMS[key].indexOf(v) < 0) return false;
    if (t === 'number' && !isFinite(v)) return false;
    return true;
  }

  function reset() {
    values = {};
    for (var k in DEFAULTS) {
      if (Object.prototype.hasOwnProperty.call(DEFAULTS, k)) values[k] = DEFAULTS[k];
    }
  }

  function load() {
    reset();
    var raw = null;
    try {
      var s = getStorage();
      if (s) raw = s.getItem(STORAGE_KEY);
    } catch (e) {
      return;
    }
    if (typeof raw !== 'string') return;
    var parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (e) {
      return;
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return;
    for (var k in DEFAULTS) {
      if (Object.prototype.hasOwnProperty.call(DEFAULTS, k) &&
          Object.prototype.hasOwnProperty.call(parsed, k) &&
          validType(k, parsed[k])) {
        values[k] = parsed[k];
      }
    }
  }

  function save() {
    try {
      var s = getStorage();
      if (s) s.setItem(STORAGE_KEY, JSON.stringify(values));
    } catch (e) { /* private browsing / quota: keep in-memory values */ }
  }

  function get(key) {
    if (Object.prototype.hasOwnProperty.call(values, key)) return values[key];
    return undefined;
  }

  function set(key, value) {
    if (!Object.prototype.hasOwnProperty.call(DEFAULTS, key)) return false;
    if (!validType(key, value)) return false;
    var old = values[key];
    values[key] = value;
    save();
    var copy = listeners.slice();
    for (var i = 0; i < copy.length; i++) {
      try { copy[i](key, value, old); } catch (e) { /* listener must not break set */ }
    }
    return true;
  }

  function onChange(fn) {
    if (typeof fn === 'function') listeners.push(fn);
  }

  load();

  window.Game.Settings = {
    STORAGE_KEY: STORAGE_KEY,
    DEFAULTS: DEFAULTS,
    get: get,
    set: set,
    onChange: onChange,
    reload: load
  };
})();
