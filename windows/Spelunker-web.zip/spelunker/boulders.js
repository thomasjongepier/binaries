// Spelunker - telegraphed boulders (campaign mechanic 'boulders').
// Vanilla JS, no build tools. Attaches to window.Game.
//
// One event at a time. Every event starts with a 1.0 s TELEGRAPH during which
// no boulder exists (so nothing can hurt the ship), then the boulder appears:
//   - fall variant (70%): a boulder drops from the ceiling at a fixed target
//     x and shatters on the floor. Marker: pulsing triangle on the ceiling, a
//     dashed line down to the floor, dust trickling from the ceiling.
//   - roll variant (30%): a boulder enters from the right screen edge and
//     rolls left along the floor at ROLL_SPEED, shattering off the left edge.
//     Marker: a pulsing left arrow at the right edge, dust from the floor.
// Coordinates are WORLD-space (worldX, like enemies and vines): boulders
// scroll with the cave. render() and renderWarning() are both called by main.js
// AFTER the headlamp darkness so neither the boulder nor its cue is dimmed.
// A hit on the ship deals HIT_DAMAGE once and shatters the boulder. Projectiles
// ignore boulders. Uses its own random stream 'boulders', touched only while
// Levels.unlocked('boulders'), so locked/endless runs are unaffected.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('boulders.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;

  // ---- Tuning ----
  var FIRST_DELAY = 3; // seconds after unlock before the first event
  var INTERVAL_MIN = 5.5; // seconds between events, scaled by Difficulty.spawnFactor()
  var INTERVAL_MAX = 8.5;
  var TELEGRAPH = 1.0; // seconds of warning before the boulder exists
  var ROLL_CHANCE = 0.3;
  var TARGET_MIN_X = 160; // screen px, fall target range (ahead of the ship)
  var TARGET_MAX_X = 520;
  var RADIUS_MIN = 14;
  var RADIUS_MAX = 18;
  var GRAVITY = 700; // px/s^2
  var MAX_FALL_SPEED = 320; // px/s
  var ROLL_SPEED = 190; // px/s in world space
  var HIT_DAMAGE = 15;
  var DUST_INTERVAL = 0.07; // seconds between telegraph dust puffs
  var OFFSCREEN_MARGIN = 40;

  // ev: the current event or null. phase 'tele' (no boulder) or 'live'.
  // { roll, phase, t, worldX, r, y, vy, spin, dust }
  var ev = null;
  var live = []; // 0 or 1 boulders (the live event), exposed via getAll()
  var spawnTimer = -1; // < 0 means "arm on the next unlocked update"

  function stream() { return Game.Random.stream('boulders'); }

  function isUnlocked() {
    return !!(Game.Levels && Game.Levels.unlocked && Game.Levels.unlocked('boulders'));
  }
  function spawnsEnabled() {
    return !(Game.Levels && Game.Levels.spawnsEnabled) || Game.Levels.spawnsEnabled();
  }
  function invulnerable() {
    return !!(Game.Levels && Game.Levels.playerInvulnerable && Game.Levels.playerInvulnerable());
  }
  function scrollX() {
    return (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;
  }
  function bounds(x) {
    return Game.Cave.getCaveBoundsAtX(x);
  }

  function rollTimer() {
    var f = (Game.Difficulty && Game.Difficulty.spawnFactor) ? Game.Difficulty.spawnFactor() : 1;
    spawnTimer = stream().range(INTERVAL_MIN, INTERVAL_MAX) * f;
  }

  function reset() {
    ev = null;
    live.length = 0;
    spawnTimer = -1;
  }

  function startEvent() {
    if (!Game.Cave || !Game.Cave.getCaveBoundsAtX) { return; }
    var s = stream();
    var roll = s.next() < ROLL_CHANCE;
    var r = s.range(RADIUS_MIN, RADIUS_MAX);
    var wx = roll ? 0 : scrollX() + s.range(TARGET_MIN_X, TARGET_MAX_X);
    ev = { roll: roll, phase: 'tele', t: 0, worldX: wx, r: r, y: 0, vy: 0, spin: 0, dust: 0 };
  }

  function shatter(x, y, count) {
    if (!Game.Particles || !Game.Particles.emit) { return; }
    Game.Particles.emit(x - scrollX(), y, { count: count, speed: { min: 40, max: 170 },
      life: { min: 0.4, max: 0.9 }, size: { min: 1, max: 3 }, ramp: 'boulder', gravity: 320 });
  }

  function endEvent() {
    ev = null;
    live.length = 0;
    rollTimer();
  }

  function goLive() {
    var b;
    ev.phase = 'live';
    if (ev.roll) {
      ev.worldX = scrollX() + Game.W + ev.r;
      b = bounds(ev.worldX);
      ev.y = b.bottom - ev.r;
    } else {
      b = bounds(ev.worldX);
      ev.y = b.top; // emerges from the ceiling
    }
    ev.vy = 0;
    live.length = 0;
    live.push(ev);
  }

  function dust(dt) {
    if (!Game.Particles || !Game.Particles.emit) { return; }
    ev.dust -= dt;
    if (ev.dust > 0) { return; }
    ev.dust = DUST_INTERVAL;
    var sx = scrollX();
    var b, x;
    if (ev.roll) {
      x = Game.W - 4;
      b = bounds(sx + x);
      Game.Particles.emit(x, b.bottom - 2, { count: 2, angle: -Math.PI / 2, spread: 1.2,
        speed: { min: 20, max: 70 }, life: { min: 0.3, max: 0.6 }, size: 1, ramp: 'rock', gravity: 120 });
    } else {
      x = ev.worldX - sx;
      b = bounds(ev.worldX);
      Game.Particles.emit(x + (Math.random() - 0.5) * 24, b.top + 2, { count: 2, angle: Math.PI / 2,
        spread: 0.6, speed: { min: 20, max: 60 }, life: { min: 0.4, max: 0.8 }, size: { min: 1, max: 2 },
        ramp: 'rock', gravity: 220 });
    }
  }

  function updateLive(dt) {
    var b = ev;
    b.spin += dt * (b.roll ? ROLL_SPEED / b.r : 4);
    if (b.roll) {
      b.worldX -= ROLL_SPEED * dt;
      b.y = bounds(b.worldX).bottom - b.r;
    } else {
      b.vy = Math.min(MAX_FALL_SPEED, b.vy + GRAVITY * dt);
      b.y += b.vy * dt;
    }

    // Ship contact: one hit, the boulder shatters.
    if (Game.Ship && Game.Ship.getPosition && !invulnerable()) {
      var pos = Game.Ship.getPosition();
      var reach = (Game.Ship.SHIP_RADIUS || 10) + b.r;
      var dx = pos.worldX - b.worldX, dy = pos.y - b.y;
      if (dx * dx + dy * dy <= reach * reach) {
        if (Game.Collision && Game.Collision.damageShield) { Game.Collision.damageShield(HIT_DAMAGE); }
        if (Game.Camera && Game.Camera.shake) { Game.Camera.shake(5, 0.25); }
        shatter(b.worldX, b.y, 18);
        endEvent();
        return;
      }
    }

    if (b.roll) {
      if (b.worldX - scrollX() < -b.r - OFFSCREEN_MARGIN) { endEvent(); }
    } else {
      var fl = bounds(b.worldX).bottom;
      if (b.y + b.r >= fl) {
        shatter(b.worldX, fl - b.r * 0.5, 14);
        if (Game.Camera && Game.Camera.shake) { Game.Camera.shake(2.5, 0.15); }
        endEvent();
      }
    }
  }

  function update(dt) {
    if (!(dt > 0)) { return; }
    if (!isUnlocked()) {
      // Locked, endless, or the level just ended: drop any event, touch nothing else.
      if (ev || spawnTimer >= 0) { ev = null; live.length = 0; spawnTimer = -1; }
      return;
    }
    if (!ev) {
      if (!spawnsEnabled()) { return; }
      if (spawnTimer < 0) { spawnTimer = FIRST_DELAY; }
      spawnTimer -= dt;
      if (spawnTimer <= 0) {
        startEvent();
        if (!ev) { rollTimer(); }
      }
      return;
    }
    if (ev.phase === 'tele') {
      ev.t += dt;
      dust(dt);
      if (ev.t >= TELEGRAPH) { goLive(); }
      return;
    }
    updateLive(dt);
  }

  function snapV(P, n) { return P && P.snap ? P.snap(n) : n; }

  // Row-stepped disc: reads as a chunky circle in retro.
  function disc(P, cx, cy, rad, step) {
    for (var dy = -rad; dy < rad; dy += step) {
      var m = Math.abs(dy + step / 2);
      var hw = Math.sqrt(Math.max(0, rad * rad - m * m));
      var x0 = snapV(P, cx - hw), x1 = snapV(P, cx + hw);
      ctx.fillRect(x0, snapV(P, cy + dy), Math.max(step, x1 - x0), step);
    }
  }

  var LAYERS = [[0, 0, 1.0, 1], [-0.14, -0.14, 0.74, 2], [-0.36, -0.36, 0.32, 3]];

  function render(rctx) {
    ctx = rctx || Game.ctx;
    if (!ev || ev.phase !== 'live') { return; }
    var T = Game.Theme;
    var c = (T && T.ramp) ? T.ramp('boulder') : ['#5A4630', '#8A7355', '#B8A47F', '#E8DCC0'];
    var P = Game.Pixel;
    var step = (P && P.SCALE) ? P.SCALE : 2;
    var retro = !!(P && P.enabled && P.enabled());
    var x = ev.worldX - scrollX(), y = ev.y, r = ev.r;
    if (x < -r - 8 || x > Game.W + r + 8) { return; }
    var sx = snapV(P, x), sy = snapV(P, y);
    var i, L;
    ctx.save();
    ctx.fillStyle = c[0];
    if (retro) {
      disc(P, sx, sy, r + 2, step);
      for (i = 0; i < 3; i++) {
        L = LAYERS[i];
        ctx.fillStyle = c[L[3]];
        disc(P, sx + L[0] * r, sy + L[1] * r, r * L[2], step);
      }
    } else {
      ctx.beginPath();
      ctx.arc(x, y, r + 1.5, 0, Math.PI * 2);
      ctx.fill();
      for (i = 0; i < 3; i++) {
        L = LAYERS[i];
        ctx.fillStyle = c[L[3]];
        ctx.beginPath();
        ctx.arc(x + L[0] * r, y + L[1] * r, r * L[2], 0, Math.PI * 2);
        ctx.fill();
      }
    }
    // Spinning crack so the rotation reads.
    ctx.fillStyle = c[0];
    var cx = sx + Math.cos(ev.spin) * r * 0.55, cy = sy + Math.sin(ev.spin) * r * 0.55;
    ctx.fillRect(snapV(P, cx) - 2, snapV(P, cy) - 2, 4, 4);
    ctx.restore();
  }

  // Telegraph marker: bright, drawn above the headlamp darkness.
  function renderWarning(rctx) {
    ctx = rctx || Game.ctx;
    if (!ev || ev.phase !== 'tele') { return; }
    var T = Game.Theme;
    var c = (T && T.ramp) ? T.ramp('boulderWarn') : ['#FF2020', '#FF8800', '#FFE040', '#FFFFFF'];
    var P = Game.Pixel;
    var sx = scrollX();
    var on = Math.floor(ev.t * 8) % 2 === 0; // 8 Hz flash
    var fg = on ? c[3] : c[2], bg = c[1];
    var k, x, y;
    ctx.save();
    if (ev.roll) {
      var b = bounds(sx + Game.W - 20);
      x = Game.W - 34;
      y = snapV(P, b.bottom - 36);
      // Left-pointing arrow built from columns.
      for (k = 0; k < 8; k++) {
        ctx.fillStyle = bg;
        ctx.fillRect(x + k * 3 - 2, y - (k + 1) * 3 - 2, 3, (k + 1) * 6 + 4);
      }
      for (k = 0; k < 8; k++) {
        ctx.fillStyle = fg;
        ctx.fillRect(x + k * 3, y - (k + 1) * 3, 3, (k + 1) * 6);
      }
    } else {
      var bb = bounds(ev.worldX);
      x = snapV(P, ev.worldX - sx);
      // Dashed vertical guide from ceiling to floor.
      ctx.fillStyle = fg;
      for (y = bb.top + 30; y < bb.bottom; y += 14) {
        ctx.fillRect(x - 1, snapV(P, y), 3, 8);
      }
      // Downward-pointing triangle just under the ceiling.
      for (k = 0; k < 8; k++) {
        ctx.fillStyle = bg;
        ctx.fillRect(x - (8 - k) * 3 - 2, snapV(P, bb.top + 2 + k * 3), (8 - k) * 6 + 4, 3);
      }
      for (k = 0; k < 8; k++) {
        ctx.fillStyle = fg;
        ctx.fillRect(x - (8 - k) * 3, snapV(P, bb.top + 4 + k * 3), (8 - k) * 6, 3);
      }
    }
    ctx.restore();
  }

  function getAll() { return live; }

  Game.Boulders = {
    update: update,
    render: render,
    renderWarning: renderWarning,
    reset: reset,
    getAll: getAll,
    getEvent: function () { return ev; },
    TELEGRAPH: TELEGRAPH,
    HIT_DAMAGE: HIT_DAMAGE,
    FIRST_DELAY: FIRST_DELAY,
    ROLL_SPEED: ROLL_SPEED
  };
})();
