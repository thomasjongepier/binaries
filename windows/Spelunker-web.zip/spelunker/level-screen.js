// Level banner and level-clear screen (campaign). An OVERLAY on the playing
// view, not a STATES entry: the clear screen shows while Game.Levels.phase()
// is 'cleared'; the entry banner shows for BANNER_DURATION after a level
// starts. main.js calls update(dt) each playing frame, handleConfirm() on
// Enter/Space/fire/gamepad A, and render(ctx) from the playing render path.
(function () {
  'use strict';
  window.Game = window.Game || {};

  var INPUT_DELAY = 0.6;   // seconds a cleared screen ignores confirm
  var BANNER_FALLBACK = 2;
  var BLINK_PERIOD = 1.0;

  var clearT = 0;
  var victoryT = 0;
  var bannerT = 0;
  var lastLevel = 0;
  var blinkT = 0;

  function Levels() { return window.Game.Levels; }

  function bannerDuration() {
    var B = window.Game.Biomes;
    return (B && B.BANNER_DURATION) || BANNER_FALLBACK;
  }

  function isShowing() {
    var L = Levels();
    return !!(L && L.campaignActive && L.campaignActive() && L.phase() === 'cleared');
  }

  function isVictoryShowing() {
    var L = Levels();
    return !!(L && L.campaignActive && L.campaignActive() && L.phase() === 'finished');
  }

  function update(dt) {
    var L = Levels();
    dt = dt > 0 ? dt : 0;
    blinkT += dt;
    if (!L || !L.campaignActive || !L.campaignActive()) {
      clearT = 0; victoryT = 0; bannerT = 0; lastLevel = 0;
      return;
    }
    var ph = L.phase();
    if (ph === 'finished') {
      victoryT += dt;
      clearT = 0;
      bannerT = 0;
      return;
    }
    victoryT = 0;
    if (ph === 'cleared') {
      clearT += dt;
      bannerT = 0;
      return;
    }
    clearT = 0;
    if (ph === 'playing') {
      var n = L.level();
      if (n !== lastLevel) {
        lastLevel = n;
        bannerT = bannerDuration();
      } else if (bannerT > 0) {
        bannerT = Math.max(0, bannerT - dt);
      }
    } else {
      bannerT = 0;
    }
  }

  // True when the key was consumed by the screen (even if ignored by the
  // guard) so a held fire key neither skips nor shoots.
  function handleConfirm() {
    if (isVictoryShowing()) {
      if (victoryT < INPUT_DELAY) return true;
      if (window.Game.setState && window.Game.STATES) {
        window.Game.setState(window.Game.STATES.GAMEOVER);
      }
      return true;
    }
    if (!isShowing()) return false;
    if (clearT < INPUT_DELAY) return false;
    var ok = Levels().advance();
    if (ok) { clearT = 0; }
    return !!ok;
  }

  // Mouse press on the canvas. While a clear/victory overlay shows, every
  // button is swallowed (returns true) so it never fires a shot; only a fresh
  // left press (mousedown, so a button held from before never counts) confirms,
  // subject to the same input guard as the keys.
  function handlePointerDown(e) {
    if (!isShowing() && !isVictoryShowing()) return false;
    if (!e || e.button === 0 || e.button === undefined) handleConfirm();
    return true;
  }

  function bannerText() {
    var L = Levels();
    var c = L && L.current ? L.current() : null;
    if (!c || bannerT <= 0) return '';
    return ('LEVEL ' + c.n + ' - ' + c.name).toUpperCase();
  }

  // Name of the next level's world when it differs from this level's, else ''.
  function nextWorldName(n) {
    var L = Levels();
    var B = window.Game.Biomes;
    if (!L || !L.themeOf) return '';
    var a = L.themeOf(n), b = L.themeOf(n + 1);
    if (!a || !b || a === b) return '';
    var t = B && B.THEMES && B.THEMES[b];
    return t && t.name ? t.name : b;
  }

  function nextWorldColor(n) {
    var L = Levels();
    var B = window.Game.Biomes;
    var b = L && L.themeOf ? L.themeOf(n + 1) : null;
    var t = b && B && B.THEMES ? B.THEMES[b] : null;
    return t && t.bannerColor ? t.bannerColor : null;
  }

  function palette() {
    var T = window.Game.Theme;
    return (T && T.get && T.get()) || {};
  }

  function text(ctx, s, x, y, color, role, css, scale) {
    var F = window.Game.Font;
    if (F && F.draw) {
      F.draw(ctx, s, x, y, { role: role || 'body', css: css || 'bold 16px monospace',
        color: color, align: 'center', baseline: 'middle', scale: scale || 1 });
    }
  }

  function renderBanner(ctx) {
    var s = bannerText();
    if (!s) return;
    var P = palette();
    var B = window.Game.Biomes;
    var L = Levels();
    var c = L.current();
    var th = c && B && B.THEMES ? B.THEMES[c.theme] : null;
    text(ctx, s, (window.Game.W || 640) / 2, 100,
      (th && th.bannerColor) || P.YELLOW || '#FFFF00', 'title', 'bold 22px monospace', 1);
  }

  function renderClear(ctx) {
    var L = Levels();
    var c = L.current();
    if (!c) return;
    var W = window.Game.W || 640, H = window.Game.H || 400;
    var P = palette();
    var white = P.WHITE || '#FFFFFF', yellow = P.YELLOW || '#FFFF00';
    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.fillRect(0, 0, W, H);
    ctx.restore();

    var y = 90;
    text(ctx, 'LEVEL ' + c.n + ' CLEAR', W / 2, y, yellow, 'title', 'bold 44px monospace', 2);
    y += 52;
    text(ctx, String(c.name).toUpperCase(), W / 2, y, white, 'body', 'bold 20px monospace', 1);
    y += 40;
    var S = window.Game.Score;
    if (S && S.total) {
      text(ctx, 'SCORE ' + S.total(), W / 2, y, yellow, 'body', 'bold 20px monospace', 1);
      y += 30;
    }
    var C = window.Game.Collision;
    var parts = [];
    if (C && C.getLives) parts.push('LIVES ' + C.getLives());
    if (C && C.getShield) parts.push('SHIELD ' + Math.round(C.getShield()));
    if (parts.length) {
      text(ctx, parts.join('   '), W / 2, y, white, 'body', 'bold 16px monospace', 1);
      y += 30;
    }
    var next = nextWorldName(c.n);
    if (next) {
      text(ctx, 'ENTERING ' + String(next).toUpperCase(), W / 2, y + 10,
        nextWorldColor(c.n) || yellow, 'title', 'bold 22px monospace', 1);
    }
    if (clearT >= INPUT_DELAY && (blinkT % BLINK_PERIOD) < BLINK_PERIOD / 2) {
      text(ctx, 'PRESS SPACE TO CONTINUE', W / 2, 340, white, 'body', 'bold 16px monospace', 1);
    }
  }

  function renderVictory(ctx) {
    var W = window.Game.W || 640, H = window.Game.H || 400;
    var P = palette();
    var white = P.WHITE || '#FFFFFF', yellow = P.YELLOW || '#FFFF00';
    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
    var y = 80;
    text(ctx, 'YOU ESCAPED THE DEPTHS', W / 2, y, yellow, 'title', 'bold 34px monospace', 2);
    y += 56;
    var L = Levels();
    var total = L && L.count ? L.count() : 25;
    text(ctx, 'ALL ' + total + ' LEVELS CLEARED', W / 2, y, white, 'body', 'bold 20px monospace', 1);
    y += 44;
    var S = window.Game.Score;
    if (S && S.total) {
      text(ctx, 'FINAL SCORE ' + S.total(), W / 2, y, yellow, 'body', 'bold 20px monospace', 1);
      y += 32;
    }
    var C = window.Game.Collision;
    var parts = [];
    if (C && C.getLives) parts.push('LIVES ' + C.getLives());
    if (C && C.getShield) parts.push('SHIELD ' + Math.round(C.getShield()));
    if (parts.length) {
      text(ctx, parts.join('   '), W / 2, y, white, 'body', 'bold 16px monospace', 1);
    }
    if (victoryT >= INPUT_DELAY && (blinkT % BLINK_PERIOD) < BLINK_PERIOD / 2) {
      text(ctx, 'PRESS SPACE TO CONTINUE', W / 2, 340, white, 'body', 'bold 16px monospace', 1);
    }
  }

  function render(ctx) {
    if (!ctx) return;
    if (isVictoryShowing()) renderVictory(ctx);
    else if (isShowing()) renderClear(ctx);
    else renderBanner(ctx);
  }

  function reset() { clearT = 0; victoryT = 0; bannerT = 0; lastLevel = 0; blinkT = 0; }

  window.Game.LevelScreen = {
    update: update,
    isShowing: isShowing,
    isVictoryShowing: isVictoryShowing,
    handleConfirm: handleConfirm,
    handlePointerDown: handlePointerDown,
    render: render,
    reset: reset,
    bannerText: bannerText,
    nextWorldName: nextWorldName,
    INPUT_DELAY: INPUT_DELAY
  };
})();
