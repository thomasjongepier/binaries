// Spelunker - biomes. Named cave sections that change every BIOME_LENGTH
// distance points, cycling. Each biome tints the rock palette (same colours in
// classic and modern) and scales hazard trigger chances. Game.Balance is not
// touched; hazards.js multiplies at roll time.
(function () {
  'use strict';
  window.Game = window.Game || {};
  var Game = window.Game;

  var BIOME_LENGTH = 2000;   // distance points per biome
  var FADE_DURATION = 3;     // seconds for the rock palette crossfade
  var FADE_STEPS = 6;        // quantised steps, so cave tiles rebuild few times
  var BANNER_DURATION = 2;   // seconds the ENTERING banner shows

  // rock: 5-colour ramp, dark to light; null = use the active theme's rock.
  var BIOMES = [
    { name: 'Crystal Caverns', rock: null, gas: 1, collapse: 1 },
    { name: 'Toxic Mines', gas: 1.5, collapse: 1,
      rock: ['#0d1c0f', '#1c3a1c', '#2f5c27', '#4d7d3a', '#7fae58'] },
    { name: 'Magma Depths', gas: 1, collapse: 1.5,
      rock: ['#2b0f09', '#4b1d11', '#722f1a', '#9b482a', '#c8693c'] }
  ];

  // Forced themes (level engine). Same shape as BIOMES entries plus bannerColor
  // and a motif tag that background.js will consume. Placeholder ramps.
  var THEMES = {
    crystal: { name: 'Crystal Caverns', gas: 1, collapse: 1,
      rock: ['#1A1456', '#3330B0', '#2F5CD8', '#2FA8F0', '#A0FFFF'],
      hot: ['#2A0A3A', '#5A1470', '#9A2AA8', '#E04AC8', '#FF9CF0'],
      bannerColor: '#9FF0FF', motif: 'crystal' },
    jungle: { name: 'Verdant Jungle', gas: 1.4, collapse: 1,
      rock: ['#0F2A12', '#1F5A22', '#2E8B2E', '#5BC03A', '#B6F060'],
      hot: ['#2A2A0A', '#5A5A12', '#9A8A1A', '#D8B02A', '#FFE066'],
      bannerColor: '#C8F580', motif: 'jungle' },
    aztec: { name: 'Aztec Temple', gas: 1, collapse: 1.4,
      rock: ['#2A1A10', '#4E4624', '#6E6A30', '#E2B83C', '#F4DC7A'],
      hot: ['#2E0E08', '#5E1C10', '#9A3418', '#D8601E', '#FFB45A'],
      bannerColor: '#FFD866', motif: 'aztec' },
    orient: { name: 'Frozen Orient', gas: 1, collapse: 1,
      rock: ['#0C1E26', '#174A52', '#2A7F7A', '#6FC4B4', '#D6F6F0'],
      hot: ['#2E0A12', '#62122A', '#A02240', '#E04A58', '#FFC0A0'],
      bannerColor: '#BFF2EA', motif: 'orient' },
    void: { name: 'Void and Abyss', gas: 1.2, collapse: 1.2,
      rock: ['#05050E', '#0B0B24', '#1F1E5E', '#4A44C0', '#C06CFF'],
      hot: ['#1A0212', '#4A0A34', '#9A1A60', '#FF3C98', '#FFE0F8'],
      bannerColor: '#FF7AF0', motif: 'void' }
  };
  var THEME_IDS = ['crystal', 'jungle', 'aztec', 'orient', 'void'];

  var forcedId = null;   // forced theme id, or null = distance cycling
  var absIndex = 0;      // floor(distance / BIOME_LENGTH), unbounded
  var fromEntry = BIOMES[0]; // biome/theme entry we are fading away from
  var fade = 1;          // 0..1 crossfade progress toward the current biome
  var bannerTimer = 0;
  var bannerName = '';
  var visualCounter = 0; // monotonic; bumps whenever the rock ramp changes
  var lastStep = FADE_STEPS;
  var cache = null;
  var reached = [BIOMES[0].name]; // (theme names are added too) unique biome names visited this run, in order

  function indexAt(distancePoints) {
    if (typeof distancePoints !== 'number' || !isFinite(distancePoints) || distancePoints < 0) return 0;
    return Math.floor(distancePoints / BIOME_LENGTH);
  }
  function cycled(i) { return i % BIOMES.length; }
  function curIdx() { return cycled(absIndex); }

  function active() { return forcedId ? THEMES[forcedId] : BIOMES[curIdx()]; }

  function current() {
    var b = active();
    var o = { index: curIdx(), absoluteIndex: absIndex, name: b.name, gas: b.gas, collapse: b.collapse };
    if (forcedId) o.theme = forcedId;
    return o;
  }

  // type: 'gas' | 'collapse'. Unknown types give 1.
  function hazardMultiplier(type) {
    var b = active();
    return (type === 'gas' || type === 'collapse') ? b[type] : 1;
  }

  function reset() {
    forcedId = null; absIndex = 0; fromEntry = BIOMES[0]; fade = 1; bannerTimer = 0; bannerName = '';
    lastStep = FADE_STEPS;
    visualCounter++; // palette snaps back to Crystal Caverns
    cache = null;
    reached = [BIOMES[0].name];
  }

  // Force a level theme. Crossfades from the ramp currently shown; no
  // ENTERING banner (the level engine shows its own).
  function setTheme(id) {
    if (typeof id !== 'string' || !Object.prototype.hasOwnProperty.call(THEMES, id)) return false;
    if (forcedId === id) return true;
    fromEntry = fade >= 1 ? active() : fromEntry;
    forcedId = id;
    fade = 0;
    lastStep = -1;
    bannerTimer = 0;
    visualCounter++;
    cache = null;
    if (reached.indexOf(THEMES[id].name) < 0) reached.push(THEMES[id].name);
    return true;
  }

  // Back to distance cycling, fading from the theme ramp to the biome at the
  // current distance. No banner.
  function clearTheme() {
    if (!forcedId) return;
    fromEntry = fade >= 1 ? active() : fromEntry;
    forcedId = null;
    absIndex = indexAt(Game.Score && Game.Score.distancePoints);
    fade = 0;
    lastStep = -1;
    visualCounter++;
    cache = null;
  }

  function update(dt) {
    if (typeof dt !== 'number' || !(dt > 0)) return;
    var S = Game.Score;
    var idx = forcedId ? absIndex : indexAt(S && S.distancePoints);
    if (idx !== absIndex) {
      // Crossfade starts from whatever is currently shown.
      fromEntry = fade >= 1 ? active() : fromEntry;
      absIndex = idx;
      fade = 0;
      lastStep = -1;
      bannerTimer = BANNER_DURATION;
      bannerName = BIOMES[curIdx()].name;
      if (reached.indexOf(bannerName) < 0) reached.push(bannerName);
    }
    if (bannerTimer > 0) bannerTimer = Math.max(0, bannerTimer - dt);
    if (fade < 1) fade = Math.min(1, fade + dt / FADE_DURATION);
    var step = Math.round(fade * FADE_STEPS);
    if (step !== lastStep) { lastStep = step; visualCounter++; cache = null; }
  }

  function hexToRgb(h) {
    var n = parseInt(h.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function mix(a, b, t) {
    var x = hexToRgb(a), y = hexToRgb(b), s = '#';
    for (var i = 0; i < 3; i++) {
      var h = Math.round(x[i] + (y[i] - x[i]) * t).toString(16).toUpperCase();
      s += h.length < 2 ? '0' + h : h;
    }
    return s;
  }

  // Rock ramp for the current moment given the theme's base rock ramp.
  function rockRamp(base) {
    if (!base || base.length < 5) return base;
    if (cache && cache.base === base) return cache.ramp;
    var from = fromEntry.rock || base;
    var to = active().rock || base;
    var t = Math.round(fade * FADE_STEPS) / FADE_STEPS;
    var out = [];
    for (var i = 0; i < base.length; i++) {
      out.push(from === to || t >= 1 ? to[i] : (t <= 0 ? from[i] : mix(from[i], to[i], t)));
    }
    cache = { base: base, ramp: out };
    return out;
  }

  // Hard-zone ("hot") rock ramp: the forced theme's own hot variant, crossfaded
  // like rockRamp. With no forced theme (endless) the base ramp is returned
  // unchanged, so the classic orange hot ramp is untouched.
  var hotCache = null;
  var hotCacheVer = -1;
  function hotRamp(base) {
    if (!base || base.length < 5) return base;
    var from = fromEntry.hot || base;
    var to = active().hot || base;
    if (from === base && to === base) return base;
    if (hotCache && hotCache.base === base && hotCacheVer === visualCounter) return hotCache.ramp;
    var t = Math.round(fade * FADE_STEPS) / FADE_STEPS;
    var out = [];
    for (var i = 0; i < base.length; i++) {
      out.push(from === to || t >= 1 ? to[i] : (t <= 0 ? from[i] : mix(from[i], to[i], t)));
    }
    hotCache = { base: base, ramp: out };
    hotCacheVer = visualCounter;
    return out;
  }

  function renderBanner(rctx) {
    if (bannerTimer <= 0) return;
    var c = rctx || Game.ctx;
    var pal = Game.Theme && Game.Theme.get ? Game.Theme.get() : { YELLOW: '#BFCE72' };
    var text = 'ENTERING: ' + bannerName.toUpperCase();
    if (Game.Font && Game.Font.draw) {
      Game.Font.draw(c, text, Game.W / 2, 100, {
        role: 'title', css: 'bold 22px monospace', color: pal.YELLOW,
        align: 'center', baseline: 'middle', scale: 1
      });
    } else {
      c.save();
      c.font = 'bold 22px monospace';
      c.fillStyle = pal.YELLOW;
      c.textAlign = 'center';
      c.textBaseline = 'middle';
      c.fillText(text, Game.W / 2, 100);
      c.restore();
    }
  }

  Game.Biomes = {
    current: current,
    indexAt: indexAt,
    hazardMultiplier: hazardMultiplier,
    gasMultiplier: function () { return hazardMultiplier('gas'); },
    collapseMultiplier: function () { return hazardMultiplier('collapse'); },
    update: update,
    reset: reset,
    setTheme: setTheme,
    clearTheme: clearTheme,
    currentTheme: function () { return forcedId; },
    bannerColor: function () { return forcedId ? THEMES[forcedId].bannerColor : null; },
    themeIds: function () { return THEME_IDS.slice(); },
    THEMES: THEMES,
    getReached: function () { return reached.slice(); },
    rockRamp: rockRamp,
    hotRamp: hotRamp,
    version: function () { return visualCounter; },
    bannerText: function () { return bannerTimer > 0 ? 'ENTERING: ' + bannerName.toUpperCase() : ''; },
    renderBanner: renderBanner,
    BIOME_LENGTH: BIOME_LENGTH,
    FADE_DURATION: FADE_DURATION,
    BANNER_DURATION: BANNER_DURATION,
    names: function () { return BIOMES.map(function (b) { return b.name; }); }
  };
})();
