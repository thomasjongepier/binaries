// background.js - three parallax layers drawn behind the cave walls (nu2.19).
//   far   : rock silhouettes at 0.25x scroll, ramp 'backdrop' shade 1
//   mid   : stalactites/stalagmites at 0.5x, shade 2 with a shade-3 edge
//   glints: sparse twinkling crystal sprites at 0.35x
// Layer shapes come from the separate seeded 'background' stream, so cave
// generation is unaffected. Each layer is a horizontally wrapping offscreen
// tile (one canvas px = 1 buffer px), rebuilt when Game.Theme.version() changes.
// Layer offsets are whole buffer pixels.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  // Retro: 2 logical px per buffer px. High: 1 logical px, tiles twice as large
  // (K = 2) with the same shapes sampled at finer steps and smooth gradients.
  function hiRes() { return !!(Game.Pixel && Game.Pixel.hiRes && Game.Pixel.hiRes()); }
  function px() { return hiRes() ? 1 : 2; }
  function kk() { return 2 / px(); } // detail factor: 1 retro, 2 high
  var TW0 = 320; // tile width in buffer px (shape space, wraps)
  var TH0 = 200; // tile height in buffer px (shape space)
  var TW = TW0; // current tile width in render units (retro 320, high 640)
  var TH = TH0;
  var FAR = 0.25, MID = 0.5, GLINT = 0.35;
  var GLINT_COUNT = 14;
  var GLINT_FPS = 8;

  var shapes = null; // generated once
  var tiles = { far: null, mid: null };
  var tilesVersion = null;
  var tilesMode = null;
  var tilesMotif = null;
  var glintDefined = false;

  // Motif registry (per-world themes). A motif def, all fields optional:
  //   backdrop: [4 hex, dark->light]  overrides the 'backdrop' ramp (far/mid layers)
  //   glint:    hex                    glints drawn as tinted plus-shapes instead of sprites
  //   extras:   function (ctx, state)  draws an extra layer each frame, between mid and glints;
  //             state = {scrollX, time (s), hi, px, W, H} (a reused object: do not keep it)
  // The active motif is Game.Biomes.THEMES[Game.Biomes.currentTheme()].motif;
  // no forced theme or an unregistered id means no motif (default rendering).
  var motifs = {};
  function registerMotif(id, def) {
    if (typeof id !== 'string' || !id || !def || typeof def !== 'object') { return false; }
    motifs[id] = def;
    tilesMotif = null; // force a rebuild if the active motif was replaced
    return true;
  }
  function activeMotifId() {
    var B = Game.Biomes;
    var id = (B && B.currentTheme) ? B.currentTheme() : null;
    var t = id && B.THEMES ? B.THEMES[id] : null;
    var m = t && t.motif;
    return (typeof m === 'string' && Object.prototype.hasOwnProperty.call(motifs, m)) ? m : null;
  }
  var motifState = { scrollX: 0, time: 0, hi: false, px: 2, W: 640, H: 400 };

  function themeVersion() {
    return (Game.Theme && Game.Theme.version) ? Game.Theme.version() : 0;
  }

  function ramp() {
    var mid = activeMotifId();
    var mb = mid ? motifs[mid].backdrop : null;
    if (mb && mb.length >= 4) { return mb; }
    var r = (Game.Theme && Game.Theme.ramp) ? Game.Theme.ramp('backdrop') : null;
    if (r && r.length >= 4) { return r; }
    var p = (Game.Theme && Game.Theme.get) ? Game.Theme.get() : {};
    var b = p.BLUE || p.BLACK || '#000';
    return [p.BLACK || '#000', b, b, b];
  }

  function generateShapes() {
    var rs = Game.Random.stream('background');
    var s = { far: { top: [], bot: [] }, mid: [], glints: [] };
    var i, k;
    // Far silhouettes: sums of integer-period sines (periodic over TW).
    ['top', 'bot'].forEach(function (side) {
      for (k = 0; k < 3; k++) {
        s.far[side].push({ f: 1 + k * 2 + rs.int(0, 1), p: rs.range(0, 6.283), a: rs.range(8, 16) });
      }
      s.far[side + 'Base'] = rs.int(66, 86);
    });
    // Mid formations: center column, half width, length, direction.
    for (i = 0; i < 12; i++) {
      s.mid.push({
        c: Math.floor((i + rs.range(0.1, 0.9)) * TW0 / 12),
        w: rs.int(5, 12),
        len: rs.int(34, 72),
        top: rs.next() < 0.5
      });
    }
    for (i = 0; i < GLINT_COUNT; i++) {
      s.glints.push({
        x: rs.int(0, TW0 - 1),
        y: rs.int(8, TH0 - 9),
        phase: rs.int(0, 2)
      });
    }
    return s;
  }

  function makeCanvas() {
    if (typeof document === 'undefined' || !document || typeof document.createElement !== 'function') {
      return null;
    }
    try {
      var cv = document.createElement('canvas');
      cv.width = TW;
      cv.height = TH;
      return (cv.getContext && cv.getContext('2d')) ? cv : null;
    } catch (e) {
      return null;
    }
  }

  function bayer(x, y) {
    var B = Game.Sprite && Game.Sprite.BAYER4;
    return B ? B[(y & 3) * 4 + (x & 3)] : ((x + y) & 1) * 8;
  }

  // Per-column edge heights (render units) of the far silhouettes. Integer-period
  // sines wrap exactly at TW, so the seam is invisible. Retro: one int/column;
  // high: finer columns, heights scaled by K and left fractional (smooth edge).
  function farHeights(side) {
    var out = [];
    var terms = shapes.far[side];
    var K = kk();
    for (var c = 0; c < TW; c++) {
      var h = shapes.far[side + 'Base'];
      for (var k = 0; k < terms.length; k++) {
        h += terms[k].a * Math.sin(6.283185 * (terms[k].f * c / TW) + terms[k].p);
      }
      out.push(K === 1 ? Math.max(4, Math.round(h)) : Math.max(4 * K, h * K));
    }
    return out;
  }

  // Tiny hex lerp for the high-res smooth gradients.
  function lerpHex(a, b, t) {
    function parse(c) {
      if (typeof c !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(c)) { return null; }
      return [parseInt(c.slice(1, 3), 16), parseInt(c.slice(3, 5), 16), parseInt(c.slice(5, 7), 16)];
    }
    var A = parse(a), B = parse(b);
    if (!A || !B) { return t < 0.5 ? a : b; }
    var out = '#';
    for (var i = 0; i < 3; i++) {
      var v = Math.round(A[i] + (B[i] - A[i]) * t);
      out += (v < 16 ? '0' : '') + v.toString(16);
    }
    return out;
  }

  function buildFar(R) {
    var cv = makeCanvas();
    if (!cv) { return null; }
    var cx = cv.getContext('2d');
    var top = farHeights('top'), bot = farHeights('bot');
    var K = kk();
    var DITHER = 6 * K; // dithered (retro) / smoothly graded (high) band depth toward the edge
    for (var c = 0; c < TW; c++) {
      for (var y = 0; y < TH; y++) {
        var d = -1; // distance inside the silhouette from its edge
        if (y < top[c]) { d = top[c] - 1 - y; }
        else if (y >= TH - bot[c]) { d = y - (TH - bot[c]); }
        if (d < 0) { continue; }
        var col = R[1];
        if (d < DITHER) {
          // edge fades from backdrop[0] to backdrop[1] with Bayer dither
          col = K === 1
            ? (bayer(c, y) < Math.round(d * 16 / DITHER) ? R[1] : R[0])
            : lerpHex(R[0], R[1], d / DITHER);
        }
        cx.fillStyle = col;
        cx.fillRect(c, y, 1, 1);
      }
    }
    return cv;
  }

  function buildMid(R) {
    var cv = makeCanvas();
    if (!cv) { return null; }
    var cx = cv.getContext('2d');
    var K = kk();
    var topH = new Array(TW), botH = new Array(TW), c, i;
    for (c = 0; c < TW; c++) { topH[c] = 0; botH[c] = 0; }
    for (i = 0; i < shapes.mid.length; i++) {
      var f = shapes.mid[i];
      var fw = f.w * K, fc = f.c * K, fl = f.len * K;
      for (var dx = -fw; dx <= fw; dx++) {
        var h = Math.round(fl * (1 - Math.abs(dx) / (fw + 1)));
        var col = (((fc + dx) % TW) + TW) % TW;
        if (f.top) { topH[col] = Math.max(topH[col], h); } else { botH[col] = Math.max(botH[col], h); }
      }
    }
    // Base rock lip so formations hang from / rise out of something.
    for (c = 0; c < TW; c++) {
      var tl = topH[c] + 4 * K, bl = botH[c] + 4 * K;
      cx.fillStyle = R[2];
      cx.fillRect(c, 0, 1, tl);
      cx.fillRect(c, TH - bl, 1, bl);
      // 1 px highlight edge in backdrop[3]: the tip pixel plus the step
      // against the left neighbour, so the lit side reads as a hard edge.
      var pl = (c + TW - 1) % TW;
      var plT = topH[pl] + 4 * K, plB = botH[pl] + 4 * K;
      cx.fillStyle = R[3];
      cx.fillRect(c, tl - 1, 1, 1);
      if (plT < tl) { cx.fillRect(c, plT, 1, tl - plT); }
      cx.fillRect(c, TH - bl, 1, 1);
      if (plB < bl) { cx.fillRect(c, TH - bl, 1, bl - plB); }
    }
    return cv;
  }

  function defineGlint() {
    if (glintDefined || !Game.Sprite || !Game.Sprite.define) { return; }
    try {
      Game.Sprite.define('crystal-glint', {
        w: 3, h: 3,
        map: { a: 'crystal:1', b: 'crystal:2', w: 'crystal:3' },
        frames: [
          ['...', '.a.', '...'],
          ['.b.', 'bwb', '.b.'],
          ['.a.', 'aba', '.a.']
        ]
      });
      glintDefined = true;
    } catch (e) {
      glintDefined = false;
    }
  }

  function ensure() {
    if (!shapes) { shapes = generateShapes(); }
    defineGlint();
    var v = themeVersion();
    var mode = hiRes() ? 'high' : 'retro';
    var mot = activeMotifId();
    if (v !== tilesVersion || mode !== tilesMode || mot !== tilesMotif) {
      tilesMode = mode;
      tilesMotif = mot;
      TW = TW0 * kk();
      TH = TH0 * kk();
      var R = ramp();
      tiles.far = buildFar(R);
      tiles.mid = buildMid(R);
      tilesVersion = v;
    }
  }

  // Layer offset in whole buffer px for a world scrollX (logical px).
  function layerOffset(scrollX, factor) {
    return Math.floor(scrollX / px() * factor);
  }

  function snap(v) {
    return (Game.Pixel && Game.Pixel.snap) ? Game.Pixel.snap(v) : Math.round(v / px()) * px();
  }

  function drawTile(ctx, tile, off) {
    if (!tile) { return; }
    var PX = px();
    var o = ((off % TW) + TW) % TW;
    var x = snap(-o * PX);
    ctx.drawImage(tile, x, 0, TW * PX, TH * PX);
    ctx.drawImage(tile, x + TW * PX, 0, TW * PX, TH * PX);
  }

  // Draws the layers into ctx (logical 640x400 coordinates). nowMs is optional.
  function render(ctx, scrollX, nowMs) {
    if (!ctx || typeof ctx.drawImage !== 'function' || !Game.Random || !Game.Random.stream) { return; }
    ensure();
    var PX = px();
    var K = kk();
    var sx = +scrollX || 0;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    drawTile(ctx, tiles.far, layerOffset(sx, FAR));
    drawTile(ctx, tiles.mid, layerOffset(sx, MID));
    var t = (nowMs === undefined ? Date.now() : nowMs) / 1000;
    var mid = activeMotifId();
    var motif = mid ? motifs[mid] : null;
    if (motif && typeof motif.extras === 'function') {
      motifState.scrollX = sx; motifState.time = t; motifState.hi = hiRes(); motifState.px = PX;
      motifState.W = Game.W || 640; motifState.H = Game.H || 400;
      ctx.save();
      try { motif.extras(ctx, motifState); } catch (e) { /* a bad motif must not kill the frame */ }
      ctx.restore();
    }
    if (motif && motif.glint) {
      var gt = ((layerOffset(sx, GLINT) % TW) + TW) % TW;
      var U = PX * K; // one tile px in logical px
      ctx.fillStyle = motif.glint;
      for (var j = 0; j < shapes.glints.length; j++) {
        var h = shapes.glints[j];
        var fr = (Math.floor(t * GLINT_FPS / 2) + h.phase) % 3;
        for (var r2 = 0; r2 < 2; r2++) {
          var gx = h.x * K - gt + r2 * TW;
          if (gx >= -2 * K && gx < TW + 2 * K) {
            var cx0 = gx * PX, cy0 = h.y * K * PX;
            if (fr === 0) { ctx.fillRect(cx0 + U, cy0 + U, U, U); }
            else { ctx.fillRect(cx0, cy0 + U, 3 * U, U); ctx.fillRect(cx0 + U, cy0, U, 3 * U); }
          }
        }
      }
    } else if (glintDefined && Game.Sprite && Game.Sprite.draw) {
      var go = ((layerOffset(sx, GLINT) % TW) + TW) % TW;
      for (var i = 0; i < shapes.glints.length; i++) {
        var g = shapes.glints[i];
        var frame = (Math.floor(t * GLINT_FPS / 2) + g.phase) % 3;
        for (var rep = 0; rep < 2; rep++) {
          var bx = g.x * K - go + rep * TW;
          if (bx >= -2 * K && bx < TW + 2 * K) {
            // sprite center, in logical px
            Game.Sprite.draw(ctx, 'crystal-glint', frame, (bx + 1.5 * K) * PX, (g.y * K + 1.5 * K) * PX);
          }
        }
      }
    }
    ctx.restore();
  }

  // ---- Crystal Caverns motif: faceted translucent shards at ~0.4x parallax ----
  var CRYSTAL_PAR = 0.4;
  var SHARD_N = 12;
  var SHARD_PERIOD = 800; // logical px; shards repeat so scroll never runs out
  var shards = null;

  function hash01(n) { // deterministic, independent of every Game.Random stream
    var x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
    return x - Math.floor(x);
  }
  function makeShards() {
    var a = [];
    for (var i = 0; i < SHARD_N; i++) {
      a.push({
        x: (i + 0.15 + 0.7 * hash01(i + 1)) * SHARD_PERIOD / SHARD_N,
        top: hash01(i + 40) < 0.5,
        w: 34 + Math.floor(hash01(i + 80) * 40),
        h: 90 + Math.floor(hash01(i + 120) * 100),
        lean: Math.floor((hash01(i + 160) - 0.5) * 24),
        c: i % 3,
        phase: hash01(i + 200) * 6.283
      });
    }
    return a;
  }
  var CRYSTAL_COLS = ['#40F0FF', '#B070FF', '#E8FFFF']; // cyan, violet, pale

  function crystalExtras(ctx, st) {
    if (!shards) { shards = makeShards(); }
    var hi = st.hi, S = hi ? 1 : 4; // retro snaps to 4 logical px (chunky)
    var off = Math.floor(st.scrollX * CRYSTAL_PAR);
    var H = st.H;
    for (var i = 0; i < shards.length; i++) {
      var s = shards[i];
      var bx = ((s.x - off) % SHARD_PERIOD + SHARD_PERIOD) % SHARD_PERIOD - 80;
      if (bx > st.W + 80) { continue; }
      var pulse = 0.5 + 0.5 * Math.sin(st.time * 1.3 + s.phase);
      // retro: two flat alpha steps; high-res: smooth pulse
      var alpha = hi ? 0.55 + 0.3 * pulse : (pulse > 0.5 ? 0.9 : 0.65);
      var x0 = Math.round(bx / S) * S, w = Math.round(s.w / S) * S;
      var h = Math.round(s.h / S) * S, lean = Math.round(s.lean / S) * S;
      var yb = s.top ? 0 : H, ya = s.top ? h : H - h; // base and apex y
      var col = CRYSTAL_COLS[s.c];
      ctx.globalAlpha = alpha;
      ctx.fillStyle = col;
      ctx.beginPath();
      ctx.moveTo(x0, yb); ctx.lineTo(x0 + w, yb); ctx.lineTo(x0 + w / 2 + lean, ya);
      ctx.closePath();
      ctx.fill();
      // lit facet: the left half, lighter
      ctx.globalAlpha = alpha * 0.55;
      ctx.fillStyle = CRYSTAL_COLS[2];
      ctx.beginPath();
      ctx.moveTo(x0, yb); ctx.lineTo(x0 + w / 2, yb); ctx.lineTo(x0 + w / 2 + lean, ya);
      ctx.closePath();
      ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  motifs.crystal = {
    backdrop: ['#0A0826', '#120F4A', '#1A2E78', '#2A6AA0'],
    glint: '#B8F0FF',
    extras: crystalExtras
  };

  // ---- Verdant Jungle motif: swaying ceiling vines (0.45x) and fireflies (0.6x) ----
  var VINE_PAR = 0.45, FLY_PAR = 0.6;
  var VINE_N = 14, VINE_SEG = 8, VINE_PERIOD = 800;
  var FLY_N = 14, FLY_PERIOD = 900;
  var vines = null, flies = null;
  var VINE_COLS = ['#2A7A5C', '#348F68', '#46A27A']; // cool, muted: scenery, not hazard

  function makeVines() {
    var a = [];
    for (var i = 0; i < VINE_N; i++) {
      a.push({
        x: (i + 0.15 + 0.7 * hash01(i + 301)) * VINE_PERIOD / VINE_N,
        len: 70 + Math.floor(hash01(i + 340) * 50),
        amp: 5 + hash01(i + 380) * 9,
        phase: hash01(i + 420) * 6.283,
        c: i % 3,
        leafAt: 2 + Math.floor(hash01(i + 460) * 3)
      });
    }
    return a;
  }
  function makeFlies() {
    var a = [];
    for (var i = 0; i < FLY_N; i++) {
      a.push({
        x: (i + 0.5) * FLY_PERIOD / FLY_N,
        y: 40 + hash01(i + 501) * 320,
        ax: 14 + hash01(i + 540) * 30,
        ay: 8 + hash01(i + 580) * 22,
        fx: 0.2 + hash01(i + 620) * 0.35,
        fy: 0.25 + hash01(i + 660) * 0.4,
        phase: hash01(i + 700) * 6.283
      });
    }
    return a;
  }

  function jungleExtras(ctx, st) {
    if (!vines) { vines = makeVines(); flies = makeFlies(); }
    var hi = st.hi, S = hi ? 1 : 4, i, j;
    var voff = Math.floor(st.scrollX * VINE_PAR);
    var t = st.time;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = hi ? 2 : 4;
    for (i = 0; i < vines.length; i++) {
      var v = vines[i];
      var bx = ((v.x - voff) % VINE_PERIOD + VINE_PERIOD) % VINE_PERIOD - 60;
      if (bx > st.W + 60) { continue; }
      var col = VINE_COLS[v.c];
      var segLen = v.len / VINE_SEG;
      ctx.globalAlpha = 0.45;
      ctx.strokeStyle = col;
      ctx.beginPath();
      ctx.moveTo(Math.round(bx / S) * S, 0);
      for (j = 1; j <= VINE_SEG; j++) {
        var f = j / VINE_SEG;
        var x = bx + Math.sin(t * 0.9 + v.phase + j * 0.55) * v.amp * f;
        ctx.lineTo(Math.round(x / S) * S, Math.round(j * segLen / S) * S);
      }
      ctx.stroke();
      // leaf blobs along the strand
      ctx.fillStyle = VINE_COLS[(v.c + 1) % 3];
      for (j = v.leafAt; j <= VINE_SEG; j += 2) {
        var ff = j / VINE_SEG;
        var lx = bx + Math.sin(t * 0.9 + v.phase + j * 0.55) * v.amp * ff;
        var ly = j * segLen, side = (j & 2) ? 1 : -1;
        if (hi) {
          ctx.beginPath();
          ctx.arc(lx + side * 5, ly, 4, 0, 6.283185);
          ctx.fill();
        } else {
          ctx.fillRect(Math.round((lx + (side > 0 ? 4 : -12)) / S) * S, Math.round(ly / S) * S - 4, 8, 8);
        }
      }
      // tip bulb
      var tx = bx + Math.sin(t * 0.9 + v.phase + VINE_SEG * 0.55) * v.amp;
      ctx.fillStyle = VINE_COLS[2];
      if (hi) { ctx.beginPath(); ctx.arc(tx, v.len, 3, 0, 6.283185); ctx.fill(); }
      else { ctx.fillRect(Math.round(tx / S) * S - 4, Math.round(v.len / S) * S, 8, 8); }
    }
    // fireflies
    ctx.globalAlpha = 1;
    var foff = Math.floor(st.scrollX * FLY_PAR);
    for (i = 0; i < flies.length; i++) {
      var fl = flies[i];
      var fx = ((fl.x - foff + Math.sin(t * fl.fx + fl.phase) * fl.ax) % FLY_PERIOD + FLY_PERIOD) % FLY_PERIOD - 100;
      if (fx > st.W + 20) { continue; }
      var fy = fl.y + Math.sin(t * fl.fy + fl.phase * 1.7) * fl.ay;
      var pulse = 0.5 + 0.5 * Math.sin(t * 2.4 + fl.phase * 3);
      if (hi) {
        ctx.fillStyle = '#E8FF50';
        ctx.globalAlpha = 0.35 + 0.25 * pulse;
        ctx.beginPath(); ctx.arc(fx, fy, 14, 0, 6.283185); ctx.fill();
        ctx.globalAlpha = 0.75 + 0.25 * pulse;
        ctx.beginPath(); ctx.arc(fx, fy, 4, 0, 6.283185); ctx.fill();
      } else {
        var rx = Math.round(fx / 2) * 2, ry = Math.round(fy / 2) * 2;
        ctx.fillStyle = '#E8FF50';
        ctx.globalAlpha = pulse > 0.5 ? 1 : 0.7;
        ctx.fillRect(rx, ry, 6, 6);
        if (pulse > 0.5) {
          ctx.globalAlpha = 0.45;
          ctx.fillRect(rx - 4, ry + 2, 14, 2);
          ctx.fillRect(rx + 2, ry - 4, 2, 14);
        }
      }
    }
    ctx.globalAlpha = 1;
  }

  motifs.jungle = {
    backdrop: ['#04201C', '#0A3A2E', '#12574A', '#1E7F5E'],
    glint: '#E0F060',
    extras: jungleExtras
  };

  // ---- Aztec Temple motif: sun disc (0.1x), stepped pyramids (0.35x), glyph band (0.55x) ----
  var SUN_PAR = 0.1, PYR_PAR = 0.35, GLYPH_PAR = 0.55;
  var PYR_N = 5, PYR_PERIOD = 1100;
  var GLYPH_CELLS = 64; // glyph pattern repeats every 64 cells
  var GLYPH_Y = 124;    // top of the glyph band (logical px, upper third)
  var AZ_PYR_COLS = ['#D8643A', '#B8482A']; // terracotta body, shaded alt tier
  var AZ_PYR_LIT = '#FFB060';
  var AZ_GLYPH_COLS = ['#30E8D0', '#FFD060']; // turquoise, gold
  var pyrs = null;
  // 8x8 glyph bitmaps (bit 7 = leftmost column): fret, square spiral, sun, stair.
  var GLYPHS = [
    [0xFE, 0x02, 0xFA, 0x8A, 0xAA, 0xA2, 0xBE, 0x80],
    [0xFF, 0x81, 0xBD, 0xA5, 0xAD, 0xA1, 0xBF, 0x80],
    [0x3C, 0x42, 0x99, 0xBD, 0xBD, 0x99, 0x42, 0x3C],
    [0x80, 0xC0, 0xE0, 0xF0, 0xF8, 0xFC, 0xFE, 0xFF]
  ];

  function makePyrs() {
    var a = [];
    for (var i = 0; i < PYR_N; i++) {
      a.push({
        x: (i + 0.1 + 0.6 * hash01(i + 801)) * PYR_PERIOD / PYR_N,
        w: 170 + Math.floor(hash01(i + 840) * 90),
        h: 140 + Math.floor(hash01(i + 880) * 40),
        tiers: 3 + (hash01(i + 920) < 0.5 ? 0 : 1),
        c: i & 1
      });
    }
    return a;
  }

  function aztecSun(ctx, st) {
    var hi = st.hi, W = st.W, wrap = W + 300;
    var cx = ((W * 0.7 - st.scrollX * SUN_PAR) % wrap + wrap) % wrap - 150;
    var cy = 190, r = 30, i;
    var pulse = 0.5 + 0.5 * Math.sin(st.time * 0.8);
    if (hi) {
      ctx.fillStyle = '#FFD060';
      ctx.globalAlpha = 0.10 + 0.05 * pulse; ctx.beginPath(); ctx.arc(cx, cy, r * 2.4, 0, 6.283185); ctx.fill();
      ctx.globalAlpha = 0.16 + 0.06 * pulse; ctx.beginPath(); ctx.arc(cx, cy, r * 1.6, 0, 6.283185); ctx.fill();
    }
    // rays
    ctx.strokeStyle = '#FFD060';
    ctx.globalAlpha = 0.6;
    ctx.lineWidth = hi ? 3 : 4;
    ctx.lineCap = 'butt';
    var spin = hi ? st.time * 0.04 : 0;
    ctx.beginPath();
    for (i = 0; i < 12; i++) {
      var an = spin + i * 0.5235988, co = Math.cos(an), si = Math.sin(an);
      var r0 = r + 6, r1 = r + (i & 1 ? 20 : 30);
      var x0 = cx + co * r0, y0 = cy + si * r0, x1 = cx + co * r1, y1 = cy + si * r1;
      if (!hi) { x0 = Math.round(x0 / 4) * 4; y0 = Math.round(y0 / 4) * 4; x1 = Math.round(x1 / 4) * 4; y1 = Math.round(y1 / 4) * 4; }
      ctx.moveTo(x0, y0); ctx.lineTo(x1, y1);
    }
    ctx.stroke();
    // disc
    ctx.fillStyle = '#FFF0B0';
    ctx.globalAlpha = 0.85;
    if (hi) {
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, 6.283185); ctx.fill();
    } else {
      for (var dy = -r; dy < r; dy += 4) {
        var yy = dy + 2, half = Math.round(Math.sqrt(r * r - yy * yy) / 4) * 4;
        ctx.fillRect(Math.round(cx / 4) * 4 - half, Math.round(cy / 4) * 4 + dy, 2 * half, 4);
      }
    }
  }

  function aztecPyramids(ctx, st) {
    if (!pyrs) { pyrs = makePyrs(); }
    var hi = st.hi, S = hi ? 2 : 4, H = st.H - 100; // base sits behind the cave floor
    var off = Math.floor(st.scrollX * PYR_PAR);
    ctx.globalAlpha = 0.78;
    for (var i = 0; i < pyrs.length; i++) {
      var p = pyrs[i];
      var bx = ((p.x - off) % PYR_PERIOD + PYR_PERIOD) % PYR_PERIOD - 260;
      if (bx > st.W + 20) { continue; }
      var th = Math.round(p.h / p.tiers / S) * S, w = Math.round(p.w / S) * S;
      for (var t = 0; t < p.tiers; t++) {
        var tw = Math.round(w * (1 - t * 0.8 / p.tiers) / S) * S;
        var tx = Math.round((bx + (w - tw) / 2) / S) * S, ty = H - (t + 1) * th;
        ctx.fillStyle = AZ_PYR_COLS[(p.c + t) & 1];
        ctx.fillRect(tx, ty, tw, th);
        ctx.fillStyle = AZ_PYR_LIT; // lit top ledge and left edge
        ctx.fillRect(tx, ty, tw, S);
        ctx.fillRect(tx, ty, S, th);
      }
      // little temple cap with a dark doorway on the summit
      var cw = 3 * S * 2, top = H - p.tiers * th, cxm = Math.round((bx + w / 2 - cw / 2) / S) * S;
      ctx.fillStyle = AZ_PYR_COLS[p.c];
      ctx.fillRect(cxm, top - 3 * S, cw, 3 * S);
      ctx.fillStyle = '#2A0F10';
      ctx.fillRect(cxm + S * 2, top - 2 * S, S * 2, 2 * S);
      ctx.fillStyle = AZ_PYR_LIT;
      ctx.fillRect(cxm, top - 3 * S, cw, S);
    }
  }

  function aztecGlyphBand(ctx, st) {
    var hi = st.hi, U = hi ? 3 : 4, cell = 8 * U, W = st.W;
    var off = Math.floor(st.scrollX * GLYPH_PAR);
    var first = Math.floor(off / cell), x0 = first * cell - off;
    // band backing with gold trim
    ctx.globalAlpha = 0.8;
    ctx.fillStyle = '#0B1C24';
    ctx.fillRect(0, GLYPH_Y, W, cell + 4 * U);
    ctx.fillStyle = '#FFD060';
    ctx.fillRect(0, GLYPH_Y, W, U);
    ctx.fillRect(0, GLYPH_Y + cell + 3 * U, W, U);
    ctx.globalAlpha = 0.95;
    for (var k = 0; x0 + k * cell < W; k++) {
      var idx = ((first + k) % GLYPH_CELLS + GLYPH_CELLS) % GLYPH_CELLS;
      var gi = Math.floor(hash01(idx + 1001) * 4) & 3;
      var gx = x0 + k * cell, gy = GLYPH_Y + 2 * U;
      ctx.fillStyle = AZ_GLYPH_COLS[Math.floor(hash01(idx + 1101) * 2) & 1];
      if (hi && gi === 2) { // smooth sun disc
        ctx.beginPath(); ctx.arc(gx + cell / 2, gy + cell / 2, cell * 0.42, 0, 6.283185); ctx.fill();
        ctx.fillStyle = '#0B1C24';
        ctx.beginPath(); ctx.arc(gx + cell / 2, gy + cell / 2, cell * 0.16, 0, 6.283185); ctx.fill();
        continue;
      }
      var g = GLYPHS[gi];
      for (var row = 0; row < 8; row++) {
        var bits = g[row], run = -1;
        for (var col = 0; col <= 8; col++) {
          var on = col < 8 && (bits & (128 >> col)) !== 0;
          if (on && run < 0) { run = col; }
          else if (!on && run >= 0) { ctx.fillRect(gx + run * U, gy + row * U, (col - run) * U, U); run = -1; }
        }
      }
    }
  }

  function aztecExtras(ctx, st) {
    aztecSun(ctx, st);
    aztecPyramids(ctx, st);
    aztecGlyphBand(ctx, st);
    ctx.globalAlpha = 1;
  }

  motifs.aztec = {
    backdrop: ['#100A1E', '#1A1838', '#1F3A4A', '#2E6A6A'],
    glint: '#FFE890',
    extras: aztecExtras
  };

  // ---- Frozen Orient motif: ink-wash ridges (0.2x/0.3x), paper lanterns (0.5x),
  // pagoda silhouettes (0.35x) and drifting snow ----
  var RIDGE_PARS = [0.2, 0.3], RIDGE_PERIOD = 960, RIDGE_COLS = ['#7C94B4', '#9EB4CE'];
  var LAN_N = 7, LAN_PERIOD = 900, LAN_PAR = 0.5;
  var PAG_N = 2, PAG_PERIOD = 1400, PAG_PAR = 0.35;
  var SNOW_N = 26, SNOW_PERIOD = 700;
  var lanterns = null, snow = null;

  function makeLanterns() {
    var a = [];
    for (var i = 0; i < LAN_N; i++) {
      a.push({
        x: (i + 0.2 + 0.6 * hash01(i + 1201)) * LAN_PERIOD / LAN_N,
        cord: 50 + Math.floor(hash01(i + 1240) * 100),
        r: 17 + Math.floor(hash01(i + 1280) * 6),
        phase: hash01(i + 1320) * 6.283
      });
    }
    return a;
  }
  function makeSnow() {
    var a = [];
    for (var i = 0; i < SNOW_N; i++) {
      a.push({
        x: hash01(i + 1401) * SNOW_PERIOD,
        y: hash01(i + 1440) * 400,
        v: 14 + hash01(i + 1480) * 16,
        ax: 6 + hash01(i + 1520) * 10,
        phase: hash01(i + 1560) * 6.283,
        par: 0.25 + hash01(i + 1600) * 0.3
      });
    }
    return a;
  }
  // ridge height at folded coordinate x: sum of sines, quantised to S
  function ridgeH(x, layer, S) {
    var k = layer ? 1.7 : 1;
    var h = 0.5 + 0.28 * Math.sin(x * 0.0131 * k + layer * 2) + 0.17 * Math.sin(x * 0.0337 * k + 1 + layer) + 0.05 * Math.sin(x * 0.083 * k);
    return Math.round((70 + h * (layer ? 120 : 150)) / S) * S;
  }

  function orientRidges(ctx, st) {
    var hi = st.hi, S = hi ? 2 : 4, W = st.W, H = st.H, step = hi ? 6 : 16;
    for (var l = 0; l < 2; l++) {
      var off = Math.floor(st.scrollX * RIDGE_PARS[l]);
      off = ((off % (2 * RIDGE_PERIOD)) + 2 * RIDGE_PERIOD) % (2 * RIDGE_PERIOD);
      ctx.globalAlpha = l ? 0.7 : 0.62;
      ctx.fillStyle = RIDGE_COLS[l];
      for (var x = 0; x < W; x += step) {
        // mirror-fold the coordinate so the ridge is continuous across the wrap
        var u = (x + off) % (2 * RIDGE_PERIOD);
        if (u > RIDGE_PERIOD) { u = 2 * RIDGE_PERIOD - u; }
        var h = ridgeH(u, l, S);
        ctx.fillRect(x, H - 40 - h, step, h);
      }
      if (l === 0) { // mist band between the layers
        ctx.globalAlpha = hi ? 0.32 : 0.4;
        ctx.fillStyle = '#E4EEF8';
        ctx.fillRect(0, H - 150, W, hi ? 26 : 24);
      }
    }
  }

  function orientPagoda(ctx, st) {
    var hi = st.hi, S = hi ? 2 : 4, H = st.H, W = st.W;
    var off = Math.floor(st.scrollX * PAG_PAR);
    for (var i = 0; i < PAG_N; i++) {
      var bx = ((i * 0.5 + 0.18 + 0.1 * hash01(i + 1701)) * PAG_PERIOD - off) % PAG_PERIOD;
      bx = (bx + PAG_PERIOD) % PAG_PERIOD - 200;
      if (bx > W + 40) { continue; }
      var tiers = 3 + (hash01(i + 1740) < 0.5 ? 1 : 0);
      var cx = Math.round(bx / S) * S, base = H - 130, tw = 64, th = 22;
      ctx.globalAlpha = 0.82;
      for (var t = 0; t < tiers; t++) {
        var w = Math.round((tw - t * 9) / S) * S, y = base - (t + 1) * (th + 4);
        ctx.fillStyle = '#34486A';
        ctx.fillRect(cx - w / 2, y + 8, w, th - 8);          // body
        ctx.fillStyle = '#5A7096';
        ctx.fillRect(cx - w / 2 + S, y + 8, S * 2, th - 8);  // lit post
        var ew = w + 30; // upturned eave: wide slab plus raised tips
        ctx.fillStyle = '#243656';
        ctx.fillRect(cx - ew / 2, y + 4, ew, 6);
        ctx.fillRect(cx - ew / 2 - 6, y, 10, 6);
        ctx.fillRect(cx + ew / 2 - 4, y, 10, 6);
        ctx.fillRect(cx - ew / 2 - 10, y - 4, 6, 6);
        ctx.fillRect(cx + ew / 2 + 4, y - 4, 6, 6);
      }
      var topY = base - tiers * (th + 4);
      ctx.fillStyle = '#243656';
      ctx.fillRect(cx - S, topY - 24, S * 2, 26); // spire
      ctx.fillRect(cx - 6, topY - 10, 12, 4);
      ctx.fillStyle = '#34486A';
      ctx.fillRect(cx - 40, base, 80, 18);         // plinth
    }
  }

  function orientLanterns(ctx, st) {
    if (!lanterns) { lanterns = makeLanterns(); }
    var hi = st.hi, S = hi ? 1 : 4, t = st.time;
    var off = Math.floor(st.scrollX * LAN_PAR);
    ctx.lineWidth = hi ? 2 : 4;
    for (var i = 0; i < lanterns.length; i++) {
      var L = lanterns[i];
      var bx = ((L.x - off) % LAN_PERIOD + LAN_PERIOD) % LAN_PERIOD - 60;
      if (bx > st.W + 60) { continue; }
      var sw = Math.sin(t * 0.8 + L.phase) * 4;
      var sx = bx + sw, cy = L.cord + L.r, r = L.r;
      var gx = Math.round(sx / S) * S;
      ctx.globalAlpha = 0.8; // cord
      ctx.strokeStyle = '#E8C060';
      ctx.beginPath(); ctx.moveTo(Math.round(bx / S) * S, 0); ctx.lineTo(gx, L.cord); ctx.stroke();
      if (hi) {
        ctx.fillStyle = '#FF8A30';
        ctx.globalAlpha = 0.16; ctx.beginPath(); ctx.arc(sx, cy, r * 2.6, 0, 6.283185); ctx.fill();
        ctx.globalAlpha = 0.22; ctx.beginPath(); ctx.arc(sx, cy, r * 1.7, 0, 6.283185); ctx.fill();
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = '#E02830';
        ctx.beginPath(); ctx.ellipse(sx, cy, r * 0.9, r, 0, 0, 6.283185); ctx.fill();
        ctx.fillStyle = '#FF7050';
        ctx.globalAlpha = 0.7;
        ctx.beginPath(); ctx.ellipse(sx - r * 0.25, cy - r * 0.15, r * 0.35, r * 0.6, 0, 0, 6.283185); ctx.fill();
        ctx.globalAlpha = 0.9;
        ctx.strokeStyle = '#A01820';
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(sx - r * 0.9, cy); ctx.lineTo(sx + r * 0.9, cy); ctx.stroke();
        ctx.lineWidth = 2;
      } else {
        var rr = Math.round(r / 4) * 4, w = rr * 2 - 8;
        ctx.fillStyle = '#E02830';
        ctx.globalAlpha = 0.95;
        ctx.fillRect(gx - w / 2 + 4, cy - rr, w - 8, 4);
        ctx.fillRect(gx - w / 2, cy - rr + 4, w, rr * 2 - 8);
        ctx.fillRect(gx - w / 2 + 4, cy + rr - 4, w - 8, 4);
        ctx.fillStyle = '#FF7050';
        ctx.fillRect(gx - w / 2 + 4, cy - rr + 8, 4, rr * 2 - 16);
        ctx.fillStyle = '#A01820';
        ctx.fillRect(gx - w / 2, cy - 2, w, 4);
      }
      ctx.globalAlpha = 0.95; // gold caps and tassel
      ctx.fillStyle = '#F0C040';
      var cw = Math.round(r * 0.9 / S) * S;
      ctx.fillRect(gx - cw / 2, Math.round((cy - r - 4) / S) * S, cw, 4);
      ctx.fillRect(gx - cw / 2, Math.round((cy + r) / S) * S, cw, 4);
      var tx = gx + Math.round(sw * 0.4 / S) * S;
      ctx.fillRect(tx - 1, Math.round((cy + r + 4) / S) * S, hi ? 2 : 4, 14);
      ctx.fillRect(tx - (hi ? 3 : 4), Math.round((cy + r + 18) / S) * S, hi ? 6 : 12, 6);
    }
  }

  function orientSnow(ctx, st) {
    if (!snow) { snow = makeSnow(); }
    var hi = st.hi, t = st.time, H = st.H;
    ctx.fillStyle = '#FFFFFF';
    ctx.globalAlpha = 0.85;
    var sz = hi ? 2.5 : 4;
    for (var i = 0; i < snow.length; i++) {
      var f = snow[i];
      var x = ((f.x - st.scrollX * f.par + Math.sin(t * 0.7 + f.phase) * f.ax) % SNOW_PERIOD + SNOW_PERIOD) % SNOW_PERIOD;
      x = x * (st.W + 40) / SNOW_PERIOD - 20;
      var y = (f.y + t * f.v) % (H + 20) - 10;
      if (hi) { ctx.beginPath(); ctx.arc(x, y, sz * 0.6, 0, 6.283185); ctx.fill(); }
      else { ctx.fillRect(Math.round(x / 4) * 4, Math.round(y / 4) * 4, sz, sz); }
    }
  }

  function orientExtras(ctx, st) {
    orientRidges(ctx, st);
    orientPagoda(ctx, st);
    orientLanterns(ctx, st);
    orientSnow(ctx, st);
    ctx.globalAlpha = 1;
  }

  motifs.orient = {
    backdrop: ['#060A1C', '#0E1834', '#1C2E55', '#34527E'],
    glint: '#DCEEFF',
    extras: orientExtras
  };

  // ---- Void and Abyss motif: planet (0.05x), nebulae (0.15x), 3 star layers
  // (0.1/0.2/0.35x) and ruined castle silhouettes (0.3x). High alpha, vivid
  // colours: the lamp overlay dims everything away from the ship. ----
  var STAR_PARS = [0.1, 0.2, 0.35], STAR_COUNTS = [30, 26, 22], STAR_PERIOD = 960;
  var STAR_COLS = ['#FFFFFF', '#40F0FF', '#FF4FE0'];
  var NEB_N = 3, NEB_PERIOD = 1300, NEB_PAR = 0.15;
  var CAS_N = 4, CAS_PERIOD = 1600, CAS_PAR = 0.3;
  var PLANET_PERIOD = 1100, PLANET_PAR = 0.05;
  var stars = null, nebulae = null;

  function makeStars() {
    var a = [], k = 0;
    for (var l = 0; l < 3; l++) {
      for (var i = 0; i < STAR_COUNTS[l]; i++, k++) {
        a.push({
          layer: l,
          x: hash01(k + 2001) * STAR_PERIOD,
          y: hash01(k + 2101) * 0.9,
          c: Math.floor(hash01(k + 2201) * 3),
          rate: 1.2 + hash01(k + 2301) * 2.4,
          phase: hash01(k + 2401) * 6.283,
          sparkle: l === 2 && i < 5
        });
      }
    }
    return a;
  }
  function makeNebulae() {
    var a = [];
    for (var i = 0; i < NEB_N; i++) {
      a.push({
        x: (i + 0.2 + 0.6 * hash01(i + 2501)) * NEB_PERIOD / NEB_N,
        y: 60 + hash01(i + 2540) * 160,
        rx: 110 + hash01(i + 2580) * 70,
        ry: 44 + hash01(i + 2620) * 30,
        drift: 6 + hash01(i + 2660) * 6,
        c: i % 2
      });
    }
    return a;
  }

  function voidPlanet(ctx, st) {
    var hi = st.hi, S = hi ? 1 : 4, W = st.W, t = st.time;
    var off = Math.floor(st.scrollX * PLANET_PAR);
    var cx = (((780 - off) % PLANET_PERIOD) + PLANET_PERIOD) % PLANET_PERIOD - 200;
    if (cx > W + 160) { return; }
    var cy = 92, r = 44, TAU = 6.283185, i;
    cx = Math.round(cx / S) * S;
    if (hi) {
      ctx.lineWidth = 6;
      ctx.strokeStyle = '#FF8AE0';
      ctx.globalAlpha = 0.75;
      ctx.beginPath(); ctx.ellipse(cx, cy, r * 1.9, r * 0.45, -0.35, Math.PI, TAU); ctx.stroke(); // back half
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#4B2A96';
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.fill();
      ctx.fillStyle = '#7C4CD0';
      ctx.beginPath(); ctx.arc(cx - r * 0.12, cy - r * 0.12, r * 0.86, 0, TAU); ctx.fill();
      ctx.fillStyle = '#B07CFF';
      ctx.beginPath(); ctx.arc(cx - r * 0.26, cy - r * 0.26, r * 0.55, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.95;
      ctx.beginPath(); ctx.ellipse(cx, cy, r * 1.9, r * 0.45, -0.35, 0, Math.PI); ctx.stroke(); // front half
      ctx.lineWidth = 2;
      return;
    }
    // retro: ring as snapped 4px blocks (back half), disc rows, ring front half
    ctx.fillStyle = '#FF8AE0';
    ctx.globalAlpha = 0.8;
    for (i = 0; i < 16; i++) {
      var a = Math.PI + (i / 15) * Math.PI;
      ctx.fillRect(Math.round((cx + Math.cos(a) * r * 1.9 * 0.9397 + Math.sin(a) * r * 0.45 * 0.3429) / 4) * 4,
        Math.round((cy - Math.cos(a) * r * 1.9 * 0.3429 + Math.sin(a) * r * 0.45 * 0.9397) / 4) * 4, 4, 4);
    }
    ctx.globalAlpha = 1;
    for (var dy = -r; dy < r; dy += 4) {
      var hw = Math.round(Math.sqrt(r * r - (dy + 2) * (dy + 2)) / 4) * 4;
      ctx.fillStyle = '#4B2A96';
      ctx.fillRect(cx - hw, cy + dy, hw * 2, 4);
      ctx.fillStyle = '#7C4CD0';
      ctx.fillRect(cx - hw, cy + dy, Math.round(hw * 1.3 / 4) * 4, 4);
      if (dy > -r * 0.7 && dy < r * 0.1) {
        ctx.fillStyle = '#B07CFF';
        ctx.fillRect(cx - hw + 4, cy + dy, Math.round(hw * 0.6 / 4) * 4, 4);
      }
    }
    ctx.fillStyle = '#FF8AE0';
    ctx.globalAlpha = 0.95;
    for (i = 0; i < 16; i++) {
      var b = (i / 15) * Math.PI;
      ctx.fillRect(Math.round((cx + Math.cos(b) * r * 1.9 * 0.9397 + Math.sin(b) * r * 0.45 * 0.3429) / 4) * 4,
        Math.round((cy - Math.cos(b) * r * 1.9 * 0.3429 + Math.sin(b) * r * 0.45 * 0.9397) / 4) * 4, 4, 4);
    }
  }

  function voidNebulae(ctx, st) {
    if (!nebulae) { nebulae = makeNebulae(); }
    var hi = st.hi, W = st.W, t = st.time, off = Math.floor(st.scrollX * NEB_PAR);
    for (var i = 0; i < nebulae.length; i++) {
      var n = nebulae[i];
      var cx = (((n.x - off + t * n.drift) % NEB_PERIOD) + NEB_PERIOD) % NEB_PERIOD - 300;
      if (cx > W + n.rx) { continue; }
      var col = n.c ? '#C02AA8' : '#3A3AE0', inner = n.c ? '#FF4FD0' : '#5A6CFF';
      if (hi) {
        ctx.fillStyle = col;
        ctx.globalAlpha = 0.16;
        ctx.beginPath(); ctx.ellipse(cx, n.y, n.rx, n.ry, 0, 0, 6.283185); ctx.fill();
        ctx.beginPath(); ctx.ellipse(cx, n.y, n.rx * 0.72, n.ry * 0.72, 0, 0, 6.283185); ctx.fill();
        ctx.fillStyle = inner;
        ctx.globalAlpha = 0.15;
        ctx.beginPath(); ctx.ellipse(cx + n.rx * 0.1, n.y, n.rx * 0.42, n.ry * 0.45, 0, 0, 6.283185); ctx.fill();
      } else {
        var y0 = Math.round((n.y - n.ry) / 8) * 8, rows = Math.round(n.ry * 2 / 8);
        for (var r = 0; r < rows; r++) {
          var v = (r + 0.5) / rows * 2 - 1, chord = Math.sqrt(1 - v * v);
          var hw = Math.round(n.rx * chord / 8) * 8, stag = (r & 1) ? 8 : 0;
          ctx.fillStyle = col;
          ctx.globalAlpha = 0.5;
          ctx.fillRect(Math.round(cx / 8) * 8 - hw + stag, y0 + r * 8, hw * 2 - stag, 8);
          var iw = Math.round(hw * 0.5 / 8) * 8;
          if (iw > 0) {
            ctx.fillStyle = inner;
            ctx.globalAlpha = 0.35;
            ctx.fillRect(Math.round(cx / 8) * 8 - iw + stag, y0 + r * 8, iw * 2 - stag, 8);
          }
        }
      }
    }
  }

  function voidStars(ctx, st) {
    if (!stars) { stars = makeStars(); }
    var hi = st.hi, W = st.W, H = st.H, t = st.time;
    for (var i = 0; i < stars.length; i++) {
      var s = stars[i];
      var x = ((s.x - st.scrollX * STAR_PARS[s.layer]) % STAR_PERIOD + STAR_PERIOD) % STAR_PERIOD;
      x = x * W / STAR_PERIOD;
      var y = s.y * H, tw = 0.5 + 0.5 * Math.sin(t * s.rate + s.phase);
      var sz = hi ? (s.layer === 2 ? 3 : 2) : (s.layer === 0 ? 2 : 4);
      ctx.fillStyle = s.sparkle ? '#FFFFFF' : STAR_COLS[s.c];
      ctx.globalAlpha = 0.72 + 0.28 * tw;
      if (hi) { x = Math.round(x); y = Math.round(y); } else { x = Math.round(x / 2) * 2; y = Math.round(y / 2) * 2; }
      ctx.fillRect(x, y, sz, sz);
      if (s.sparkle) {
        var arm = (hi ? 6 : 8) + Math.round(tw * (hi ? 3 : 4) / 2) * 2;
        ctx.fillStyle = STAR_COLS[1 + (i & 1)];
        ctx.globalAlpha = 0.9;
        ctx.fillRect(x - arm, y + (hi ? 1 : 0), arm * 2 + sz, hi ? 1 : 2);
        ctx.fillRect(x + (hi ? 1 : 1), y - arm, hi ? 1 : 2, arm * 2 + sz);
      }
    }
  }

  function voidCastles(ctx, st) {
    var hi = st.hi, S = hi ? 2 : 4, H = st.H, W = st.W, t = st.time;
    var off = Math.floor(st.scrollX * CAS_PAR);
    for (var i = 0; i < CAS_N; i++) {
      var bx = ((i * 0.25 + 0.05 + 0.12 * hash01(i + 3001)) * CAS_PERIOD - off) % CAS_PERIOD;
      bx = (bx + CAS_PERIOD) % CAS_PERIOD - 220;
      if (bx > W + 40) { continue; }
      var x0 = Math.round(bx / S) * S;
      var th = Math.round((110 + hash01(i + 3040) * 70) / S) * S, tw = 40 + (i & 1) * 8;
      var t2h = Math.round(th * 0.62 / S) * S, t2x = x0 + 112, t2w = 32;
      var wallh = Math.round(th * 0.38 / S) * S;
      var by = H;
      ctx.globalAlpha = 0.96;
      ctx.fillStyle = '#12104A';
      ctx.fillRect(x0, by - th, tw, th);                       // main tower
      for (var m = 0; m < tw; m += 16) { ctx.fillRect(x0 + m, by - th - 8, 8, 8); } // crenellations
      ctx.fillRect(x0 + tw, by - wallh, 112 - tw, wallh);       // wall (arch gap drawn as dark pier cut)
      ctx.fillRect(t2x, by - t2h, t2w, t2h);                   // second tower, broken top
      ctx.fillRect(t2x, by - t2h - 8, 8, 8);
      ctx.fillRect(t2x + 16, by - t2h - 16, 8, 16);
      ctx.fillRect(t2x + 24, by - t2h - 8, 8, 8);
      // broken arch above the wall: left half only
      ctx.fillStyle = '#1C1870';
      var ax = x0 + tw + 8, aw = 112 - tw - 16;
      if (hi) {
        ctx.lineWidth = 6;
        ctx.strokeStyle = '#1C1870';
        ctx.beginPath(); ctx.arc(ax + aw / 2, by - wallh, aw / 2, Math.PI, Math.PI * 1.6); ctx.stroke();
        ctx.lineWidth = 2;
      } else {
        ctx.fillRect(ax, by - wallh - 8, 8, 8);
        ctx.fillRect(ax + 4, by - wallh - 16, 8, 8);
        ctx.fillRect(ax + 12, by - wallh - 20, 8, 4);
      }
      ctx.fillRect(ax, by - wallh - 12, 6, 12);                // arch pier stub
      // faint violet rim light on the left edges and tower tops
      ctx.fillStyle = '#9A5CFF';
      ctx.globalAlpha = 0.6;
      ctx.fillRect(x0, by - th, S, th);
      ctx.fillRect(x0, by - th - 8, tw, 2);
      ctx.fillRect(t2x, by - t2h, S, t2h);
      // lit windows, warm yellow (slow flicker on one)
      ctx.fillStyle = '#FFD24A';
      ctx.globalAlpha = 0.95;
      ctx.fillRect(x0 + 12, by - th + 28, 8, 14);
      if (i !== 1) { ctx.fillRect(x0 + tw - 18, by - th + 64, 8, 14); }
      ctx.globalAlpha = 0.7 + 0.25 * Math.sin(t * 2.1 + i);
      ctx.fillRect(t2x + 12, by - t2h + 22, 8, 14);
    }
  }

  function voidExtras(ctx, st) {
    voidPlanet(ctx, st);
    voidNebulae(ctx, st);
    voidStars(ctx, st);
    voidCastles(ctx, st);
    ctx.globalAlpha = 1;
  }

  motifs.void = {
    backdrop: ['#03030A', '#080820', '#10104A', '#1C1C70'],
    glint: '#9A8CFF',
    extras: voidExtras
  };

  Game.Background = {
    render: render,
    motifs: motifs,
    registerMotif: registerMotif,
    activeMotif: activeMotifId,
    layerOffset: layerOffset,
    FAR: FAR, MID: MID, GLINT: GLINT,
    TILE_W: TW0,
    _tileWidth: function () { ensure(); return TW; }
  };
})();
