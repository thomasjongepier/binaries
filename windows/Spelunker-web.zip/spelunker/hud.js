// Spelunker - HUD: bevelled pixel bars, ship-icon lives, ammo pips, animated
// score, measure progress bar. All text goes through Game.Font and all colours
// come from Game.Theme ramps. Drawn in 640x400 logical coordinates; every
// rectangle is snapped to the 2-logical-px buffer grid.
(function () {
  'use strict';
  window.Game = window.Game || {};

  var G = 2;                 // logical px per buffer px
  var SCORE_RATE = 300;      // points per second for the count-up
  var MAX_STEP_SECONDS = 0.1; // clamp so a stalled tab does not jump
  var PIP_CAP = 14;          // starting ammo; above this show text
  var LIFE_ICON_CAP = 5;
  var BAR_INNER_W = 60;      // buffer px
  var BAR_INNER_H = 4;
  var BAR_W = (BAR_INNER_W + 4) * G;  // frame + bevel on each side
  var BAR_H = (BAR_INNER_H + 4) * G;
  var BLINK_PERIOD_MS = 250;
  var LOW_FRACTION = 0.25;

  // ---- score count-up (pure helpers + one tiny state) ----
  var shown = 0;
  var lastMs = null;

  // Advance `current` toward `target` by rate*dt; never passes target.
  // A target below current (new run) snaps immediately.
  function stepScore(current, target, dt) {
    if (!(target > current)) { return target; }
    var next = current + SCORE_RATE * Math.max(0, dt);
    return next >= target ? target : next;
  }

  // Display value for this frame. nowMs is injectable for tests.
  function scoreFor(target, nowMs) {
    var now = (typeof nowMs === 'number') ? nowMs : Date.now();
    var dt = lastMs === null ? 0 : Math.min(MAX_STEP_SECONDS, Math.max(0, (now - lastMs) / 1000));
    lastMs = now;
    shown = stepScore(shown, target, dt);
    return Math.floor(shown + 1e-9) >= target ? target : Math.floor(shown);
  }

  function resetScore() { shown = 0; lastMs = null; }

  // ---- ship icon: 8x5 buffer px, same ramps as the ship ----
  var ICON_W = 8, ICON_H = 5;
  var SHIP_ICON = [
    '.dmm....',
    'odmmmkc.',
    'oddmmmll',
    'odmmmkc.',
    '.dmm....'
  ];
  if (window.Game.Sprite && window.Game.Sprite.define) {
    try {
      window.Game.Sprite.define('ship-icon', {
        w: ICON_W, h: ICON_H,
        map: { o: 'hull:0', d: 'hull:1', m: 'hull:2', l: 'hull:3', k: 'cockpit:0', c: 'cockpit:1' },
        frames: [SHIP_ICON]
      });
    } catch (e) {
      if (typeof console !== 'undefined' && console.warn) { console.warn('Hud: ship-icon not defined', e); }
    }
  }

  // ---- drawing helpers ----
  function ramp(name) {
    var t = window.Game.Theme;
    var r = t && t.ramp ? t.ramp(name) : null;
    return r && r.length ? r : ['#000000', '#555555', '#AAAAAA', '#FFFFFF'];
  }
  function at(r, i) { return r[Math.min(i, r.length - 1)]; }

  function snap(v) {
    var P = window.Game.Pixel;
    return (P && P.snap) ? P.snap(v) : Math.round(v / G) * G;
  }

  function rect(ctx, color, x, y, w, h) {
    ctx.fillStyle = color;
    ctx.fillRect(snap(x), snap(y), w, h);
  }

  function text(ctx, s, x, y, align, color) {
    var F = window.Game.Font;
    if (F && F.draw) {
      F.draw(ctx, s, x, y, { role: 'hud', css: 'bold 14px monospace', color: color, align: align || 'left', baseline: 'top' });
    }
  }

  // Bevelled bar. (x, y) is the top-left of the outer frame, BAR_W x BAR_H.
  // frac 0..1 fills left to right with three bands: light, body, dark.
  function drawBar(ctx, x, y, frac, rampName, hidden) {
    var ui = ramp('ui');
    var back = ramp('backdrop');
    var w = BAR_W, h = BAR_H;
    rect(ctx, at(ui, 0), x, y, w, h);                 // 1 px frame
    rect(ctx, at(ui, 3), x + G, y + G, w - 2 * G, G); // bevel top
    rect(ctx, at(ui, 3), x + G, y + G, G, h - 2 * G); // bevel left
    rect(ctx, at(ui, 0), x + G, y + h - 2 * G, w - 2 * G, G); // bevel bottom
    rect(ctx, at(ui, 0), x + w - 2 * G, y + G, G, h - 2 * G); // bevel right
    var ix = x + 2 * G, iy = y + 2 * G;
    var iw = BAR_INNER_W * G, ih = BAR_INNER_H * G;
    rect(ctx, at(back, 1), ix, iy, iw, ih);
    var f = Math.max(0, Math.min(1, +frac || 0));
    var fw = Math.round(f * BAR_INNER_W) * G;
    if (fw <= 0 || hidden) { return; }
    var r = ramp(rampName);
    rect(ctx, at(r, 3), ix, iy, fw, G);                 // light top row
    rect(ctx, at(r, 2), ix, iy + G, fw, ih - 2 * G);    // mid body
    rect(ctx, at(r, 1), ix, iy + ih - G, fw, G);        // dark bottom row
  }

  function blinkOff(nowMs) {
    var now = (typeof nowMs === 'number') ? nowMs : Date.now();
    return Math.floor(now / (BLINK_PERIOD_MS / 2)) % 2 === 1;
  }

  function drawPips(ctx, ammo, cx, y) {
    var ui = ramp('ui');
    var ar = ramp('ammo');
    var pw = 2 * G, ph = 3 * G, stride = 3 * G;
    if (ammo > PIP_CAP) {
      var label = 'x' + ammo;
      var F = window.Game.Font;
      var tw = (F && F.measure) ? F.measure(label, { role: 'hud' }) : label.length * 12;
      var total = pw + G * 2 + tw;
      var x0 = cx - total / 2;
      rect(ctx, at(ar, 2), x0, y, pw, ph);
      text(ctx, label, x0 + pw + G * 2, y - G, 'left', at(ui, 3));
      return;
    }
    var width = PIP_CAP * stride - G;
    var x = cx - width / 2;
    for (var i = 0; i < PIP_CAP; i++) {
      var on = i < ammo;
      rect(ctx, on ? at(ar, 2) : at(ui, 0), x + i * stride, y, pw, ph);
      if (on) { rect(ctx, at(ar, 3), x + i * stride, y, pw, G); }
    }
  }

  function drawLives(ctx, lives, rightX, y) {
    var S = window.Game.Sprite;
    var ui = ramp('ui');
    var iw = ICON_W * G, stride = iw + 2 * G;
    var n = Math.max(0, lives);
    if (n > LIFE_ICON_CAP) {
      var label = 'x' + n;
      var F = window.Game.Font;
      var tw = (F && F.measure) ? F.measure(label, { role: 'hud' }) : label.length * 12;
      text(ctx, label, rightX, y - G, 'right', at(ui, 3));
      if (S && S.draw) { S.draw(ctx, 'ship-icon', 0, rightX - tw - 2 * G - iw / 2, y + ICON_H * G / 2); }
      return;
    }
    for (var i = 0; i < n; i++) {
      if (S && S.draw) { S.draw(ctx, 'ship-icon', 0, rightX - iw / 2 - i * stride, y + ICON_H * G / 2); }
    }
  }

  // Campaign level readout (top centre, under the ammo pips): 'LV n/N', the
  // level name dimmer beside it, and a thin progress bar in the biome colour.
  // Draws nothing in endless mode or when the level engine is absent.
  var LEVEL_BAR_W = 100 * G;
  var LEVEL_TEXT_H = 14, LEVEL_BAR_DY = LEVEL_TEXT_H + 6; // bar sits 6px under the text bottom
  function drawLevel(ctx, W, y, maxRight) {
    var L = window.Game.Levels;
    if (!L || !L.campaignActive || !L.campaignActive()) { return; }
    var cur = L.current ? L.current() : null;
    var n = L.level ? L.level() : null;
    if (n === null || n === undefined) { return; }
    var ui = ramp('ui');
    var F = window.Game.Font;
    var label = 'LV ' + n + '/' + (L.count ? L.count() : n);
    var name = cur && cur.name ? String(cur.name).toUpperCase() : '';
    var lw = (F && F.measure) ? F.measure(label, { role: 'hud' }) : label.length * 12;
    var gap = 3 * G;
    var nw = name ? ((F && F.measure) ? F.measure(name, { role: 'hud' }) : name.length * 12) : 0;
    var total = lw + (name ? gap + nw : 0);
    if (name && W / 2 + total / 2 > maxRight) { name = ''; total = lw; }
    var x0 = W / 2 - total / 2;
    text(ctx, label, x0, y, 'left', at(ui, 3));
    if (name) { text(ctx, name, x0 + lw + gap, y, 'left', at(ui, 2)); }
    var by = y + LEVEL_BAR_DY;
    var bx = W / 2 - LEVEL_BAR_W / 2;
    var B = window.Game.Biomes;
    var color = (B && B.bannerColor && B.bannerColor()) || YELLOW();
    rect(ctx, at(ui, 0), bx, by, LEVEL_BAR_W, G * 2);
    var p = L.progress ? Math.max(0, Math.min(1, +L.progress() || 0)) : 0;
    var fw = Math.round(p * (LEVEL_BAR_W / G)) * G;
    if (fw > 0) { rect(ctx, color, bx, by, fw, G * 2); }
  }
  function YELLOW() {
    var t = window.Game.Theme;
    var p = t && t.get ? t.get() : null;
    return (p && (p.YELLOW || p.yellow)) || '#FFD84A';
  }

  // d: { score, combo, lives, ammo, shield, maxShield, stamina, maxStamina,
  //      measureProgress }
  function draw(ctx, d, W, H, nowMs) {
    var ui = ramp('ui');
    var txt = at(ui, 3);
    var margin = 8;

    // Score (top left), combo below.
    text(ctx, 'SCORE: ' + scoreFor(d.score || 0, nowMs), margin, margin, 'left', txt);
    if (d.combo >= 2) { text(ctx, 'COMBO x' + d.combo, margin, margin + 18, 'left', txt); }

    // Ammo pips (top centre).
    drawPips(ctx, d.ammo || 0, W / 2, margin + 4);

    // Level readout must stay left of the shield/stamina numbers (3 digits max).
    var F = window.Game.Font;
    var numW = (F && F.measure) ? F.measure('000', { role: 'hud' }) : 36;
    drawLevel(ctx, W, margin + 22, W - margin - BAR_W - 4 - numW - 8 - 14);

    // Right column: lives, shield bar, stamina bar. Number beside each bar.
    var rx = W - margin;
    drawLives(ctx, d.lives || 0, rx, margin);
    var barX = rx - BAR_W;
    var rowY = margin + 16;
    var shieldFrac = d.maxShield > 0 ? d.shield / d.maxShield : 0;
    var low = shieldFrac < LOW_FRACTION;
    drawBar(ctx, barX, rowY, shieldFrac, low ? 'hazardCollapse' : 'shield', low && blinkOff(nowMs));
    text(ctx, String(Math.round(d.shield || 0)), barX - 4, rowY + (BAR_H - 14) / 2, 'right', low ? at(ramp('hazardCollapse'), 2) : txt);
    var rowY2 = rowY + BAR_H + 4;
    var stamFrac = d.maxStamina > 0 ? d.stamina / d.maxStamina : 0;
    drawBar(ctx, barX, rowY2, stamFrac, 'cockpit', false);
    text(ctx, String(Math.round(d.stamina || 0)), barX - 4, rowY2 + (BAR_H - 14) / 2, 'right', txt);

    // 1 buffer px music progress bar (hidden in the gap between songs).
    if (d.measureProgress !== null && d.measureProgress !== undefined) {
      var bw = 100 * G, by = H - margin - G;
      var bx = W / 2 - bw / 2;
      rect(ctx, at(ui, 0), bx, by, bw, G);
      var fw = Math.round(Math.max(0, Math.min(1, d.measureProgress)) * 100) * G;
      if (fw > 0) { rect(ctx, at(ui, 2), bx, by, fw, G); }
    }
  }

  window.Game.Hud = {
    BAR_W: BAR_W,
    BAR_H: BAR_H,
    LEVEL_BAR_DY: LEVEL_BAR_DY,
    LEVEL_TEXT_H: LEVEL_TEXT_H,
    stepScore: stepScore,
    scoreFor: scoreFor,
    resetScore: resetScore,
    drawBar: drawBar,
    draw: draw
  };
})();
