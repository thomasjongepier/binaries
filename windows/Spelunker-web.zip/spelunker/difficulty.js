// Spelunker - difficulty ramp. Pure level term from distance points; callers
// read it through getters each call so the ramp applies live.
(function () {
  'use strict';
  window.Game = window.Game || {};

  var RAMP_DISTANCE = 3000; // distance points for the ramp to reach full level

  // 0..1, linear in distance points, clamped. Bad input gives 0.
  function level(distancePoints) {
    if (typeof distancePoints !== 'number' || !isFinite(distancePoints)) return 0;
    var l = distancePoints / RAMP_DISTANCE;
    return l < 0 ? 0 : (l > 1 ? 1 : l);
  }

  // Level for the current run, from the Score module (0 if unavailable).
  function current() {
    var S = window.Game.Score;
    return level(S && typeof S.distancePoints === 'number' ? S.distancePoints : 0);
  }

  // Player-selected preset (Game.Settings 'difficulty'), applied on top of the
  // ramp. Normal multiplies by exactly 1, so it matches the pre-preset game.
  //   livesDelta: added to the base lives (collision.js DEFAULT_LIVES)
  //   damage:     shield damage multiplier
  //   gap:        multiplier on the cave gap min and max
  var PRESETS = {
    easy:   { livesDelta: 2, damage: 0.6,  gap: 1.1 },
    normal: { livesDelta: 0, damage: 1,    gap: 1 },
    hard:   { livesDelta: 0, damage: 1.25, gap: 0.92 }
  };

  function presetName() {
    var S = window.Game.Settings;
    var n = S && S.get ? S.get('difficulty') : 'normal';
    return Object.prototype.hasOwnProperty.call(PRESETS, n) ? n : 'normal';
  }

  function preset() { return PRESETS[presetName()]; }

  // Campaign level knobs apply only when no explicit level was passed.
  function campaignLevel() {
    var G = window.Game;
    if (G.Mode === 'campaign' && G.Levels && G.Levels.campaignActive && G.Levels.campaignActive()) {
      return G.Levels.current();
    }
    return null;
  }

  window.Game.Difficulty = {
    PRESETS: PRESETS,
    presetName: presetName,
    livesFor: function (base) { return base + preset().livesDelta; },
    damageFactor: function () { return preset().damage; },
    gapPresetFactor: function () { return preset().gap; },
    level: level,
    current: current,
    RAMP_DISTANCE: RAMP_DISTANCE,
    scrollFactor: function (l) {
      var c = l === undefined ? campaignLevel() : null;
      if (c) return c.scroll;
      return 1 + 0.3 * (l === undefined ? current() : l); },
    gapFactor: function (l) {
      var c = l === undefined ? campaignLevel() : null;
      if (c) return c.gap * preset().gap;
      return (1 - 0.15 * (l === undefined ? current() : l)) * preset().gap; },
    spawnFactor: function (l) {
      var c = l === undefined ? campaignLevel() : null;
      if (c) return c.spawn;
      return 1 - 0.25 * (l === undefined ? current() : l); }
  };
})();
