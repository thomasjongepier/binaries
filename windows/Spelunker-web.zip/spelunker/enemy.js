// Spelunker - enemy entities.
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so main.js can call Enemies.update/render each
// frame, following the same pattern as cave.js/ship.js/collision.js/
// projectile.js.
//
// Enemies are tracked in WORLD-space (worldX, y), unlike projectiles which
// are tracked in screen-space (see projectile.js's header comment). This
// matches cave.js's convention (world-x = scrollX + screen-x) and makes it
// natural to spawn an enemy ahead of the camera and let it "move left" for
// free as the camera scrolls, without needing per-frame velocity math.
//
// Ship-vs-enemy collision: handled in collision.js (see the comment there)
// rather than here, so all "what counts as a crash"/lives/invulnerability
// logic stays centralized in a single owner.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('enemy.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;
  function palette() { return Game.Theme.get(); }

  // ---- Tuning constants ----
  var SPAWN_INTERVAL_MIN = 2; // seconds
  var SPAWN_INTERVAL_MAX = 4; // seconds
  // Must be <= cave.js's SEGMENT_SPACING so getCaveBoundsAtX is queried
  // within the range cave.js's ensureGeneratedAhead guarantees is already
  // generated, instead of relying on clamp/extrapolation behavior. Derived
  // directly from Game.Cave.SEGMENT_SPACING (exported by cave.js, which
  // loads before this file per index.html's script order) so the two
  // values can never drift apart; 40 is a fallback only in case cave.js
  // hasn't populated Game.Cave yet for some reason.
  var SPAWN_AHEAD_BUFFER = (Game.Cave && Game.Cave.SEGMENT_SPACING) || 40; // px beyond the right edge, world-x
  var ENEMY_RADIUS = 12; // collision + rough render size
  var PROJECTILE_HIT_RADIUS = 4; // treat projectiles as a small circle
  var BLAST_RADIUS = 70; // px, an explosion this close to the ship damages its shield
  var BLAST_MAX_DAMAGE = 40; // shield damage at zero distance, falling to 0 at BLAST_RADIUS
  var BOB_AMPLITUDE = 10; // px, vertical sine bob
  var BOB_FREQUENCY = 2; // radians/sec
  // "Fast variant" enemies: a subset spawned with a higher bob amplitude and
  // frequency than the default, for extra challenge/visual variety.
  var FAST_VARIANT_CHANCE = 0.35; // ~35% of spawned enemies
  var FAST_BOB_AMPLITUDE_MIN = 22; // px
  var FAST_BOB_AMPLITUDE_MAX = 28; // px
  var FAST_BOB_FREQUENCY_MIN = 3.5; // radians/sec
  var FAST_BOB_FREQUENCY_MAX = 4.5; // radians/sec
  // Keep-out from cave top/bottom at spawn: must cover the full possible
  // vertical excursion of an enemy (radius + bob amplitude), plus a safety
  // buffer, so a spawned enemy can never bob into a wall. Derived from the
  // fast-variant's max amplitude (the largest any enemy can have), not the
  // base BOB_AMPLITUDE, so fast variants can't bob into a wall either.
  var SPAWN_MARGIN = ENEMY_RADIUS + FAST_BOB_AMPLITUDE_MAX + 5; // px
  var CULL_SCREEN_X = -100; // remove once this far behind the camera
  var SCORE_PER_KILL = 100;
  var EXPLOSION_FRAMES = 6;
  var EXPLOSION_DURATION = EXPLOSION_FRAMES / 15; // seconds: 6 frames at 15 fps

  // ---- Sprite (16-bit look). 12x12 buffer px = 24 logical px = ENEMY_RADIUS * 2.
  // o = outline, l/m/d = body light/mid/dark (lit top-left), w = eye white,
  // p = pupil. Frames: eye open, half, closed, half.
  var SPRITE_SIZE = 12;
  function buildEnemyFrames() {
    var n = SPRITE_SIZE;
    var half = n / 2;
    var base = [];
    for (var y = 0; y < n; y++) {
      var d = y < half ? y : n - 1 - y; // 0 at the top/bottom tips
      var w = 2 * (d + 1);
      var start = half - (d + 1);
      var row = [];
      for (var x = 0; x < n; x++) {
        var ch = '.';
        if (x >= start && x < start + w) {
          if (x === start || x === start + w - 1 || y === 0 || y === n - 1) {
            ch = 'o';
          } else {
            var s = (x - (half - 0.5)) + (y - (half - 0.5));
            ch = s < -3 ? 'l' : (s < 3 ? 'm' : 'd');
          }
        }
        row.push(ch);
      }
      base.push(row);
    }
    function withEye(rows) { // rows: { y: 'string for cols 5..7' }
      var out = base.map(function (r) { return r.slice(); });
      Object.keys(rows).forEach(function (yy) {
        for (var k = 0; k < 3; k++) { out[+yy][5 + k] = rows[yy].charAt(k); }
      });
      return out.map(function (r) { return r.join(''); });
    }
    return [
      withEye({ 5: 'www', 6: 'wpp' }),
      withEye({ 5: 'ooo', 6: 'wpp' }),
      withEye({ 5: 'ooo', 6: 'ooo' }),
      withEye({ 5: 'ooo', 6: 'wpp' })
    ];
  }
  // 24x24 explosion: white core -> yellow -> orange -> red fire, then smoke.
  // Chars a-e = fire ramp 0-4 (dark to white); s,t,u = rock ramp 1,2,3.
  function buildExplosionFrames() {
    var N = 24, c = 11.5;
    // Per frame: outer radius and bands [maxNormalisedDist, char] inner to outer.
    var spec = [
      { r: 5,  bands: [[0.6, 'e'], [1, 'd']] },
      { r: 8,  bands: [[0.4, 'e'], [0.7, 'd'], [1, 'c']] },
      { r: 10, bands: [[0.3, 'e'], [0.55, 'd'], [0.8, 'c'], [1, 'b']] },
      { r: 11, bands: [[0.35, 'd'], [0.65, 'c'], [0.88, 'b'], [1, 'a']] },
      { r: 11.5, bands: [[0.4, 'b'], [0.75, 'a'], [1, 't']], hole: true },
      { r: 11.5, bands: [[0.6, 't'], [1, 's']], hole: true, sparse: true }
    ];
    return spec.map(function (f, fi) {
      var rows = [];
      for (var y = 0; y < N; y++) {
        var row = '';
        for (var x = 0; x < N; x++) {
          var dx = x - c, dy = y - c;
          var ang = Math.atan2(dy, dx);
          var wob = 1 + 0.13 * Math.sin(3 * ang + fi) + 0.08 * Math.sin(5 * ang + 2 * fi);
          var d = Math.sqrt(dx * dx + dy * dy) / (f.r * wob);
          var ch = '.';
          if (d <= 1) {
            for (var b = 0; b < f.bands.length; b++) {
              if (d <= f.bands[b][0]) { ch = f.bands[b][1]; break; }
            }
            if (f.hole && d < 0.3) { ch = '.'; }
            if (f.sparse && ((x + y) % 2 === 1 || d > 0.85)) { ch = '.'; }
          }
          row += ch;
        }
        rows.push(row);
      }
      return rows;
    });
  }
  if (Game.Sprite && Game.Sprite.define) {
    Game.Sprite.define('explosion', {
      w: 24, h: 24,
      map: { a: 'fire:0', b: 'fire:1', c: 'fire:2', d: 'fire:3', e: 'fire:4',
        s: 'rock:1', t: 'rock:2' },
      frames: buildExplosionFrames()
    });
  }
  if (Game.Sprite && Game.Sprite.define) {
    Game.Sprite.define('enemy', {
      w: SPRITE_SIZE, h: SPRITE_SIZE,
      map: { o: 'enemy:0', d: 'enemy:1', m: 'enemy:2', l: 'enemy:3', w: 'ui:3', p: 'enemy:0' },
      frames: buildEnemyFrames()
    });
  }
  // Fast variant silhouette: a left-pointing chevron (shape, not just colour).
  function buildFastFrames() {
    var n = SPRITE_SIZE;
    var base = [];
    for (var y = 0; y < n; y++) {
      var a = Math.round(Math.abs(y - (n - 1) / 2) - 0.5);
      var row = [];
      for (var x = 0; x < n; x++) {
        var ch = '.';
        if (x >= a && x <= a + 5) {
          if (x === a || x === a + 5 || y === 0 || y === n - 1) { ch = 'o'; }
          else {
            var s = (x - 5.5) + (y - 5.5);
            ch = s < -3 ? 'l' : (s < 3 ? 'm' : 'd');
          }
        }
        row.push(ch);
      }
      base.push(row);
    }
    function withEye(rows) {
      var out = base.map(function (r) { return r.slice(); });
      Object.keys(rows).forEach(function (yy) {
        for (var k = 0; k < 3; k++) { out[+yy][2 + k] = rows[yy].charAt(k); }
      });
      return out.map(function (r) { return r.join(''); });
    }
    return [
      withEye({ 5: 'www', 6: 'wpp' }),
      withEye({ 5: 'ooo', 6: 'wpp' }),
      withEye({ 5: 'ooo', 6: 'ooo' }),
      withEye({ 5: 'ooo', 6: 'wpp' })
    ];
  }
  if (Game.Sprite && Game.Sprite.define) {
    Game.Sprite.define('enemyFastShape', {
      w: SPRITE_SIZE, h: SPRITE_SIZE,
      map: { o: 'enemy:0', d: 'enemy:1', m: 'enemy:2', l: 'enemy:3', w: 'ui:3', p: 'enemy:0' },
      frames: buildFastFrames()
    });
  }
  function spriteName(e) {
    var S = Game.Settings;
    var shapes = !(S && S.get) || S.get('enemyShapes') !== false;
    return (e.isFastVariant && shapes) ? 'enemyFastShape' : 'enemy';
  }
  var FAST_SWAP = { enemy: 'enemyFast' };
  // Blink: eye open for most of a bob cycle, then half, closed, half.
  var BLINK_START = 0.85;
  function blinkFrame(bobPhase) {
    var t = bobPhase / (Math.PI * 2);
    t = t - Math.floor(t);
    if (t < BLINK_START) { return 0; }
    return 1 + Math.min(2, Math.floor((t - BLINK_START) / (1 - BLINK_START) * 3));
  }

  // Fast-variant afterimages: fixed ring of the last HISTORY_LEN screen
  // positions (newest at histHead), overwritten in place, never grows.
  var HISTORY_LEN = 6;
  var TRAIL_STEPS = [2, 4, 6]; // 1 = newest
  var TRAIL_ALPHAS = [0.5, 0.3, 0.15];
  function newHistory(x, y) {
    var h = [];
    for (var i = 0; i < HISTORY_LEN; i++) { h.push({ x: x, y: y }); }
    return h;
  }
  function pushHistory(e, x, y) {
    if (!e.history) { e.history = newHistory(x, y); e.histHead = 0; }
    e.histHead = (e.histHead + 1) % HISTORY_LEN;
    var slot = e.history[e.histHead];
    slot.x = x;
    slot.y = y;
  }

  var enemies = []; // each: { worldX, baseY, y, bobPhase }
  var explosions = []; // each: { worldX, y, timer }
  var spawnTimer = 0; // seconds remaining until next spawn
  var score = 0;

  function randRange(min, max) {
    return min + Game.Random.stream('enemies').next() * (max - min);
  }

  function resetSpawnTimer() {
    var spawnFactor = (Game.Difficulty && Game.Difficulty.spawnFactor) ? Game.Difficulty.spawnFactor() : 1;
    spawnTimer = randRange(SPAWN_INTERVAL_MIN, SPAWN_INTERVAL_MAX) * spawnFactor;
  }

  function reset() {
    enemies = [];
    explosions = [];
    score = 0;
    resetSpawnTimer();
  }

  // Damages the ship's shield if it is within BLAST_RADIUS of an explosion at
  // (worldX, y); damage falls off linearly with distance to the ship centre.
  function blastShip(worldX, y) {
    if (!Game.Ship || !Game.Ship.getPosition || !Game.Collision || !Game.Collision.damageShield) {
      return;
    }
    var pos = Game.Ship.getPosition();
    var dx = pos.worldX - worldX;
    var dy = pos.y - y;
    var dist = Math.sqrt(dx * dx + dy * dy);
    if (dist >= BLAST_RADIUS) {
      return;
    }
    Game.Collision.damageShield(BLAST_MAX_DAMAGE * (1 - dist / BLAST_RADIUS));
    if (Game.Ship.triggerHitFlash) {
      Game.Ship.triggerHitFlash();
    }
  }

  // opts.noBlast: skip the proximity blast (ship rams already deal their own damage).
  function explode(enemy, opts) {
    var idx = enemies.indexOf(enemy);
    if (idx !== -1) {
      enemies.splice(idx, 1);
    }
    if (!(opts && opts.noBlast)) {
      blastShip(enemy.worldX, enemy.y);
    }
    explosions.push({ worldX: enemy.worldX, y: enemy.y, timer: EXPLOSION_DURATION });
    var sx = enemy.worldX - ((Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0);
    if (Game.Particles && Game.Particles.emit) {
      Game.Particles.emit(sx, enemy.y, { count: 14, speed: { min: 40, max: 140 },
        life: { min: 0.25, max: 0.5 }, size: { min: 1, max: 2 }, ramp: 'fire' });
      Game.Particles.emit(sx, enemy.y, { count: 8, speed: { min: 20, max: 80 },
        life: { min: 0.4, max: 0.8 }, size: { min: 1, max: 2 }, ramp: 'rock', gravity: 120 });
    }
    if (Game.Camera && Game.Camera.shake) {
      Game.Camera.shake(3, 0.15);
    }
    if (Game.Audio && Game.Audio.playExplosionSound) {
      Game.Audio.playExplosionSound(Game.Audio.panForX ? Game.Audio.panForX(sx) : undefined);
    }
  }

  function spawn() {
    if (!Game.Cave || !Game.Cave.getScrollX || !Game.Cave.getCaveBoundsAtX) {
      return;
    }
    var scrollX = Game.Cave.getScrollX();
    var spawnWorldX = scrollX + Game.W + SPAWN_AHEAD_BUFFER;
    var bounds = Game.Cave.getCaveBoundsAtX(spawnWorldX);

    var top = bounds.top + SPAWN_MARGIN;
    var bottom = bounds.bottom - SPAWN_MARGIN;
    var baseY;
    if (top >= bottom) {
      // Gap too narrow for the margin - fall back to the gap's midpoint so
      // we still spawn something reasonable rather than skipping entirely.
      baseY = (bounds.top + bounds.bottom) / 2;
    } else {
      baseY = randRange(top, bottom);
    }

    var isFastVariant = Game.Random.stream('enemies').next() < FAST_VARIANT_CHANCE;

    enemies.push({
      worldX: spawnWorldX,
      baseY: baseY,
      y: baseY,
      bobPhase: Game.Random.stream('enemies').next() * Math.PI * 2,
      isFastVariant: isFastVariant,
      bobAmplitude: isFastVariant ? randRange(FAST_BOB_AMPLITUDE_MIN, FAST_BOB_AMPLITUDE_MAX) : BOB_AMPLITUDE,
      bobFrequency: isFastVariant ? randRange(FAST_BOB_FREQUENCY_MIN, FAST_BOB_FREQUENCY_MAX) : BOB_FREQUENCY,
      flash: false,
      history: newHistory(spawnWorldX - scrollX, baseY),
      histHead: 0
    });
  }

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    spawnTimer -= dt;
    if (spawnTimer <= 0) {
      spawn();
      resetSpawnTimer();
    }

    var scrollX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;

    for (var i = 0; i < enemies.length; i++) {
      var e = enemies[i];
      e.bobPhase += e.bobFrequency * dt;
      e.y = e.baseY + Math.sin(e.bobPhase) * e.bobAmplitude;
      pushHistory(e, e.worldX - scrollX, e.y);
    }

    // ---- Projectile collision: destroy enemy + projectile, award score. ----
    // Reverse-iterate enemies so splicing mid-loop never skips an element.
    var projectiles = (Game.Projectiles && Game.Projectiles.getAll) ? Game.Projectiles.getAll() : null;
    if (projectiles) {
      for (var ei = enemies.length - 1; ei >= 0; ei--) {
        var enemy = enemies[ei];
        var hitProjectileIndex = -1;
        for (var pi = projectiles.length - 1; pi >= 0; pi--) {
          var proj = projectiles[pi];
          var projWorldX = proj.x + scrollX;
          var dx = projWorldX - enemy.worldX;
          var dy = proj.y - enemy.y;
          var hitRadius = ENEMY_RADIUS + PROJECTILE_HIT_RADIUS;
          if ((dx * dx + dy * dy) <= (hitRadius * hitRadius)) {
            hitProjectileIndex = pi;
            break;
          }
        }
        if (hitProjectileIndex !== -1) {
          projectiles.splice(hitProjectileIndex, 1);
          explode(enemy);
          score += SCORE_PER_KILL;
          if (Game.Score && Game.Score.addKill) {
            var awarded = Game.Score.addKill(SCORE_PER_KILL);
            if (Game.Effects && Game.Effects.popText) {
              Game.Effects.popText('+' + awarded, enemy.worldX - scrollX, enemy.y);
            }
          }
        }
      }
    }

    // ---- Cull enemies sufficiently far behind the camera. ----
    for (var ci = enemies.length - 1; ci >= 0; ci--) {
      var screenX = enemies[ci].worldX - scrollX;
      if (screenX < CULL_SCREEN_X) {
        enemies.splice(ci, 1);
      }
    }

    // ---- Advance and cull explosion timers. ----
    for (var xi = explosions.length - 1; xi >= 0; xi--) {
      explosions[xi].timer -= dt;
      if (explosions[xi].timer <= 0) {
        explosions.splice(xi, 1);
      }
    }
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    var scrollX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;

    for (var i = 0; i < enemies.length; i++) {
      var e = enemies[i];
      var screenX = e.worldX - scrollX;

      // Cull off-screen draws (kept in the update list until CULL_SCREEN_X).
      if (screenX < -ENEMY_RADIUS || screenX > Game.W + ENEMY_RADIUS) {
        continue;
      }

      var swap = e.isFastVariant ? FAST_SWAP : null;
      var frame = blinkFrame(e.bobPhase);
      var sname = spriteName(e);

      // Fast variant: afterimages (2nd, 4th, 6th most recent positions).
      if (e.isFastVariant && e.history) {
        for (var ti = 0; ti < TRAIL_STEPS.length; ti++) {
          var h = e.history[(e.histHead - (TRAIL_STEPS[ti] - 1) + HISTORY_LEN * 2) % HISTORY_LEN];
          Game.Sprite.draw(ctx, sname, frame, h.x, h.y,
            { swap: swap, alpha: TRAIL_ALPHAS[ti] });
        }
      }

      Game.Sprite.draw(ctx, sname, frame, screenX, e.y,
        { swap: swap, flash: !!e.flash });
    }

    for (var j = 0; j < explosions.length; j++) {
      var ex = explosions[j];
      var exScreenX = ex.worldX - scrollX;

      if (exScreenX < -ENEMY_RADIUS || exScreenX > Game.W + ENEMY_RADIUS) {
        continue;
      }

      var xframe = Math.min(EXPLOSION_FRAMES - 1,
        Math.floor((1 - ex.timer / EXPLOSION_DURATION) * EXPLOSION_FRAMES));
      Game.Sprite.draw(ctx, 'explosion', xframe, exScreenX, ex.y);
    }
  }

  function getAll() {
    return enemies;
  }

  function getScore() {
    return score;
  }

  Game.Enemies = {
    update: update,
    render: render,
    reset: reset,
    explode: explode,
    getAll: getAll,
    getScore: getScore,
    ENEMY_RADIUS: ENEMY_RADIUS
  };
})();
