// Spelunker - enemy entities.
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so main.js can call Enemies.update/render each
// frame, following the same pattern as cave.js/ship.js/collision.js/
// projectile.js.
//
// Enemies are tracked in WORLD-space (worldX, y), unlike projectiles which
// are tracked in screen-space (see projectile.js's header comment). This
// matches cave.js's convention (world-x = scrollX + screen-x) and makes it
// natural to spawn an enemy ahead of the camera and let it "move left" for
// free as the camera scrolls, without needing per-frame velocity math.
//
// Ship-vs-enemy collision: handled in collision.js (see the comment there)
// rather than here, so all "what counts as a crash"/lives/invulnerability
// logic stays centralized in a single owner.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('enemy.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;
  function palette() { return Game.Theme.get(); }

  // ---- Tuning constants ----
  var SPAWN_INTERVAL_MIN = 2; // seconds
  var SPAWN_INTERVAL_MAX = 4; // seconds
  // Must be <= cave.js's SEGMENT_SPACING so getCaveBoundsAtX is queried
  // within the range cave.js's ensureGeneratedAhead guarantees is already
  // generated, instead of relying on clamp/extrapolation behavior. Derived
  // directly from Game.Cave.SEGMENT_SPACING (exported by cave.js, which
  // loads before this file per index.html's script order) so the two
  // values can never drift apart; 40 is a fallback only in case cave.js
  // hasn't populated Game.Cave yet for some reason.
  var SPAWN_AHEAD_BUFFER = (Game.Cave && Game.Cave.SEGMENT_SPACING) || 40; // px beyond the right edge, world-x
  var ENEMY_RADIUS = 12; // collision + rough render size
  var PROJECTILE_HIT_RADIUS = 4; // treat projectiles as a small circle
  var BLAST_RADIUS = 70; // px, an explosion this close to the ship damages its shield
  var BLAST_MAX_DAMAGE = 40; // shield damage at zero distance, falling to 0 at BLAST_RADIUS
  var BOB_AMPLITUDE = 10; // px, vertical sine bob
  var BOB_FREQUENCY = 2; // radians/sec
  // "Fast variant" enemies: a subset spawned with a higher bob amplitude and
  // frequency than the default, for extra challenge/visual variety.
  var FAST_VARIANT_CHANCE = 0.35; // ~35% of spawned enemies
  var FAST_BOB_AMPLITUDE_MIN = 22; // px
  var FAST_BOB_AMPLITUDE_MAX = 28; // px
  var FAST_BOB_FREQUENCY_MIN = 3.5; // radians/sec
  var FAST_BOB_FREQUENCY_MAX = 4.5; // radians/sec
  // Keep-out from cave top/bottom at spawn: must cover the full possible
  // vertical excursion of an enemy (radius + bob amplitude), plus a safety
  // buffer, so a spawned enemy can never bob into a wall. Derived from the
  // fast-variant's max amplitude (the largest any enemy can have), not the
  // base BOB_AMPLITUDE, so fast variants can't bob into a wall either.
  var SPAWN_MARGIN = ENEMY_RADIUS + FAST_BOB_AMPLITUDE_MAX + 5; // px
  var CULL_SCREEN_X = -100; // remove once this far behind the camera
  var SCORE_PER_KILL = 100;
  // "Weave" variant (campaign mechanic 'sineweave'): glides on a wide sine path.
  var WEAVE_CHANCE = 0.35; // per spawn, only while the mechanic is unlocked
  var WEAVE_AMPLITUDE_MIN = 24; // px
  var WEAVE_AMPLITUDE_MAX = 40; // px
  var WEAVE_PERIOD_MIN = 1.6; // seconds per full wave
  var WEAVE_PERIOD_MAX = 2.6;
  var WEAVE_KILL_BONUS = 10; // added to SCORE_PER_KILL (Score rounds to 10s)
  // Snake variant (campaign mechanic 'snakes'): one entity = a hittable HEAD plus
  // SNAKE_SEGMENTS body segments trailing to its right. Hit rules: ship contact
  // with the head OR any segment damages the ship and destroys the snake (like a
  // normal enemy ram: collision.js calls explode with noBlast);
  // projectiles hitting the head deal 1 damage (SNAKE_HP total, head flashes),
  // projectiles hitting a segment are absorbed with a spark and do no damage.
  // Killing the head explodes it (one proximity blast) and chain-pops the
  // segments SNAKE_POP_STAGGER apart.
  var SNAKE_CHANCE = 0.20; // per spawn, only while unlocked; replaces the spawn
  var SNAKE_MAX_LIVE = 2;
  var SNAKE_SEGMENTS = 6;
  var SNAKE_HP = 3;
  var SNAKE_HEAD_R = 11;
  var SNAKE_SEG_R = 8; // first segment; tapers toward the tail
  var SNAKE_SEG_TAPER = 0.6; // px of radius lost per segment
  var SNAKE_SEG_SPACING = 10; // px of worldX between consecutive segments
  var SNAKE_LAG = 0.14; // seconds of head path each segment lags behind the previous
  var SNAKE_AMP_MIN = 30;
  var SNAKE_AMP_MAX = 48;
  var SNAKE_PERIOD_MIN = 2.2;
  var SNAKE_PERIOD_MAX = 3.2;
  var SNAKE_KILL_SCORE = 250;
  var SNAKE_POP_STAGGER = 0.06;
  var SNAKE_FLASH_TIME = 0.12;
  // Swarm (campaign mechanic 'swarm'): SWARM_SIZE small orbs spawn together as ONE
  // spawn event, replacing the normal pick with SWARM_CHANCE (dedicated stream
  // 'enemies-swarm', touched only while unlocked). Each member has 1 hp, orbits
  // its slot in a loose cluster, the cluster bobs on a slow sine, and members
  // drift gently toward the ship's y. A ship ram destroys every member it
  // overlaps that frame for ONE damage instance (see collision.js). Shooting
  // all SWARM_SIZE members within SWARM_CLEAR_WINDOW seconds pays a bonus.
  var SWARM_CHANCE = 0.18;
  var SWARM_SIZE = 6;
  var SWARM_MAX_LIVE = 12;
  var SWARM_RADIUS = 7;
  var SWARM_MIN_GAP = 70; // px: skip the swarm if the cave is narrower at spawn
  var SWARM_W = 70; // cluster ellipse width / height, px
  var SWARM_H = 60;
  var SWARM_ORBIT_MIN = 6;
  var SWARM_ORBIT_MAX = 12;
  var SWARM_ORBIT_SPEED_MIN = 2; // rad/s
  var SWARM_ORBIT_SPEED_MAX = 4;
  var SWARM_DRIFT_AMP = 18;
  var SWARM_DRIFT_PERIOD = 3;
  var SWARM_HOMING = 25; // px/s toward the ship's y
  var SWARM_KILL_SCORE = 30;
  var SWARM_CLEAR_WINDOW = 2.5; // seconds between first and last kill
  var SWARM_CLEAR_BONUS = 100;
  // Ghost (campaign mechanic 'phase'): ignores cave walls and cycles between a
  // solid and a ghostly phase. Spawn roll uses its own stream 'enemies-ghost',
  // touched only while unlocked, and replaces the picked enemy. Only the solid
  // phase (alpha >= GHOST_SOLID_ALPHA) can be shot or hurts the ship on contact.
  // Cycle: solid, fade out, ghostly, fade in (alpha ramps linearly between).
  var GHOST_CHANCE = 0.22;
  var GHOST_MAX_LIVE = 3;
  var GHOST_RADIUS = 12;
  var GHOST_SOLID_T = 1.2; // seconds fully solid
  var GHOST_FADE_T = 0.2; // seconds per fade
  var GHOST_FAINT_T = 1.0; // seconds ghostly
  var GHOST_CYCLE = GHOST_SOLID_T + GHOST_FADE_T + GHOST_FAINT_T + GHOST_FADE_T;
  var GHOST_FAINT_ALPHA = 0.35;
  var GHOST_SOLID_ALPHA = 0.7; // alpha at/above which the ghost is solid
  var GHOST_BAND = 30; // px kept clear of the top/bottom of the screen
  var GHOST_WANDER_AMP = 45; // px of slow vertical sine
  var GHOST_WANDER_PERIOD_MIN = 3;
  var GHOST_WANDER_PERIOD_MAX = 5;
  var GHOST_HOMING = 30; // px/s toward the ship's y
  var GHOST_KILL_SCORE = 150;
  var EXPLOSION_FRAMES = 6;
  var EXPLOSION_DURATION = EXPLOSION_FRAMES / 15; // seconds: 6 frames at 15 fps

  // ---- Sprite (16-bit look). 12x12 buffer px = 24 logical px = ENEMY_RADIUS * 2.
  // o = outline, l/m/d = body light/mid/dark (lit top-left), w = eye white,
  // p = pupil. Frames: eye open, half, closed, half.
  var SPRITE_SIZE = 12;
  function buildEnemyFrames() {
    var n = SPRITE_SIZE;
    var half = n / 2;
    var base = [];
    for (var y = 0; y < n; y++) {
      var d = y < half ? y : n - 1 - y; // 0 at the top/bottom tips
      var w = 2 * (d + 1);
      var start = half - (d + 1);
      var row = [];
      for (var x = 0; x < n; x++) {
        var ch = '.';
        if (x >= start && x < start + w) {
          if (x === start || x === start + w - 1 || y === 0 || y === n - 1) {
            ch = 'o';
          } else {
            var s = (x - (half - 0.5)) + (y - (half - 0.5));
            ch = s < -3 ? 'l' : (s < 3 ? 'm' : 'd');
          }
        }
        row.push(ch);
      }
      base.push(row);
    }
    function withEye(rows) { // rows: { y: 'string for cols 5..7' }
      var out = base.map(function (r) { return r.slice(); });
      Object.keys(rows).forEach(function (yy) {
        for (var k = 0; k < 3; k++) { out[+yy][5 + k] = rows[yy].charAt(k); }
      });
      return out.map(function (r) { return r.join(''); });
    }
    return [
      withEye({ 5: 'www', 6: 'wpp' }),
      withEye({ 5: 'ooo', 6: 'wpp' }),
      withEye({ 5: 'ooo', 6: 'ooo' }),
      withEye({ 5: 'ooo', 6: 'wpp' })
    ];
  }
  // 24x24 explosion: white core -> yellow -> orange -> red fire, then smoke.
  // Chars a-e = fire ramp 0-4 (dark to white); s,t,u = rock ramp 1,2,3.
  function buildExplosionFrames() {
    var N = 24, c = 11.5;
    // Per frame: outer radius and bands [maxNormalisedDist, char] inner to outer.
    var spec = [
      { r: 5,  bands: [[0.6, 'e'], [1, 'd']] },
      { r: 8,  bands: [[0.4, 'e'], [0.7, 'd'], [1, 'c']] },
      { r: 10, bands: [[0.3, 'e'], [0.55, 'd'], [0.8, 'c'], [1, 'b']] },
      { r: 11, bands: [[0.35, 'd'], [0.65, 'c'], [0.88, 'b'], [1, 'a']] },
      { r: 11.5, bands: [[0.4, 'b'], [0.75, 'a'], [1, 't']], hole: true },
      { r: 11.5, bands: [[0.6, 't'], [1, 's']], hole: true, sparse: true }
    ];
    return spec.map(function (f, fi) {
      var rows = [];
      for (var y = 0; y < N; y++) {
        var row = '';
        for (var x = 0; x < N; x++) {
          var dx = x - c, dy = y - c;
          var ang = Math.atan2(dy, dx);
          var wob = 1 + 0.13 * Math.sin(3 * ang + fi) + 0.08 * Math.sin(5 * ang + 2 * fi);
          var d = Math.sqrt(dx * dx + dy * dy) / (f.r * wob);
          var ch = '.';
          if (d <= 1) {
            for (var b = 0; b < f.bands.length; b++) {
              if (d <= f.bands[b][0]) { ch = f.bands[b][1]; break; }
            }
            if (f.hole && d < 0.3) { ch = '.'; }
            if (f.sparse && ((x + y) % 2 === 1 || d > 0.85)) { ch = '.'; }
          }
          row += ch;
        }
        rows.push(row);
      }
      return rows;
    });
  }
  if (Game.Sprite && Game.Sprite.define) {
    Game.Sprite.define('explosion', {
      w: 24, h: 24,
      map: { a: 'fire:0', b: 'fire:1', c: 'fire:2', d: 'fire:3', e: 'fire:4',
        s: 'rock:1', t: 'rock:2' },
      frames: buildExplosionFrames()
    });
  }
  if (Game.Sprite && Game.Sprite.define) {
    Game.Sprite.define('enemy', {
      w: SPRITE_SIZE, h: SPRITE_SIZE,
      map: { o: 'enemy:0', d: 'enemy:1', m: 'enemy:2', l: 'enemy:3', w: 'ui:3', p: 'enemy:0' },
      frames: buildEnemyFrames()
    });
  }
  // Fast variant silhouette: a left-pointing chevron (shape, not just colour).
  function buildFastFrames() {
    var n = SPRITE_SIZE;
    var base = [];
    for (var y = 0; y < n; y++) {
      var a = Math.round(Math.abs(y - (n - 1) / 2) - 0.5);
      var row = [];
      for (var x = 0; x < n; x++) {
        var ch = '.';
        if (x >= a && x <= a + 5) {
          if (x === a || x === a + 5 || y === 0 || y === n - 1) { ch = 'o'; }
          else {
            var s = (x - 5.5) + (y - 5.5);
            ch = s < -3 ? 'l' : (s < 3 ? 'm' : 'd');
          }
        }
        row.push(ch);
      }
      base.push(row);
    }
    function withEye(rows) {
      var out = base.map(function (r) { return r.slice(); });
      Object.keys(rows).forEach(function (yy) {
        for (var k = 0; k < 3; k++) { out[+yy][2 + k] = rows[yy].charAt(k); }
      });
      return out.map(function (r) { return r.join(''); });
    }
    return [
      withEye({ 5: 'www', 6: 'wpp' }),
      withEye({ 5: 'ooo', 6: 'wpp' }),
      withEye({ 5: 'ooo', 6: 'ooo' }),
      withEye({ 5: 'ooo', 6: 'wpp' })
    ];
  }
  if (Game.Sprite && Game.Sprite.define) {
    Game.Sprite.define('enemyFastShape', {
      w: SPRITE_SIZE, h: SPRITE_SIZE,
      map: { o: 'enemy:0', d: 'enemy:1', m: 'enemy:2', l: 'enemy:3', w: 'ui:3', p: 'enemy:0' },
      frames: buildFastFrames()
    });
  }
  // Weave variant silhouette: the normal diamond with its narrower rows
  // shifted sideways by a travelling wave, so each frame looks wiggly.
  function buildWeaveFrames() {
    var n = SPRITE_SIZE;
    return buildEnemyFrames().map(function (rows, fi) {
      return rows.map(function (row, y) {
        if (y === 5 || y === 6) { return row; } // widest rows keep the full width
        var sh = Math.round(Math.sin(y * 0.9 + fi * Math.PI / 2));
        if (sh === 0) { return row; }
        return sh > 0 ? '.' + row.slice(0, n - 1) : row.slice(1) + '.';
      });
    });
  }
  if (Game.Sprite && Game.Sprite.define) {
    Game.Sprite.define('enemyWeaveShape', {
      w: SPRITE_SIZE, h: SPRITE_SIZE,
      map: { o: 'enemy:0', d: 'enemy:1', m: 'enemy:2', l: 'enemy:3', w: 'ui:3', p: 'enemy:0' },
      frames: buildWeaveFrames()
    });
  }
  var WEAVE_SWAP = { enemy: 'enemyWeave' };
  function spriteName(e) {
    var S = Game.Settings;
    var shapes = !(S && S.get) || S.get('enemyShapes') !== false;
    if (e.isWeave && shapes) { return 'enemyWeaveShape'; }
    return (e.isFastVariant && shapes) ? 'enemyFastShape' : 'enemy';
  }

  // Pure sine path shared by weaving enemies (and snakes): y at time t seconds
  // for a wave of the given amplitude (px) and period (s) around baseY. The
  // caller clamps the result into the cave.
  function weaveY(baseY, amp, period, t) {
    return baseY + amp * Math.sin(2 * Math.PI * t / period);
  }
  // Clamp y into the cave gap at worldX, keeping ENEMY_RADIUS clear of the
  // walls; a gap too narrow for the margin collapses to its midpoint.
  // margin defaults to ENEMY_RADIUS (snake segments pass their own radius).
  function clampToCave(y, worldX, margin) {
    if (!Game.Cave || !Game.Cave.getCaveBoundsAtX) { return y; }
    var m = margin === undefined ? ENEMY_RADIUS : margin;
    var b = Game.Cave.getCaveBoundsAtX(worldX);
    var lo = b.top + m;
    var hi = b.bottom - m;
    if (lo > hi) { return (b.top + b.bottom) / 2; }
    return y < lo ? lo : (y > hi ? hi : y);
  }
  var FAST_SWAP = { enemy: 'enemyFast' };
  // Blink: eye open for most of a bob cycle, then half, closed, half.
  var BLINK_START = 0.85;
  function blinkFrame(bobPhase) {
    var t = bobPhase / (Math.PI * 2);
    t = t - Math.floor(t);
    if (t < BLINK_START) { return 0; }
    return 1 + Math.min(2, Math.floor((t - BLINK_START) / (1 - BLINK_START) * 3));
  }

  // Fast-variant afterimages: fixed ring of the last HISTORY_LEN screen
  // positions (newest at histHead), overwritten in place, never grows.
  var HISTORY_LEN = 6;
  var TRAIL_STEPS = [2, 4, 6]; // 1 = newest
  var TRAIL_ALPHAS = [0.5, 0.3, 0.15];
  function newHistory(x, y) {
    var h = [];
    for (var i = 0; i < HISTORY_LEN; i++) { h.push({ x: x, y: y }); }
    return h;
  }
  function pushHistory(e, x, y) {
    if (!e.history) { e.history = newHistory(x, y); e.histHead = 0; }
    e.histHead = (e.histHead + 1) % HISTORY_LEN;
    var slot = e.history[e.histHead];
    slot.x = x;
    slot.y = y;
  }

  var enemies = []; // each: { worldX, baseY, y, bobPhase }
  var explosions = []; // each: { worldX, y, timer }
  var spawnTimer = 0; // seconds remaining until next spawn
  var score = 0;
  var clock = 0; // seconds of enemy updates, for swarm-clear timing
  var swarmInfo = {}; // swarmId -> { shot, firstT, born, failed }
  var nextSwarmId = 1;

  function randRange(min, max) {
    return min + Game.Random.stream('enemies').next() * (max - min);
  }

  function resetSpawnTimer() {
    var spawnFactor = (Game.Difficulty && Game.Difficulty.spawnFactor) ? Game.Difficulty.spawnFactor() : 1;
    spawnTimer = randRange(SPAWN_INTERVAL_MIN, SPAWN_INTERVAL_MAX) * spawnFactor;
  }

  function reset() {
    enemies = [];
    explosions = [];
    score = 0;
    clock = 0;
    swarmInfo = {};
    nextSwarmId = 1;
    resetSpawnTimer();
  }

  // Level end: drop every enemy and pending explosion without score or
  // blast damage (a short poof marks each). Keeps score and the clock.
  function clearAll() {
    var sx = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;
    if (Game.Particles && Game.Particles.emit) {
      for (var i = 0; i < enemies.length; i++) {
        var e = enemies[i];
        if (typeof e.worldX !== 'number' || typeof e.y !== 'number') { continue; }
        Game.Particles.emit(e.worldX - sx, e.y, { count: 6, speed: { min: 20, max: 70 },
          life: { min: 0.2, max: 0.4 }, size: { min: 1, max: 2 }, ramp: 'fire' });
      }
    }
    enemies = [];
    explosions = [];
    swarmInfo = {};
    resetSpawnTimer();
  }

  // Damages the ship's shield if it is within BLAST_RADIUS of an explosion at
  // (worldX, y); damage falls off linearly with distance to the ship centre.
  function blastShip(worldX, y) {
    if (!Game.Ship || !Game.Ship.getPosition || !Game.Collision || !Game.Collision.damageShield) {
      return;
    }
    var pos = Game.Ship.getPosition();
    var dx = pos.worldX - worldX;
    var dy = pos.y - y;
    var dist = Math.sqrt(dx * dx + dy * dy);
    if (dist >= BLAST_RADIUS) {
      return;
    }
    Game.Collision.damageShield(BLAST_MAX_DAMAGE * (1 - dist / BLAST_RADIUS));
    if (Game.Ship.triggerHitFlash) {
      Game.Ship.triggerHitFlash();
    }
  }

  // opts.noBlast: skip the proximity blast (ship rams already deal their own damage).
  function explode(enemy, opts) {
    var idx = enemies.indexOf(enemy);
    if (idx !== -1) {
      enemies.splice(idx, 1);
    }
    if (enemy.isSwarm) {
      // Small pop only: no blast, explosion sprite, shake or sound (six at once).
      var px = enemy.worldX - ((Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0);
      if (Game.Particles && Game.Particles.emit) {
        Game.Particles.emit(px, enemy.y, { count: 7, speed: { min: 30, max: 90 },
          life: { min: 0.2, max: 0.4 }, size: { min: 1, max: 2 }, ramp: 'enemySwarm' });
      }
      return;
    }
    if (!(opts && opts.noBlast)) {
      blastShip(enemy.worldX, enemy.y);
    }
    explosions.push({ worldX: enemy.worldX, y: enemy.y, timer: EXPLOSION_DURATION, delay: 0 });
    if (enemy.isSnake) {
      // Segments chain-pop after the head as delayed explosion objects (no
      // extra blast/damage: the head's blast above is the only one).
      for (var si = 0; si < enemy.segs.length; si++) {
        explosions.push({ worldX: enemy.segs[si].worldX, y: enemy.segs[si].y,
          timer: EXPLOSION_DURATION, delay: (si + 1) * SNAKE_POP_STAGGER });
      }
    }
    var sx = enemy.worldX - ((Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0);
    if (Game.Particles && Game.Particles.emit) {
      Game.Particles.emit(sx, enemy.y, { count: 14, speed: { min: 40, max: 140 },
        life: { min: 0.25, max: 0.5 }, size: { min: 1, max: 2 }, ramp: 'fire' });
      Game.Particles.emit(sx, enemy.y, { count: 8, speed: { min: 20, max: 80 },
        life: { min: 0.4, max: 0.8 }, size: { min: 1, max: 2 }, ramp: 'rock', gravity: 120 });
    }
    if (Game.Camera && Game.Camera.shake) {
      Game.Camera.shake(3, 0.15);
    }
    if (Game.Audio && Game.Audio.playExplosionSound) {
      Game.Audio.playExplosionSound(Game.Audio.panForX ? Game.Audio.panForX(sx) : undefined);
    }
  }

  function liveSnakes() {
    var n = 0;
    for (var i = 0; i < enemies.length; i++) { if (enemies[i].isSnake) { n++; } }
    return n;
  }

  // Head follows a wave; body segment i (1-based) is the same wave
  // SNAKE_LAG * i seconds behind (i.e. sampled from the head's path at a fixed
  // time lag), clamped inside the cave at its own worldX.
  function layoutSnake(e) {
    e.y = clampToCave(weaveY(e.baseY, e.snakeAmp, e.snakePeriod, e.snakeT), e.worldX, SNAKE_HEAD_R);
    for (var i = 0; i < e.segs.length; i++) {
      var sg = e.segs[i];
      sg.worldX = e.worldX + (i + 1) * SNAKE_SEG_SPACING;
      sg.y = clampToCave(weaveY(e.baseY, e.snakeAmp, e.snakePeriod, e.snakeT - (i + 1) * SNAKE_LAG),
        sg.worldX, sg.r);
    }
  }

  function makeSnake(worldX, baseY, amp, period, t0) {
    var segs = [];
    for (var i = 0; i < SNAKE_SEGMENTS; i++) {
      segs.push({ worldX: worldX, y: baseY, r: SNAKE_SEG_R - i * SNAKE_SEG_TAPER });
    }
    var e = {
      worldX: worldX, baseY: baseY, y: baseY, bobPhase: 0, bobAmplitude: 0, bobFrequency: 0,
      isFastVariant: false, isWeave: false, isSnake: true, radius: SNAKE_HEAD_R,
      snakeAmp: amp, snakePeriod: period, snakeT: t0, hp: SNAKE_HP, flashT: 0,
      segs: segs, flash: false, history: null, histHead: 0
    };
    layoutSnake(e);
    return e;
  }

  function liveGhosts() {
    var n = 0;
    for (var i = 0; i < enemies.length; i++) { if (enemies[i].isGhost) { n++; } }
    return n;
  }

  // Alpha of the ghost phase cycle at time t (seconds, any offset): 1 solid,
  // linear fade to GHOST_FAINT_ALPHA, faint, linear fade back.
  function ghostAlpha(t) {
    var c = t - Math.floor(t / GHOST_CYCLE) * GHOST_CYCLE;
    if (c < GHOST_SOLID_T) { return 1; }
    c -= GHOST_SOLID_T;
    if (c < GHOST_FADE_T) { return 1 - (1 - GHOST_FAINT_ALPHA) * (c / GHOST_FADE_T); }
    c -= GHOST_FADE_T;
    if (c < GHOST_FAINT_T) { return GHOST_FAINT_ALPHA; }
    c -= GHOST_FAINT_T;
    return GHOST_FAINT_ALPHA + (1 - GHOST_FAINT_ALPHA) * (c / GHOST_FADE_T);
  }
  function ghostSolid(e) { return e.ghostAlpha >= GHOST_SOLID_ALPHA; }

  function layoutGhost(e) {
    e.ghostAlpha = ghostAlpha(e.ghostT);
    var y = e.baseY + GHOST_WANDER_AMP * Math.sin(2 * Math.PI * e.ghostLife / e.wanderPeriod + e.wanderPhase);
    var H = Game.H || 400;
    e.y = y < GHOST_BAND ? GHOST_BAND : (y > H - GHOST_BAND ? H - GHOST_BAND : y);
  }

  function makeGhost(worldX, baseY, offset, wanderPhase, wanderPeriod) {
    var e = {
      worldX: worldX, baseY: baseY, y: baseY, bobPhase: 0, bobAmplitude: 0, bobFrequency: 0,
      isFastVariant: false, isWeave: false, isGhost: true, radius: GHOST_RADIUS, hp: 1,
      ghostT: offset, ghostLife: 0, ghostAlpha: 1, wanderPhase: wanderPhase,
      wanderPeriod: wanderPeriod, flash: false, history: null, histHead: 0
    };
    layoutGhost(e);
    return e;
  }

  function liveSwarmMembers() {
    var n = 0;
    for (var i = 0; i < enemies.length; i++) { if (enemies[i].isSwarm) { n++; } }
    return n;
  }

  // Position a member from its slot, orbit and the cluster drift. worldX orbits
  // a little too; y is clamped into the cave at the member's own worldX.
  function layoutSwarmMember(e) {
    var a = e.swarmPhase;
    e.worldX = e.slotX + e.orbitR * 0.5 * Math.cos(a);
    var drift = SWARM_DRIFT_AMP * Math.sin(2 * Math.PI * e.swarmT / SWARM_DRIFT_PERIOD);
    e.y = clampToCave(e.baseY + e.slotY + drift + e.orbitR * Math.sin(a), e.worldX, e.radius + 2);
  }

  // The caller draws every parameter unconditionally (stream use must not depend
  // on cave/cap skips); this just builds the members from them.
  function makeSwarm(worldX, baseY, params) {
    var id = nextSwarmId++;
    var members = [];
    for (var i = 0; i < params.length; i++) {
      var q = params[i];
      var rad = Math.sqrt(q.u);
      var m = {
        worldX: worldX, slotX: worldX + SWARM_W / 2 * rad * Math.cos(q.ang),
        slotY: SWARM_H / 2 * rad * Math.sin(q.ang), baseY: baseY, y: baseY,
        bobPhase: q.phase, bobAmplitude: 0, bobFrequency: 0,
        isFastVariant: false, isWeave: false, isSwarm: true, swarmId: id, radius: SWARM_RADIUS,
        hp: 1, orbitR: q.orbitR, orbitSpeed: q.orbitSpeed, swarmPhase: q.phase,
        swarmT: 0, flash: false, history: null, histHead: 0
      };
      layoutSwarmMember(m);
      members.push(m);
    }
    swarmInfo[id] = { shot: 0, firstT: 0, born: clock, failed: false };
    return members;
  }

  function spawn() {
    if (!Game.Cave || !Game.Cave.getScrollX || !Game.Cave.getCaveBoundsAtX) {
      return;
    }
    var scrollX = Game.Cave.getScrollX();
    var spawnWorldX = scrollX + Game.W + SPAWN_AHEAD_BUFFER;
    var bounds = Game.Cave.getCaveBoundsAtX(spawnWorldX);

    var top = bounds.top + SPAWN_MARGIN;
    var bottom = bounds.bottom - SPAWN_MARGIN;
    var baseY;
    if (top >= bottom) {
      // Gap too narrow for the margin - fall back to the gap's midpoint so
      // we still spawn something reasonable rather than skipping entirely.
      baseY = (bounds.top + bounds.bottom) / 2;
    } else {
      baseY = randRange(top, bottom);
    }

    var isFastVariant = Game.Random.stream('enemies').next() < FAST_VARIANT_CHANCE;
    var bobPhase = Game.Random.stream('enemies').next() * Math.PI * 2;

    // Weave rolls use their own stream and only happen while unlocked, so the
    // 'enemies' sequence is identical to the original game when it is locked.
    var weave = null;
    if (Game.Levels && Game.Levels.unlocked && Game.Levels.unlocked('sineweave')) {
      var ws = Game.Random.stream('enemies-weave');
      if (ws.next() < WEAVE_CHANCE) {
        var period = ws.range(WEAVE_PERIOD_MIN, WEAVE_PERIOD_MAX);
        weave = {
          amp: ws.range(WEAVE_AMPLITUDE_MIN, WEAVE_AMPLITUDE_MAX),
          period: period,
          t: ws.next() * period
        };
      }
    }

    var normal = {
      worldX: spawnWorldX,
      baseY: baseY,
      y: baseY,
      bobPhase: bobPhase,
      isFastVariant: isFastVariant && !weave,
      isWeave: !!weave,
      weaveAmp: weave ? weave.amp : 0,
      weavePeriod: weave ? weave.period : 0,
      weaveT: weave ? weave.t : 0,
      bobAmplitude: isFastVariant ? randRange(FAST_BOB_AMPLITUDE_MIN, FAST_BOB_AMPLITUDE_MAX) : BOB_AMPLITUDE,
      bobFrequency: isFastVariant ? randRange(FAST_BOB_FREQUENCY_MIN, FAST_BOB_FREQUENCY_MAX) : BOB_FREQUENCY,
      flash: false,
      history: newHistory(spawnWorldX - scrollX, baseY),
      histHead: 0
    };

    // Snake roll: own stream, only while unlocked. The normal enemy above is
    // always built first so the 'enemies' stream is consumed identically; a
    // successful roll just swaps it for a snake (if under the live cap).
    var pick = normal;
    if (Game.Levels && Game.Levels.unlocked && Game.Levels.unlocked('snakes')) {
      var ss = Game.Random.stream('enemies-snake');
      if (ss.next() < SNAKE_CHANCE) {
        var sPeriod = ss.range(SNAKE_PERIOD_MIN, SNAKE_PERIOD_MAX);
        var sAmp = ss.range(SNAKE_AMP_MIN, SNAKE_AMP_MAX);
        var sT = ss.next() * sPeriod;
        if (liveSnakes() < SNAKE_MAX_LIVE) {
          pick = makeSnake(spawnWorldX, baseY, sAmp, sPeriod, sT);
        }
      }
    }

    // Ghost roll: own stream, only while unlocked; every parameter is drawn on
    // a successful roll even if the live cap skips it, so consumption is stable.
    if (Game.Levels && Game.Levels.unlocked && Game.Levels.unlocked('phase')) {
      var gs = Game.Random.stream('enemies-ghost');
      if (gs.next() < GHOST_CHANCE) {
        var gOff = gs.next() * GHOST_CYCLE;
        var gPhase = gs.next() * Math.PI * 2;
        var gPeriod = gs.range(GHOST_WANDER_PERIOD_MIN, GHOST_WANDER_PERIOD_MAX);
        if (liveGhosts() < GHOST_MAX_LIVE) {
          pick = makeGhost(spawnWorldX, baseY, gOff, gPhase, gPeriod);
        }
      }
    }

    // Swarm roll: own stream, only while unlocked; replaces whatever was picked
    // above. All member parameters are drawn whenever the roll succeeds, even if
    // the cave gap or the live cap then skips it, so consumption is consistent.
    if (Game.Levels && Game.Levels.unlocked && Game.Levels.unlocked('swarm')) {
      var sw = Game.Random.stream('enemies-swarm');
      if (sw.next() < SWARM_CHANCE) {
        var params = [];
        for (var k = 0; k < SWARM_SIZE; k++) {
          params.push({ ang: sw.next() * Math.PI * 2, u: sw.next(), phase: sw.next() * Math.PI * 2,
            orbitR: sw.range(SWARM_ORBIT_MIN, SWARM_ORBIT_MAX),
            orbitSpeed: sw.range(SWARM_ORBIT_SPEED_MIN, SWARM_ORBIT_SPEED_MAX) });
        }
        if (bounds.bottom - bounds.top >= SWARM_MIN_GAP &&
            liveSwarmMembers() + SWARM_SIZE <= SWARM_MAX_LIVE) {
          Object.keys(swarmInfo).forEach(function (key) {
            if (clock - swarmInfo[key].born > 60) { delete swarmInfo[key]; }
          });
          var members = makeSwarm(spawnWorldX, baseY, params);
          for (var mi = 0; mi < members.length; mi++) { enemies.push(members[mi]); }
          return;
        }
      }
    }
    enemies.push(pick);
  }

  // Projectiles vs one snake: head hit = 1 damage (kill at 0), segment hit = absorbed.
  function hitSnake(snake, projectiles, scrollX) {
    var headHit = SNAKE_HEAD_R + PROJECTILE_HIT_RADIUS;
    for (var pi = projectiles.length - 1; pi >= 0; pi--) {
      var proj = projectiles[pi];
      var px = proj.x + scrollX;
      var dx = px - snake.worldX;
      var dy = proj.y - snake.y;
      if (dx * dx + dy * dy <= headHit * headHit) {
        projectiles.splice(pi, 1);
        snake.hp -= 1;
        snake.flashT = SNAKE_FLASH_TIME;
        snake.flash = true;
        if (snake.hp <= 0) {
          explode(snake);
          score += SNAKE_KILL_SCORE;
          if (Game.Score && Game.Score.addKill) {
            var awarded = Game.Score.addKill(SNAKE_KILL_SCORE);
            if (Game.Effects && Game.Effects.popText) {
              Game.Effects.popText('+' + awarded, snake.worldX - scrollX, snake.y);
            }
          }
          return;
        }
        continue;
      }
      for (var si = 0; si < snake.segs.length; si++) {
        var sg = snake.segs[si];
        var sr = sg.r + PROJECTILE_HIT_RADIUS;
        var sdx = px - sg.worldX;
        var sdy = proj.y - sg.y;
        if (sdx * sdx + sdy * sdy <= sr * sr) {
          projectiles.splice(pi, 1);
          if (Game.Particles && Game.Particles.emit) {
            Game.Particles.emit(proj.x, proj.y, { count: 4, speed: { min: 30, max: 90 },
              life: { min: 0.1, max: 0.25 }, size: { min: 1, max: 2 }, ramp: 'ui' });
          }
          break;
        }
      }
    }
  }

  // Score one shot swarm member; the last member of a swarm shot within
  // SWARM_CLEAR_WINDOW of the first pays the one-off clear bonus.
  function killSwarmMember(m, scrollX) {
    score += SWARM_KILL_SCORE;
    var sx = m.worldX - scrollX;
    if (Game.Score && Game.Score.addKill) {
      var awarded = Game.Score.addKill(SWARM_KILL_SCORE);
      if (Game.Effects && Game.Effects.popText) {
        Game.Effects.popText('+' + awarded, sx, m.y);
      }
    }
    var info = swarmInfo[m.swarmId];
    if (!info) { return; }
    if (info.shot === 0) { info.firstT = clock; }
    info.shot++;
    if (clock - info.firstT > SWARM_CLEAR_WINDOW) { info.failed = true; }
    if (info.shot >= SWARM_SIZE) {
      if (!info.failed) {
        score += SWARM_CLEAR_BONUS;
        if (Game.Score && Game.Score.addDiscovery) { Game.Score.addDiscovery(SWARM_CLEAR_BONUS); }
        if (Game.Effects && Game.Effects.popText) {
          Game.Effects.popText('SWARM +' + SWARM_CLEAR_BONUS, sx, m.y - 12);
        }
      }
      delete swarmInfo[m.swarmId];
    }
  }

  function update(dt) {
    if (dt <= 0) {
      return;
    }

    // Level cleared/finished: hold off spawning (enemies are cleared at level end).
    if (!Game.Levels || !Game.Levels.spawnsEnabled || Game.Levels.spawnsEnabled()) {
      spawnTimer -= dt;
      if (spawnTimer <= 0) {
        spawn();
        resetSpawnTimer();
      }
    }

    var scrollX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;
    clock += dt;
    var shipY = (Game.Ship && Game.Ship.getPosition) ? Game.Ship.getPosition().y : null;

    for (var i = 0; i < enemies.length; i++) {
      var e = enemies[i];
      if (e.isSnake) {
        e.snakeT += dt;
        if (e.flashT > 0) { e.flashT = Math.max(0, e.flashT - dt); }
        e.flash = e.flashT > 0;
        layoutSnake(e);
        continue;
      }
      if (e.isSwarm) {
        e.swarmT += dt;
        e.swarmPhase += e.orbitSpeed * dt;
        if (shipY !== null) {
          var dyh = shipY - (e.baseY + e.slotY);
          var stepH = SWARM_HOMING * dt;
          e.baseY += dyh > stepH ? stepH : (dyh < -stepH ? -stepH : dyh);
        }
        layoutSwarmMember(e);
        continue;
      }
      if (e.isGhost) {
        e.ghostT += dt;
        e.ghostLife += dt;
        if (shipY !== null) {
          var dyg = shipY - e.baseY;
          var stepG = GHOST_HOMING * dt;
          e.baseY += dyg > stepG ? stepG : (dyg < -stepG ? -stepG : dyg);
        }
        layoutGhost(e);
        continue;
      }
      e.bobPhase += e.bobFrequency * dt;
      if (e.isWeave) {
        e.weaveT += dt;
        e.y = clampToCave(weaveY(e.baseY, e.weaveAmp, e.weavePeriod, e.weaveT), e.worldX);
      } else {
        e.y = e.baseY + Math.sin(e.bobPhase) * e.bobAmplitude;
      }
      pushHistory(e, e.worldX - scrollX, e.y);
    }

    // ---- Projectile collision: destroy enemy + projectile, award score. ----
    // Reverse-iterate enemies so splicing mid-loop never skips an element.
    var projectiles = (Game.Projectiles && Game.Projectiles.getAll) ? Game.Projectiles.getAll() : null;
    if (projectiles) {
      for (var ei = enemies.length - 1; ei >= 0; ei--) {
        var enemy = enemies[ei];
        var hitProjectileIndex = -1;
        if (enemy.isSnake) {
          hitSnake(enemy, projectiles, scrollX);
          continue;
        }
        if (enemy.isGhost && !ghostSolid(enemy)) { continue; } // shots pass through
        for (var pi = projectiles.length - 1; pi >= 0; pi--) {
          var proj = projectiles[pi];
          var projWorldX = proj.x + scrollX;
          var dx = projWorldX - enemy.worldX;
          var dy = proj.y - enemy.y;
          var hitRadius = (enemy.isSwarm ? enemy.radius : ENEMY_RADIUS) + PROJECTILE_HIT_RADIUS;
          if ((dx * dx + dy * dy) <= (hitRadius * hitRadius)) {
            hitProjectileIndex = pi;
            break;
          }
        }
        if (hitProjectileIndex !== -1 && enemy.isSwarm) {
          projectiles.splice(hitProjectileIndex, 1);
          explode(enemy, { noBlast: true });
          killSwarmMember(enemy, scrollX);
          continue;
        }
        if (hitProjectileIndex !== -1) {
          projectiles.splice(hitProjectileIndex, 1);
          explode(enemy);
          var killScore = enemy.isGhost ? GHOST_KILL_SCORE : SCORE_PER_KILL + (enemy.isWeave ? WEAVE_KILL_BONUS : 0);
          score += killScore;
          if (Game.Score && Game.Score.addKill) {
            var awarded = Game.Score.addKill(killScore);
            if (Game.Effects && Game.Effects.popText) {
              Game.Effects.popText('+' + awarded, enemy.worldX - scrollX, enemy.y);
            }
          }
        }
      }
    }

    // ---- Cull enemies sufficiently far behind the camera. ----
    for (var ci = enemies.length - 1; ci >= 0; ci--) {
      var screenX = enemies[ci].worldX - scrollX;
      if (screenX < CULL_SCREEN_X) {
        enemies.splice(ci, 1);
      }
    }

    // ---- Advance and cull explosion timers. ----
    for (var xi = explosions.length - 1; xi >= 0; xi--) {
      if (explosions[xi].delay > 0) { explosions[xi].delay -= dt; continue; }
      explosions[xi].timer -= dt;
      if (explosions[xi].timer <= 0) {
        explosions.splice(xi, 1);
      }
    }
  }

  // Layered rounded squares (retro, snapped to the pixel grid) or circles
  // (hi-res): dark outline, body colour alternating teal/amber bands, highlight.
  function drawBall(c, x, y, r, outline, body, hi, P, round) {
    if (round) {
      c.fillStyle = outline; c.beginPath(); c.arc(x, y, r, 0, 6.2832); c.fill();
      c.fillStyle = body; c.beginPath(); c.arc(x, y, r - 1.5, 0, 6.2832); c.fill();
      c.fillStyle = hi; c.beginPath(); c.arc(x - r * 0.3, y - r * 0.3, r * 0.3, 0, 6.2832); c.fill();
      return;
    }
    var x0 = P.snap(x - r), y0 = P.snap(y - r), d = P.snap(2 * r);
    c.fillStyle = outline; c.fillRect(x0, y0, d, d);
    c.fillStyle = body; c.fillRect(x0 + 2, y0 + 2, d - 4, d - 4);
    c.fillStyle = hi; c.fillRect(x0 + 2, y0 + 2, 4, 2);
  }

  function renderSnake(e, scrollX) {
    var T = Game.Theme;
    var r = (T && T.ramp) ? T.ramp('enemySnake') : ['#0E5A5A', '#19B5B5', '#FFB000', '#FFF2B0'];
    var P = Game.Pixel;
    var round = !(P && P.enabled && P.enabled());
    if (!P || !P.snap) { P = { snap: function (v) { return v; } }; }
    var i, sg, sx;
    for (i = e.segs.length - 1; i >= 0; i--) {
      sg = e.segs[i];
      sx = sg.worldX - scrollX;
      if (sx < -20 || sx > Game.W + 20) { continue; }
      drawBall(ctx, sx, sg.y, sg.r, r[0], (i & 1) ? r[2] : r[1], r[3], P, round);
    }
    var hx = e.worldX - scrollX;
    if (hx < -20 || hx > Game.W + 20) { return; }
    var white = (T && T.ramp) ? T.ramp('ui')[3] : '#FFFFFF';
    drawBall(ctx, hx, e.y, SNAKE_HEAD_R, r[0], e.flash ? white : r[1], r[3], P, round);
    // Eye pair on the left (facing) side: white with a dark pupil pixel.
    var ex0 = P.snap(hx - 6), ey0 = P.snap(e.y - 5), ey1 = P.snap(e.y + 1);
    ctx.fillStyle = white;
    ctx.fillRect(ex0, ey0, 4, 4);
    ctx.fillRect(ex0, ey1, 4, 4);
    ctx.fillStyle = r[0];
    ctx.fillRect(ex0, ey0 + 1, 2, 2);
    ctx.fillRect(ex0, ey1 + 1, 2, 2);
  }

  // Pulsing orb: retro = 5x5 snapped diamond, hi-res/plain canvas = glowing circle.
  function renderSwarmMember(e, sx) {
    var T = Game.Theme;
    var r = (T && T.ramp) ? T.ramp('enemySwarm') : ['#5A1A7A', '#E65CFF', '#FFE14D', '#FFFFFF'];
    var P = Game.Pixel;
    var retro = !!(P && P.enabled && P.enabled());
    var pulse = 0.5 + 0.5 * Math.sin(e.swarmPhase * 1.7 + e.swarmT * 6);
    var body = pulse > 0.5 ? r[2] : r[1];
    if (!retro) {
      var rad = e.radius * (0.9 + 0.15 * pulse);
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = r[1];
      ctx.beginPath(); ctx.arc(sx, e.y, rad + 4, 0, 6.2832); ctx.fill();
      ctx.globalAlpha = 1;
      ctx.fillStyle = r[0];
      ctx.beginPath(); ctx.arc(sx, e.y, rad, 0, 6.2832); ctx.fill();
      ctx.fillStyle = body;
      ctx.beginPath(); ctx.arc(sx, e.y, rad - 1.5, 0, 6.2832); ctx.fill();
      ctx.fillStyle = r[3];
      ctx.beginPath(); ctx.arc(sx - 1, e.y - 1, 1.8, 0, 6.2832); ctx.fill();
      return;
    }
    // 5x5 diamond in buffer pixels (u logical px each).
    var u = P.snap(2);
    var cx = P.snap(sx), cy = P.snap(e.y);
    ctx.fillStyle = r[0];
    ctx.fillRect(cx - 2 * u, cy - u, 5 * u, 3 * u);
    ctx.fillRect(cx - u, cy - 2 * u, 3 * u, 5 * u);
    ctx.fillStyle = body;
    ctx.fillRect(cx - u, cy - u, 3 * u, 3 * u);
    ctx.fillStyle = r[3];
    ctx.fillRect(cx, cy - u, u, u);
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    var scrollX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;

    for (var i = 0; i < enemies.length; i++) {
      var e = enemies[i];
      var screenX = e.worldX - scrollX;

      // Cull off-screen draws (kept in the update list until CULL_SCREEN_X).
      // A snake's body trails to the right of its head, so it stays visible
      // for ~70px after the head leaves the left edge.
      if (screenX < -ENEMY_RADIUS - (e.isSnake ? 70 : 0) || screenX > Game.W + ENEMY_RADIUS) {
        continue;
      }

      if (e.isSnake) {
        renderSnake(e, scrollX);
        continue;
      }
      if (e.isSwarm || e.isGhost) { continue; } // drawn above the headlamp darkness by renderSwarm/renderGhosts
      var swap = e.isFastVariant ? FAST_SWAP : (e.isWeave ? WEAVE_SWAP : null);
      var frame = blinkFrame(e.bobPhase);
      var sname = spriteName(e);

      // Fast variant: afterimages (2nd, 4th, 6th most recent positions).
      if (e.isFastVariant && e.history) {
        for (var ti = 0; ti < TRAIL_STEPS.length; ti++) {
          var h = e.history[(e.histHead - (TRAIL_STEPS[ti] - 1) + HISTORY_LEN * 2) % HISTORY_LEN];
          Game.Sprite.draw(ctx, sname, frame, h.x, h.y,
            { swap: swap, alpha: TRAIL_ALPHAS[ti] });
        }
      }

      Game.Sprite.draw(ctx, sname, frame, screenX, e.y,
        { swap: swap, flash: !!e.flash });
    }

    for (var j = 0; j < explosions.length; j++) {
      var ex = explosions[j];
      if (ex.delay > 0) { continue; }
      var exScreenX = ex.worldX - scrollX;

      if (exScreenX < -ENEMY_RADIUS || exScreenX > Game.W + ENEMY_RADIUS) {
        continue;
      }

      var xframe = Math.min(EXPLOSION_FRAMES - 1,
        Math.floor((1 - ex.timer / EXPLOSION_DURATION) * EXPLOSION_FRAMES));
      Game.Sprite.draw(ctx, 'explosion', xframe, exScreenX, ex.y);
    }
  }

  // Swarm orbs are drawn from main.js after the lighting overlay (like the
  // dragon) so the bright glow reads even in unlit stretches of cave.
  function renderSwarm(rctx) {
    ctx = rctx || Game.ctx;
    var scrollX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;
    for (var i = 0; i < enemies.length; i++) {
      var e = enemies[i];
      if (!e.isSwarm) { continue; }
      var sx = e.worldX - scrollX;
      if (sx < -SWARM_RADIUS - 8 || sx > Game.W + SWARM_RADIUS + 8) { continue; }
      renderSwarmMember(e, sx);
    }
  }

  // Dome body rows as [first, last] cell columns of a 12-wide grid.
  var GHOST_ROWS = [[4, 7], [2, 9], [1, 10], [1, 10], [0, 11], [0, 11], [0, 11], [0, 11], [0, 11], [0, 11]];

  // Retro ghost: chunky cells of size u. expand grows the silhouette by that
  // many cells on every side (used for the outline and the solid tell).
  function ghostCells(cx, cy, u, expand, color, wave) {
    var x0 = cx - 6 * u, y0 = cy - 6 * u, r, c, row;
    ctx.fillStyle = color;
    for (r = 0; r < GHOST_ROWS.length; r++) {
      row = GHOST_ROWS[r];
      ctx.fillRect(x0 + (row[0] - expand) * u, y0 + (r - (r === 0 ? expand : 0)) * u,
        (row[1] - row[0] + 1 + 2 * expand) * u, u * (r === 0 ? 1 + expand : 1));
    }
    // Wavy hem: two rows of teeth that shift with the wave phase.
    for (c = 0; c < 12; c++) {
      if (((c + wave) % 3) !== 2) { ctx.fillRect(x0 + c * u, y0 + 10 * u, u, u + (expand ? u : 0)); }
      if (((c + wave) % 3) === 0) { ctx.fillRect(x0 + c * u, y0 + 11 * u, u, u); }
    }
  }

  function renderGhost(e, sx) {
    var T = Game.Theme;
    var r = (T && T.ramp) ? T.ramp('ghost') : ['#0B2A5C', '#BFEFFF', '#EAFBFF', '#FFFFFF'];
    var P = Game.Pixel;
    var retro = !!(P && P.enabled && P.enabled());
    var solid = ghostSolid(e);
    var a = e.ghostAlpha;
    if (!solid) { a = Math.max(0.2, a + 0.07 * Math.sin(e.ghostLife * 38)); } // ghostly flicker
    // Tell: bright outline pulse during the fade back in, just before solid.
    var cyc = e.ghostT - Math.floor(e.ghostT / GHOST_CYCLE) * GHOST_CYCLE;
    var tell = cyc >= GHOST_CYCLE - GHOST_FADE_T;
    var wave = Math.floor(e.ghostLife * 6) % 3;
    var cy = e.y + Math.sin(e.ghostLife * 5) * 1.5;
    ctx.globalAlpha = a;
    if (!retro) {
      var rad = GHOST_RADIUS;
      ctx.globalAlpha = a * 0.3;
      ctx.fillStyle = r[1];
      ctx.beginPath(); ctx.arc(sx, cy, rad + 7, 0, 6.2832); ctx.fill();
      ctx.globalAlpha = a;
      ctx.beginPath();
      ctx.arc(sx, cy - 2, rad, Math.PI, 0);
      ctx.lineTo(sx + rad, cy + rad);
      var seg = (2 * rad) / 4;
      for (var k = 0; k < 4; k++) {
        var x1 = sx + rad - (k + 1) * seg;
        ctx.quadraticCurveTo(x1 + seg / 2, cy + rad + (((k + wave) & 1) ? -5 : 3), x1, cy + rad);
      }
      ctx.closePath();
      ctx.fillStyle = r[1]; ctx.fill();
      if (solid || tell) {
        ctx.strokeStyle = tell ? r[3] : r[0];
        ctx.lineWidth = tell ? 2 : 1;
        ctx.stroke();
      }
      ctx.fillStyle = r[2];
      ctx.beginPath(); ctx.arc(sx - 4, cy - 6, 3.5, 0, 6.2832); ctx.fill();
      ctx.fillStyle = r[0];
      ctx.beginPath(); ctx.arc(sx - 4.5, cy - 2, 2.4, 0, 6.2832); ctx.fill();
      ctx.beginPath(); ctx.arc(sx + 4.5, cy - 2, 2.4, 0, 6.2832); ctx.fill();
    } else {
      var u = P.snap(2);
      var gx = P.snap(sx), gy = P.snap(cy);
      if (tell) { ghostCells(gx, gy, u, 1, r[3], wave); }
      else if (solid) { ghostCells(gx, gy, u, 1, r[0], wave); }
      ghostCells(gx, gy, u, 0, r[1], wave);
      ctx.fillStyle = r[2];
      ctx.fillRect(gx - 5 * u, gy - 4 * u, 2 * u, 2 * u);
      ctx.fillStyle = r[0];
      ctx.fillRect(gx - 3 * u, gy - 2 * u, 2 * u, 3 * u);
      ctx.fillRect(gx + 1 * u, gy - 2 * u, 2 * u, 3 * u);
    }
    ctx.globalAlpha = 1;
  }

  // Ghosts are drawn from main.js after the lighting overlay so they stay
  // visible inside rock and in the dark.
  function renderGhosts(rctx) {
    ctx = rctx || Game.ctx;
    var scrollX = (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;
    for (var i = 0; i < enemies.length; i++) {
      var e = enemies[i];
      if (!e.isGhost) { continue; }
      var sx = e.worldX - scrollX;
      if (sx < -GHOST_RADIUS - 12 || sx > Game.W + GHOST_RADIUS + 12) { continue; }
      renderGhost(e, sx);
    }
  }

  function getAll() {
    return enemies;
  }

  function getScore() {
    return score;
  }

  Game.Enemies = {
    update: update,
    render: render,
    renderSwarm: renderSwarm,
    renderGhosts: renderGhosts,
    ghostAlpha: ghostAlpha,
    GHOST_CYCLE: GHOST_CYCLE,
    GHOST_SOLID_ALPHA: GHOST_SOLID_ALPHA,
    reset: reset,
    clearAll: clearAll,
    explode: explode,
    getAll: getAll,
    getScore: getScore,
    weaveY: weaveY,
    clampToCave: clampToCave,
    SNAKE_SEG_SPACING: SNAKE_SEG_SPACING,
    SNAKE_LAG: SNAKE_LAG,
    ENEMY_RADIUS: ENEMY_RADIUS
  };
})();
