// Spelunker - sweeping dragon (campaign mechanic 'dragon').
// Vanilla JS, no build tools. Attaches to window.Game.
//
// NOT a boss fight: no arena, no health bar. One event at a time. Each event
// starts with a 1.5 s TELEGRAPH (no dragon exists, nothing can hurt the ship):
// a pulsing '!' and arrow at the LEFT screen edge, a flash strip, dust and a
// dotted preview of the arc. Then the dragon enters from behind (the left edge)
// and sweeps across the screen in SWEEP_TIME seconds, then leaves on the right
// (or dies to 6 head shots).
//
// Frame of reference: the dragon moves in SCREEN space (like projectiles), x from
// -60 to W+60 at a constant rate. Each body part's y is derived EVERY frame from
// the cave bounds at that part's own worldX (scrollX + screen x): a fraction of
// the local gap (0.5 +- ARC_AMP * sin(pi * progress)) plus a body wave, then
// clamped inside the cave with Game.Enemies.clampToCave so it never touches a
// wall. Parts trail the head along the same path (spacing along x, time lag in
// progress), so the body follows the head's arc like a snake.
//
// Fairness: the ship sits at screen x ~100. The head reaches x=100 at ~21% of
// the sweep where the arc has only drifted ~16% of the gap off-centre, and the
// whole body at that x occupies a narrow vertical band (see body-band test), so
// the ship can always dodge vertically. The event is postponed while the gap at
// the ship is below MIN_GAP.
//
// Own random stream 'dragon', touched only while Levels.unlocked('dragon'), so
// locked/endless runs are byte-identical. render()/renderWarning() are called by
// main.js AFTER the headlamp darkness so the dragon is never dimmed.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('dragon.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;

  // ---- Tuning ----
  var FIRST_DELAY = 8; // seconds after unlock before the first event
  var INTERVAL_MIN = 14; // seconds between events, scaled by Difficulty.spawnFactor()
  var INTERVAL_MAX = 22;
  var RETRY_DELAY = 2; // postponement when the cave is too narrow
  var MIN_GAP = 90; // px, gap at the ship below which no dragon starts
  var TELEGRAPH = 1.5;
  var SWEEP_TIME = 4.0; // seconds for the head to cross X_START..X_END
  var X_START = -60;
  var X_END_MARGIN = 60;
  var ARC_AMP_MIN = 0.22; // fraction of the local gap, peak drift off-centre
  var ARC_AMP_MAX = 0.30;
  var WAVE_AMP = 8; // px body wave
  var WAVE_SPEED = 5; // rad/s
  var WAVE_PHASE = 0.8; // rad per segment
  var HEAD_R = 16;
  var SEG_COUNT = 8;
  var SEG_R_FIRST = 12; // tapers by 1 px per segment to 5
  var SEG_SPACING = 14; // px along x
  var HEAD_HP = 6;
  var KILL_SCORE = 500;
  var HIT_DAMAGE = 30;
  var FLASH_TIME = 0.12;
  var PROJECTILE_R = 4;
  var CLEAR_MARGIN = 2; // px kept off the walls in addition to the part radius
  var FLAP_SPEED = 9;
  var DUST_INTERVAL = 0.06;

  // ev: the current event or null. phase 'tele' or 'live'.
  var ev = null;
  var live = []; // 0 or 1 events (the live one), exposed via getAll()
  var spawnTimer = -1; // < 0 means "arm on the next unlocked update"

  // Preallocated body: parts[0] is the head, parts[1..SEG_COUNT] the segments.
  var parts = [];
  (function () {
    for (var i = 0; i <= SEG_COUNT; i++) {
      parts.push({ x: 0, y: 0, r: i === 0 ? HEAD_R : SEG_R_FIRST - (i - 1) });
    }
  })();

  function stream() { return Game.Random.stream('dragon'); }

  function isUnlocked() {
    return !!(Game.Levels && Game.Levels.unlocked && Game.Levels.unlocked('dragon'));
  }
  function spawnsEnabled() {
    return !(Game.Levels && Game.Levels.spawnsEnabled) || Game.Levels.spawnsEnabled();
  }
  function invulnerable() {
    return !!(Game.Levels && Game.Levels.playerInvulnerable && Game.Levels.playerInvulnerable());
  }
  function scrollX() {
    return (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;
  }
  function bounds(x) { return Game.Cave.getCaveBoundsAtX(x); }
  function snapV(P, n) { return P && P.snap ? P.snap(n) : n; }

  function clampY(y, worldX, margin) {
    if (Game.Enemies && Game.Enemies.clampToCave) { return Game.Enemies.clampToCave(y, worldX, margin); }
    var b = bounds(worldX);
    var lo = b.top + margin, hi = b.bottom - margin;
    if (lo > hi) { return (b.top + b.bottom) / 2; }
    return y < lo ? lo : (y > hi ? hi : y);
  }

  function spanPx() { return (Game.W || 640) + X_END_MARGIN - X_START; }

  // Cave-fraction of the arc at progress p (0..1); dir is +1 (dips) or -1 (rises).
  function arcFrac(dir, amp, p) {
    var q = p < 0 ? 0 : (p > 1 ? 1 : p);
    return 0.5 + dir * amp * Math.sin(Math.PI * q);
  }

  function rollTimer() {
    var f = (Game.Difficulty && Game.Difficulty.spawnFactor) ? Game.Difficulty.spawnFactor() : 1;
    spawnTimer = stream().range(INTERVAL_MIN, INTERVAL_MAX) * f;
  }

  function reset() {
    ev = null;
    live.length = 0;
    spawnTimer = -1;
  }

  function endEvent() {
    ev = null;
    live.length = 0;
    rollTimer();
  }

  function startEvent() {
    if (!Game.Cave || !Game.Cave.getCaveBoundsAtX) { return; }
    var b = bounds(scrollX() + 100);
    if (b.bottom - b.top < MIN_GAP) {
      spawnTimer = RETRY_DELAY; // too cramped to dodge in; try again shortly
      return;
    }
    var s = stream();
    var dir = s.next() < 0.5 ? -1 : 1;
    var amp = s.range(ARC_AMP_MIN, ARC_AMP_MAX);
    ev = { phase: 'tele', t: 0, dir: dir, amp: amp, hp: HEAD_HP, flashT: 0, flash: false,
      hurt: false, dust: 0, flap: 0, parts: parts, head: parts[0] };
  }

  // Recompute every part's screen x and y for the event's current time.
  function layout() {
    var sx = scrollX();
    var span = spanPx();
    var head = ev.t / SWEEP_TIME;
    var lag = SEG_SPACING / span; // progress per segment spacing
    for (var i = 0; i <= SEG_COUNT; i++) {
      var pt = parts[i];
      var p = head - i * lag;
      pt.x = X_START + span * p;
      var wx = sx + pt.x;
      var b = bounds(wx);
      var y = b.top + (b.bottom - b.top) * arcFrac(ev.dir, ev.amp, p) +
        WAVE_AMP * Math.sin(ev.t * WAVE_SPEED - i * WAVE_PHASE);
      pt.y = clampY(y, wx, pt.r + CLEAR_MARGIN);
    }
  }

  function goLive() {
    ev.phase = 'live';
    ev.t = 0;
    layout();
    live.length = 0;
    live.push(ev);
  }

  function dust(dt) {
    if (!Game.Particles || !Game.Particles.emit) { return; }
    ev.dust -= dt;
    if (ev.dust > 0) { return; }
    ev.dust = DUST_INTERVAL;
    var b = bounds(scrollX() + 4);
    var fr = arcFrac(ev.dir, ev.amp, 0);
    Game.Particles.emit(4, b.top + (b.bottom - b.top) * fr + (Math.random() - 0.5) * 40,
      { count: 2, angle: 0, spread: 0.8, speed: { min: 30, max: 90 },
        life: { min: 0.3, max: 0.6 }, size: { min: 1, max: 2 }, ramp: 'rock', gravity: 40 });
  }

  function killDragon() {
    var sx = scrollX();
    var h = parts[0];
    var awarded = KILL_SCORE;
    if (Game.Score && Game.Score.addKill) {
      awarded = Game.Score.addKill(KILL_SCORE);
    }
    if (Game.Effects && Game.Effects.popText) { Game.Effects.popText('+' + awarded, h.x, h.y); }
    if (Game.Enemies && Game.Enemies.explode) {
      // Reuse the snake chain-pop: the head explodes, then each segment pops a
      // beat later (explode() reads isSnake + segs for the delayed explosions).
      var segs = [];
      for (var i = 1; i <= SEG_COUNT; i++) {
        segs.push({ worldX: sx + parts[i].x, y: parts[i].y });
      }
      Game.Enemies.explode({ worldX: sx + h.x, y: h.y, isSnake: true, segs: segs }, { noBlast: true });
    } else if (Game.Particles && Game.Particles.emit) {
      for (var j = 0; j <= SEG_COUNT; j++) {
        Game.Particles.emit(parts[j].x, parts[j].y, { count: 10, speed: { min: 40, max: 140 },
          life: { min: 0.25, max: 0.6 }, size: { min: 1, max: 2 }, ramp: 'fire' });
      }
    }
    if (Game.Camera && Game.Camera.shake) { Game.Camera.shake(5, 0.35); }
    endEvent();
  }

  // Projectiles (screen space): head hit = 1 damage, segment hit = absorbed.
  function hitByProjectiles() {
    var list = (Game.Projectiles && Game.Projectiles.getAll) ? Game.Projectiles.getAll() : null;
    if (!list) { return false; }
    var h = parts[0];
    var hr = HEAD_R + PROJECTILE_R;
    for (var pi = list.length - 1; pi >= 0; pi--) {
      var pr = list[pi];
      var dx = pr.x - h.x, dy = pr.y - h.y;
      if (dx * dx + dy * dy <= hr * hr) {
        list.splice(pi, 1);
        ev.hp -= 1;
        ev.flashT = FLASH_TIME;
        ev.flash = true;
        if (ev.hp <= 0) { killDragon(); return true; }
        continue;
      }
      for (var si = 1; si <= SEG_COUNT; si++) {
        var sg = parts[si];
        var rr = sg.r + PROJECTILE_R;
        var sdx = pr.x - sg.x, sdy = pr.y - sg.y;
        if (sdx * sdx + sdy * sdy <= rr * rr) {
          list.splice(pi, 1);
          if (Game.Particles && Game.Particles.emit) {
            Game.Particles.emit(pr.x, pr.y, { count: 4, speed: { min: 30, max: 90 },
              life: { min: 0.1, max: 0.25 }, size: { min: 1, max: 2 }, ramp: 'ui' });
          }
          break;
        }
      }
    }
    return false;
  }

  function hitShip() {
    if (ev.hurt || invulnerable()) { return; }
    if (!Game.Ship || !Game.Ship.getPosition) { return; }
    var pos = Game.Ship.getPosition();
    var shipX = pos.worldX - scrollX();
    var sr = Game.Ship.SHIP_RADIUS || 10;
    for (var i = 0; i <= SEG_COUNT; i++) {
      var pt = parts[i];
      var reach = sr + pt.r - 2;
      var dx = shipX - pt.x, dy = pos.y - pt.y;
      if (dx * dx + dy * dy <= reach * reach) {
        if (Game.Collision && Game.Collision.damageShield) { Game.Collision.damageShield(HIT_DAMAGE); }
        if (Game.Ship.triggerHitFlash) { Game.Ship.triggerHitFlash(); }
        if (Game.Camera && Game.Camera.shake) { Game.Camera.shake(5, 0.25); }
        ev.hurt = true; // once per event pass, however long the ship stays in contact
        return;
      }
    }
  }

  function updateLive(dt) {
    ev.t += dt;
    ev.flap += dt;
    if (ev.flashT > 0) { ev.flashT = Math.max(0, ev.flashT - dt); }
    ev.flash = ev.flashT > 0;
    layout();
    if (hitByProjectiles()) { return; }
    hitShip();
    // Gone once the tail has left the right edge.
    if (parts[SEG_COUNT].x > (Game.W || 640) + SEG_R_FIRST + 10) { endEvent(); }
  }

  function update(dt) {
    if (!(dt > 0)) { return; }
    if (!isUnlocked()) {
      // Locked, endless, or the level just ended: drop any event, touch nothing else.
      if (ev || spawnTimer >= 0) { ev = null; live.length = 0; spawnTimer = -1; }
      return;
    }
    if (!ev) {
      if (!spawnsEnabled()) { return; }
      if (spawnTimer < 0) { spawnTimer = FIRST_DELAY; }
      spawnTimer -= dt;
      if (spawnTimer <= 0) { startEvent(); if (!ev && spawnTimer <= 0) { rollTimer(); } }
      return;
    }
    if (ev.phase === 'tele') {
      ev.t += dt;
      dust(dt);
      if (ev.t >= TELEGRAPH) { goLive(); }
      return;
    }
    updateLive(dt);
  }

  // ---- Rendering ----
  function disc(P, cx, cy, rad, step) {
    for (var dy = -rad; dy < rad; dy += step) {
      var m = Math.abs(dy + step / 2);
      var hw = Math.sqrt(Math.max(0, rad * rad - m * m));
      var x0 = snapV(P, cx - hw), x1 = snapV(P, cx + hw);
      ctx.fillRect(x0, snapV(P, cy + dy), Math.max(step, x1 - x0), step);
    }
  }

  function ball(P, retro, step, x, y, r) {
    if (retro) {
      disc(P, snapV(P, x), snapV(P, y), r, step);
    } else {
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function tri(P, ax, ay, bx, by, cx, cy) {
    ctx.beginPath();
    ctx.moveTo(snapV(P, ax), snapV(P, ay));
    ctx.lineTo(snapV(P, bx), snapV(P, by));
    ctx.lineTo(snapV(P, cx), snapV(P, cy));
    ctx.closePath();
    ctx.fill();
  }

  function renderWings(P, c, anchor, flap) {
    // Two bat-style triangles on the shoulders, drawn over the body: far wing
    // (jade) and near wing (gold) flapping out of phase; tips swing up and back.
    var f = Math.sin(flap * FLAP_SPEED);
    var hFar = 14 + (f * 0.5 + 0.5) * 34;
    var hNear = 14 + (-f * 0.5 + 0.5) * 34;
    var bx = anchor.x, by = anchor.y - anchor.r + 2;
    ctx.fillStyle = c[0];
    tri(P, bx + 12, by + 3, bx - 18, by + 3, bx - 44, by - hFar - 3);
    ctx.fillStyle = c[1];
    tri(P, bx + 10, by + 1, bx - 16, by + 1, bx - 41, by - hFar * 0.95);
    ctx.fillStyle = c[0];
    tri(P, bx + 14, by + 5, bx - 12, by + 5, bx - 8, by - hNear - 3);
    ctx.fillStyle = c[2];
    tri(P, bx + 12, by + 3, bx - 10, by + 3, bx - 6, by - hNear * 0.95);
    ctx.fillStyle = c[3]; // bright membrane highlight
    tri(P, bx + 6, by + 2, bx - 6, by + 2, bx - 3, by - hNear * 0.55);
  }

  function render(rctx) {
    ctx = rctx || Game.ctx;
    if (!ev || ev.phase !== 'live') { return; }
    var T = Game.Theme;
    var c = (T && T.ramp) ? T.ramp('dragon') : ['#0E5A3A', '#19B57A', '#FFC820', '#F0FFE0'];
    var white = (T && T.ramp) ? T.ramp('ui')[3] : '#FFFFFF';
    var P = Game.Pixel;
    var step = (P && P.SCALE) ? P.SCALE : 2;
    var retro = !!(P && P.enabled && P.enabled());
    var i, pt, x, y, r;
    ctx.save();
    // Body: tail first so the head overlaps. Outline, scales, belly, dorsal spine.
    for (i = SEG_COUNT; i >= 1; i--) {
      pt = parts[i];
      x = pt.x; y = pt.y; r = pt.r;
      if (x < -r - 8 || x > Game.W + r + 8) { continue; }
      ctx.fillStyle = c[0];
      ball(P, retro, step, x, y, r + 1.5);
      ctx.fillStyle = (i & 1) ? c[1] : c[2];
      ball(P, retro, step, x, y - 0.5, r - 0.5);
      ctx.fillStyle = c[3]; // bright belly crescent
      ball(P, retro, step, x, y + r * 0.45, r * 0.5);
      ctx.fillStyle = (i & 1) ? c[2] : c[1]; // dorsal spine tip
      tri(P, x - 3, y - r + 1, x + 3, y - r + 1, x, y - r - 4);
    }
    renderWings(P, c, parts[2], ev.flap);
    // Head, facing right.
    pt = parts[0];
    x = pt.x; y = pt.y; r = HEAD_R;
    if (x > -r - 20 && x < Game.W + r + 20) {
      ctx.fillStyle = c[0];
      ball(P, retro, step, x, y, r + 1.5);
      ctx.fillStyle = ev.flash ? white : c[1];
      ball(P, retro, step, x, y - 0.5, r - 1);
      // Snout, jaw and glowing mouth.
      ctx.fillStyle = ev.flash ? white : c[1];
      ctx.fillRect(snapV(P, x + 6), snapV(P, y - 5), 14, 10);
      ctx.fillStyle = c[0];
      ctx.fillRect(snapV(P, x + 6), snapV(P, y + 4), 15, 2);
      ctx.fillStyle = '#FFB020';
      ctx.fillRect(snapV(P, x + 10), snapV(P, y + 4), 10, 2);
      ctx.fillStyle = c[3];
      ctx.fillRect(snapV(P, x + 16), snapV(P, y + 4), 4, 2);
      ctx.fillStyle = c[0]; // nostril
      ctx.fillRect(snapV(P, x + 17), snapV(P, y - 3), 2, 2);
      // Horns sweeping back and up.
      ctx.fillStyle = c[2];
      tri(P, x - 6, y - 10, x - 20, y - 22, x - 1, y - 14);
      tri(P, x - 1, y - 12, x - 12, y - 25, x + 4, y - 15);
      // Eye: white with a dark pupil, over a gold brow.
      ctx.fillStyle = c[2];
      ctx.fillRect(snapV(P, x + 1), snapV(P, y - 10), 10, 3);
      ctx.fillStyle = white;
      ctx.fillRect(snapV(P, x + 3), snapV(P, y - 7), 6, 5);
      ctx.fillStyle = c[0];
      ctx.fillRect(snapV(P, x + 6), snapV(P, y - 6), 3, 4);
    }
    ctx.restore();
  }

  // Telegraph cue: bright, drawn above the headlamp darkness.
  function renderWarning(rctx) {
    ctx = rctx || Game.ctx;
    if (!ev || ev.phase !== 'tele') { return; }
    var T = Game.Theme;
    var c = (T && T.ramp) ? T.ramp('boulderWarn') : ['#FF2020', '#FF8800', '#FFE040', '#FFFFFF'];
    var P = Game.Pixel;
    var sx = scrollX();
    var on = Math.floor(ev.t * 8) % 2 === 0;
    var fg = on ? c[3] : c[2], bg = c[1];
    var b0 = bounds(sx + 20);
    var y0 = b0.top + (b0.bottom - b0.top) * arcFrac(ev.dir, ev.amp, 0);
    var k, x, y;
    ctx.save();
    // Faint flash strip along the left edge, building up.
    ctx.globalAlpha = (on ? 0.35 : 0.18) * (0.4 + 0.6 * Math.min(1, ev.t / TELEGRAPH));
    ctx.fillStyle = c[2];
    ctx.fillRect(0, b0.top, 8, b0.bottom - b0.top);
    ctx.globalAlpha = 0.45;
    // Dotted arc preview across the screen.
    ctx.fillStyle = fg;
    var W = Game.W || 640;
    var span = spanPx();
    for (k = 0; k < 28; k++) {
      x = 16 + k * 22;
      var p = (x - X_START) / span;
      var b = bounds(sx + x);
      y = b.top + (b.bottom - b.top) * arcFrac(ev.dir, ev.amp, p);
      if (x < W - 8) { ctx.fillRect(snapV(P, x), snapV(P, y), 4, 4); }
    }
    ctx.globalAlpha = 1;
    // Right-pointing arrow and '!' glyph at the left edge.
    x = 14;
    y = snapV(P, y0);
    for (k = 0; k < 7; k++) {
      ctx.fillStyle = bg;
      ctx.fillRect(x + 24 + (6 - k) * 3 - 2, y - (k + 1) * 3 - 2, 3 + 2, (k + 1) * 6 + 4);
    }
    for (k = 0; k < 7; k++) {
      ctx.fillStyle = fg;
      ctx.fillRect(x + 24 + (6 - k) * 3, y - (k + 1) * 3, 3, (k + 1) * 6);
    }
    ctx.fillStyle = bg;
    ctx.fillRect(x - 2, y - 22, 14, 34);
    ctx.fillStyle = fg;
    ctx.fillRect(x + 1, y - 19, 8, 22); // exclamation bar
    ctx.fillRect(x + 1, y + 6, 8, 5); // exclamation dot
    ctx.restore();
  }

  function getAll() { return live; }

  Game.Dragon = {
    update: update,
    render: render,
    renderWarning: renderWarning,
    reset: reset,
    getAll: getAll,
    getEvent: function () { return ev; },
    getParts: function () { return parts; },
    arcFrac: arcFrac,
    TELEGRAPH: TELEGRAPH,
    SWEEP_TIME: SWEEP_TIME,
    FIRST_DELAY: FIRST_DELAY,
    HEAD_HP: HEAD_HP,
    KILL_SCORE: KILL_SCORE,
    HIT_DAMAGE: HIT_DAMAGE,
    SEG_COUNT: SEG_COUNT,
    MIN_GAP: MIN_GAP
  };
})();
