// Spelunker - the "Little" Fugue in G minor, BWV 578, by J. S. Bach.
//
// GENERATED FILE - DO NOT EDIT BY HAND. Regenerate with:
//   node tools/midi-to-measures.js --piece 578 --format game-js --out music-bach-578.js
// Source: tools/sources/bwv578-fugue.mid, a user-supplied MIDI whose upstream
// and licence are unknown (the composition itself is public domain).
// Notes are snapped to a 1/32-whole-note grid and split into monophonic
// keyboard tracks. Sections come from tools/sources/bwv578-sections.json:
// one constant-tempo body plus the final ritardando as short sections.
// Each tempo section is a separate score because the parser supports one
// tempo per notation. Sections play back to back; no trailing pause is added.

var Bach578ScoreHelpers = (typeof window !== 'undefined' && window.MusicScore)
  ? window.MusicScore
  : require('./music-score.js');

// ---- Section 1: measures 1-64, 96 bpm ----
var FUGUE_578_TRACKS = {
  v1: {
    instrument: 'organ',
    header: '# BWV 578 voice 1.'
  },
  v2: {
    instrument: 'organ',
    header: '# BWV 578 voice 2.'
  },
  v3: {
    instrument: 'organ',
    header: '# BWV 578 voice 3.'
  },
  v4: {
    instrument: 'organ',
    header: '# BWV 578 voice 4.'
  }
};

var FUGUE_578_MEASURES = [
  {
    label: '# Measure 1',
    v1: ['R,1'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['G4,4 D5,4 A#4,4. A4,8']
  },
  {
    label: '# Measure 2',
    v1: ['R,1'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['G4,8 A#4,8 A4,8 G4,8 F#4,8 A4,8 D4,4']
  },
  {
    label: '# Measure 3',
    v1: ['R,1'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['G4,8 D4,8 A4,8 D4,8 A#4,8 A4,16 G4,16 A4,8 D4,8']
  },
  {
    label: '# Measure 4',
    v1: ['R,1'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['G4,8 D4,16 G4,16 A4,8 D4,16 A4,16 A#4,8 A4,16 G4,16 A4,16 D4,16 D5,16 C5,16']
  },
  {
    label: '# Measure 5',
    v1: ['R,1'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['A#4,16 A4,16 G4,16 A#4,16 A4,16 G4,16 F#4,16 A4,16 G4,16 D4,16 G4,16 A4,16 A#4,16 C5,16 D5,16 E5,16']
  },
  {
    label: '# Measure 6',
    v1: ['F5,16 E5,16 D5,16 F5,16 E5,16 D5,16 C#5,16 E5,16 D5,8 A4,8 D5,8 E5,8'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['D4,4 A4,4 F4,4. E4,8']
  },
  {
    label: '# Measure 7',
    v1: ['F5,16 G5,16 F5,16 G5,16 A5,32 G5,32 A5,32 G5,32 A5,32 G5,32 F5,32 G5,32 A5,16 G5,16 A5,16 A#5,16 A5,16 G5,16 F5,16 E5,16'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['D4,8 F4,8 E4,8 D4,8 C#4,8 E4,8 A3,4']
  },
  {
    label: '# Measure 8',
    v1: ['F5,16 A5,16 G5,16 A5,16 C#5,16 A5,16 G5,16 A5,16 D5,16 A5,16 G5,16 A5,16 C#5,16 A5,16 G5,16 A5,16'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['D4,8 A3,8 E4,8 A3,8 F4,8 E4,16 D4,16 E4,8 A3,8']
  },
  {
    label: '# Measure 9',
    v1: ['F5,16 D5,16 C#5,16 D5,16 G5,16 D5,16 C#5,16 D5,16 A5,16 D5,16 C#5,16 D5,16 G5,16 D5,16 A4,16 G4,16'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['D4,8 A3,16 D4,16 E4,8 A3,16 E4,16 F4,8 E4,16 D4,16 E4,16 A3,16 C#5,16 D5,16']
  },
  {
    label: '# Measure 10',
    v1: ['F4,16 E4,16 D4,16 F4,16 E4,16 D4,16 C#4,16 E4,16 D4,16 A3,16 A4,8 D5,8 F5,8'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['A4,8 F5,8 G4,8 E5,8 F4,8 D4,16 E4,16 F4,16 G4,16 A4,16 B4,16']
  },
  {
    label: '# Measure 11',
    v1: ['D#5,8 A5,8 R,8 D#5,8 D5,8 G5,8 R,8 D5,8'],
    v2: ['R,1'],
    v3: ['R,1'],
    v4: ['C5,16 A#4,16 C5,16 D5,16 C5,16 A#4,16 A4,16 C5,16 A#4,16 A4,16 A#4,16 C5,16 A#4,16 A4,16 G4,16 A#4,16']
  },
  {
    label: '# Measure 12',
    v1: ['C5,16 A#4,16 C5,16 D5,16 C5,16 A5,16 G5,16 A5,16 G4,4 D4,4'],
    v2: ['R,1'],
    v3: ['R,2 A#4,16 G5,16 F#5,16 G5,16 A4,16 F#5,16 E5,16 F#5,16'],
    v4: ['A4,8 G4,8 F#4,8 D4,8 G3,4 R,4']
  },
  {
    label: '# Measure 13',
    v1: ['R,8 D4,8 G4,8 A4,8 A#4,16 C5,16 A#4,16 C5,16 D5,32 C5,32 D5,32 C5,32 D5,32 C5,32 A#4,32 C5,32'],
    v2: ['R,1'],
    v3: ['G5,2 R,2'],
    v4: ['A#3,4. A3,8 G3,8 A#3,8 A3,8 G3,8']
  },
  {
    label: '# Measure 14',
    v1: ['D5,16 C5,16 D5,16 D#5,16 D5,16 C5,16 A#4,16 A4,16 D4,8 R,8 A3,8 D3,8'],
    v2: ['R,1'],
    v3: ['R,2 A#4,16 D5,16 C5,16 D5,16 F#4,16 D5,16 C5,16 D5,16'],
    v4: ['F#3,8 A3,8 D3,4 G3,8 D3,8 C4,8 R,8']
  },
  {
    label: '# Measure 15',
    v1: ['D4,8 R,8 C4,8 R,8. G4,16 F#4,16 G4,16 R,16 G4,16 F#4,16 G4,16'],
    v2: ['R,1'],
    v3: ['G4,16 D5,16 C5,16 D5,16 F#4,16 D5,16 C5,16 D5,16 A#4,4 C5,4'],
    v4: ['A#3,8 A3,16 G3,16 A3,8 D3,8 G3,8 D3,16 G3,16 A3,8 D3,16 A3,16']
  },
  {
    label: '# Measure 16',
    v1: ['R,16 G4,16 F#4,16 G4,16 R,16 G4,16 D4,16 C4,16 A#3,16 A3,16 G3,16 A#3,16 A3,16 G3,16 F#3,16 A3,16'],
    v2: ['R,1'],
    v3: ['D5,4 C5,4 R,8 A#4,8 R,8 A4,8'],
    v4: ['A#3,8 A3,16 G3,16 A3,16 D3,16 F#4,16 G4,16 D4,4 C4,4']
  },
  {
    label: '# Measure 17',
    v1: ['G3,16 D3,16 G3,16 A3,16 R,4 D3,4 A3,4'],
    v2: ['R,1'],
    v3: ['R,8 D4,8 G4,16 A4,16 A#4,16 G4,16 A4,8 D5,8 C#5,8 E5,8'],
    v4: ['A#3,4 A#3,16 C4,16 D4,16 E4,16 F4,16 E4,16 D4,16 F4,16 E4,16 D4,16 C#4,16 E4,16']
  },
  {
    label: '# Measure 18',
    v1: ['F3,4. E3,8 D3,8 F3,8 E3,8 D3,8'],
    v2: ['R,1'],
    v3: ['A5,16 A#5,16 A5,16 G5,16 F5,16 E5,16 D5,16 C#5,16 D5,8 R,8 A#5,8 R,8'],
    v4: ['D4,8 A3,8 D4,8 E4,8 F4,16 G4,16 F4,16 G4,16 A4,32 G4,32 A4,32 G4,32 A4,32 G4,32 F4,32 G4,32']
  },
  {
    label: '# Measure 19',
    v1: ['C#3,8 E3,8 A2,4 D3,8 A2,8 E3,8 A2,8'],
    v2: ['R,1'],
    v3: ['E5,8 R,4 A5,8 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32'],
    v4: ['A4,16 G4,16 A4,16 A#4,16 A4,16 G4,16 F4,16 E4,16 F4,16 A4,16 G4,16 A4,16 C#4,16 A4,16 G4,16 A4,16']
  },
  {
    label: '# Measure 20',
    v1: ['F3,8 E3,16 D3,16 E3,8 A2,8 D3,8 A2,16 D3,16 E3,8 A2,16 E3,16'],
    v2: ['R,1'],
    v3: ['A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32'],
    v4: ['D4,16 A4,16 G4,16 A4,16 C#4,16 A4,16 G4,16 A4,16 F4,16 D4,16 C#4,16 D4,16 G4,16 D4,16 C#4,16 D4,16']
  },
  {
    label: '# Measure 21',
    v1: ['F3,8 E3,16 D3,16 E3,8 A2,8 D3,8 G2,8 A2,4'],
    v2: ['R,1'],
    v3: ['A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,32 A#5,32 A5,16 G5,16 A5,16 A#5,16 A5,16 G5,16 F5,16 E5,16'],
    v4: ['A4,16 D4,16 C#4,16 D4,16 G4,16 D4,16 C#4,16 D4,16 F4,8 E4,16 D4,16 C#4,8. D4,16']
  },
  {
    label: '# Measure 22',
    v1: ['D2,4 R,2.'],
    v2: ['R,8 A4,8 D5,8 C5,8 A#4,2'],
    v3: ['F5,2 F5,8 D5,8 G5,8 F5,8'],
    v4: ['D4,16 C4,16 D4,16 E4,16 D4,16 C4,16 A#3,16 A3,16 G3,16 F3,16 G3,16 A3,16 G3,16 F3,16 D#3,16 D3,16']
  },
  {
    label: '# Measure 23',
    v1: ['R,1'],
    v2: ['A#4,8 G4,8 C5,8 A#4,8 A4,2'],
    v3: ['D#5,2 D#5,8 C5,8 F5,8 D#5,8'],
    v4: ['C4,16 A#3,16 C4,16 D4,16 C4,16 A#3,16 A3,16 G3,16 F3,16 D#3,16 F3,16 G3,16 F3,16 D#3,16 D3,16 C3,16']
  },
  {
    label: '# Measure 24',
    v1: ['R,1'],
    v2: ['A4,4 G4,2 F#4,4'],
    v3: ['D5,4 D5,16 G5,16 F#5,16 G5,16 C5,4 C5,16 A#4,16 A4,16 C5,16'],
    v4: ['A#2,16 A#3,16 C4,16 D4,16 D#4,4 R,16 A3,16 A#3,16 C4,16 D4,4']
  },
  {
    label: '# Measure 25',
    v1: ['R,1'],
    v2: ['G4,8 G4,16 R,16 D4,4 R,16 D4,16 E4,16 R,8 D4,16 R,8'],
    v3: ['A#4,16 A4,16 R,16 A#4,16 A4,16 G4,16 F#4,16 A4,16 G4,16 R,8 F#4,16 G4,16 R,16 G4,16 A4,16'],
    v4: ['G3,4 R,4 A#3,4. A3,8']
  },
  {
    label: '# Measure 26',
    v1: ['R,2 R,8 G2,8 R,16 D3,16 G3,16 A3,16'],
    v2: ['R,1'],
    v3: ['A#4,16 G4,16 A#4,16 C5,16 D5,16 A4,16 D5,16 C5,16 A#4,4. A4,8'],
    v4: ['G3,16 A#3,16 A3,16 G3,16 F#3,16 G3,16 E3,16 F#3,16 G3,16 D3,16 E3,16 F#3,16 G3,8 F3,8']
  },
  {
    label: '# Measure 27',
    v1: ['A#3,16 C4,16 A#3,16 C4,16 R,32 C4,32 R,32 C4,32 R,32 C4,32 A#3,32 C4,32 R,16 C4,16 D3,8 D3,4'],
    v2: ['R,4 D4,32 R,32 D4,32 R,32 D4,32 R,16. D4,16 R,16 D4,16 D#4,16 D4,4'],
    v3: ['G4,8 A#4,8 A4,8 G4,8 F#4,8 A4,8 R,16 C4,16 A#3,16 A3,16'],
    v4: ['D#3,8 R,8 D#2,8 R,8 D2,8 R,4.']
  },
  {
    label: '# Measure 28',
    v1: ['D3,1'],
    v2: ['G4,8 D4,16 D4,16 A4,8 D4,16 D4,16 A#4,8 A4,16 G4,16 A4,8 D4,16 D4,16'],
    v3: ['A#3,16 D4,16 C4,16 R,16 F#3,16 D4,16 C4,16 R,16 G3,16 D4,16 C4,16 D4,16 F#3,16 D4,16 C4,16 R,16'],
    v4: ['R,1']
  },
  {
    label: '# Measure 29',
    v1: ['D3,1'],
    v2: ['G4,8 D4,16 G4,16 A4,8 D4,16 A4,16 A#4,8 A4,16 G4,16 A4,16 D4,16 D5,16 C5,16'],
    v3: ['A#3,16 G3,16 F#3,16 G3,16 C4,16 G3,16 F#3,16 G3,16 D4,16 G3,16 F#3,16 G3,16 C4,16 G3,16 F#3,16 A3,16'],
    v4: ['R,1']
  },
  {
    label: '# Measure 30',
    v1: ['D3,2. C3,4'],
    v2: ['A#4,16 A4,16 G4,16 A#4,16 A4,16 G4,16 F#4,16 A4,16 G4,16 A#4,16 C5,16 D5,16 D#5,16 A#4,16 A4,16 G4,16'],
    v3: ['G3,8 A#3,8 C4,16 A#3,16 A3,16 C4,16 A#3,4 A#3,16 D4,16 C4,16 A#3,16'],
    v4: ['R,1']
  },
  {
    label: '# Measure 31',
    v1: ['C3,4 A#2,2 A2,4'],
    v2: ['F#4,16 A4,16 A#4,16 C5,16 D5,16 A4,16 G4,16 F4,16 D#4,16 G4,16 A4,16 A#4,16 C5,16 G4,16 F4,16 D#4,16'],
    v3: ['A3,4 A3,16 C4,16 A#3,16 A3,16 G3,4 G3,16 A#3,16 A3,16 G3,16'],
    v4: ['R,1']
  },
  {
    label: '# Measure 32',
    v1: ['A#2,8 A2,8 G2,4 F2,4 R,4'],
    v2: ['D4,16 F4,16 G4,16 A4,16 A#4,16 D5,16 C5,16 A#4,16 A4,16 C5,16 D5,16 D#5,16 F5,16 G5,16 F5,16 D#5,16'],
    v3: ['F3,4. E3,8 F3,8 D#3,8 D3,8 C3,8'],
    v4: ['R,1']
  },
  {
    label: '# Measure 33',
    v1: ['A#3,4 F4,4 D4,4. C4,8'],
    v2: ['D5,16 F5,16 D#5,16 D5,16 C5,16 A#4,16 A4,16 C5,16 A#4,16 F4,16 C4,8 A#3,8 A3,8'],
    v3: ['A#2,4 R,4. G4,16 A4,16 A#4,16 C5,16 A#4,16 C5,16'],
    v4: ['R,1']
  },
  {
    label: '# Measure 34',
    v1: ['A#3,8 D4,8 C4,8 A#3,8 A3,8 C4,8 R,8 F4,8'],
    v2: ['G3,2 F3,4 F3,4'],
    v3: ['D5,16 E5,16 D5,16 E5,16 F5,32 E5,32 F5,32 E5,32 F5,32 E5,32 D5,32 E5,32 F5,16 D#5,16 F5,16 G5,16 F5,16 D#5,16 D5,16 C5,16'],
    v4: ['R,1']
  },
  {
    label: '# Measure 35',
    v1: ['F4,1'],
    v2: ['A#3,8 F3,8 C4,8 F3,8 D4,8 C4,16 A#3,16 C4,8 F3,8'],
    v3: ['D5,16 F5,16 D#5,16 F5,16 A4,16 F5,16 D#5,16 F5,16 A#4,16 F5,16 D#5,16 F5,16 A4,16 F5,16 D#5,16 F5,16'],
    v4: ['R,1']
  },
  {
    label: '# Measure 36',
    v1: ['F4,2. F4,8 F4,8'],
    v2: ['A#3,8 F3,16 A#3,16 C4,8 F3,16 C4,16 D4,8 C4,16 A#3,16 C4,16 F3,16 R,16 A#4,16'],
    v3: ['D5,16 A#4,16 A4,16 A#4,16 D#5,16 A#4,16 A4,16 A#4,16 F5,16 A#4,16 A4,16 A#4,16 D#5,16 A#4,16 A4,16 D#4,16'],
    v4: ['R,1']
  },
  {
    label: '# Measure 37',
    v1: ['R,8. D4,16 C4,16 R,8 C4,16 R,8 D5,16 D#5,16 D5,16 C5,16 A#4,16 D5,16'],
    v2: ['A#4,16 C5,16 D5,16 A#4,16 D#5,16 D5,16 C5,16 D#5,16 D5,16 C5,16 G4,8 R,4'],
    v3: ['D4,16 C4,16 A#3,16 R,8 A#3,16 A3,16 R,16 A#3,8 R,4 G3,8'],
    v4: ['R,1']
  },
  {
    label: '# Measure 38',
    v1: ['C5,16 A#4,16 C5,16 D5,16 C5,16 A#4,16 A4,16 C5,16 A#4,16 A4,16 A#4,16 C5,16 A#4,16 A4,16 G4,16 A#4,16'],
    v2: ['R,8 F4,8 R,4. F4,8 R,8 E4,8'],
    v3: ['A3,8 R,4 F3,8 G3,8 R,8 C4,8 R,8'],
    v4: ['R,1']
  },
  {
    label: '# Measure 39',
    v1: ['A4,8 F5,8 R,4. D#5,8 R,4'],
    v2: ['F4,16 D#4,16 F4,16 G4,16 F4,16 D#4,16 D4,16 F4,16 D#4,16 D4,16 D#4,16 R,16 D#4,16 D4,16 C4,16 D#4,16'],
    v3: ['R,4. G#4,8 G4,8 R,16 F4,16 R,8 G4,8'],
    v4: ['R,1']
  },
  {
    label: '# Measure 40',
    v1: ['R,8 D5,8 R,4. C5,16 A#4,16 A4,16 R,8.'],
    v2: ['D4,16 C4,16 D4,16 D#4,16 D4,16 C4,16 A#3,16 D4,16 C4,16 A#3,16 C4,16 D4,16 C4,16 A#3,16 A3,16 C4,16'],
    v3: ['F4,8 R,4 F4,8 D#4,16 G4,16 R,8. G4,16 F4,16 D#4,16'],
    v4: ['R,1']
  },
  {
    label: '# Measure 41',
    v1: ['R,8 F4,16 G4,16 A4,16 A#4,16 C5,16 A4,16 A#4,16 F4,16 G4,16 A4,16 A#4,16 C5,16 A#4,16 C5,16'],
    v2: ['A#3,16 D#4,16 D4,16 R,16 C4,16 D4,16 D#4,16 C4,16 D4,16 C4,16 A#3,16 C4,16 D4,16 D#4,16 D4,16 D#4,16'],
    v3: ['D4,16 C4,16 R,16 A#3,16 F3,4 D3,4. R,8'],
    v4: ['A#2,4 R,2 R,8 C3,8']
  },
  {
    label: '# Measure 42',
    v1: ['D5,16 E5,16 D5,16 E5,16 F5,32 E5,32 F5,32 E5,32 F5,32 E5,32 D5,32 E5,32 F5,16 D#5,16 F5,16 G5,16 F5,8 F5,8'],
    v2: ['F4,16 G4,16 F4,16 G4,16 A4,32 G4,32 A4,32 G4,32 A4,32 G4,32 F4,32 G4,32 A4,16 G4,16 A4,16 A#4,16 A4,16 G4,16 F4,16 D#4,16'],
    v3: ['R,8 D3,8 R,4. C3,8 R,4'],
    v4: ['A#2,8 R,8 C3,8 A#2,8 A2,8 R,8 F2,4']
  },
  {
    label: '# Measure 43',
    v1: ['F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32'],
    v2: ['D4,16 F4,16 D#4,16 F4,16 A3,16 F4,16 D#4,16 F4,16 A#3,16 F4,16 D#4,16 F4,16 A3,16 F4,16 D#4,16 F4,16'],
    v3: ['A#2,8 R,8 C3,8 R,8 D3,8 C3,16 A#2,16 C3,8 R,8'],
    v4: ['R,8 F2,8 R,8 F2,8 R,4. F2,8']
  },
  {
    label: '# Measure 44',
    v1: ['F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32 F5,32 G5,32'],
    v2: ['D4,16 A#4,16 A4,16 A#4,16 D#4,16 A#4,16 A4,16 A#4,16 F4,16 A#4,16 A4,16 A#4,16 D#4,16 A#4,16 A4,16 A#4,16'],
    v3: ['A#2,8 R,16 A#2,16 C3,8 R,16 C3,16 D3,8 C3,16 A#2,16 C3,8 R,8'],
    v4: ['R,8 F2,16 R,8. F2,16 R,4. R,16 F2,8']
  },
  {
    label: '# Measure 45',
    v1: ['F5,16 D5,16 C5,16 A#4,16 A4,16 G4,16 F4,16 D#4,16 D4,2'],
    v2: ['A#4,16 D#5,16 F5,16 G5,16 C5,8. A5,16 A#5,16 A5,16 A#5,16 C6,16 A#5,16 A5,16 G5,16 F5,16'],
    v3: ['D3,8 D#3,8 F3,8 R,4 F4,8 A#4,8 A4,8'],
    v4: ['R,4. F2,8 A#2,4 R,4']
  },
  {
    label: '# Measure 46',
    v1: ['D4,8 G3,8 C4,8 A#3,8 A3,2'],
    v2: ['D#5,16 D5,16 D#5,16 F5,16 D#5,16 D5,16 C5,16 A#4,16 A5,16 G5,16 A5,16 A#5,16 A5,16 G5,16 F5,16 D#5,16'],
    v3: ['G4,2 G4,8 C4,8 A4,8 G4,8'],
    v4: ['C3,4 R,4 F2,4 R,4']
  },
  {
    label: '# Measure 47',
    v1: ['A3,8 F3,8 A#3,8 A3,8 G3,2'],
    v2: ['D5,16 C5,16 D5,16 D#5,16 D5,16 C5,16 A#4,16 A4,16 G5,16 F5,16 G5,16 G#5,16 G5,16 F5,16 D#5,16 D5,16'],
    v3: ['F4,2 F4,8 A#3,8 G4,8 F4,8'],
    v4: ['A#2,4 R,4 D#2,4 R,4']
  },
  {
    label: '# Measure 48',
    v1: ['G3,8 D#3,8 G#3,8 G3,8 F3,4 G3,4'],
    v2: ['C5,16 B4,16 C5,16 D5,16 C5,16 D5,16 D#5,16 C5,16 F5,4 F5,16 G#5,16 G5,16 F5,16'],
    v3: ['D#4,2 D#4,16 D#4,16 D4,16 C4,16 B3,4'],
    v4: ['G#2,4 R,4 D2,4 G2,4']
  },
  {
    label: '# Measure 49',
    v1: ['G3,16 G3,16 A3,16 B3,16 R,8. C4,16 G#3,2'],
    v2: ['D#5,2 D#5,16 C5,16 D5,16 D#5,16 G#4,8 F4,8'],
    v3: ['C4,4 C4,16 D4,16 D#4,16 R,8. C4,8 F5,16 G5,16 G#5,16 F5,16'],
    v4: ['C2,4 R,4 F2,4 R,4']
  },
  {
    label: '# Measure 50',
    v1: ['G3,8 A3,8 B3,4 C4,8 C4,8 R,16 C4,16 B3,16 R,16'],
    v2: ['F4,4 F4,16 F4,16 D#4,16 D4,16 D#4,16 D4,16 R,16 D#4,16 D4,16 R,8 D4,16'],
    v3: ['B4,16 C5,16 D5,16 B4,16 G4,8 R,8 C5,4 G5,4'],
    v4: ['G2,1']
  },
  {
    label: '# Measure 51',
    v1: ['C4,16 G3,16 R,2. R,8'],
    v2: ['R,8 C4,16 D4,16 D#4,16 F4,16 D#4,16 F4,16 G4,16 D#4,16 C4,16 G4,16 G#4,16 F4,16 G4,16 G#4,16'],
    v3: ['D#5,4. D5,8 C5,8 D#5,8 D5,8 C5,8'],
    v4: ['C2,8 G2,8 C3,8 D3,8 D#3,4 F3,4']
  },
  {
    label: '# Measure 52',
    v1: ['G3,4 G3,16 G3,16 R,16 G3,16 G3,16 G3,8 G3,8 G3,8 G3,16'],
    v2: ['D4,16 D#4,16 D4,16 C4,16 B3,8 D4,8 R,4. G4,8'],
    v3: ['B4,8 D5,8 G4,4 C5,8 G4,8 D5,8 R,8'],
    v4: ['R,4. F3,16 R,16 D#3,16 R,16 F3,16 R,16 B2,16 R,16 F3,16 R,16']
  },
  {
    label: '# Measure 53',
    v1: ['G3,16 G3,8 G3,8 G3,8 G3,2 G3,16'],
    v2: ['R,4. G4,8 R,16 C4,16 B3,16 C4,16 R,16 C4,16 B3,16 C4,16'],
    v3: ['D#5,8 D5,16 C5,16 D5,8 R,8 C5,8 G4,16 C5,16 D5,8 G4,16 D5,16'],
    v4: ['C3,16 R,16 F3,16 R,16 B2,16 R,16 F3,16 R,16 D#3,16 R,8. F3,16 R,8.']
  },
  {
    label: '# Measure 54',
    v1: ['G3,2 G3,8 R,4 G3,8'],
    v2: ['R,16 C4,16 B3,16 C4,16 R,16 B3,16 A3,16 B3,16 R,8 C5,16 D#5,16 D5,16 C5,16 B4,16 D5,16'],
    v3: ['D#5,8 D5,16 C5,16 D5,16 G4,16 G5,16 F5,16 D#5,16 D5,16 G4,8 F4,16 D#4,16 D4,16 F4,16'],
    v4: ['R,4 F3,16 R,8. C3,8 D#3,8 F3,8 R,8']
  },
  {
    label: '# Measure 55',
    v1: ['R,8 G3,8 R,4 F3,4 R,8 F3,8'],
    v2: ['C5,16 G5,16 D#5,16 G5,16 C5,16 D#5,16 R,2 R,8'],
    v3: ['D#4,4 R,8 G4,16 A#4,16 A4,16 C5,16 A4,16 C5,16 F4,16 A4,16 R,8'],
    v4: ['C3,4 D#3,8 C3,8 R,8 C4,8 A3,8 C4,16 D#4,16']
  },
  {
    label: '# Measure 56',
    v1: ['R,8 F3,8 D3,8 A#2,8 D#3,4 R,8 D#3,8'],
    v2: ['R,16 F5,16 D5,16 F5,16 A#4,16 D5,16 R,2 R,8'],
    v3: ['D4,16 R,4 R,16 F4,16 A4,16 G4,16 A#4,16 G4,16 A#4,16 D#4,16 G4,16 R,8'],
    v4: ['A#3,2 A#3,8 A#3,8 G3,8 A#3,16 D4,16']
  },
  {
    label: '# Measure 57',
    v1: ['R,8 D#3,8 C3,8 A2,8 D3,4 R,8 D3,8'],
    v2: ['R,16 D#5,16 C5,16 D#5,16 A4,16 C5,16 R,2 R,8'],
    v3: ['C4,16 R,4 R,16 E4,16 G4,16 F#4,16 A4,16 F#4,16 A4,16 D4,16 F#4,16 R,8'],
    v4: ['A3,2 A3,8 A3,8 F#3,8 A3,16 C4,16']
  },
  {
    label: '# Measure 58',
    v1: ['G2,16 A#2,16 A2,16 G2,16 R,16 A2,16 D2,16 R,4 R,16 F#2,8 R,8'],
    v2: ['R,8 G4,8 R,8 F#4,8 G4,4 D4,16 R,8 C4,16'],
    v3: ['A#3,8 R,8 A3,8 R,8 G3,16 A#3,16 A3,16 G3,16 R,16 A3,16 R,8'],
    v4: ['G3,4 D3,16 R,8 C3,16 A#2,8 D3,8 R,8 D3,8']
  },
  {
    label: '# Measure 59',
    v1: ['R,1'],
    v2: ['A#3,8 D4,8 A3,8 D4,4 G4,8 C4,8 F4,8'],
    v3: ['G3,4 F#3,4 G3,4 A3,4'],
    v4: ['G4,16 A#4,16 A4,16 G4,16 D5,16 A4,16 R,16 C5,16 A#4,16 D5,16 C5,16 A#4,16 F5,16 C5,16 R,16 D#5,16']
  },
  {
    label: '# Measure 60',
    v1: ['R,1'],
    v2: ['F4,8 F4,8 D4,8 G4,4 G4,8 E4,8 A4,8'],
    v3: ['A#3,4 B3,4 C4,4 C#4,4'],
    v4: ['D5,16 F5,16 D#5,16 D5,16 G5,16 D5,16 R,16 F5,16 E5,16 G5,16 F5,16 E5,16 A5,16 E5,16 R,16 G5,16']
  },
  {
    label: '# Measure 61',
    v1: ['R,1'],
    v2: ['A4,16 D#5,16 D5,16 C5,16 A#4,16 D5,16 A4,16 D5,16 R,16 G#5,16 G5,16 F5,16 G5,16 F5,16 D#5,16 D5,16'],
    v3: ['D4,4 E4,8 F#4,8 G4,4 A4,8 A#4,8'],
    v4: ['F#5,4 G5,8 A5,8 A#5,2']
  },
  {
    label: '# Measure 62',
    v1: ['R,1'],
    v2: ['D#5,2 D5,2'],
    v3: ['C5,16 G4,16 F4,16 D#4,16 C5,16 A4,16 F4,16 A4,16 A#3,16 F4,16 D#4,16 D4,16 A#4,16 G4,16 D#4,16 G4,16'],
    v4: ['A#5,4 A5,2 G5,4']
  },
  {
    label: '# Measure 63',
    v1: ['R,2 R,16 D5,16 C5,16 G4,16 D4,4'],
    v2: ['C5,2 A#4,16 A#3,16 D4,16 A#4,16 F#4,16 G4,16 E4,16 A4,16'],
    v3: ['A3,16 D#4,16 D4,16 C4,16 A4,16 F#4,16 D4,16 F#4,16 G3,4 R,4'],
    v4: ['G5,4 F#5,4 G5,4 A4,16 A#4,16 G4,16 F#4,16']
  },
  {
    label: '# Measure 64',
    v1: ['R,8 D5,8 D5,16 D#5,16 D5,16 C5,16 A#4,8 D5,8 C5,8 A#4,8'],
    v2: ['A#4,16 C5,16 A#4,16 C5,16 G5,8 A5,8 A#5,16 A5,16 G5,16 A5,16 F#5,16 G5,16 F#5,16 G5,16'],
    v3: ['A#3,4. A3,8 G3,8 A#3,8 A3,8 G3,8'],
    v4: ['G4,4. F#4,8 G4,4 A4,8 D4,8']
  }
];

var MUSIC_BACH_578_BPM = 96;
var MUSIC_BACH_578_MEASURE_MAP = Bach578ScoreHelpers.buildMeasureMap(FUGUE_578_TRACKS, FUGUE_578_MEASURES, MUSIC_BACH_578_BPM);
if (typeof window !== 'undefined') { window.MUSIC_BACH_578_MEASURE_MAP = MUSIC_BACH_578_MEASURE_MAP; }
var MUSIC_BACH_578_NOTATION = Bach578ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue in G minor ("Little"), BWV 578 (measures 1-64)',
  '# Converted from a MIDI file of unknown provenance; final ritardando as separate sections.'
], MUSIC_BACH_578_BPM, FUGUE_578_TRACKS, FUGUE_578_MEASURES);
if (typeof window !== 'undefined') { window.MUSIC_BACH_578_NOTATION = MUSIC_BACH_578_NOTATION; }

// ---- Section 2: measures 65-66, 87.7 bpm ----
var FUGUE_578_TRACKS_2 = {
  v1: {
    instrument: 'organ',
    header: '# BWV 578 voice 1.'
  },
  v2: {
    instrument: 'organ',
    header: '# BWV 578 voice 2.'
  },
  v3: {
    instrument: 'organ',
    header: '# BWV 578 voice 3.'
  },
  v4: {
    instrument: 'organ',
    header: '# BWV 578 voice 4.'
  }
};

var FUGUE_578_MEASURES_2 = [
  {
    label: '# Measure 65',
    v1: ['A4,4 R,8 D4,8 D4,2'],
    v2: ['A5,16 G5,16 F#5,16 E5,16 D5,16 C5,16 A#4,16 A4,16 A#4,16 D5,16 C5,16 D5,16 F#4,16 D5,16 C5,16 D5,16'],
    v3: ['F#3,8 A3,8 D3,4 R,8 D3,8 C4,8 R,8'],
    v4: ['D4,4 R,8 F#3,8 G3,8 R,8 A3,8 D3,8']
  },
  {
    label: '# Measure 66',
    v1: ['D4,1'],
    v2: ['G4,16 D5,16 C5,16 D5,16 F#4,16 D5,16 C5,16 D5,16 A#4,16 G4,16 F#4,16 G4,16 C5,16 G4,16 F#4,16 G4,16'],
    v3: ['A#3,8 A3,16 G3,16 A3,8 D3,8 A#3,8 R,16 G3,16 A3,8 R,16 A3,16'],
    v4: ['R,4 C4,8 R,8 G3,8 D3,16 R,8. D3,16 R,16']
  }
];

var MUSIC_BACH_578_BPM_2 = 87.7;
var MUSIC_BACH_578_MEASURE_MAP_2 = Bach578ScoreHelpers.buildMeasureMap(FUGUE_578_TRACKS_2, FUGUE_578_MEASURES_2, MUSIC_BACH_578_BPM_2);
if (typeof window !== 'undefined') { window.MUSIC_BACH_578_MEASURE_MAP_2 = MUSIC_BACH_578_MEASURE_MAP_2; }
var MUSIC_BACH_578_NOTATION_2 = Bach578ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue in G minor ("Little"), BWV 578 (measures 65-66)',
  '# Converted from a MIDI file of unknown provenance; final ritardando as separate sections.'
], MUSIC_BACH_578_BPM_2, FUGUE_578_TRACKS_2, FUGUE_578_MEASURES_2);
if (typeof window !== 'undefined') { window.MUSIC_BACH_578_NOTATION_2 = MUSIC_BACH_578_NOTATION_2; }

// ---- Section 3: measures 67-68, 69.7 bpm ----
var FUGUE_578_TRACKS_3 = {
  v1: {
    instrument: 'organ',
    header: '# BWV 578 voice 1.'
  },
  v2: {
    instrument: 'organ',
    header: '# BWV 578 voice 2.'
  },
  v3: {
    instrument: 'organ',
    header: '# BWV 578 voice 3.'
  },
  v4: {
    instrument: 'organ',
    header: '# BWV 578 voice 4.'
  }
};

var FUGUE_578_MEASURES_3 = [
  {
    label: '# Measure 67',
    v1: ['D4,2 D4,8 D#4,4 D4,8'],
    v2: ['D5,16 G4,16 F#4,16 G4,16 C5,16 G4,16 F#4,16 G4,16 A#4,8 G5,8 A4,8 F#5,8'],
    v3: ['G3,8 R,16 G3,16 R,8 D3,8 R,8 D#3,8 C3,8 D3,8'],
    v4: ['A#3,8 A3,16 R,16 A3,8 R,8 G3,8 A#3,8 C4,8 A3,8']
  },
  {
    label: '# Measure 68',
    v1: ['D4,1'],
    v2: ['G5,1'],
    v3: ['G2,1'],
    v4: ['B3,1']
  }
];

var MUSIC_BACH_578_BPM_3 = 69.7;
var MUSIC_BACH_578_MEASURE_MAP_3 = Bach578ScoreHelpers.buildMeasureMap(FUGUE_578_TRACKS_3, FUGUE_578_MEASURES_3, MUSIC_BACH_578_BPM_3);
if (typeof window !== 'undefined') { window.MUSIC_BACH_578_MEASURE_MAP_3 = MUSIC_BACH_578_MEASURE_MAP_3; }
var MUSIC_BACH_578_NOTATION_3 = Bach578ScoreHelpers.buildNotation([
  '# J. S. Bach - Fugue in G minor ("Little"), BWV 578 (measures 67-68)',
  '# Converted from a MIDI file of unknown provenance; final ritardando as separate sections.'
], MUSIC_BACH_578_BPM_3, FUGUE_578_TRACKS_3, FUGUE_578_MEASURES_3);
if (typeof window !== 'undefined') { window.MUSIC_BACH_578_NOTATION_3 = MUSIC_BACH_578_NOTATION_3; }

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    MUSIC_BACH_578_NOTATION: MUSIC_BACH_578_NOTATION,
    MUSIC_BACH_578_MEASURE_MAP: MUSIC_BACH_578_MEASURE_MAP,
    MUSIC_BACH_578_NOTATION_2: MUSIC_BACH_578_NOTATION_2,
    MUSIC_BACH_578_MEASURE_MAP_2: MUSIC_BACH_578_MEASURE_MAP_2,
    MUSIC_BACH_578_NOTATION_3: MUSIC_BACH_578_NOTATION_3,
    MUSIC_BACH_578_MEASURE_MAP_3: MUSIC_BACH_578_MEASURE_MAP_3
  };
}
