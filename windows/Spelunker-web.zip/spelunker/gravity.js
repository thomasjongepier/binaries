// Spelunker - gravity zones (campaign mechanic 'gravity').
// Vanilla JS, no build tools. Attaches to window.Game.
//
// A ZONE is a world-x range [x0, x0 + width] that scrolls with the cave. While
// the ship's world x is inside it, a constant vertical acceleration (up or
// down) is applied through Ship.applyPull. The cue is the zone itself: a
// translucent violet/cyan field filling the cave gap with chevrons that flow in
// the pull direction. It spawns off the right edge at least MIN_LEAD px ahead
// of the ship, so it is visible for several seconds before contact (no hidden
// hazard, no separate telegraph needed).
//
// Escapable by design: STRENGTH_MAX (380) is far below the ship's 900 px/s^2
// key acceleration, so holding the opposite key always wins; mouse control is
// only nudged by a capped offset (see Ship.applyPull). Wall contact caused by
// the pull follows the normal wall-bump rules.
//
// Own random stream 'gravity', touched only while Levels.unlocked('gravity'),
// so locked/endless runs are byte-identical. No pull while the clear/victory
// overlay waits (Levels.playerInvulnerable()). render() is called by main.js
// AFTER the headlamp darkness so the field is never dimmed.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('gravity.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;

  // ---- Tuning ----
  var FIRST_DELAY = 6; // seconds after unlock before the first zone
  var INTERVAL_MIN = 9; // seconds between zone spawns, scaled by Difficulty.spawnFactor()
  var INTERVAL_MAX = 14;
  var WIDTH_MIN = 220; // px
  var WIDTH_MAX = 320;
  var STRENGTH_MIN = 260; // px/s^2
  var STRENGTH_MAX = 380; // << ship ACCEL (900): always escapable
  var MIN_LEAD = 380; // px, minimum distance ahead of the ship at spawn
  var MAX_SAME_DIR = 2; // never the same direction three times in a row
  var COL = 8; // px, field column width
  var CHEV_SPACING_X = 48;
  var CHEV_SPACING_Y = 44;
  var FLOW_SPEED = 70; // px/s chevron drift in the pull direction

  var zone = null; // {x0, width, dir (+1 down / -1 up), strength, t}
  var spawnTimer = -1; // < 0 means "arm on the next unlocked update"
  var lastDir = 0, sameCount = 0;

  function stream() { return Game.Random.stream('gravity'); }

  function isUnlocked() {
    return !!(Game.Levels && Game.Levels.unlocked && Game.Levels.unlocked('gravity'));
  }
  function spawnsEnabled() {
    return !(Game.Levels && Game.Levels.spawnsEnabled) || Game.Levels.spawnsEnabled();
  }
  function invulnerable() {
    return !!(Game.Levels && Game.Levels.playerInvulnerable && Game.Levels.playerInvulnerable());
  }
  function scrollX() {
    return (Game.Cave && Game.Cave.getScrollX) ? Game.Cave.getScrollX() : 0;
  }
  function shipWorldX() {
    if (Game.Ship && Game.Ship.getPosition) { return Game.Ship.getPosition().worldX; }
    return scrollX() + 100;
  }
  function snapV(P, n) { return P && P.snap ? P.snap(n) : n; }

  function reset() {
    zone = null;
    spawnTimer = -1;
    lastDir = 0;
    sameCount = 0;
  }

  function rollTimer() {
    var f = (Game.Difficulty && Game.Difficulty.spawnFactor) ? Game.Difficulty.spawnFactor() : 1;
    spawnTimer = stream().range(INTERVAL_MIN, INTERVAL_MAX) * f;
  }

  function spawn() {
    var s = stream();
    var dir = s.next() < 0.5 ? -1 : 1;
    if (dir === lastDir && sameCount >= MAX_SAME_DIR) { dir = -dir; }
    sameCount = dir === lastDir ? sameCount + 1 : 1;
    lastDir = dir;
    var width = s.range(WIDTH_MIN, WIDTH_MAX);
    var strength = s.range(STRENGTH_MIN, STRENGTH_MAX);
    var edge = scrollX() + (Game.W || 640) + 20; // just off the right edge
    var x0 = Math.max(edge, shipWorldX() + MIN_LEAD);
    zone = { x0: x0, width: width, dir: dir, strength: strength, t: 0 };
    rollTimer(); // interval counts from spawn
  }

  function update(dt) {
    if (!(dt > 0)) { return; }
    if (!isUnlocked()) {
      // Locked, endless, or the level just ended: drop any zone, touch nothing else.
      if (zone || spawnTimer >= 0) { reset(); }
      return;
    }
    if (!zone) {
      if (!spawnsEnabled()) { return; }
      if (spawnTimer < 0) { spawnTimer = FIRST_DELAY; }
      spawnTimer -= dt;
      if (spawnTimer <= 0) { spawn(); }
      return;
    }
    zone.t += dt;
    if (zone.x0 + zone.width < scrollX() - 20) { zone = null; return; } // scrolled off the left
    if (invulnerable()) { return; }
    var wx = shipWorldX();
    if (wx >= zone.x0 && wx <= zone.x0 + zone.width && Game.Ship && Game.Ship.applyPull) {
      Game.Ship.applyPull(zone.dir * zone.strength, dt);
    }
  }

  // ---- Rendering ----
  function chevron(P, retro, cx, cy, dir) {
    var k;
    if (retro) {
      for (k = 0; k < 5; k++) {
        var yy = snapV(P, cy + dir * (k * 3 - 6));
        ctx.fillRect(snapV(P, cx - 12 + k * 3), yy, 4, 4);
        ctx.fillRect(snapV(P, cx + 8 - k * 3), yy, 4, 4);
      }
    } else {
      ctx.beginPath();
      ctx.moveTo(cx - 12, cy - dir * 6);
      ctx.lineTo(cx, cy + dir * 6);
      ctx.lineTo(cx + 12, cy - dir * 6);
      ctx.stroke();
    }
  }

  function render(rctx) {
    ctx = rctx || Game.ctx;
    if (!zone || !Game.Cave || !Game.Cave.getCaveBoundsAtX) { return; }
    var T = Game.Theme;
    var c = (T && T.ramp) ? T.ramp('gravity') : ['#2A1A7A', '#7A5CFF', '#2FD0E0', '#E8FBFF'];
    var P = Game.Pixel;
    var retro = !!(P && P.enabled && P.enabled());
    var W = Game.W || 640;
    var sx = scrollX();
    var a = zone.x0 - sx, b = a + zone.width; // screen-space extent
    var from = Math.max(0, Math.floor(a / COL) * COL);
    var to = Math.min(W, b);
    if (to <= from) { return; }
    var x, bd, i;
    ctx.save();
    // Field: translucent columns following the cave gap, gently shimmering.
    for (x = from; x < to; x += COL) {
      bd = Game.Cave.getCaveBoundsAtX(sx + x);
      var shim = 0.5 + 0.5 * Math.sin(zone.t * 3 + x * 0.05);
      ctx.globalAlpha = 0.2 + 0.1 * shim;
      ctx.fillStyle = (Math.floor(x / COL) & 1) ? c[1] : c[2];
      ctx.fillRect(x, bd.top, COL, bd.bottom - bd.top);
    }
    // Bright rims at both ends so the zone entry/exit is crisp.
    ctx.globalAlpha = 0.55;
    ctx.fillStyle = c[3];
    var rims = [a, b - 3];
    for (i = 0; i < 2; i++) {
      if (rims[i] >= -3 && rims[i] <= W) {
        bd = Game.Cave.getCaveBoundsAtX(sx + Math.max(0, Math.min(W, rims[i])));
        ctx.fillRect(snapV(P, rims[i]), bd.top, 3, bd.bottom - bd.top);
      }
    }
    // Chevrons flowing in the pull direction.
    ctx.globalAlpha = 0.65;
    ctx.fillStyle = c[3];
    ctx.strokeStyle = c[3];
    ctx.lineWidth = 3;
    var flow = (zone.t * FLOW_SPEED * zone.dir) % CHEV_SPACING_Y;
    if (flow < 0) { flow += CHEV_SPACING_Y; }
    var cx0 = Math.ceil((a + 24) / CHEV_SPACING_X) * CHEV_SPACING_X;
    for (var cx = Math.max(cx0, from + 12); cx < Math.min(to, b) - 12; cx += CHEV_SPACING_X) {
      bd = Game.Cave.getCaveBoundsAtX(sx + cx);
      for (var cy = bd.top - CHEV_SPACING_Y + flow; cy < bd.bottom; cy += CHEV_SPACING_Y) {
        if (cy < bd.top + 10 || cy > bd.bottom - 10) { continue; }
        chevron(P, retro, cx, cy, zone.dir);
      }
    }
    ctx.restore();
  }

  Game.Gravity = {
    update: update,
    render: render,
    reset: reset,
    getZone: function () { return zone; },
    getEvent: function () { return zone; },
    FIRST_DELAY: FIRST_DELAY,
    STRENGTH_MIN: STRENGTH_MIN,
    STRENGTH_MAX: STRENGTH_MAX,
    WIDTH_MIN: WIDTH_MIN,
    WIDTH_MAX: WIDTH_MAX,
    MIN_LEAD: MIN_LEAD
  };
})();
