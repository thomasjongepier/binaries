// Spelunker - campaign level table. 25 levels in 5 themed worlds of 5.
// Knobs are multiplicative factors applied in campaign mode:
//   scroll   >= 1  scroll speed factor
//   gap      <= 1  cave gap factor
//   spawn    <= 1  enemy spawn interval factor (lower = more enemies,
//                  same meaning as Difficulty.spawnFactor)
//   gas, collapse  hazard chance multipliers
//   light    view radius multiplier (1 = full view)
//   drift    0 = none, otherwise slip/damping amount
//   length   distance points needed to finish the level
//   unlocks  CUMULATIVE list of mechanic ids available at that level
// get(n) returns a fresh object each call; for n outside 1..25 or a
// non-integer (including strings and NaN) it returns null, never throws.
(function () {
  'use strict';
  window.Game = window.Game || {};

  var THEMES = ['crystal', 'jungle', 'aztec', 'orient', 'void'];
  var MECHANICS = ['sineweave', 'swarm', 'drift', 'gravity', 'torch',
    'phase', 'vines', 'boulders', 'snakes', 'dragon'];
  var PER_WORLD = 5;

  var NAMES = [
    'Glimmer Gate', 'Prism Hall', 'Geode Run', 'Mirror Shafts', 'Heart of the Crystal',
    'Canopy Cut', 'Vine Tangle', 'Spore Swamp', 'Predator Roots', 'The Strangler Fig',
    'Sun Stairs', 'Serpent Causeway', 'Obsidian Traps', 'Hall of Glyphs', 'Throne of the Sun',
    'Lantern Lane', 'Jade Dragon Gate', 'Ice Pagoda', 'Storm of Paper Cranes', 'Imperial Vault',
    'Starfall Rift', 'Gravity Wells', 'Haunted Keep', 'Blackout', 'The Core'
  ];

  // First level where each mechanic becomes available.
  var UNLOCK_AT = {
    vines: 7, sineweave: 9, snakes: 12, boulders: 13, torch: 14,
    dragon: 17, drift: 18, swarm: 19, gravity: 22, phase: 23
  };

  // World 2 per-level overrides on top of the linear formula. Gas keeps its
  // monotonic ramp but steps up +0.3 from L8 (Spore Swamp) on; L10 (Strangler
  // Fig) gets an extra spawn/gap push so it is clearly the hardest of world 2.
  var GAS_BONUS = { 8: 0.3, 9: 0.3, 10: 0.3 };
  // World 4: L19 (swarm) gets a modest spawn push; L20 (Imperial Vault) gets the
  // gauntlet push, but its gap push stays tiny because drift 0.7 already makes
  // a narrow gap punishing (gap factor stays >= 0.78).
  // World 5: L25 (The Core) gets the final gauntlet push; its gap push stays tiny
  // (total gap factor 0.74) because the dark (light 0.45) and every earlier
  // mechanic already stack on it. L21-24 follow the formula (no push).
  var SPAWN_PUSH = { 10: 0.06, 15: 0.06, 19: 0.02, 20: 0.06, 25: 0.06 };
  var GAP_PUSH = { 10: 0.03, 15: 0.03, 20: 0.01, 25: 0.01 };

  // World 3: collapse steps up +0.3 from L13 (Obsidian Traps, boulders) on and
  // stays monotonic; L15 (Throne of the Sun) gets the gauntlet spawn/gap push.
  var COLLAPSE_BONUS = { 13: 0.3, 14: 0.3, 15: 0.3 };

  var LIGHT = { 14: 0.6, 15: 0.6, 24: 0.35, 25: 0.45 };
  var DRIFT = { 18: 0.3, 19: 0.5, 20: 0.7 };

  // Difficulty t (0..1) at the end of each world; each world starts at 90% of
  // the previous world's end so it eases in, and ramps linearly to its end.
  var WORLD_END = [0.3, 0.45, 0.65, 0.82, 1];
  // World 1 ramps on a curve: gentle L1-L3, a clear jump at the L5 gauntlet.
  var W1_SHAPE = [0, 0.15, 0.35, 0.6, 1];

  function r3(x) { return Math.round(x * 1000) / 1000; }

  function tOf(n) {
    var w = Math.floor((n - 1) / PER_WORLD);
    var i = (n - 1) % PER_WORLD;
    var s = w === 0 ? 0 : WORLD_END[w - 1] * 0.9;
    var f = w === 0 ? W1_SHAPE[i] : i / (PER_WORLD - 1);
    return s + (WORLD_END[w] - s) * f;
  }

  // Target clear time: ~40 s at L1 rising to ~71 s at L25, with the last
  // level of each world (gauntlet) 12% longer. Distance points accrue at
  // 100 px/s * scroll / 10, so length = seconds * 10 * scroll (multiple of 10).
  function lengthOf(n, scroll) {
    var secs = 40 + 31 * (n - 1) / 24;
    if (n % PER_WORLD === 0) secs *= 1.12;
    return Math.round(secs * scroll) * 10;
  }

  function valid(n) {
    return typeof n === 'number' && isFinite(n) && Math.floor(n) === n &&
      n >= 1 && n <= NAMES.length;
  }

  function unlocksAt(n) {
    var out = [];
    for (var m = 0; m < MECHANICS.length; m++) {
      if (UNLOCK_AT[MECHANICS[m]] <= n) out.push(MECHANICS[m]);
    }
    return out;
  }

  function themeOf(n) {
    return valid(n) ? THEMES[Math.floor((n - 1) / PER_WORLD)] : null;
  }

  function get(n) {
    if (!valid(n)) return null;
    var t = tOf(n);
    return {
      n: n,
      theme: themeOf(n),
      name: NAMES[n - 1],
      length: lengthOf(n, 1 + 0.45 * t),
      scroll: r3(1 + 0.45 * t),
      gap: r3(1 - 0.25 * t - (GAP_PUSH[n] || 0)),
      spawn: r3(1 - 0.45 * t - (SPAWN_PUSH[n] || 0)),
      gas: r3(0.8 + 1.2 * t + (GAS_BONUS[n] || 0)),
      collapse: r3(0.8 + 1.0 * t + (COLLAPSE_BONUS[n] || 0)),
      light: LIGHT[n] || 1,
      drift: DRIFT[n] || 0,
      unlocks: unlocksAt(n)
    };
  }

  // ---- Campaign state ----
  var MODES = ['campaign', 'endless'];
  if (MODES.indexOf(window.Game.Mode) < 0) window.Game.Mode = 'campaign';

  var active = false;
  var curLevel = 0;
  var curPhase = null; // 'playing' | 'cleared' | 'finished' | null
  var levelStartDistance = 0;
  var clearedAt = 0;

  function distance() {
    var S = window.Game.Score;
    return S && typeof S.distancePoints === 'number' ? S.distancePoints : 0;
  }

  function setBiomeTheme(id) {
    var B = window.Game.Biomes;
    if (B && B.setTheme && B.currentTheme() !== id) B.setTheme(id);
  }

  // ---- Progress persistence (highest level reached, campaign finished) ----
  var PROGRESS_KEY = 'spelunker.progress.v1';

  function storage() {
    try { return window.localStorage || null; } catch (e) { return null; }
  }

  // Corrupt/missing/out-of-range data reads as {highest:1, finished:false}.
  function readProgress() {
    var out = { highest: 1, finished: false };
    try {
      var s = storage();
      var raw = s ? s.getItem(PROGRESS_KEY) : null;
      if (raw === null || raw === undefined) return out;
      var o = JSON.parse(raw);
      if (o && typeof o === 'object') {
        if (valid(o.highest)) out.highest = o.highest;
        out.finished = o.finished === true;
      }
    } catch (e) { /* unavailable or corrupt: defaults */ }
    return out;
  }

  function writeProgress(p) {
    try {
      var s = storage();
      if (s) s.setItem(PROGRESS_KEY, JSON.stringify({ highest: p.highest, finished: p.finished }));
    } catch (e) { /* storage unavailable: progress is not persisted */ }
  }

  function recordLevel(n) {
    var p = readProgress();
    if (n > p.highest) { p.highest = n; writeProgress(p); }
  }

  function recordFinished() {
    var p = readProgress();
    p.highest = NAMES.length;
    p.finished = true;
    writeProgress(p);
  }

  function resetProgress() {
    try {
      var s = storage();
      if (s) s.removeItem(PROGRESS_KEY);
    } catch (e) { /* ignore */ }
  }

  function startCampaign(startLevel) {
    var n = startLevel === undefined ? 1 : startLevel;
    if (!valid(n)) n = 1;
    active = true;
    curLevel = n;
    curPhase = 'playing';
    levelStartDistance = distance();
    clearedAt = 0;
    recordLevel(n);
    setBiomeTheme(themeOf(n));
  }

  function stop() {
    var was = active;
    active = false;
    curLevel = 0;
    curPhase = null;
    clearedAt = 0;
    if (was && window.Game.Biomes && window.Game.Biomes.clearTheme) window.Game.Biomes.clearTheme();
  }

  function current() { return active ? get(curLevel) : null; }

  function progress() {
    var c = current();
    if (!c) return 0;
    if (curPhase !== 'playing') return 1;
    var p = (distance() - levelStartDistance) / c.length;
    return p < 0 ? 0 : (p > 1 ? 1 : p);
  }

  function update(dt) {
    if (!active || curPhase !== 'playing') return;
    var c = get(curLevel);
    if (distance() - levelStartDistance >= c.length) {
      curPhase = 'cleared';
      clearedAt = distance();
      windDown();
    }
  }

  // True in an active campaign once the level is cleared / the run finished.
  function levelEnded() {
    return active && (curPhase === 'cleared' || curPhase === 'finished');
  }

  // One-shot on playing -> cleared: remove everything that could hurt, be
  // shot or be picked up, without awarding score. Each module is optional.
  function windDown() {
    var G = window.Game;
    if (G.Enemies && G.Enemies.clearAll) G.Enemies.clearAll();
    if (G.Pickups && G.Pickups.clear) G.Pickups.clear();
    if (G.Projectiles && G.Projectiles.clear) G.Projectiles.clear();
    var mods = ['Vines', 'Boulders', 'Dragon', 'Gravity', 'Hazards'];
    for (var i = 0; i < mods.length; i++) {
      if (G[mods[i]] && G[mods[i]].reset) G[mods[i]].reset();
    }
    if (G.Ship && G.Ship.holdStill) G.Ship.holdStill();
  }

  function advance() {
    if (!active || curPhase !== 'cleared') return false;
    if (curLevel >= NAMES.length) {
      curPhase = 'finished';
      recordFinished();
      return true;
    }
    curLevel++;
    levelStartDistance = distance();
    curPhase = 'playing';
    recordLevel(curLevel);
    setBiomeTheme(themeOf(curLevel));
    return true;
  }

  function hazardKnob(type) {
    if (!active || curPhase !== 'playing') return 1;
    if (type !== 'gas' && type !== 'collapse') return 1;
    return get(curLevel)[type];
  }

  window.Game.Levels = {
    THEMES: THEMES.slice(),
    MECHANICS: MECHANICS.slice(),
    count: function () { return NAMES.length; },
    get: get,
    themeOf: themeOf,
    startCampaign: startCampaign,
    stop: stop,
    campaignActive: function () { return active; },
    update: update,
    phase: function () { return curPhase; },
    level: function () { return active ? curLevel : null; },
    current: current,
    progress: progress,
    clearedAt: function () { return clearedAt; },
    advance: advance,
    highestReached: function () { return readProgress().highest; },
    hasFinished: function () { return readProgress().finished; },
    resetProgress: resetProgress,
    spawnsEnabled: function () { return !(active && (curPhase === 'cleared' || curPhase === 'finished')); },
    // True while the clear/victory overlay waits for confirm: the ship takes no damage.
    playerInvulnerable: levelEnded,
    levelEnded: levelEnded,
    hazardKnob: hazardKnob,
    // True only in an active campaign while playing a level that unlocks the
    // mechanic id. False in endless mode, when inactive, and for unknown ids.
    unlocked: function (id) {
      if (!active || curPhase !== 'playing') return false;
      return get(curLevel).unlocks.indexOf(id) >= 0;
    },
    mode: function () { return window.Game.Mode; },
    setMode: function (m) { if (MODES.indexOf(m) >= 0) window.Game.Mode = m; }
  };
})();
