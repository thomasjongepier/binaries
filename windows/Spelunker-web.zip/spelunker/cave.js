// Spelunker - procedurally generated scrolling cave.
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so main.js can call Cave.update/render each frame.
//
// Difficulty tuning:
//   GAP_MIN / GAP_MAX      - min/max vertical gap width (px) between walls.
//   CENTER_STEP_MAX        - max random-walk step per segment for the gap
//                            center's vertical position (higher = jerkier).
//   CENTER_SINE_AMPLITUDE  - amplitude of a slow sine wave added on top of
//                            the random walk (higher = wider slow curves).
//   CENTER_SINE_FREQ       - frequency of that sine wave (higher = tighter
//                            curves).
//   SCROLL_SPEED           - horizontal scroll speed in px/sec.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('cave.js requires window.Game to be set up by main.js first');
  }

  var ctx = Game.ctx;
  function palette() { return Game.Theme.get(); }

  // ---- Tuning constants ----
  var SCROLL_SPEED = 100; // px/sec
  var SEGMENT_SPACING = 40; // world-x distance between generated points
  var GAP_MIN = 90;
  var GAP_MAX = 160;
  var CENTER_STEP_MAX = 12; // max random-walk delta per segment
  var CENTER_SINE_AMPLITUDE = 30;
  var CENTER_SINE_FREQ = 0.0015; // radians per world-x unit
  var CENTER_MARGIN = 40; // keep gap center away from canvas top/bottom edges
  var MIN_FLYABLE_GAP = 50; // gap never collapses below this, in any zone

  // "Hard zone" tuning: periodically the cave narrows and steepens.
  var GAP_MIN_HARD = 55;
  var GAP_MAX_HARD = 90;
  var CENTER_STEP_MAX_HARD_MIN = 22;
  var CENTER_STEP_MAX_HARD_MAX = 28;
  var NORMAL_ZONE_LEN_MIN = 15;
  var NORMAL_ZONE_LEN_MAX = 30;
  var HARD_ZONE_LEN_MIN = 8;
  var HARD_ZONE_LEN_MAX = 15;

  var scrollX = 0; // world-x offset of the left edge of the canvas

  // points: array of { x: worldX, top: y, bottom: y }, sorted by ascending x.
  var points = [];

  // Random-walk state for the gap center (independent of the sine term).
  var walkCenter = Game.H / 2;

  // Difficulty-zone state machine: alternates 'normal' and 'hard' zones,
  // each lasting a random number of segments. randRange() is a function
  // declaration, so it is hoisted and safe to use here even though it is
  // defined later in the file.
  var zoneType = 'normal';
  var zoneSegmentsLeft = Math.floor(randRange(NORMAL_ZONE_LEN_MIN, NORMAL_ZONE_LEN_MAX));

  function randRange(min, max) {
    return min + Game.Random.stream('cave').next() * (max - min);
  }

  function clamp(v, min, max) {
    return v < min ? min : (v > max ? max : v);
  }

  function advanceZone() {
    zoneSegmentsLeft--;
    if (zoneSegmentsLeft <= 0) {
      if (zoneType === 'normal') {
        zoneType = 'hard';
        zoneSegmentsLeft = Math.floor(randRange(HARD_ZONE_LEN_MIN, HARD_ZONE_LEN_MAX));
      } else {
        zoneType = 'normal';
        zoneSegmentsLeft = Math.floor(randRange(NORMAL_ZONE_LEN_MIN, NORMAL_ZONE_LEN_MAX));
      }
    }
  }

  function generatePointAt(x) {
    advanceZone();

    var isHard = zoneType === 'hard';
    var centerStepMax = isHard
      ? randRange(CENTER_STEP_MAX_HARD_MIN, CENTER_STEP_MAX_HARD_MAX)
      : CENTER_STEP_MAX;
    var gapFactor = (Game.Difficulty && Game.Difficulty.gapFactor) ? Game.Difficulty.gapFactor() : 1;
    var gapMin = (isHard ? GAP_MIN_HARD : GAP_MIN) * gapFactor;
    var gapMax = (isHard ? GAP_MAX_HARD : GAP_MAX) * gapFactor;

    // Advance the random walk component.
    walkCenter += randRange(-centerStepMax, centerStepMax);
    walkCenter = clamp(walkCenter, CENTER_MARGIN, Game.H - CENTER_MARGIN);

    var sineOffset = Math.sin(x * CENTER_SINE_FREQ) * CENTER_SINE_AMPLITUDE;
    var center = clamp(walkCenter + sineOffset, CENTER_MARGIN, Game.H - CENTER_MARGIN);

    var gap = randRange(gapMin, gapMax);
    // Never let the gap collapse below the minimum flyable width, in any zone.
    gap = Math.max(gap, MIN_FLYABLE_GAP);
    var top = center - gap / 2;
    var bottom = center + gap / 2;

    // Keep walls fully on-canvas.
    top = clamp(top, 0, Game.H - gap);
    bottom = top + gap;

    return { x: x, top: top, bottom: bottom };
  }

  function ensureGeneratedAhead() {
    var rightEdge = scrollX + Game.W;
    // Always keep at least one point beyond the right edge so interpolation
    // never runs off the end of the array while rendering/querying.
    var targetX = rightEdge + SEGMENT_SPACING;

    if (points.length === 0) {
      points.push(generatePointAt(scrollX - SEGMENT_SPACING));
    }

    var lastX = points[points.length - 1].x;
    while (lastX < targetX) {
      lastX += SEGMENT_SPACING;
      points.push(generatePointAt(lastX));
    }
  }

  function prunePassed() {
    // Keep one point at or before the left edge so segments spanning the
    // left edge still interpolate correctly (never remove the last point
    // that is <= scrollX, i.e. always keep the bracketing pair).
    while (points.length > 1 && points[1].x <= scrollX) {
      points.shift();
    }
  }

  function update(dt) {
    var speedMultiplier = (Game.Ship && Game.Ship.getSpeedMultiplier) ? Game.Ship.getSpeedMultiplier() : 1;
    var rampFactor = (Game.Difficulty && Game.Difficulty.scrollFactor) ? Game.Difficulty.scrollFactor() : 1;
    // Level cleared/finished: the cave stands still (background keeps animating).
    if (!(Game.Levels && Game.Levels.levelEnded && Game.Levels.levelEnded())) {
      scrollX += SCROLL_SPEED * rampFactor * speedMultiplier * dt;
    }
    ensureGeneratedAhead();
    prunePassed();
    updateBlend(dt);
  }

  function updateBlend(dt) {
    if (!(dt > 0)) { return; }
    var target = zoneType === 'hard' ? 1 : 0;
    var step = dt / BLEND_SECONDS;
    if (zoneBlend < target) {
      if (zoneBlend === 0) { bannerTimer = BANNER_SECONDS; } // hard zone begins
      zoneBlend = Math.min(target, zoneBlend + step);
    } else if (zoneBlend > target) {
      zoneBlend = Math.max(target, zoneBlend - step);
    }
    if (bannerTimer > 0) { bannerTimer = Math.max(0, bannerTimer - dt); }
  }

  // "HARD SECTION" text, same style as the hazard warnings; Hazards.render
  // calls this so it sits above the lighting overlay.
  function renderBanner(rctx) {
    if (bannerTimer <= 0) { return; }
    var c = rctx || ctx;
    c.save();
    c.font = 'bold 22px monospace';
    c.fillStyle = palette().YELLOW;
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText('HARD SECTION', Game.W / 2, 64);
    c.restore();
  }

  // Pure query function: interpolates between the two bracketing generated
  // points. Out-of-range x is clamped to the nearest known point.
  function getCaveBoundsAtX(worldX) {
    if (points.length === 0) {
      return { top: 0, bottom: Game.H };
    }
    if (worldX <= points[0].x) {
      return { top: points[0].top, bottom: points[0].bottom };
    }
    var last = points[points.length - 1];
    if (worldX >= last.x) {
      return { top: last.top, bottom: last.bottom };
    }
    for (var i = 0; i < points.length - 1; i++) {
      var a = points[i];
      var b = points[i + 1];
      if (worldX >= a.x && worldX <= b.x) {
        var t = (worldX - a.x) / (b.x - a.x);
        return {
          top: a.top + (b.top - a.top) * t,
          bottom: a.bottom + (b.bottom - a.bottom) * t
        };
      }
    }
    // Should not be reached, but fall back sanely.
    return { top: last.top, bottom: last.bottom };
  }

  // ---- Visual-only rock rendering (nu2.20). Everything below works in
  // buffer-pixel units (1 buffer px = 2 logical px). Collision keeps using
  // getCaveBoundsAtX untouched; the jitter never feeds back into it.
  // In high resolution mode everything renders at 1 logical px detail
  // (px() === 1); retro keeps the 2-logical-px buffer grid.
  function hiRes() {
    return !!(Game.Pixel && Game.Pixel.hiRes && Game.Pixel.hiRes());
  }
  function px() { return hiRes() ? 1 : 2; }
  function tileUnits() { return hiRes() ? 64 : 32; } // tile size in render units (64x64 logical either way)
  var tileMode = null;
  var JITTER_MAX = 2; // jitter is 0..2 buffer px
  var tileCanvas = null;
  var tileVersion = null;
  var hotTileCanvas = null;
  var mixTiles = {}; // dither level (1..15) -> mixed normal/hot tile canvas
  var tilePatterns = {}; // dither level (0..16) -> CanvasPattern
  var tilePatternCtx = null;

  // Hard-zone cue (nu2.21): zoneBlend eases 0 (normal) .. 1 (hard) at
  // 1 unit per BLEND_SECONDS. Purely visual; zone logic is untouched.
  var BLEND_SECONDS = 0.5;
  var BANNER_SECONDS = 1.5;
  var zoneBlend = 0;
  var bannerTimer = 0;
  var BAYER_FALLBACK = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];

  // Deterministic integer hash (no Math.random): same input, same output.
  function hash32(n) {
    var h = (n | 0) ^ 0x9e3779b9;
    h = Math.imul(h ^ (h >>> 16), 0x85ebca6b);
    h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
    return (h ^ (h >>> 16)) >>> 0;
  }

  // Edge jitter for a buffer column given its world buffer-column index
  // (worldX / 2, floored). Always an integer in 0..JITTER_MAX.
  function edgeJitter(worldCol) {
    return hash32(Math.floor(worldCol)) % (JITTER_MAX + 1);
  }

  // High-res jitter per logical column: 0..4 logical px (same max depth as
  // retro's 0..2 buffer px), smoothed with the neighbouring columns' hashes.
  function edgeJitterHi(col) {
    var a = edgeJitter(col - 1) * 2, b = edgeJitter(col) * 2, c = edgeJitter(col + 1) * 2;
    return Math.round((a + 2 * b + c) / 4);
  }

  function themeVersion() {
    return (Game.Theme && Game.Theme.version) ? Game.Theme.version() : 0;
  }

  function rockRamp() {
    var r = (Game.Theme && Game.Theme.ramp) ? Game.Theme.ramp('rock') : null;
    if (r && r.length >= 5) { return r; }
    var p = palette();
    return [p.DARK_GREY, p.DARK_GREY, p.GREY, p.GREY, p.LIGHT_GREY || p.GREY];
  }

  function rampOf(name, fallback) {
    var r = (Game.Theme && Game.Theme.ramp) ? Game.Theme.ramp(name) : null;
    return (r && r.length >= 5) ? r : fallback;
  }

  function hotRamp() {
    var p = palette();
    var base = rampOf('rockHot', [p.BROWN, p.BROWN, p.ORANGE, p.ORANGE, p.ORANGE]);
    return (Game.Biomes && Game.Biomes.hotRamp) ? Game.Biomes.hotRamp(base) : base;
  }

  // Tiny hex colour helpers for the high-res smooth ramps.
  function parseHex(c) {
    if (typeof c !== 'string' || c.charAt(0) !== '#') { return null; }
    var h = c.slice(1);
    if (h.length === 3) { h = h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2); }
    if (!/^[0-9a-fA-F]{6}$/.test(h)) { return null; }
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
  }
  function hex2(n) { n = Math.round(clamp(n, 0, 255)); return (n < 16 ? '0' : '') + n.toString(16); }
  // Blend colour a toward b by t (0..1); returns '#rrggbb' (or a/b if unparsable).
  function lerpHex(a, b, t) {
    var A = parseHex(a), B = parseHex(b);
    if (!A || !B) { return t < 0.5 ? a : b; }
    return '#' + hex2(A[0] + (B[0] - A[0]) * t) + hex2(A[1] + (B[1] - A[1]) * t) + hex2(A[2] + (B[2] - A[2]) * t);
  }
  // rgba() of colour a at the given alpha (falls back to a when unparsable).
  function withAlpha(a, alpha) {
    var A = parseHex(a);
    return A ? 'rgba(' + A[0] + ',' + A[1] + ',' + A[2] + ',' + alpha + ')' : a;
  }

  function bayerOf(i) {
    var B = (Game.Sprite && Game.Sprite.BAYER4) || BAYER_FALLBACK;
    return B[i];
  }

  // High-res tile: 64x64 canvas px (1 logical px each), smooth colour ramp
  // between rock shades and rounded shaded pebbles. Periodic, so seamless.
  // Per-pixel css colours are kept on cv._pix for the hot/normal mix.
  function buildTileHi(rock, cv, cx) {
    var T = 64;
    var TWO_PI = Math.PI * 2;
    var pix = new Array(T * T);
    var x, y;
    for (y = 0; y < T; y++) {
      for (x = 0; x < T; x++) {
        var f = Math.sin(TWO_PI * x / T + 0.7) * 0.5 +
          Math.sin(TWO_PI * (2 * y) / T + 2.1) * 0.35 +
          Math.sin(TWO_PI * (x + 2 * y) / T + 4.0) * 0.4 +
          Math.sin(TWO_PI * (3 * x - y) / T) * 0.25 +
          Math.sin(TWO_PI * (5 * x + 3 * y) / T + 1.3) * 0.12 +
          Math.sin(TWO_PI * (4 * y - 7 * x) / T + 5.1) * 0.1;
        var grain = (hash32(y * T + x + 4099) % 1000) / 1000 - 0.5; // fine grain
        var u = clamp(2 + f * 0.9 + grain * 0.35, 1, 2.999);
        var base = Math.floor(u);
        pix[y * T + x] = lerpHex(rock[base], rock[base + 1], u - base);
      }
    }
    function set(sx, sy, color) {
      pix[((((sy % T) + T) % T) * T) + (((sx % T) + T) % T)] = color;
    }
    for (var i = 0; i < 9; i++) {
      var hh = hash32(i * 7919 + 13);
      var cxp = hh % T;
      var cyp = (hh >>> 8) % T;
      var pebbles = 1 + ((hh >>> 16) & 1);
      for (var k = 0; k < pebbles; k++) {
        var ox = cxp + k * 8;
        var oy = cyp + k * 4;
        var rx = 3 + ((hh >>> (20 + k)) & 1);
        var ry = 2 + ((hh >>> (22 + k)) & 1);
        for (var by = -ry; by <= ry; by++) {
          for (var bx = -rx; bx <= rx; bx++) {
            var d = (bx * bx) / (rx * rx + 0.5) + (by * by) / (ry * ry + 0.5);
            if (d > 1) { continue; }
            // Light from the top-left: highlight toward it, shadow at the far rim.
            var lt = clamp(0.5 - (bx / rx + by / ry) * 0.35 - (d > 0.7 ? 0.25 : 0), 0, 1);
            var col = lt > 0.5 ? lerpHex(rock[2], rock[3], (lt - 0.5) * 2) : lerpHex(rock[0], rock[2], lt * 2);
            set(ox + bx, oy + by, col);
          }
        }
      }
    }
    for (y = 0; y < T; y++) {
      for (x = 0; x < T; x++) {
        cx.fillStyle = pix[y * T + x];
        cx.fillRect(x, y, 1, 1);
      }
    }
    cv._pix = pix;
    return cv;
  }

  // Pre-render the seamless rock tile: 32x32 in retro (one canvas pixel = 1
  // buffer px), 64x64 in high (one canvas pixel = 1 logical px).
  function buildTile(rock) {
    if (typeof document === 'undefined' || !document || typeof document.createElement !== 'function') {
      return null;
    }
    var cv, cx;
    try {
      cv = document.createElement('canvas');
      cv.width = tileUnits();
      cv.height = tileUnits();
      cx = cv.getContext('2d');
    } catch (e) {
      return null;
    }
    if (!cx) { return null; }
    if (hiRes()) { return buildTileHi(rock, cv, cx); }
    var TILE = 32;
    var TWO_PI = Math.PI * 2;
    var x, y;
    // Base: smooth, tile-periodic field in [1,3) dithered between rock[1..3].
    for (y = 0; y < TILE; y++) {
      for (x = 0; x < TILE; x++) {
        var f = Math.sin(TWO_PI * x / TILE + 0.7) * 0.5 +
          Math.sin(TWO_PI * (2 * y) / TILE + 2.1) * 0.35 +
          Math.sin(TWO_PI * (x + 2 * y) / TILE + 4.0) * 0.4 +
          Math.sin(TWO_PI * (3 * x - y) / TILE) * 0.25; // about -1.5..1.5
        var u = clamp(2 + f * 0.9, 1, 2.999); // 1..3
        var base = Math.floor(u);
        var level = Math.round((u - base) * 16);
        var up = bayerOf((y & 3) * 4 + (x & 3)) < level;
        cx.fillStyle = rock[base + (up ? 1 : 0)];
        cx.fillRect(x, y, 1, 1);
      }
    }
    // Pebble clusters at hashed positions; coordinates wrap so no seam.
    function put(px, py, color) {
      cx.fillStyle = color;
      cx.fillRect(((px % TILE) + TILE) % TILE, ((py % TILE) + TILE) % TILE, 1, 1);
    }
    for (var i = 0; i < 9; i++) {
      var hh = hash32(i * 7919 + 13);
      var cxp = hh % TILE;
      var cyp = (hh >>> 8) % TILE;
      var pebbles = 1 + ((hh >>> 16) & 1);
      for (var k = 0; k < pebbles; k++) {
        var ox = cxp + k * 4;
        var oy = cyp + k * 2;
        // 3x2 body, highlight top-left, shadow bottom-right.
        for (var by = 0; by < 2; by++) {
          for (var bx = 0; bx < 3; bx++) { put(ox + bx, oy + by, rock[2]); }
        }
        put(ox, oy, rock[3]);
        put(ox + 2, oy + 1, rock[0]);
      }
    }
    return cv;
  }

  function ensureTile() {
    var v = themeVersion();
    var mode = hiRes() ? 'high' : 'retro';
    if (v !== tileVersion || mode !== tileMode) {
      tileMode = mode;
      tileCanvas = buildTile(rockRamp());
      hotTileCanvas = buildTile(hotRamp());
      mixTiles = {};
      tileVersion = v;
      tilePatterns = {};
      tilePatternCtx = null;
    }
    return tileCanvas;
  }

  // Normal tile with hot-tile pixels where the Bayer mask is below level.
  function mixTile(level) {
    if (mixTiles[level]) { return mixTiles[level]; }
    var cv, cx;
    try {
      cv = document.createElement('canvas');
      cv.width = tileUnits();
      cv.height = tileUnits();
      cx = cv.getContext('2d');
    } catch (e) {
      return null;
    }
    if (!cx) { return null; }
    if (hiRes()) {
      // Smooth per-pixel colour blend toward the hot tile.
      var T = 64, pa = tileCanvas._pix, pb = hotTileCanvas._pix;
      if (!pa || !pb) { return null; }
      for (var i = 0; i < T * T; i++) {
        cx.fillStyle = lerpHex(pa[i], pb[i], level / 16);
        cx.fillRect(i % T, (i / T) | 0, 1, 1);
      }
      mixTiles[level] = cv;
      return cv;
    }
    var TILE = 32;
    cx.drawImage(tileCanvas, 0, 0);
    for (var y = 0; y < TILE; y++) {
      for (var x = 0; x < TILE; x++) {
        if (bayerOf((y & 3) * 4 + (x & 3)) < level) {
          cx.drawImage(hotTileCanvas, x, y, 1, 1, x, y, 1, 1);
        }
      }
    }
    mixTiles[level] = cv;
    return cv;
  }

  function blendLevel() {
    return Math.round(zoneBlend * 16);
  }

  function rockFill(c) {
    var tile = ensureTile();
    var level = blendLevel();
    if (tile && hotTileCanvas && typeof c.createPattern === 'function') {
      if (tilePatternCtx !== c) {
        tilePatterns = {};
        tilePatternCtx = c;
      }
      if (!tilePatterns[level]) {
        var src = level <= 0 ? tile : (level >= 16 ? hotTileCanvas : mixTile(level));
        tilePatterns[level] = src ? c.createPattern(src, 'repeat') : null;
      }
      if (tilePatterns[level]) { return tilePatterns[level]; }
    }
    return level >= 8 ? hotRamp()[2] : rockRamp()[2];
  }

  // Stepped wall outline in buffer px: one horizontal step per column.
  function wallPath(c, edges, n, off, baseY) {
    c.beginPath();
    c.moveTo(off, baseY);
    for (var i = 0; i < n; i++) {
      c.lineTo(off + i, edges[i]);
      c.lineTo(off + i + 1, edges[i]);
    }
    c.lineTo(off + n, baseY);
    c.closePath();
  }

  // Calls fn(startCol, endColExclusive, edgeY) for runs of equal edge value.
  function eachRun(edges, n, fn) {
    var s = 0;
    for (var i = 1; i <= n; i++) {
      if (i === n || edges[i] !== edges[s]) {
        fn(s, i, edges[s]);
        s = i;
      }
    }
  }

  function bandFill(c, colorA, colorB, level) {
    var p = (Game.Sprite && Game.Sprite.ditherPattern)
      ? Game.Sprite.ditherPattern(c, colorA, colorB, level) : null;
    return p || colorA;
  }

  // High-res bands: smooth gradient over the same 28 logical px extent from
  // the outer screen edge, then a 2 px rim light with a shadow behind it.
  function drawWallHi(c, edges, n, off, isTop, rock, BH, baseY) {
    c.save();
    wallPath(c, edges, n, off, baseY);
    c.clip();
    var EXT = 28, d;
    for (d = 0; d < EXT; d++) {
      var col;
      if (d < 8) { col = rock[0]; }
      else if (d < 18) { col = lerpHex(rock[0], rock[1], (d - 8) / 10); }
      else { col = withAlpha(rock[1], (1 - (d - 18) / 10).toFixed(2)); }
      c.fillStyle = col;
      c.fillRect(off, isTop ? d : BH - d - 1, n, 1);
    }
    c.restore();

    var rimColor = zoneBlend > 0.5 ? rampOf('fire', rock)[3] : rock[4];
    var rimSoft = lerpHex(rimColor, rock[2], 0.5);
    eachRun(edges, n, function (s, e, y) {
      c.fillStyle = rock[0];
      c.fillRect(off + s, isTop ? y - 3 : y + 2, e - s, 1);
      c.fillStyle = rimSoft;
      c.fillRect(off + s, isTop ? y - 2 : y + 1, e - s, 1);
      c.fillStyle = rimColor;
      c.fillRect(off + s, isTop ? y - 1 : y, e - s, 1);
    });
  }

  function drawWall(c, edges, n, off, isTop, rock) {
    var BH = Game.H / px();
    var baseY = isTop ? 0 : BH;
    wallPath(c, edges, n, off, baseY);
    c.fillStyle = rockFill(c);
    c.fill();

    if (hiRes()) {
      drawWallHi(c, edges, n, off, isTop, rock, BH, baseY);
      return;
    }

    // Three darker dithered bands toward the outer screen edge, clipped to
    // the wall. Outermost uses the darkest shade.
    c.save();
    wallPath(c, edges, n, off, baseY);
    c.clip();
    var bands = [
      { from: 9, to: 14, fill: bandFill(c, rock[1], rock[2], 5) },
      { from: 4, to: 9, fill: bandFill(c, rock[0], rock[1], 9) },
      { from: 0, to: 4, fill: rock[0] }
    ];
    for (var b = 0; b < bands.length; b++) {
      var y0 = isTop ? bands[b].from : BH - bands[b].to;
      c.fillStyle = bands[b].fill;
      c.fillRect(off, y0, n, bands[b].to - bands[b].from);
    }
    c.restore();

    var rimColor = zoneBlend > 0.5 ? rampOf('fire', rock)[3] : rock[4];
    // Rim light: 1 px of rock[4] on the gap-side edge, 1 px of rock[0] behind.
    eachRun(edges, n, function (s, e, y) {
      var rimY = isTop ? y - 1 : y;
      var backY = isTop ? y - 2 : y + 1;
      c.fillStyle = rock[0];
      c.fillRect(off + s, backY, e - s, 1);
      c.fillStyle = rimColor;
      c.fillRect(off + s, rimY, e - s, 1);
    });
  }

  function render(rctx) {
    ctx = rctx || Game.ctx; // main.js passes the active (possibly pixel-buffer) context
    ctx.fillStyle = palette().BLACK;
    ctx.fillRect(0, 0, Game.W, Game.H);
    if (Game.Background && Game.Background.render) {
      Game.Background.render(ctx, scrollX);
    }

    if (points.length === 0) {
      return;
    }

    var PX = px();
    var hi = PX === 1;
    var TILE = tileUnits();
    var BW = Math.ceil(Game.W / PX);
    var BH = Game.H / PX;
    var n = BW + 1;
    var bs = Math.floor(scrollX / PX); // snapped scroll, in render units
    var off = ((bs % TILE) + TILE) % TILE; // keeps pattern locked to the world
    var topEdges = new Array(n);
    var botEdges = new Array(n);
    for (var i = 0; i < n; i++) {
      var col = bs + i;
      var bounds = getCaveBoundsAtX(col * PX + PX / 2);
      var j = hi ? edgeJitterHi(col) : edgeJitter(col);
      // Jitter pushes the drawn wall 0..2 buffer px into the gap.
      topEdges[i] = clamp(Math.round(bounds.top / PX) + j, 0, BH);
      botEdges[i] = clamp(Math.round(bounds.bottom / PX) - j, 0, BH);
    }

    var rock = rockRamp();
    ctx.save();
    if (!hi) { ctx.scale(PX, PX); } // from here on, 1 unit = 1 buffer px
    ctx.translate(-off, 0); // pattern origin so tile/dither scroll with walls
    ctx.imageSmoothingEnabled = false;
    drawWall(ctx, topEdges, n, off, true, rock);
    drawWall(ctx, botEdges, n, off, false, rock);
    ctx.restore();
  }

  function getScrollX() {
    return scrollX;
  }

  // Exposes the current difficulty zone ('normal' or 'hard') so other
  // subsystems (e.g. hazards.js) can gate behavior to specific zones without
  // duplicating the zone state machine.
  function getZoneType() {
    return zoneType;
  }

  function reset() {
    scrollX = 0;
    points = [];
    walkCenter = Game.H / 2;
    zoneType = 'normal';
    zoneSegmentsLeft = Math.floor(randRange(NORMAL_ZONE_LEN_MIN, NORMAL_ZONE_LEN_MAX));
    zoneBlend = 0;
    bannerTimer = 0;
    // Reuse the same bootstrap logic that generates the initial window of
    // points on first use, so reset() produces identical state to a fresh
    // page load.
    ensureGeneratedAhead();
  }

  Game.Cave = {
    update: update,
    render: render,
    getCaveBoundsAtX: getCaveBoundsAtX,
    getScrollX: getScrollX,
    getZoneType: getZoneType,
    edgeJitter: edgeJitter,
    _tileSize: function () { var t = ensureTile(); return t ? t.width : tileUnits(); },
    getZoneBlend: function () { return zoneBlend; },
    renderBanner: renderBanner,
    reset: reset,
    SEGMENT_SPACING: SEGMENT_SPACING
  };
})();
