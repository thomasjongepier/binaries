// Spelunker - score owner.
// Single owner of the run total: kills + distance + discoveries.
(function () {
  'use strict';
  window.Game = window.Game || {};

  var DISTANCE_DIVISOR = 10;
  var kills = 0;
  var distancePoints = 0;
  var discoveryPoints = 0;
  var lastScrollX = null;

  // Kill combo. comboClock counts playing seconds since the last kill; it is
  // advanced by update(scrollX, dt), which main.js only calls while playing
  // and unpaused.
  var COMBO_WINDOW = 2.0;
  var MULT_STEP = 0.5;
  var MULT_CAP = 4;
  var combo = 0;
  var bestCombo = 0;
  var comboClock = 0;

  function multiplier(c) {
    return Math.min(1 + MULT_STEP * (c - 1), MULT_CAP);
  }

  function reset() {
    combo = 0;
    bestCombo = 0;
    comboClock = 0;
    kills = 0;
    distancePoints = 0;
    discoveryPoints = 0;
    lastScrollX = null;
  }

  // Registers a kill worth `base` points (default 100) and returns the points
  // actually awarded after the combo multiplier, rounded to the nearest 10.
  function addKill(base) {
    if (typeof base !== 'number' || !isFinite(base)) base = 100;
    if (combo > 0 && comboClock <= COMBO_WINDOW) combo += 1; else combo = 1;
    comboClock = 0;
    if (combo > bestCombo) bestCombo = combo;
    var pts = Math.round(base * multiplier(combo) / 10) * 10;
    kills += pts;
    return pts;
  }

  function tick(dt) {
    if (typeof dt === 'number' && isFinite(dt) && dt > 0) comboClock += dt;
  }

  // Current combo for the HUD; 0 once the window has lapsed.
  function getCombo() {
    return (combo > 0 && comboClock <= COMBO_WINDOW) ? combo : 0;
  }

  function addDiscovery(points) {
    discoveryPoints += (typeof points === 'number' && isFinite(points)) ? points : 0;
  }

  // Called once per PLAYING frame with the current world scroll. The first
  // call after reset only sets the baseline.
  function update(scrollX, dt) {
    tick(dt);
    if (typeof scrollX !== 'number' || !isFinite(scrollX)) return;
    if (lastScrollX !== null && scrollX > lastScrollX) {
      distancePoints += (scrollX - lastScrollX) / DISTANCE_DIVISOR;
    }
    lastScrollX = scrollX;
  }

  function total() {
    return Math.floor(kills + distancePoints + discoveryPoints);
  }

  function getBreakdown() {
    return {
      total: total(),
      kills: kills,
      distancePoints: Math.floor(distancePoints),
      discoveryPoints: discoveryPoints,
      bestCombo: bestCombo
    };
  }

  window.Game.Score = {
    reset: reset,
    addKill: addKill,
    addDiscovery: addDiscovery,
    update: update,
    tick: tick,
    getCombo: getCombo,
    getBestCombo: function () { return bestCombo; },
    multiplier: multiplier,
    total: total,
    getBreakdown: getBreakdown,
    get kills() { return kills; },
    get distancePoints() { return distancePoints; },
    get discoveryPoints() { return discoveryPoints; }
  };
})();
