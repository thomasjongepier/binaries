// Spelunker - centralized balance/tuning config.
// Vanilla JS, no build tools, no dependencies. Attaches to window.Game
// (created by main.js) so other modules can read Game.Balance.* instead
// of keeping their own local tuning constants.
(function () {
  'use strict';

  var Game = window.Game;
  if (!Game) {
    throw new Error('config.js requires window.Game to be set up by main.js first');
  }

  Game.Balance = {
    stamina: {
      MAX_STAMINA: 100,
      DRAIN_RATE: 12, // stamina/sec while thrusting
      REGEN_RATE: 8, // stamina/sec while idle
      RECOVER_THRESHOLD: 20, // stamina must exceed this to lift the depleted penalty
      DEPLETED_MULTIPLIER: 0.5 // thrust multiplier applied while depleted
    },
    hazards: {
      collapse: {
        TRIGGER_CHANCE_PER_SEC: 0.15, // chance per second while in a 'hard' zone
        SHIELD_DAMAGE: 20,
        COOLDOWN_DURATION: 4, // seconds
        WARNING_DURATION: 1.5 // seconds the on-screen warning text is shown
      },
      gas: {
        TRIGGER_CHANCE_PER_SEC: 0.12, // chance per second while in a 'normal' zone
        SHIELD_DAMAGE: 10,
        COOLDOWN_DURATION: 3, // seconds
        WARNING_DURATION: 1.5 // seconds the on-screen warning text is shown
      }
    },
    discoveries: {
      crystal: {
        SPAWN_MIN: 7, // seconds
        SPAWN_MAX: 11, // seconds
        VALUE: 10
      },
      fossil: {
        SPAWN_MIN: 25, // seconds
        SPAWN_MAX: 35, // seconds
        VALUE: 50
      }
    }
  };
})();
