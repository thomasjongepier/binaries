// Game-over screen: run stats with a count-up total.
// Pure helpers (rows, countValue) are unit-tested; render() draws the layout
// for the 640x400 logical canvas using Game.Font.
(function () {
  'use strict';
  window.Game = window.Game || {};

  var COUNT_SECONDS = 1.2;

  function int(v) {
    v = Math.floor(+v);
    return isFinite(v) && v > 0 ? v : 0;
  }

  // Breakdown rows that always add up to the total exactly: distance is the
  // remainder after kills and discoveries.
  function rows(b) {
    b = b || {};
    var total = int(b.total);
    var kills = Math.min(int(b.kills), total);
    var disc = Math.min(int(b.discoveryPoints), total - kills);
    var dist = total - kills - disc;
    return {
      total: total,
      items: [
        { label: 'KILLS', value: kills },
        { label: 'DISTANCE', value: dist },
        { label: 'DISCOVERIES', value: disc }
      ]
    };
  }

  // Displayed total t seconds after the screen appears (integer, ends at total).
  function countValue(total, t) {
    total = int(total);
    if (!(t > 0)) { return 0; }
    if (t >= COUNT_SECONDS) { return total; }
    return Math.min(total, Math.floor(total * (t / COUNT_SECONDS)));
  }

  function text(ctx, s, x, y, color, align, scale, role, css) {
    var F = window.Game.Font;
    if (F && F.draw) {
      F.draw(ctx, s, x, y, { role: role || 'body', css: css || 'bold 16px monospace',
        color: color, align: align, baseline: 'middle', scale: scale || 1 });
    }
  }

  // opts: { W, H, breakdown, t, blink, highScore, palette, biomes }
  function render(ctx, opts) {
    var W = opts.W || 640, P = opts.palette || {};
    var white = P.WHITE || '#FFFFFF', yellow = P.YELLOW || '#FFFF00', green = P.GREEN || '#00FF00';
    var r = rows(opts.breakdown);
    var t = opts.t || 0;

    text(ctx, 'GAME OVER', W / 2, 56, yellow, 'center', 2, 'title', 'bold 44px monospace');

    var xl = W / 2 - 130, xr = W / 2 + 130, y = 115;
    r.items.forEach(function (it) {
      text(ctx, it.label, xl, y, white, 'left');
      text(ctx, String(it.value), xr, y, white, 'right');
      y += 26;
    });
    ctx.save();
    ctx.fillStyle = white;
    ctx.fillRect(xl, y - 12, xr - xl, 2);
    ctx.restore();
    y += 14;
    text(ctx, 'TOTAL', xl, y, yellow, 'left', 1, 'body', 'bold 20px monospace');
    text(ctx, String(countValue(r.total, t)), xr, y, yellow, 'right', 1, 'body', 'bold 20px monospace');
    y += 34;
    var combo = int(opts.breakdown && opts.breakdown.bestCombo);
    text(ctx, 'BEST COMBO X' + combo, W / 2, y, green, 'center');
    y += 24;
    if (opts.biomes && opts.biomes.length) {
      text(ctx, 'BIOMES: ' + opts.biomes.join(', ').toUpperCase(), W / 2, y, green, 'center');
    }
    if (opts.finds && opts.finds.length) {
      var C = window.Game.Codex;
      var names = opts.finds.map(function (id) { return C && C.nameOf ? C.nameOf(id) : id; });
      text(ctx, 'FINDS: ' + names.join(', ').toUpperCase(), W / 2, y + 24, green, 'center', 1, 'body', 'bold 12px monospace');
    }
    if (opts.highScore && t >= COUNT_SECONDS) {
      text(ctx, 'NEW HIGH SCORE!', W / 2, 300, yellow, 'center', 1, 'body', 'bold 20px monospace');
    }
    if (opts.blink) {
      text(ctx, 'PRESS ANY KEY OR CLICK TO RESTART', W / 2, 360, white, 'center');
    }
  }

  window.Game.GameOverScreen = { rows: rows, countValue: countValue, render: render,
    COUNT_SECONDS: COUNT_SECONDS };
})();
