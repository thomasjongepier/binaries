// daily.js - Daily cave: a shared seed built from the player's local date.
//
// Game.Daily.begin() is called by the title menu's DAILY CAVE item right before
// it starts a run. main.js calls prepareRun(prevState) at the start of every
// run (before subsystem resets) and recordScore(score) when a run ends.
//  - From TITLE the run is daily only if begin() was just called; from GAMEOVER
//    the previous mode (and seed) is kept, so a retry flies the same cave.
//  - Daily runs call Game.Random.setSeed(YYYYMMDD); the first normal run after
//    a daily one reseeds randomly so normal play stays random.
// Only the cave walls are deterministic; enemy/pickup/hazard timing is not.
// Best score is stored per date under 'spelunker.daily.<YYYYMMDD>'.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  var KEY_PREFIX = 'spelunker.daily.';
  var LABEL = 'Same cave for everyone today';

  var pending = false;   // begin() called, consumed by the next prepareRun
  var active = false;    // current run is a daily run
  var seededDaily = false; // random streams currently hold a daily seed
  var runSeed = 0;

  function today() { return new Date(); }

  // Local date as the number YYYYMMDD.
  function seedForDate(d) {
    d = d || today();
    return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
  }

  function getStorage() {
    try { return window.localStorage || null; } catch (e) { return null; }
  }

  function keyFor(seed) { return KEY_PREFIX + seed; }

  function getBest(seed) {
    seed = seed || seedForDate();
    try {
      var s = getStorage();
      var raw = s ? s.getItem(keyFor(seed)) : null;
      var n = Math.floor(Number(raw));
      return raw !== null && isFinite(n) && n > 0 ? n : 0;
    } catch (e) { return 0; }
  }

  // Stores score if it beats today's best (daily runs only). Returns true if so.
  function recordScore(score) {
    if (!active) return false;
    score = Math.floor(Number(score));
    if (!isFinite(score) || score <= 0 || score <= getBest(runSeed)) return false;
    try {
      var s = getStorage();
      if (s) s.setItem(keyFor(runSeed), String(score));
    } catch (e) { /* storage unavailable: best is not persisted */ }
    return true;
  }

  function begin() { pending = true; }

  function prepareRun(prevState) {
    var fromTitle = !(Game.STATES && prevState === Game.STATES.GAMEOVER);
    if (fromTitle) {
      active = pending;
      if (active) runSeed = seedForDate();
    }
    pending = false;
    if (active) {
      if (Game.Random && Game.Random.setSeed) Game.Random.setSeed(runSeed);
      seededDaily = true;
    } else if (seededDaily) {
      if (Game.Random && Game.Random.setSeed) Game.Random.setSeed(Math.floor(Math.random() * 4294967296));
      seededDaily = false;
    }
  }

  Game.Daily = {
    label: LABEL,
    seedForDate: seedForDate,
    begin: begin,
    prepareRun: prepareRun,
    recordScore: recordScore,
    getBest: getBest,
    isActive: function () { return active; },
    getSeed: function () { return runSeed; }
  };
})();
