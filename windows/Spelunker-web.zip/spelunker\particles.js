// Shared particle system: hard pixel squares from a fixed pool of 256 slots,
// optionally stepping through a theme colour ramp over their life. Never
// draws circles or gradients.
(function () {
  'use strict';

  window.Game = window.Game || {};

  var POOL = 256;
  var pool = [];
  var next = 0; // next slot to overwrite (ring: oldest first)
  var seq = 0;
  var i;
  for (i = 0; i < POOL; i++) {
    pool.push({ alive: false, x: 0, y: 0, vx: 0, vy: 0, age: 0, life: 1, size: 1,
      color: null, ramp: null, gravity: 0, fade: true, lighter: false, order: 0 });
  }

  // Ramps run dark -> light, so the lightest shade is the last index.
  function rampIndex(age, life, n) {
    var idx = Math.floor((1 - age / life) * n);
    return idx < 0 ? 0 : (idx > n - 1 ? n - 1 : idx);
  }

  function rnd(range, dflt) {
    var lo, hi;
    if (typeof range === 'number') { lo = hi = range; }
    else if (range && typeof range.min === 'number') {
      lo = range.min;
      hi = typeof range.max === 'number' ? range.max : range.min;
    } else { lo = hi = dflt; }
    return lo + Math.random() * (hi - lo);
  }

  function emit(x, y, o) {
    o = o || {};
    var count = o.count === undefined ? 1 : o.count;
    var full = typeof o.angle !== 'number';
    var spread = typeof o.spread === 'number' ? o.spread : 0;
    for (var n = 0; n < count; n++) {
      var p = pool[next];
      next = (next + 1) % POOL; // ring order => overwrites the oldest slot
      var a = full ? Math.random() * Math.PI * 2 : o.angle + (Math.random() - 0.5) * spread;
      var s = rnd(o.speed, 50);
      p.alive = true;
      p.x = x; p.y = y;
      p.vx = Math.cos(a) * s;
      p.vy = Math.sin(a) * s;
      p.age = 0;
      p.life = Math.max(0.0001, rnd(o.life, 0.5));
      var sz = Math.round(rnd(o.size, 1));
      p.size = sz < 1 ? 1 : (sz > 3 ? 3 : sz);
      p.color = o.color || '#ffffff';
      p.ramp = o.ramp || null;
      p.gravity = o.gravity || 0;
      p.fade = o.fade !== false;
      p.lighter = o.blend === 'lighter';
      p.order = ++seq;
    }
  }

  function update(dt) {
    if (!(dt > 0)) { return; }
    for (var k = 0; k < POOL; k++) {
      var p = pool[k];
      if (!p.alive) { continue; }
      p.age += dt;
      if (p.age >= p.life) { p.alive = false; continue; }
      p.vy += p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
  }

  function resolve(p) {
    var T = window.Game.Theme;
    if (p.ramp && T && T.ramp) {
      var r = T.ramp(p.ramp);
      if (r && r.length) { return r[rampIndex(p.age, p.life, r.length)]; }
    }
    var pal = T && T.get ? T.get() : null;
    return (pal && pal[p.color]) || p.color;
  }

  function render(ctx) {
    if (!ctx) { return; }
    var P = window.Game.Pixel;
    var snap = P && P.snap ? P.snap : function (v) { return Math.round(v); };
    var scale = P && P.SCALE ? P.SCALE : 2;
    var prevAlpha = ctx.globalAlpha;
    var prevOp = ctx.globalCompositeOperation;
    for (var k = 0; k < POOL; k++) {
      var p = pool[k];
      if (!p.alive) { continue; }
      ctx.globalAlpha = p.fade ? Math.max(0, 1 - p.age / p.life) : 1;
      ctx.globalCompositeOperation = p.lighter ? 'lighter' : 'source-over';
      ctx.fillStyle = resolve(p);
      var sz = p.size * scale;
      ctx.fillRect(snap(p.x), snap(p.y), sz, sz);
    }
    ctx.globalAlpha = prevAlpha === undefined ? 1 : prevAlpha;
    ctx.globalCompositeOperation = prevOp === undefined ? 'source-over' : prevOp;
  }

  function reset() {
    for (var k = 0; k < POOL; k++) { pool[k].alive = false; }
    next = 0;
  }

  window.Game.Particles = {
    POOL_SIZE: POOL,
    emit: emit,
    update: update,
    render: render,
    reset: reset,
    rampIndex: rampIndex,
    // For tests: number of live particles and total slots.
    aliveCount: function () {
      var c = 0;
      for (var k = 0; k < POOL; k++) { if (pool[k].alive) { c++; } }
      return c;
    },
    poolSize: function () { return pool.length; }
  };
})();
