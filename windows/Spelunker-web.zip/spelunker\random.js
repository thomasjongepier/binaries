// random.js - named, independent, seedable PRNG streams (mulberry32).
//
// Game.Random.stream(name) returns { next, range, int }. Streams are created on
// first use. Game.Random.setSeed(n) reseeds existing streams and sets the base
// seed for streams created later. Without setSeed the base seed comes from
// Math.random, so normal play stays random.
(function () {
  'use strict';

  window.Game = window.Game || {};

  var baseSeed = Math.floor(Math.random() * 4294967296) >>> 0;
  var streams = {};

  // FNV-1a hash of the stream name, mixed with the base seed.
  function seedFor(name) {
    var h = 2166136261;
    for (var i = 0; i < name.length; i++) {
      h ^= name.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h ^ baseSeed) >>> 0;
  }

  function createStream(name) {
    var state = seedFor(name);
    var s = {
      next: function () {
        state = (state + 0x6D2B79F5) >>> 0;
        var t = state;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
      },
      range: function (min, max) {
        return min + s.next() * (max - min);
      },
      // Integer in [min, max] inclusive.
      int: function (min, max) {
        return min + Math.floor(s.next() * (max - min + 1));
      },
      _reseed: function () { state = seedFor(name); }
    };
    return s;
  }

  function stream(name) {
    name = String(name);
    if (!Object.prototype.hasOwnProperty.call(streams, name)) {
      streams[name] = createStream(name);
    }
    return streams[name];
  }

  function setSeed(n) {
    baseSeed = (Number(n) || 0) >>> 0;
    for (var name in streams) {
      if (Object.prototype.hasOwnProperty.call(streams, name)) {
        streams[name]._reseed();
      }
    }
  }

  window.Game.Random = { stream: stream, setSeed: setSeed };
})();
