// touch.js - touch controls for tablets and phones.
//
// While playing, the first finger on the canvas steers the ship (its clientY
// becomes the ship's target y, through the same scaling as the mouse) and a
// finger-down fires. Extra fingers are ignored. Everything else (title, game
// over, paused, options) is left alone: the browser's synthesized click then
// starts / resumes / navigates exactly like a mouse click, so no preventDefault
// is called there and clicks are not doubled.
(function () {
  'use strict';

  window.Game = window.Game || {};
  var Game = window.Game;

  var activeId = null; // identifier of the steering finger, null when none

  function playing() {
    return !!(Game.STATES && Game.getState && Game.getState() === Game.STATES.PLAYING) &&
      !(Game.isPaused && Game.isPaused());
  }

  function steer(touch) {
    if (Game.Ship && Game.Ship.setPointerClientY && touch) {
      Game.Ship.setPointerClientY(touch.clientY);
    }
  }

  function findTouch(list, id) {
    if (!list) { return null; }
    for (var i = 0; i < list.length; i++) {
      if (list[i].identifier === id) { return list[i]; }
    }
    return null;
  }

  function onTouchStart(e) {
    if (!e || !e.changedTouches || !e.changedTouches.length) { return; }
    if (!playing()) { activeId = null; return; } // let the click path handle it
    if (activeId !== null) { return; }            // first touch only
    var t = e.changedTouches[0];
    activeId = t.identifier;
    steer(t);
    if (Game.Projectiles && Game.Projectiles.tryFire) { Game.Projectiles.tryFire(); }
    if (e.cancelable && e.preventDefault) { e.preventDefault(); }
  }

  function onTouchMove(e) {
    if (activeId === null || !e || !playing()) { return; }
    var t = findTouch(e.changedTouches, activeId);
    if (!t) { return; }
    steer(t);
    if (e.cancelable && e.preventDefault) { e.preventDefault(); }
  }

  function onTouchEnd(e) {
    if (activeId === null || !e) { return; }
    if (findTouch(e.changedTouches, activeId)) { activeId = null; }
  }

  var canvas = Game.canvas;
  if (canvas && canvas.addEventListener) {
    var opts = { passive: false };
    canvas.addEventListener('touchstart', onTouchStart, opts);
    canvas.addEventListener('touchmove', onTouchMove, opts);
    canvas.addEventListener('touchend', onTouchEnd);
    canvas.addEventListener('touchcancel', onTouchEnd);
  }

  Game.Touch = {
    onTouchStart: onTouchStart,
    onTouchMove: onTouchMove,
    onTouchEnd: onTouchEnd,
    getActiveId: function () { return activeId; }
  };
})();
