// The 3D dressing room: her live 3D figure in the dress-up page, on a canvas over the 2D picture's place.
// The 2D SVG stays in the page, hidden: it is still the one source of truth (state, colours, the face and
// clothing pictures all come from it, see facetex.js), so this file keeps no copy of her options. It only
// watches the SVG change and dresses the 3D her again.
//
//   await PREVIEW3D.start(wrap, svg)   build her on a canvas inside `wrap`; false if WebGL is not available
//   PREVIEW3D.active                   true once the first picture is on screen
//   PREVIEW3D.cheer()                  a little dance (Surprise me!, Save)
//   PREVIEW3D.pause(true / false)      stop drawing while the 3D world is open
//   PREVIEW3D.snapshot(w, h)           a canvas of her, front, whole body, on a transparent background
//
// Needs window.THREE, TOON, FACETEX, CHARACTER3D, and from game.js: state, ACCESSORY_ZONE.
// Starts with window.__STILL (the screenshot tools): no idle animation, the view jumps instead of gliding,
// and a picture is drawn only when something changed.
(function () {
  const T = window.THREE;

  // Where the camera looks (height on her, distance) and how far her body is turned, per part of her.
  const VIEWS = {
    body: { y: 1.05, dist: 4.7, turn: 0 },
    head: { y: 1.6, dist: 2.9, turn: 0.45 },     // hair: a little to the side, so the length behind shows too
    top: { y: 1.7, dist: 3.4, turn: 0.2 },       // hats, horns, ears on top: room above the head for tall ones
    face: { y: 1.55, dist: 3.1, turn: 0 },
    chest: { y: 1.3, dist: 3.5, turn: 0 },
  };
  const TAB_VIEW = { hair: 'head', clothing: 'body', background: 'body' };
  // D6: the face and makeup tabs look at the face, closer, at the part they are about (y = what the camera looks at on her, dist = how
  // far); `frameFace` below then moves and backs the camera off as much as her hair and what is on her head need, so nothing is cut off.
  const FACE_FOCUS = {
    face: { y: 1.52, dist: 2.75 },                // the Face tab (and Paint, and an extra worn on the face): the whole head
    eyes: { y: 1.62, dist: 2.5 },                 // eyes, brows, eyeshadow: the eye line in the middle
    mouth: { y: 1.42, dist: 2.5 },                // nose, mouth, lipstick: lower, the lips in the middle
    cheeks: { y: 1.5, dist: 2.55 },
  };
  const TAB_FOCUS = { eyes: 'eyes', brows: 'eyes', eyeshadow: 'eyes', nose: 'mouth', mouth: 'mouth', lipstick: 'mouth', cheeks: 'cheeks' };
  const CHIN_Y = 1.25;                            // the chin, in the model's frame (the camera always keeps it in the picture)

  const ZONE_VIEW = { eyes: 'face', ears: 'head', neck: 'chest', hand: 'body', head: 'top' };
  const OUTLINE_PX = 4.4;                         // the picture is about half as tall as the world's, so twice the width
  const FOV = 28, PITCH = 0.07;                    // a little from above, like a doll on a shelf
  const TAN_HALF_FOV = Math.tan(FOV / 2 * Math.PI / 180);
  const RETURN_AFTER = 1.8;                        // seconds after letting go before she turns back to the front
  const FACE_VARS = ['--skin', '--eye', '--lip', '--blush', '--shadow', '--brow'];   // what the face pictures are drawn with
  const CLOTH_VARS = ['--clothing', '--pattern'];

  let renderer, scene, camera, char, pivot, canvas, wrap, svgEl, observer;
  let raf = 0, last = 0, paused = false, needsDraw = true, running = false;
  const view = { y: VIEWS.body.y, dist: VIEWS.body.dist, turn: 0 };
  const turn = { user: 0, drag: null, released: 0 };
  const sync = { busy: false, again: false, queued: false, done: null };
  const still = () => !!window.__STILL;

  const layerText = id => {
    const el = svgEl.querySelector('#layer-' + id);
    return el ? el.innerHTML + '|' + (el.getAttribute('transform') || '') : '';
  };
  const varsText = (vars, names) => names.map(n => vars[n]).join('|');
  function signatures() {
    const vars = colorVars();
    return {
      face: ['face', 'cheeks', 'nose', 'mouth', 'lipstick', 'marks', 'eyeshadow', 'eyes', 'brows'].map(layerText).join('#') + varsText(vars, FACE_VARS),
      cloth: layerText('clothing') + varsText(vars, CLOTH_VARS),
      all: JSON.stringify(vars) + state.hair + JSON.stringify(state.scales.hair || 0) + state.face + state.accessories.map(id => id + JSON.stringify([state.scales['accessories::' + id], state.offsets['accessories::' + id]])).join(),
    };
  }

  // Dress her again from the SVG, redrawing only the pictures that changed. Changes that arrive while
  // that is busy are picked up by one more round.
  async function dressAgain() {
    if (sync.busy) { sync.again = true; return; }
    sync.busy = true;
    try {
      do {
        sync.again = false;
        const now = signatures(), before = sync.done;
        if (!before || now.all !== before.all || now.face !== before.face || now.cloth !== before.cloth) {
          await char.dress(renderer, { face: !before || now.face !== before.face, cloth: !before || now.cloth !== before.cloth });
          sync.done = now;
          aim();                                   // her hair or hat changed: the close-up may need more room
          needsDraw = true;
        }
      } while (sync.again);
    } finally { sync.busy = false; }
  }
  function queueDress() {
    if (sync.queued) return;
    sync.queued = true;
    requestAnimationFrame(() => { sync.queued = false; dressAgain(); aim(); });
  }

  // Where the camera must be for a face tab's close-up: as close as the focus says, but far enough (and high or low enough) that the
  // top of her hair or hat, its width and her chin all stay in the picture.
  function frameFace(focus) {
    const f = FACE_FOCUS[focus] || FACE_FOCUS.face, aspect = (canvas && canvas.clientWidth && canvas.clientHeight) ? canvas.clientWidth / canvas.clientHeight : 296 / 385;
    const e = char ? char.extent() : null;
    if (!e) return { y: f.y, dist: f.dist, turn: 0 };
    const NEAR = 0.25;                             // the hair and the hat are this much closer to the camera than the middle of her
    const halfH = d => 0.96 * (d - NEAR) * TAN_HALF_FOV;            // what the camera sees above and below its look point, at her hair's distance
    let d = Math.max(f.dist, 0.92 * (e.half / (0.96 * TAN_HALF_FOV * aspect) + NEAR));     // wide hair may lose 8 percent of its width
    d = Math.max(d, (e.top - CHIN_Y) / (2 * 0.96 * TAN_HALF_FOV) + NEAR);                // chin and top both fit
    const h = halfH(d);
    const y = Math.min(Math.max(f.y, e.top - h), CHIN_Y + h);
    return { y, dist: Math.min(d, 4.2), turn: 0 };
  }

  // The part of her the open tab is about.
  function aim() {
    const tab = state.activeTab;
    let name = TAB_VIEW[tab] || 'face';                        // every face and makeup tab looks at the face
    if (tab === 'accessories') name = ZONE_VIEW[ACCESSORY_ZONE[state.activeAccessoryId] || 'head'];
    PREVIEW3D.view = name;
    PREVIEW3D.target = name === 'face' ? frameFace(tab === 'accessories' ? 'face' : TAB_FOCUS[tab] || 'face') : VIEWS[name];
    needsDraw = true;
  }

  function place() {
    const p = PITCH, d = view.dist;
    camera.position.set(0, view.y + d * Math.sin(p), d * Math.cos(p));
    camera.lookAt(0, view.y, 0);
    TOON.outlineNear.value = 0;                 // the dressing room's camera is always close: a constant width
    TOON.aimSun(camera);
    pivot.rotation.y = view.turn + turn.user;
  }

  function resize() {
    if (!renderer) return;
    const w = canvas.clientWidth || 296, h = canvas.clientHeight || 385;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    needsDraw = true;
  }

  // The ground under her: a broad soft shadow and a tight one under each shoe (toon.js), so her soles sit on it.
  const FOOT_DROP = 0.028;                        // the model's soles are this high above its origin: she is lowered so they touch the ground
  function groundShadow() {
    const m = TOON.contactShadow('110,70,160', 1.5);
    m.position.set(0, 0.004, 0.04);
    return m;
  }

  function frame(t) {
    raf = requestAnimationFrame(frame);
    if (paused) return;
    const dt = Math.min((t - last) / 1000, 0.1); last = t;
    const goal = PREVIEW3D.target || VIEWS.body;
    const k = still() ? 1 : 1 - Math.exp(-6 * dt);
    const before = view.y + view.dist + view.turn + turn.user;
    view.y += (goal.y - view.y) * k; view.dist += (goal.dist - view.dist) * k; view.turn += (goal.turn - view.turn) * k;
    // After a moment without a hand on her she turns back to the front, the short way round.
    if (!turn.drag && !still() && turn.user !== 0) {
      turn.released += dt;
      if (turn.released > RETURN_AFTER) {
        turn.user = Math.atan2(Math.sin(turn.user), Math.cos(turn.user));
        turn.user *= Math.exp(-3 * dt);
        if (Math.abs(turn.user) < 1e-3) turn.user = 0;
      }
    }
    if (view.y + view.dist + view.turn + turn.user !== before) needsDraw = true;
    if (!still()) {
      char.update(dt);
      blinkIn -= dt;
      if (blinkIn <= 0) { char.blink(); blinkIn = 2.5 + Math.random() * 3.5; }
      needsDraw = true;
    }
    if (!needsDraw) return;
    needsDraw = false;
    place();
    renderer.render(scene, camera);
  }
  let blinkIn = 3;

  function wirePointer() {
    canvas.addEventListener('pointerdown', e => {
      canvas.setPointerCapture?.(e.pointerId);
      turn.drag = { id: e.pointerId, x: e.clientX, moved: 0 };
      e.preventDefault();
    });
    canvas.addEventListener('pointermove', e => {
      if (!turn.drag || turn.drag.id !== e.pointerId) return;
      const dx = e.clientX - turn.drag.x;
      turn.drag.x = e.clientX; turn.drag.moved += Math.abs(dx);
      turn.user += dx * 0.012;
      turn.released = 0;
      needsDraw = true;
    });
    const up = e => {
      if (!turn.drag || turn.drag.id !== e.pointerId) return;
      if (turn.drag.moved < 4) PREVIEW3D.cheer('Waving');          // a tap on her says hello
      turn.drag = null; turn.released = 0;
    };
    canvas.addEventListener('pointerup', up);
    canvas.addEventListener('pointercancel', up);
  }

  const PREVIEW3D = window.PREVIEW3D = {
    active: false, view: 'body', target: VIEWS.body,

    async start(host, svg) {
      if (renderer) return true;
      wrap = host; svgEl = svg;
      canvas = document.createElement('canvas');
      canvas.className = 'preview3d-canvas';
      canvas.setAttribute('aria-label', 'Your character, in 3D. Drag to turn her around.');
      try {
        wrap.appendChild(canvas);
        renderer = new T.WebGLRenderer({ canvas, alpha: true, antialias: true });
        renderer.outputColorSpace = T.SRGBColorSpace;
        renderer.setClearColor(0x000000, 0);
        scene = new T.Scene();
        camera = new T.PerspectiveCamera(FOV, 296 / 385, 0.1, 50);
        pivot = new T.Group();
        scene.add(pivot, groundShadow());
        char = await CHARACTER3D.create({ outlinePx: OUTLINE_PX });
        char.model.position.y = -FOOT_DROP;
        pivot.add(char.model);
        char.actions.Waving.setLoop(T.LoopOnce, 1); char.actions.Waving.clampWhenFinished = true;
        char.actions.Cheering.setLoop(T.LoopOnce, 1); char.actions.Cheering.clampWhenFinished = true;
        char.mixer.addEventListener('finished', () => char.play('Idle_A', 0.25));
        char.play('Idle_A', 0);
        await dressAgain();
        if (still()) { char.pose('Idle_A', 0); }
        aim();
        const goal = PREVIEW3D.target; Object.assign(view, goal);        // the first picture is already framed
        wirePointer();
        resize();
        window.addEventListener('resize', resize);
        new ResizeObserver(resize).observe(wrap);
        // Whatever changes in the SVG (an option, a colour, a size) dresses her again, on the next frame.
        observer = new MutationObserver(queueDress);
        observer.observe(svgEl, { subtree: true, childList: true, attributes: true, attributeFilter: ['transform', 'style'] });
        place();
        renderer.render(scene, camera);
        last = performance.now();
        raf = requestAnimationFrame(frame);
        PREVIEW3D.active = true;
        return true;
      } catch (err) {
        console.warn('3D dressing room not available:', err);
        PREVIEW3D.stop();
        return false;
      }
    },

    stop() {
      cancelAnimationFrame(raf);
      if (observer) observer.disconnect();
      if (char) char.dispose();
      if (renderer) renderer.dispose();
      if (canvas) canvas.remove();
      renderer = char = canvas = observer = null;
      PREVIEW3D.active = false;
    },

    // Not drawn (and not kept busy) while something else is on top, like the world.
    pause(on) { paused = !!on; if (!on) { last = performance.now(); needsDraw = true; } },

    cheer(clip = 'Cheering') {
      if (!char || still() || paused) return;
      char.actions[clip].reset();
      char.play(clip, 0.15);
    },

    // A picture of her from the front, whole, as big as asked (the saved picture).
    snapshot(w, h) {
      const keep = { ...view, user: turn.user }, size = renderer.getSize(new T.Vector2()), ratio = renderer.getPixelRatio();
      Object.assign(view, VIEWS.body); turn.user = 0;
      renderer.setPixelRatio(1); renderer.setSize(w, h, false);
      camera.aspect = w / h; camera.updateProjectionMatrix();
      place();
      renderer.render(scene, camera);
      const out = document.createElement('canvas');
      out.width = w; out.height = h;
      out.getContext('2d').drawImage(canvas, 0, 0, w, h);
      Object.assign(view, { y: keep.y, dist: keep.dist, turn: keep.turn }); turn.user = keep.user;
      renderer.setPixelRatio(ratio); renderer.setSize(size.x, size.y, false);
      camera.aspect = size.x / size.y; camera.updateProjectionMatrix();
      needsDraw = true;
      return out;
    },

    aim,                                // look at the part of her the open tab is about (call when the tab changes)

    // For tests: turn her, and wait until the dressing is up to date.
    setTurn(a) { turn.user = a; turn.released = 0; needsDraw = true; },
    get turned() { return turn.user; },
    get paused() { return paused; },
    get dressed() { return !!sync.done && !sync.busy && !sync.queued; },
    get character() { return char; },
    get drawingCanvas() { return canvas; },
  };
})();
