// The 3D world. Opened from the dress-up page by the "Let's play!" button (see openWorld in
// game.js), which loads the scripts this needs: vendor/three.bundle.js, the model packs, solid.js,
// layout.js, cutout.js, then this file.
// Classic script (no modules) so it works when the page is opened from file://.
//
//   await WORLD.open(canvas)   show the world with her current look
//   WORLD.close()              stop drawing (the page keeps the renderer for next time)
(function () {
  const T = window.THREE;

  const HERO_HEIGHT = 2.1;                       // world units, from the soles to the top of the picture

  // The camera circles a point on her chest. `zoom` (0..1) sets distance and height together: 0 is
  // close and low, just over her shoulder; 1 is far and high, most of the world. `yaw` turns around
  // her (0 = from the south, looking north; more = the view turns left). Both glide to their targets.
  const CAM = {
    DIST: [3.8, 24],               // distance to the look point at zoom 0 and 1
    PITCH: [14, 55],               // degrees looking down at zoom 0 and 1
    START_ZOOM: 0.27,              // the view she gets when the world opens (6.3 away, 20 degrees down)
    LOOK_HEIGHT: 1.1,              // the look point: this high on her...
    LEAD: 0.6,                     // ...and this far toward the camera, so the ground in front of her shows
    TURN_STEP: Math.PI / 4,        // one tap of a turn button or key
    ZOOM_STEP: 0.14,               // one tap of a zoom button or key, or one wheel notch
    HOLD_AFTER: 0.3,               // seconds a button is held before it keeps going
    TURN_SPEED: 1.8, ZOOM_SPEED: 0.6,   // per second while held
    LEAN: 0.6,                     // seen from high up she leans back by this much of the extra pitch
  };
  const cam = { yaw: 0, zoom: CAM.START_ZOOM, wantYaw: 0, wantZoom: CAM.START_ZOOM, focus: new T.Vector3(), holds: new Map(), orbit: null, lift: 0, reach: 1 };
  // Things tall enough to get between the camera and her: { x, z, r, top }. Made from each placed
  // model's real size when the layout is built. The camera rises over them, or comes closer.
  const camBlockers = [];
  const MAX_PITCH = (80 * Math.PI) / 180;

  const OUTLINE_NEAR = 6.3;       // her outline is full width at about the opening view's distance and thins when the camera goes further (toon.js)
  const FOOT_DROP = 0.028;        // character3d's soles are this high above its origin
  const FEET = 0.05;              // her picture floats this far above the ground, so paving never cuts off her shoes
  const HERO_RADIUS = 0.45;       // how close she can get to the middle of a tree or a wall
  const WALK_SPEED = 3.4;         // world units per second
  const STEP_LENGTH = 0.55;       // distance for one walk frame (stand, left, stand, right)
  const BOB = 0.07;               // how far she rises on each step
  // The 3D character (makeupgame-jko.4). 'cutout' is the old flat picture: open the page with #cutout to get it back.
  const HERO_MODE = /cutout/.test(location.hash) ? 'cutout' : '3d';
  const RUN_GROUND_SPEED = 2.16;  // how fast KayKit's Running_A carries a body at timeScale 1 (measured from its feet)
  const TURN_SPEED = 12;          // how quickly she turns to where she walks (higher = snappier)
  const IDLE_TURN_AFTER = 1.5;    // seconds standing still before she turns to look at the camera
  const STEP_UP = 22, STEP_DOWN = 14;   // how quickly she steps up onto something, and down from it
  const ARRIVE = 0.12;            // a tapped spot counts as reached this close
  const STUCK_AFTER = 0.35;       // seconds of pushing against something before she gives up
  // The space bar: a hop. KayKit's Jump_Full_Short crouches, leaves the ground at FROM and lands about AIR
  // seconds later (its own hips barely rise, so the height is added here); the clip lasts TIME in all.
  const JUMP = { CLIP: 'Jump_Full_Short', TIME: 1.17, FROM: 0.28, AIR: 0.5, HEIGHT: 0.7 };

  let renderer, scene, camera, hero, running = false, raf = 0, canvas = null, lastT = 0;
  let bounds = 18;                // radius of the walkable circle
  const colliders = [];           // what she cannot walk through: circles and rectangles (see solid.js)
  // What she walks on top of (the bridge): its real shape, never drawn. Her
  // height comes from a ray straight down onto these, and a tap lands on them, not the grass below.
  const standOn = [];
  const walk = { target: null, travelled: 0, stuck: 0, moving: false, dragging: false, marker: null };
  const keys = new Set();
  // Picture sharpness. A slow computer drops it (never raises it again) so walking stays smooth.
  const quality = { ratio: Math.min(window.devicePixelRatio || 1, 2), avg: 1 / 60, slowFor: 0, warm: 0, shown: false, fpsClock: 0, frames: 0 };

  // ── Pieces ───────────────────────────────────────────────────────────────
  function skyTexture() {
    const c = document.createElement('canvas'); c.width = 4; c.height = 256;
    const g = c.getContext('2d'), grad = g.createLinearGradient(0, 0, 0, 256);
    grad.addColorStop(0, '#6fb8ff'); grad.addColorStop(0.55, '#b9e3ff'); grad.addColorStop(1, '#fff3d6');
    g.fillStyle = grad; g.fillRect(0, 0, 4, 256);
    const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; return t;
  }

  function blobShadowTexture() {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g = c.getContext('2d'), grad = g.createRadialGradient(64, 64, 4, 64, 64, 62);
    grad.addColorStop(0, 'rgba(40,60,20,0.6)'); grad.addColorStop(0.4, 'rgba(40,60,20,0.38)'); grad.addColorStop(1, 'rgba(40,60,20,0)');
    g.fillStyle = grad; g.fillRect(0, 0, 128, 128);
    return new T.CanvasTexture(c);
  }

  function buildScene() {
    scene = new T.Scene();
    scene.background = skyTexture();
    scene.fog = new T.Fog(0xcdeaff, 30, 90);

    scene.add(new T.HemisphereLight(0xffffff, 0x9bd37a, 1.5));
    const sun = new T.DirectionalLight(0xfff0d0, 1.6);
    sun.position.set(-8, 14, 6);
    scene.add(sun);

    const ground = new T.Mesh(new T.CircleGeometry(120, 64), new T.MeshLambertMaterial({ color: 0x8fd66a }));
    ground.rotation.x = -Math.PI / 2;
    scene.add(ground);

    camera = new T.PerspectiveCamera(45, 1, 0.1, 300);
  }

  // The character: an upright picture that always turns to face the camera, four walk frames side
  // by side in one texture, and a soft blob shadow on the ground under her feet. The picture hangs
  // from a pivot at her feet: it turns around the vertical axis to face the camera, and leans back a
  // little when the camera is high, so she never looks squashed and her feet stay on the ground.
  // A faint copy of her is drawn on top of everything, so a tree or a house in front of her shows
  // her through it. Where nothing is in front, the copy lands exactly on her and changes nothing.
  function buildHero() {
    const group = new T.Group();
    const shadow = new T.Mesh(new T.PlaneGeometry(1.7, 1.1), new T.MeshBasicMaterial({ map: blobShadowTexture(), transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = FEET + 0.01;
    group.add(shadow);

    const pivot = new T.Group();
    pivot.rotation.order = 'YXZ';                   // turn to the camera first, then lean back
    pivot.position.y = FEET;
    const sprite = new T.Mesh(new T.PlaneGeometry(1, 1), new T.MeshBasicMaterial({ transparent: true, premultipliedAlpha: true, alphaTest: 0.01 }));
    const ghost = new T.Mesh(sprite.geometry, new T.MeshBasicMaterial({ transparent: true, premultipliedAlpha: true, opacity: 0.35, depthTest: false, depthWrite: false }));
    ghost.renderOrder = 10;                         // after everything else
    pivot.add(sprite, ghost);
    group.add(pivot);
    scene.add(group);

    // A ring on the ground where she was told to walk.
    const marker = new T.Mesh(new T.RingGeometry(0.28, 0.4, 32), new T.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, depthWrite: false }));
    marker.rotation.x = -Math.PI / 2;
    marker.visible = false;
    scene.add(marker);
    walk.marker = marker;
    return { group, pivot, sprite, ghost, shadow, frames: 1, frame: 0, model: null, state: { still: 0, blinkIn: 3, jump: null } };
  }

  // Replace her picture with the current look. The old texture is freed, so opening the world
  // again and again does not pile up memory.
  async function dressHero(cut) {
    const old = hero.sprite.material.map;
    const tex = new T.CanvasTexture(cut.canvas);
    tex.colorSpace = T.SRGBColorSpace;
    tex.premultiplyAlpha = true;                    // no dark fringe at the edge of her outline
    tex.anisotropy = renderer.capabilities.getMaxAnisotropy();
    tex.repeat.set(1 / cut.frames, 1);
    for (const m of [hero.sprite, hero.ghost]) { m.material.map = tex; m.material.needsUpdate = true; }
    if (old) old.dispose();

    const h = HERO_HEIGHT, w = h * cut.aspect;
    hero.sprite.geometry.dispose();
    hero.sprite.geometry = hero.ghost.geometry = new T.PlaneGeometry(w, h);
    hero.sprite.position.y = hero.ghost.position.y = h / 2;   // the soles are at the pivot, the bottom edge of the picture
    hero.frames = cut.frames;
    setFrame(0);
  }

  // The 3D character stands where the picture did. Made once; dressed again on every open from the current look.
  async function dressHero3d() {
    if (!hero.model) {
      const c = await CHARACTER3D.create();
      hero.model = c;
      c.model.position.y = -FOOT_DROP;             // the model's soles are 3 cm above its origin: they touch the ground
      hero.pivot.add(c.model);
      const contact = TOON.contactShadow('40,60,20', 1.1);     // a tight shadow under each shoe (the soft blob under her stays)
      contact.position.set(0, 0.014, 0.04);
      hero.pivot.add(contact);                     // turns with her (its blobs are under the shoes), and stays on the ground in a jump (animateHero)
      hero.contact = contact;
      hero.sprite.visible = hero.ghost.visible = false;
      c.play('Idle_A', 0);
      c.actions[JUMP.CLIP].setLoop(T.LoopOnce, 1);
      c.actions[JUMP.CLIP].clampWhenFinished = true;
    }
    await hero.model.dress(renderer);
    hero.state.still = 0;
  }

  function setFrame(i) {
    hero.frame = i;
    const tex = hero.sprite.material.map;
    if (tex) tex.offset.x = (i % hero.frames) / hero.frames;
  }

  // Angle that makes her turn toward a point (the model's front is +Z, like the picture's).
  const headingTo = (fromX, fromZ, toX, toZ) => Math.atan2(toX - fromX, toZ - fromZ);
  const turnTo = (want, k) => {
    let d = want - hero.pivot.rotation.y;
    d = Math.atan2(Math.sin(d), Math.cos(d));                 // the short way round
    hero.pivot.rotation.y += d * k;
  };

  function faceCamera() {
    if (hero.model) return;                                   // the 3D character turns where she walks (updateWalking)
    const p = hero.group.position, c = camera.position;
    hero.pivot.rotation.y = Math.atan2(c.x - p.x, c.z - p.z);
    const pitch = Math.atan2(c.y - p.y - CAM.LOOK_HEIGHT, Math.hypot(c.x - p.x, c.z - p.z));
    hero.pivot.rotation.x = -Math.max(0, pitch - (20 * Math.PI) / 180) * CAM.LEAN;
  }

  function resize() {
    if (!renderer || !canvas) return;
    const w = canvas.clientWidth || innerWidth, h = canvas.clientHeight || innerHeight;
    renderer.setPixelRatio(quality.ratio);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }

  // The camera glides after her (it trails a little, which makes walking feel soft), and glides to
  // a new turn or zoom rather than jumping. `snap` goes straight there, for when the world opens.
  // It is placed from yaw and zoom around the look point, so turning swings it round on a circle.
  const lerp = (a, b, t) => a + (b - a) * t;
  function camDistance(z) { return CAM.DIST[0] * Math.pow(CAM.DIST[1] / CAM.DIST[0], z); }
  function camPitch(z) { return (lerp(CAM.PITCH[0], CAM.PITCH[1], Math.pow(z, 1.5)) * Math.PI) / 180; }

  function updateCameraTargets(dt) {
    for (const h of cam.holds.values()) {           // buttons and keys held down keep going
      h.t += dt;
      if (h.t < CAM.HOLD_AFTER) continue;
      if (h.kind === 'turn') cam.wantYaw += h.dir * CAM.TURN_SPEED * dt;
      else cam.wantZoom += h.dir * CAM.ZOOM_SPEED * dt;
    }
    cam.wantZoom = Math.min(1, Math.max(0, cam.wantZoom));
  }

  function placeCamera(dt = 0, snap = false) {
    if (WORLD.debugView) {                          // a fixed view for screenshots and tests
      camera.position.fromArray(WORLD.debugView.pos);
      camera.lookAt(...WORLD.debugView.look);
      return;
    }
    const kFollow = snap ? 1 : 1 - Math.exp(-5 * dt), kView = snap ? 1 : 1 - Math.exp(-7 * dt);
    cam.focus.lerp(hero.group.position, kFollow);
    cam.yaw = lerp(cam.yaw, cam.wantYaw, kView);
    cam.zoom = lerp(cam.zoom, cam.wantZoom, kView);

    const back = new T.Vector3(Math.sin(cam.yaw), 0, Math.cos(cam.yaw));   // from her toward the camera
    const d = camDistance(cam.zoom), pitch = camPitch(cam.zoom);
    // The look point leads toward the camera by less as the camera rises over something.
    const lead = pt => CAM.LEAD * (Math.cos(pt) / Math.cos(pitch)) ** 2;

    // Keep the camera out of houses and trees. In order of preference: the view asked for; the
    // same, higher (up to 80 degrees); at 80, further back (over a roof); last of all, closer.
    const chest = cam.focus.y + CAM.LOOK_HEIGHT;             // (higher when she is up on the bridge)
    const from = cam.focus.clone().setY(chest);               // her chest; walking keeps her outside everything
    const near = camBlockers.filter(b => Math.hypot(b.x - from.x, b.z - from.z) < d * 2.5 + b.reach + 1);
    const clear = (pt, f) => viewIsClear(near, from, back, lead(pt) + d * f * Math.cos(pt), d * f * Math.sin(pt));
    let wantPitch = MAX_PITCH, wantReach = 0.15;
    const tries = [];
    for (let extra = 0; pitch + extra < MAX_PITCH; extra += (6 * Math.PI) / 180) tries.push([pitch + extra, 1]);
    for (let f = 1; f <= 2.51; f += 0.25) tries.push([MAX_PITCH, f]);
    for (let f = 0.85; f > 0.14; f -= 0.1) tries.push([MAX_PITCH, f]);
    // If no line to her is clear (she is pressed against a tree on the camera's side), take the
    // first place where at least the camera itself is not inside anything: her see-through copy
    // shows her through the leaves.
    const freeSpot = (pt, f) => { const a = lead(pt) + d * f * Math.cos(pt); return !near.some(b => covers(b, from.x + back.x * a, from.y + d * f * Math.sin(pt), from.z + back.z * a)); };
    let found = tries.find(([pt, f]) => clear(pt, f)) || tries.find(([pt, f]) => freeSpot(pt, f));
    if (found) [wantPitch, wantReach] = found;
    // Hurry only when the camera is blocked where it is now (so it never sits inside anything);
    // otherwise settle back gently (so it does not bob as she walks past things).
    const k = snap ? 1 : 1 - Math.exp(-(clear(Math.min(MAX_PITCH, pitch + cam.lift), cam.reach) ? 2.5 : 14) * dt);
    cam.lift = lerp(cam.lift, wantPitch - pitch, k);
    cam.reach = lerp(cam.reach, wantReach, k);

    const p = Math.min(MAX_PITCH, pitch + cam.lift), dd = d * cam.reach;
    const look = cam.focus.clone().addScaledVector(back, lead(p)).setY(chest);
    camera.position.copy(look).addScaledVector(back, dd * Math.cos(p)).setY(chest + dd * Math.sin(p));
    camera.lookAt(look);
  }

  // A cover is a circle { x, z, r } or a rectangle { x0, z0, x1, z1 } on the ground, up to `top`.
  function addCover(c) {
    const b = c.r !== undefined
      ? { x: c.x, z: c.z, r: c.r, reach: c.r, top: c.top }
      : { x: (c.x0 + c.x1) / 2, z: (c.z0 + c.z1) / 2, x0: c.x0, z0: c.z0, x1: c.x1, z1: c.z1, reach: Math.hypot(c.x1 - c.x0, c.z1 - c.z0) / 2, top: c.top };
    camBlockers.push(b);
  }
  const covers = (b, x, y, z) => y < b.top && (b.r !== undefined ? (x - b.x) ** 2 + (z - b.z) ** 2 < b.r * b.r : x > b.x0 && x < b.x1 && z > b.z0 && z < b.z1);

  // Is the straight line from her chest to the camera (`along` units sideways, `rise` up) free of
  // tall things? Checked every 0.3 units along it.
  function viewIsClear(near, from, back, along, rise) {
    const n = Math.ceil(Math.hypot(along, rise) / 0.3);
    for (let i = 1; i <= n; i++) {
      const t = i / n, x = from.x + back.x * along * t, z = from.z + back.z * along * t, y = from.y + rise * t;
      for (const b of near) if (covers(b, x, y, z)) return false;
    }
    return true;
  }

  function turn(dir) { cam.wantYaw += dir * CAM.TURN_STEP; }
  function zoomBy(amount) { cam.wantZoom = Math.min(1, Math.max(0, cam.wantZoom + amount)); }
  function resetCamera() {
    cam.wantYaw = cam.yaw = 0; cam.wantZoom = cam.zoom = CAM.START_ZOOM;
    cam.holds.clear(); cam.orbit = null; cam.lift = 0; cam.reach = 1;
    cam.focus.copy(hero.group.position);
  }

  // ── The place: built from world/layout.js ────────────────────────────────
  // Everything the layout lists is drawn with instancing: one draw call per piece of each model,
  // however many copies there are (a few hundred flowers cost the same as a few).
  function parseModel(pack, name) {
    return new Promise((resolve, reject) => new T.GLTFLoader().parse(WORLD_PACKS.decode(pack, name), '', g => resolve(g.scene), reject));
  }

  function softShadowMaterial() {
    return new T.MeshBasicMaterial({ map: blobShadowTexture(), transparent: true, depthWrite: false, opacity: 0.8 });
  }

  // A thin bright rim along the shore: a ring for a pond, two long strips for a stream.
  function waterRims(w) {
    if (w.r) return [new T.Mesh(new T.RingGeometry(w.r - 0.14, w.r - 0.02, 48).rotateX(-Math.PI / 2))];
    return [-1, 1].map(s => new T.Mesh(new T.PlaneGeometry(Math.min(w.w, 16), 0.12).rotateX(-Math.PI / 2).translate(0, 0, s * (w.d / 2 - 0.08))));
  }

  async function buildLayout(L) {
    const root = new T.Group();
    scene.add(root);
    bounds = L.bounds;

    colliders.push(...L.solids);
    // Group the items by model, parse each model once.
    const byModel = new Map();
    for (const it of L.items) {
      if (it.cover) addCover(it.cover.r !== undefined ? { x: it.x, z: it.z, ...it.cover } : it.cover);
      if (!it.pack) continue;
      const key = it.pack + '/' + it.name;
      if (!byModel.has(key)) byModel.set(key, []);
      byModel.get(key).push(it);
    }
    const parsed = await Promise.all([...byModel.keys()].map(k => parseModel(...k.split('/'))));

    const m4 = new T.Matrix4(), q = new T.Quaternion(), up = new T.Vector3(0, 1, 0), pos = new T.Vector3(), sc = new T.Vector3();
    [...byModel.keys()].forEach((key, i) => {
      const list = byModel.get(key), model = parsed[i];
      model.updateMatrixWorld(true);
      // Anything taller than about her shoulders can hide her from a low camera.
      const box = new T.Box3().setFromObject(model), size = box.getSize(new T.Vector3());
      // It is never bigger than the space walking keeps her out of, so she can never stand inside one
      // (from there every view would look blocked).
      for (const it of list) {
        if (it.cover !== undefined && it.cover !== null) continue;   // set by hand (or false: part of something bigger)
        const top = it.y + box.max.y * it.s;
        if (top < 1.6 || !it.solid) continue;
        const inner = it.solid.r !== undefined ? it.solid.r : Math.min(it.solid.hw, it.solid.hd);   // the closest she gets to its middle, less her radius
        const r = Math.min((Math.max(size.x, size.z) / 2) * it.s * 0.85, inner + HERO_RADIUS - 0.05);
        addCover({ x: it.x, z: it.z, r, top });
      }
      model.traverse(o => {
        if (!o.isMesh) return;
        const mats = Array.isArray(o.material) ? o.material : [o.material];
        mats.forEach(m => { if (m.metalness) m.metalness = 0; });   // the Nature kit is "metal", which renders black
        const inst = new T.InstancedMesh(o.geometry, o.material, list.length);
        list.forEach((it, n) => {
          q.setFromAxisAngle(up, it.rot);
          m4.compose(pos.set(it.x, it.y, it.z), q, sc.setScalar(it.s)).multiply(o.matrixWorld);
          inst.setMatrixAt(n, m4);
          if (it.touch) (it.slots = it.slots || []).push({ inst, n, local: o.matrixWorld.clone() });   // life.js moves these
          if (it.stand) standOn.push(new T.Mesh(o.geometry.clone().applyMatrix4(m4), standMaterial));
        });
        inst.frustumCulled = false;
        root.add(inst);
      });
    });

    // Soft shadows on the ground under everything that asks for one.
    const shadowed = L.items.filter(it => it.shadow > 0);
    if (shadowed.length) {
      const geo = new T.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
      const sh = new T.InstancedMesh(geo, softShadowMaterial(), shadowed.length);
      // A box gets a shadow shaped and turned like itself; everything else a round one.
      shadowed.forEach((it, n) => {
        const box = it.solid && it.solid.hw !== undefined ? it.solid : null;
        q.setFromAxisAngle(up, box ? box.rot : 0);
        sh.setMatrixAt(n, m4.compose(pos.set(it.x, 0.05, it.z), q, box ? sc.set(box.hw * 2 + 0.7, 1, box.hd * 2 + 0.7) : sc.set(it.shadow, 1, it.shadow)));
      });
      sh.frustumCulled = false;
      root.add(sh);
    }

    // Water: strips (a stream) and discs (a pond).
    const waterMat = new T.MeshLambertMaterial({ color: 0x5cc8f5, transparent: true, opacity: 0.92 });
    const rimMat = new T.MeshBasicMaterial({ color: 0xeafaff, transparent: true, opacity: 0.55, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 });
    for (const w of L.water) {
      const geo = w.r ? new T.CircleGeometry(w.r, 40) : new T.PlaneGeometry(w.w, w.d);
      const mesh = new T.Mesh(geo.rotateX(-Math.PI / 2), waterMat);
      mesh.position.set(w.x, 0.04, w.z);
      root.add(mesh);
      for (const rim of waterRims(w)) { rim.material = rimMat; rim.position.add(new T.Vector3(w.x, 0.06, w.z)); root.add(rim); }
    }

    hero.group.position.set(L.start.x, heightAt(L.start.x, L.start.z), L.start.z);
  }

  // How high is the top of whatever she would stand on at (x, z)? 0 on the grass. Walking keeps
  // her off the bridge's rails, so the highest thing under her middle is always the floor.
  const standMaterial = new T.MeshBasicMaterial();
  const down = new T.Raycaster(new T.Vector3(), new T.Vector3(0, -1, 0));
  function heightAt(x, z) {
    if (!standOn.length) return 0;
    down.ray.origin.set(x, 30, z);
    const hit = down.intersectObjects(standOn, false)[0];
    return hit ? Math.max(0, hit.point.y) : 0;
  }

  // ── Walking ──────────────────────────────────────────────────────────────
  // Two ways to steer: the arrow keys / WASD, or a tap (or a drag) on the ground, which she walks
  // to. Round colliders stop her; she slides along them rather than sticking.
  const KEY_DIR = {
    ArrowUp: [0, -1], KeyW: [0, -1], ArrowDown: [0, 1], KeyS: [0, 1],
    ArrowLeft: [-1, 0], KeyA: [-1, 0], ArrowRight: [1, 0], KeyD: [1, 0],
  };
  const ground = new T.Plane(new T.Vector3(0, 1, 0), 0);
  const ray = new T.Raycaster();

  // Where on the ground (x, z) is the pointer? On the bridge if it points at it (the grass under
  // the bridge is further off); null if it points at the sky.
  function pointerRay(e) {
    const r = canvas.getBoundingClientRect();
    ray.setFromCamera(new T.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), camera);
    return ray.ray;
  }
  function groundPoint(e) {
    pointerRay(e);
    const top = ray.intersectObjects(standOn, false)[0];
    if (top) return top.point;
    const p = new T.Vector3();
    return ray.ray.intersectPlane(ground, p) ? p : null;
  }

  function setTarget(p) {
    if (!p) return;
    const len = Math.hypot(p.x, p.z), max = bounds - HERO_RADIUS;
    if (len > max) { p.x *= max / len; p.z *= max / len; }
    walk.target = { x: p.x, z: p.z };
    walk.stuck = 0;
    walk.marker.position.set(p.x, heightAt(p.x, p.z) + 0.03, p.z);
    walk.marker.visible = true;
  }

  function clearTarget() { walk.target = null; walk.marker.visible = false; }

  // Push her out of anything she overlaps. Pushing along the surface's normal removes the part of
  // her movement that goes into the obstacle and keeps the rest, which is the sliding.
  function resolveCollisions(pos) {
    for (let pass = 0; pass < 3; pass++) {
      for (const c of colliders) {
        const out = WORLD_SOLID.push(c, pos.x, pos.z, HERO_RADIUS);
        if (out) { pos.x = out.x; pos.z = out.z; }
      }
      const len = Math.hypot(pos.x, pos.z), max = bounds - HERO_RADIUS;
      if (len > max) { pos.x *= max / len; pos.z *= max / len; }
    }
  }

  // Could she stand here? (Inside the world and clear of everything solid.)
  const canStand = (x, z) => Math.hypot(x, z) <= bounds - HERO_RADIUS + 1e-6 && !colliders.some(c => WORLD_SOLID.overlaps(c, x, z, HERO_RADIUS - 1e-6));

  function updateWalking(dt) {
    const pos = hero.group.position;
    let dx = 0, dz = 0;
    // The keys are relative to the view: up is away from the camera, right is screen-right.
    const s = Math.sin(cam.yaw), c = Math.cos(cam.yaw);
    for (const k of keys) {
      const v = KEY_DIR[k];
      if (v) { dx += v[0] * c + v[1] * s; dz += -v[0] * s + v[1] * c; }
    }
    if (Math.abs(dx) < 1e-9) dx = 0;
    if (Math.abs(dz) < 1e-9) dz = 0;
    if (dx || dz) {
      clearTarget();                              // the keys take over from a tap
    } else if (walk.target) {
      dx = walk.target.x - pos.x; dz = walk.target.z - pos.z;
      if (Math.hypot(dx, dz) < ARRIVE) { clearTarget(); dx = dz = 0; }
    }

    let moved = 0;
    if (dx || dz) {
      const len = Math.hypot(dx, dz), want = Math.min(WALK_SPEED * dt, walk.target ? len : Infinity);
      const fromX = pos.x, fromZ = pos.z;
      pos.x += (dx / len) * want; pos.z += (dz / len) * want;
      resolveCollisions(pos);
      moved = Math.hypot(pos.x - fromX, pos.z - fromZ);
      // Pushing against something without getting anywhere: stop trying to reach the tapped spot.
      if (walk.target) {
        walk.stuck = moved < want * 0.25 ? walk.stuck + dt : 0;
        if (walk.stuck > STUCK_AFTER) clearTarget();
      }
    }

    // Up onto the bridge quickly, like a step; down again a little softer.
    const floor = heightAt(pos.x, pos.z);
    pos.y = lerp(pos.y, floor, 1 - Math.exp(-(floor > pos.y ? STEP_UP : STEP_DOWN) * dt));
    if (Math.abs(pos.y - floor) < 1e-3) pos.y = floor;

    walk.moving = moved > 1e-4;
    if (walk.moving) walk.travelled += moved; else walk.travelled = 0;

    // A jump runs on its clock; her height above the floor is an arc between taking off and landing.
    const st = hero.state;
    let lift = 0;
    if (st.jump) {
      st.jump.t += dt;
      if (st.jump.t >= (hero.model ? JUMP.TIME : JUMP.FROM + JUMP.AIR)) st.jump = null;
      else lift = JUMP.HEIGHT * Math.sin(Math.PI * Math.min(1, Math.max(0, (st.jump.t - JUMP.FROM) / JUMP.AIR)));
    }
    hero.shadow.scale.setScalar(1 - 0.4 * lift / JUMP.HEIGHT);       // the shadow stays on the ground and shrinks

    if (hero.model) {
      animateHero(dt, walk.moving, dx, dz, lift);
    } else {
      const phase = walk.travelled / STEP_LENGTH;
      setFrame(walk.moving ? Math.floor(phase) % hero.frames : 0);
      hero.pivot.position.y = FEET + lift + (walk.moving && !st.jump ? Math.abs(Math.sin(phase * Math.PI)) * BOB : 0);
    }

    if (walk.marker.visible) {
      const pulse = 1 + 0.12 * Math.sin(performance.now() / 120);
      walk.marker.scale.set(pulse, pulse, pulse);
    }
  }

  // The 3D character: run while moving (speed matched to the ground so the feet do not slide), idle when
  // still, turn to where she walks, and after a moment of standing turn to look at the camera.
  function animateHero(dt, moving, dx, dz, lift) {
    const c = hero.model, st = hero.state;
    hero.pivot.position.y = FEET + lift;
    if (hero.contact) { hero.contact.position.y = 0.014 - lift; hero.contact.material.opacity = 1 - 0.6 * lift / JUMP.HEIGHT; }
    if (st.jump) {
      st.still = 0;
      if (st.jump.t - dt <= 0) c.actions[JUMP.CLIP].reset();       // a fresh take-off, also when jumping again straight away
      c.play(JUMP.CLIP, 0.08);
      if (moving) turnTo(headingTo(0, 0, dx, dz), 1 - Math.exp(-TURN_SPEED * dt));
    } else if (moving) {
      st.still = 0;
      c.play('Running_A', 0.15);
      c.actions.Running_A.timeScale = WALK_SPEED / RUN_GROUND_SPEED;
      turnTo(headingTo(0, 0, dx, dz), 1 - Math.exp(-TURN_SPEED * dt));
    } else {
      st.still += dt;
      c.play('Idle_A', 0.25);
      const look = WORLD.heroLook;                               // a friend she is meeting (social.js): look at them, not at the camera
      if (look) turnTo(headingTo(hero.group.position.x, hero.group.position.z, look.x, look.z), 1 - Math.exp(-4 * dt));
      else if (st.still > IDLE_TURN_AFTER) {
        const p = hero.group.position, cp = camera.position;
        turnTo(headingTo(p.x, p.z, cp.x, cp.z), 1 - Math.exp(-4 * dt));
      }
    }
    // a blink now and then, as in the 2D picture (not for the screenshot tools)
    if (!window.__STILL) {
      st.blinkIn -= dt;
      if (st.blinkIn <= 0) { c.blink(); st.blinkIn = 2.5 + Math.random() * 3.5; }
    }
    c.update(dt);
  }

  function wireInput() {
    const onKeyDown = e => {
      if (!running) return;                                      // in the dress-up page the keys are the page's own
      if (e.code === 'KeyF' && !e.repeat && !e.ctrlKey && !e.metaKey && !e.altKey) {   // grown-ups: show the frame rate
        quality.shown = !quality.shown;
        document.getElementById('world-fps').hidden = !quality.shown;
        return;
      }
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      if (e.code === 'Space') {                                  // jump; never a press on whichever button has the focus
        e.preventDefault();
        document.activeElement?.blur?.();
        if (!e.repeat && !hero.state.jump) hero.state.jump = { t: hero.model ? 0 : JUMP.FROM };
        return;
      }
      const camKey = CAM_KEYS[e.code];
      if (camKey) {                                              // Q / E turn, + / - zoom
        e.preventDefault();
        if (!e.repeat) startHold(e.code, camKey[0], camKey[1]);
        return;
      }
      if (!KEY_DIR[e.code]) return;
      keys.add(e.code); e.preventDefault();
    };
    const onKeyUp = e => {
      if (running && e.code === 'Space') e.preventDefault();     // buttons click on the release of the space bar
      keys.delete(e.code); cam.holds.delete(e.code);
    };

    // Left button / finger: walk there (hold and drag to steer). Right or middle button: drag to
    // turn the camera (sideways) and zoom (up and down).
    const onDown = e => {
      canvas.setPointerCapture?.(e.pointerId);
      if (e.button === 1 || e.button === 2) { cam.orbit = { id: e.pointerId, x: e.clientX, y: e.clientY }; e.preventDefault(); return; }
      if (WORLD.onTap.some(fn => fn(pointerRay(e)))) return;     // a tap on a friend (social.js): not a walk
      walk.dragging = true; setTarget(groundPoint(e));
    };
    const onMove = e => {
      if (cam.orbit && cam.orbit.id === e.pointerId) {
        cam.wantYaw += (e.clientX - cam.orbit.x) * 0.006;
        zoomBy((e.clientY - cam.orbit.y) * 0.003);
        cam.orbit.x = e.clientX; cam.orbit.y = e.clientY;
      } else if (walk.dragging) setTarget(groundPoint(e));
    };
    const onUp = e => { if (cam.orbit && cam.orbit.id === e.pointerId) cam.orbit = null; else walk.dragging = false; };

    // The wheel (and a touchpad pinch, which arrives as ctrl + wheel) zooms. Never the page.
    const onWheel = e => {
      e.preventDefault();
      const px = e.deltaMode === 1 ? e.deltaY * 33 : e.deltaMode === 2 ? e.deltaY * 800 : e.deltaY;
      zoomBy(px * (e.ctrlKey ? 0.006 : CAM.ZOOM_STEP / 100));   // one notch (100 px) = one zoom step
    };

    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', () => { keys.clear(); cam.holds.clear(); });
    canvas.addEventListener('pointerdown', onDown);
    canvas.addEventListener('pointermove', onMove);
    canvas.addEventListener('pointerup', onUp);
    canvas.addEventListener('pointercancel', onUp);
    canvas.parentElement.addEventListener('wheel', onWheel, { passive: false });   // anywhere in the world, buttons too
    canvas.addEventListener('contextmenu', e => e.preventDefault());

    // The big buttons for her: a tap turns 45 degrees (or zooms one step), holding keeps going.
    document.querySelectorAll('#world-cam [data-cam]').forEach(btn => {
      const kind = btn.dataset.cam, dir = Number(btn.dataset.dir), id = 'btn-' + kind + dir;
      btn.addEventListener('pointerdown', e => { e.preventDefault(); btn.setPointerCapture?.(e.pointerId); startHold(id, kind, dir); });
      const stop = () => cam.holds.delete(id);
      btn.addEventListener('pointerup', stop);
      btn.addEventListener('pointercancel', stop);
      btn.addEventListener('lostpointercapture', stop);
      btn.addEventListener('click', e => { if (e.detail === 0) startHold(null, kind, dir); });   // Enter / Space on a focused button
    });
  }

  const CAM_KEYS = { KeyQ: ['turn', 1], KeyE: ['turn', -1], Equal: ['zoom', -1], NumpadAdd: ['zoom', -1], Minus: ['zoom', 1], NumpadSubtract: ['zoom', 1] };
  // One step now; if `id` is still held after a moment, updateCameraTargets keeps it going.
  function startHold(id, kind, dir) {
    if (kind === 'turn') turn(dir); else zoomBy(dir * CAM.ZOOM_STEP);
    if (id) cam.holds.set(id, { kind, dir, t: 0 });
  }

  // Frame time, smoothed. After a second of warming up, if it stays above ~22 fps' worth for 1.5 s,
  // draw fewer pixels. Grown-ups can press F in the world to see the numbers.
  function watchSpeed(raw) {
    raw = Math.min(raw, 0.25);                       // a tab that was in the background says nothing about speed
    quality.avg = quality.avg * 0.92 + raw * 0.08;
    quality.warm += raw;
    if (quality.warm > 1 && !window.__STILL && quality.ratio > 0.6 && quality.avg > 1 / 22) {
      quality.slowFor += raw;
      if (quality.slowFor > 1.5) { quality.ratio = Math.max(0.6, quality.ratio - 0.25); quality.slowFor = 0; quality.avg = 1 / 30; resize(); }
    } else quality.slowFor = 0;
    if (quality.shown) {
      quality.fpsClock += raw; quality.frames++;
      if (quality.fpsClock > 0.5) {
        document.getElementById('world-fps').textContent = `${Math.round(quality.frames / quality.fpsClock)} fps, picture ${canvas.width}x${canvas.height} (x${quality.ratio.toFixed(2)})`;
        quality.fpsClock = 0; quality.frames = 0;
      }
    }
  }

  function frame(t) {
    if (!running) return;
    raf = requestAnimationFrame(frame);
    const raw = (t - lastT) / 1000, dt = Math.min(raw, 0.1); lastT = t;
    watchSpeed(raw);
    updateCameraTargets(dt);
    WORLD.update(dt);
    placeCamera(dt);
    faceCamera();
    TOON.outlineNear.value = OUTLINE_NEAR;
    TOON.aimSun(camera);                       // her key light follows the camera: upper left of the picture, as in the dressing room
    renderer.render(scene, camera);
  }

  // ── Public ───────────────────────────────────────────────────────────────
  const WORLD = {
    // Things that must happen every frame (walking, animals, ...) register here: fn(dt).
    updaters: [],
    onBuilt: [],        // fn(parts, layout), called once, after the scene is built
    onOpen: [],         // async fn(), called on every open before the first picture: re-dress her from the current look
    onTap: [],          // fn(ray) -> true when a left tap / click hit something of theirs (a friend): then she does not walk there
    heroLook: null,     // { x, z } she turns to while standing (a friend she is meeting), instead of the camera
    update(dt) { for (const fn of this.updaters) fn(dt); },

    async open(targetCanvas) {
      canvas = targetCanvas;
      if (!renderer) {
        const r = new T.WebGLRenderer({ canvas, antialias: true });
        r.outputColorSpace = T.SRGBColorSpace;
        renderer = r;
        try {
          buildScene();
          hero = buildHero();
          await buildLayout(window.WORLD_LAYOUT);
        } catch (err) {
          renderer = null; colliders.length = 0; standOn.length = 0; r.dispose();    // so the next try starts clean
          throw err;
        }
        wireInput();
        WORLD.updaters.push(updateWalking);
        for (const fn of WORLD.onBuilt) fn(WORLD.parts, window.WORLD_LAYOUT);   // life.js and friends add their parts
        window.addEventListener('resize', resize);
      }
      if (HERO_MODE === '3d') {
        await dressHero3d();
      } else {
        await dressHero(await characterCutout());
      }
      for (const fn of WORLD.onOpen) await fn();
      hero.group.position.set(WORLD_LAYOUT.start.x, heightAt(WORLD_LAYOUT.start.x, WORLD_LAYOUT.start.z), WORLD_LAYOUT.start.z);
      keys.clear(); clearTarget(); walk.travelled = 0; walk.dragging = false; hero.state.jump = null;
      resetCamera();                   // every visit starts from the same friendly view
      resize();
      placeCamera(0, true);
      faceCamera();
      if (hero.model) hero.pivot.rotation.y = headingTo(hero.group.position.x, hero.group.position.z, camera.position.x, camera.position.z);
      TOON.outlineNear.value = OUTLINE_NEAR;
      TOON.aimSun(camera);
      renderer.render(scene, camera);   // a first picture before the loop starts
      running = true;
      lastT = performance.now();
      quality.warm = 0; quality.slowFor = 0;
      raf = requestAnimationFrame(frame);
    },

    close() {
      running = false;
      keys.clear(); walk.dragging = false; cam.holds.clear(); cam.orbit = null;
      cancelAnimationFrame(raf);
    },

    get isOpen() { return running; },
    get heroMode() { return HERO_MODE; },
    // For tests and development (jko.1, jko.2): a copy of the 3D character standing next to her, dressed in her
    // look and playing a clip. Not part of the game yet; she stays the cut-out until jko.4.
    async debugCharacter(clip = 'Idle_A') {
      const c = await CHARACTER3D.create();
      c.model.position.copy(hero.group.position).add(new T.Vector3(1.4, 0, 0));
      scene.add(c.model);
      await c.dress(renderer);
      WORLD.onOpen.push(() => c.dress(renderer));       // a changed look shows up the next time the world opens
      c.play(clip);
      WORLD.updaters.push(dt => c.update(dt));
      return c;
    },
    // For tests and the later steps: the live objects.
    get parts() { return { renderer, scene, camera, hero, THREE: T }; },
    setFrame,
    quality,
    HERO_HEIGHT, HERO_RADIUS, WALK_SPEED, JUMP,

    // The layout (step .5) says where she may walk and what is in the way.
    setBounds(r) { bounds = r; },
    addCollider(x, z, r) { colliders.push({ x, z, r }); },
    clearColliders() { colliders.length = 0; },
    walkTo(x, z) { setTarget({ x, z }); },
    // The camera: { yaw, zoom, wantYaw, wantZoom } now, and the limits in CAM.
    get camera() { return { yaw: cam.yaw, zoom: cam.zoom, wantYaw: cam.wantYaw, wantZoom: cam.wantZoom, distance: camDistance(cam.zoom), lift: cam.lift, reach: cam.reach, holding: cam.holds.size }; },
    // For the tests: is this point inside something tall (where a camera must never be)?
    insideSomething(x, y, z) { return camBlockers.some(b => covers(b, x, y, z)); },
    camBlockers,
    CAM,
    turn, zoomBy,
    snapCamera() { placeCamera(0, true); faceCamera(); camera.updateMatrixWorld(); },   // for tests: go straight to where the camera is heading
    get colliders() { return colliders; },
    canStand,           // (x, z): inside the world and clear of everything solid
    heightAt,           // (x, z): the top of what she would stand on there (0 on the grass)
    get walking() { return { ...walk, marker: undefined, keys: [...keys], hasTarget: !!walk.target }; },
  };

  window.WORLD = WORLD;
})();
