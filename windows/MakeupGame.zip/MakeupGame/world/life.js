// Little things that make the world feel alive. Nothing here can be won or lost.
//   flowers and mushrooms   sway and sparkle when she walks through them
//   the fountain            sprays all the time, and splashes when she stands close
//   the camp fire           flickers and sends up sparks
//   butterflies             drift about the meadow
// What and where comes from `features` and the `touch` flags in layout.js. Sounds are the dress-up
// game's own (playSound), so the speaker button mutes them too. Classic script (no modules).
(function () {
  const T = window.THREE;
  const calm = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const ding = name => { try { if (typeof playSound === 'function') playSound(name); } catch (e) { /* no sound is fine */ } };
  const rand = (a, b) => a + Math.random() * (b - a);

  // ── Particles: a pool of points that fly, fall and fade ──────────────────
  function sprite(draw) {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    draw(c.getContext('2d'));
    const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; return t;
  }
  const starTexture = () => sprite(g => {
    g.fillStyle = '#fff'; g.beginPath();
    for (let k = 0; k < 8; k++) { const a = -Math.PI / 2 + k * Math.PI / 4, r = k % 2 ? 9 : 30; g.lineTo(32 + r * Math.cos(a), 32 + r * Math.sin(a)); }
    g.closePath(); g.fill();
  });
  const dotTexture = () => sprite(g => {
    const grad = g.createRadialGradient(32, 32, 2, 32, 32, 30);
    grad.addColorStop(0, '#fff'); grad.addColorStop(0.6, 'rgba(255,255,255,0.8)'); grad.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grad; g.fillRect(0, 0, 64, 64);
  });

  function particles(scene, { texture, size, max, gravity }) {
    const pos = new Float32Array(max * 3), col = new Float32Array(max * 4);
    const vel = new Float32Array(max * 3), life = new Float32Array(max), ttl = new Float32Array(max);
    for (let i = 0; i < max; i++) pos[i * 3 + 1] = -100;
    const geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.BufferAttribute(pos, 3));
    geo.setAttribute('color', new T.BufferAttribute(col, 4));
    const mat = new T.PointsMaterial({ size, map: texture, vertexColors: true, transparent: true, depthWrite: false, alphaTest: 0.02 });
    const points = new T.Points(geo, mat);
    points.frustumCulled = false;
    scene.add(points);
    let next = 0;
    return {
      points,
      spawn(x, y, z, vx, vy, vz, seconds, r, g, b) {
        const i = next; next = (next + 1) % max;
        pos.set([x, y, z], i * 3); vel.set([vx, vy, vz], i * 3);
        life[i] = ttl[i] = seconds; col.set([r, g, b, 1], i * 4);
      },
      update(dt) {
        for (let i = 0; i < max; i++) {
          if (life[i] <= 0) continue;
          life[i] -= dt;
          if (life[i] <= 0) { col[i * 4 + 3] = 0; pos[i * 3 + 1] = -100; continue; }
          vel[i * 3 + 1] -= gravity * dt;
          pos[i * 3] += vel[i * 3] * dt; pos[i * 3 + 1] += vel[i * 3 + 1] * dt; pos[i * 3 + 2] += vel[i * 3 + 2] * dt;
          col[i * 4 + 3] = Math.min(1, (life[i] / ttl[i]) * 2.2);
        }
        geo.attributes.position.needsUpdate = true;
        geo.attributes.color.needsUpdate = true;
      },
    };
  }

  const SPARKLE = [[1, 0.84, 0.29], [1, 0.44, 0.64], [0.5, 0.82, 0.95], [0.71, 0.42, 1], [0.42, 0.84, 0.42]];

  // ── Set up, once the world is built ───────────────────────────────────────
  function setup(parts, layout) {
    const { scene, camera, hero } = parts;
    const updaters = WORLD.updaters;
    const stars = particles(scene, { texture: starTexture(), size: 0.42, max: 160, gravity: 3 });
    const drops = particles(scene, { texture: dotTexture(), size: 0.4, max: 260, gravity: 9 });
    const embers = particles(scene, { texture: dotTexture(), size: 0.22, max: 40, gravity: -1.2 });
    updaters.push(dt => { stars.update(dt); drops.update(dt); embers.update(dt); });
    const swaying = new Set();
    WORLD.life = { swaying, stars, drops, embers };      // for the tests

    const burstStars = (x, y, z, n) => {
      for (let i = 0; i < n; i++) {
        const a = rand(0, 6.28), sp = rand(1.2, 2.6), c = SPARKLE[i % SPARKLE.length];
        stars.spawn(x, y, z, Math.cos(a) * sp, rand(2, 4), Math.sin(a) * sp, rand(0.6, 1.0), c[0], c[1], c[2]);
      }
    };

    // Flowers and mushrooms: sway away from her, then settle.
    const touchables = layout.items.filter(it => it.touch && it.slots);
    const m4 = new T.Matrix4(), q = new T.Quaternion(), qt = new T.Quaternion(), up = new T.Vector3(0, 1, 0), axis = new T.Vector3(), p = new T.Vector3(), sc = new T.Vector3();
    const place = (it, tilt, ax) => {
      q.setFromAxisAngle(up, it.rot);
      if (tilt) q.premultiply(qt.setFromAxisAngle(ax, tilt));
      m4.compose(p.set(it.x, it.y, it.z), q, sc.setScalar(it.s));
      for (const sl of it.slots) {
        sl.inst.setMatrixAt(sl.n, new T.Matrix4().multiplyMatrices(m4, sl.local));
        sl.inst.instanceMatrix.needsUpdate = true;
      }
    };
    let lastTouchSound = 0;
    updaters.push(dt => {
      const hx = hero.group.position.x, hz = hero.group.position.z;
      for (const it of touchables) {
        const dx = it.x - hx, dz = it.z - hz;
        if (dx * dx + dz * dz < 0.8 && !(it.sway >= 0)) {        // she is walking through it
          const d = Math.hypot(dx, dz) || 1;
          it.sway = 0; it.axis = [dz / d, 0, -dx / d];              // lean away from her
          swaying.add(it);
          if (!calm()) burstStars(it.x, 0.5, it.z, 6);
          const now = performance.now();
          if (now - lastTouchSound > 220) { lastTouchSound = now; ding('pick'); }
        }
      }
      for (const it of swaying) {
        it.sway += dt;
        const done = it.sway > 1.4;
        place(it, done ? 0 : 0.5 * Math.exp(-3.2 * it.sway) * Math.sin(16 * it.sway), axis.fromArray(it.axis));
        if (done) { swaying.delete(it); it.sway = -1; }
      }
    });

    for (const f of layout.features || []) {
      if (f.type === 'fountain') fountain(f);
      else if (f.type === 'fire') fire(f);
      else if (f.type === 'butterflies') butterflies(f);
    }

    // Water: a few still glints, and ripples that grow and fade. One instanced mesh each, spots fixed.
    // With reduced motion the ripples stand still half grown; the water itself is always there.
    function waterLife() {
      const glintSpots = [[-1.6, -8.5], [2.4, -9.6], [-5, -9.2], [6, -8.6], [12.2, -0.4], [15.6, -2.6], [13.2, -3.6], [16.2, -0.2]];
      const rippleSpots = [[-2.6, -9.3], [2.8, -8.7], [-6, -9], [12.8, -2.2], [15.2, -0.4], [13.4, -3.4], [11.6, -0.6]];
      const flat = new T.Matrix4(), spot = new T.Vector3(), none = new T.Quaternion(), size = new T.Vector3();
      const glints = new T.InstancedMesh(new T.CircleGeometry(0.16, 8).rotateX(-Math.PI / 2).scale(2.2, 1, 1), new T.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8, depthWrite: false }), glintSpots.length);
      glintSpots.forEach(([x, z], n) => glints.setMatrixAt(n, flat.compose(spot.set(x, 0.07, z), none, size.set(1, 1, 1))));
      const ripples = new T.InstancedMesh(new T.RingGeometry(0.88, 1, 28).rotateX(-Math.PI / 2), new T.MeshBasicMaterial({ color: 0xffffff, blending: T.AdditiveBlending, transparent: true, depthWrite: false }), rippleSpots.length);
      const tint = new T.Color();
      const show = t => rippleSpots.forEach(([x, z], n) => {
        const phase = (t * 0.35 + n * 0.37) % 1;
        ripples.setMatrixAt(n, flat.compose(spot.set(x, 0.065, z), none, size.setScalar(0.15 + 0.75 * phase)));
        ripples.setColorAt(n, tint.setScalar(0.55 * (1 - phase)));
      });
      glints.frustumCulled = ripples.frustumCulled = false;
      show(0.5 / 0.35);
      scene.add(glints, ripples);
      let t = 0, drawn = true;
      updaters.push(dt => {
        if (calm()) { if (drawn) return; drawn = true; show(0.5 / 0.35); }
        else { t += dt; drawn = false; show(t); }
        ripples.instanceMatrix.needsUpdate = true; ripples.instanceColor.needsUpdate = true;
      });
    }
    waterLife();

    // The fountain: a steady spray from the middle; stand close and it splashes.
    function fountain(f) {
      let acc = 0, cool = 0;
      const jet = (n, spread, up) => {
        for (let i = 0; i < n; i++) {
          const a = rand(0, 6.28), s = rand(0, spread);
          drops.spawn(f.x, 1.45, f.z, Math.cos(a) * s, rand(up, up * 1.35), Math.sin(a) * s, rand(0.9, 1.3), 0.82, 0.93, 1);
        }
      };
      updaters.push(dt => {
        if (calm()) return;
        acc += dt * 16;
        const n = Math.floor(acc); acc -= n;
        jet(n, 0.9, 4.6);
        cool -= dt;
        if (cool <= 0 && Math.hypot(hero.group.position.x - f.x, hero.group.position.z - f.z) < f.r + 1.7) {
          cool = 3;
          jet(45, 3.4, 5.2);
          burstStars(f.x, 2.2, f.z, 10);
          ding('color');
        }
      });
    }

    // The camp fire: three cones that flicker, a warm light, and a few sparks going up.
    function fire(f) {
      const g = new T.Group();
      const cone = (r, h, color, x, z) => {
        const m = new T.Mesh(new T.ConeGeometry(r, h, 8).translate(0, h / 2, 0), new T.MeshBasicMaterial({ color, fog: false }));
        m.position.set(x, 0, z); g.add(m); return m;
      };
      const flames = [cone(0.3, 1.0, 0xff7a1a, -0.22, 0.05), cone(0.28, 1.3, 0xffb52e, 0.12, 0.12), cone(0.28, 0.9, 0xff6a1a, 0.2, -0.15), cone(0.17, 0.75, 0xfff3b0, 0, -0.02)];
      g.position.set(f.x, 0.12, f.z);
      scene.add(g);
      const light = new T.PointLight(0xff9a40, 2, 10, 1.6);
      light.position.set(f.x, 1.2, f.z);
      scene.add(light);
      let t = 0, acc = 0;
      updaters.push(dt => {
        t += dt;
        if (calm()) { light.intensity = 2; return; }
        flames.forEach((m, i) => {
          m.scale.set(1 + 0.12 * Math.sin(t * 11 + i * 2), 1 + 0.2 * Math.sin(t * 13 + i), 1 + 0.12 * Math.cos(t * 9 + i));
          m.rotation.y = t * (1.5 + i);
        });
        light.intensity = 2 + 0.5 * Math.sin(t * 17) + 0.3 * Math.sin(t * 31);
        acc += dt * 4;
        while (acc >= 1) { acc -= 1; embers.spawn(f.x + rand(-0.2, 0.2), 1.1, f.z + rand(-0.2, 0.2), rand(-0.3, 0.3), rand(1, 1.8), rand(-0.3, 0.3), rand(1.2, 2), 1, 0.7, 0.2); }
      });
    }

    // Butterflies: each flutters around its own wandering spot.
    function butterflies(f) {
      const colours = [['#ff6fa3', '#ffd0e4'], ['#ffb347', '#fff0c2'], ['#6cc7ff', '#d6f0ff'], ['#b46bff', '#ead6ff']];
      for (let k = 0; k < f.n; k++) {
        const [c1, c2] = colours[k % colours.length];
        const tex = sprite(g => {
          g.translate(32, 32);
          for (const s of [-1, 1]) {
            g.save(); g.scale(s, 1);
            g.fillStyle = c1; g.beginPath(); g.ellipse(14, -9, 15, 11, -0.5, 0, 6.3); g.fill();
            g.fillStyle = c2; g.beginPath(); g.ellipse(11, 11, 10, 8, 0.5, 0, 6.3); g.fill();
            g.restore();
          }
          g.fillStyle = '#4a3a5c'; g.fillRect(-2, -14, 4, 28);
        });
        const mesh = new T.Mesh(new T.PlaneGeometry(0.75, 0.75), new T.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: T.DoubleSide }));
        scene.add(mesh);
        const a = rand(0, 6.28), b = rand(0.15, 0.35), c = rand(0.2, 0.4), ph = rand(0, 6.28), r = f.r * rand(0.5, 1);
        let t = rand(0, 100);
        updaters.push(dt => {
          if (calm()) { mesh.visible = false; return; }
          mesh.visible = true;
          t += dt;
          mesh.position.set(f.x + Math.cos(t * b + a) * r, 1.1 + 0.45 * Math.sin(t * 1.3 + ph), f.z + Math.sin(t * c + a) * r * 0.8);
          mesh.lookAt(camera.position);
          mesh.scale.x = 0.25 + 0.75 * Math.abs(Math.sin(t * 12 + ph));     // the wings flap
        });
      }
    }
  }

  WORLD.onBuilt.push(setup);
})();
