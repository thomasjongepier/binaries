// What is inside each house and where (makeupgame-hfl.4). Pure data, like layout.js: world/houses.js builds whatever this
// describes (INTERIOR_BUILDERS), scripts/world-layout-check.js walks it without a browser, so adding a room, a doorway or a
// chair means adding an entry here and nothing else.
//
// Coordinates are world units on the floor of the house's own scene (a place of its own, nothing to do with the outdoor
// coordinates): x runs right, z runs toward the camera, so "north" (the back of the house) is negative z. The camera looks
// north into the house, so the front door is in the south wall. She is about 2.1 units tall.
//
//   WORLD_INTERIOR = { SCALE, SIZE, STYLES, houses: { 'house-west': house, ... } }
//
//   house = {
//     id         the building's id (layout.js) this is the inside of
//     style      a key of STYLES: sky, light, outside colour, how the Furniture Kit's materials are recoloured
//     bounds     { x0, z0, x1, z1 } the floor: where she may walk (the edge); the walls stand just outside it
//     rooms      [{ id, kind, x0, z0, x1, z1, floor, wall, spot }] tiling the floor with no gap. kind: living | kitchen | bedroom |
//                bathroom. floor: { pattern: 'planks' | 'tiles', a, b } colours. wall: the colour of its inner wall faces.
//                spot: { x, z } open floor she can always walk to (tests, and later where the camera looks)
//     walls      [{ x0, z0, x1, z1, h, role }] the wall pieces as rectangles (outer walls just outside bounds, dividers
//                centred on the line between two rooms), h the height. Each is also a solid. role: 'outer' | 'divider'
//     doorways   [{ x, z, axis, width, between: [roomId, roomId] }] gaps left in the dividers (informative: the walls
//                already have the gap), every one at least 2.4 wide
//     door       { x, z, nx, nz, width, height, wall } the way out, in the south wall: (x, z) where it meets the floor,
//                (nx, nz) the way it faces into the house. The wall there is a knee-high stub (the dollhouse camera, houses.js, looks
//                over it), the door as high as the stub
//     spawn      { x, z, facing, camera } where she stands when she comes in (the same spot every time)
//     items      what stands in the rooms, built like layout.js items (see below)
//     solids     what she cannot walk through: every wall and every solid item (circles and turned rectangles, solid.js)
//   }
//
// An item is { pack: 'furniture', name, x, z, rot, s, y, room, solid, box, use, shadow, wall, on }:
//   x, z       the middle of its footprint (not the model's origin: the Furniture Kit's origins are at a corner, the builder
//              centres each model by its own bounds and stands it on the floor)
//   rot        turn about the vertical axis in radians; 0 = its front toward +z (the south, the camera). A quarter turn
//              to face east is PI/2, west -PI/2, north PI
//   s          size on top of SCALE (3; the kit draws about 1 unit big): default 1
//   y          height of its underside above the floor (things on a table, wall units); default 0
//   box        [w, d] she cannot walk into this rectangle (turned with it). Default from SIZE; flat or high-up things
//              (rugs, wall units, things on tables) are not solid: solid false
//   use        'bed' | 'sofa' | 'stove' | 'shower': becomes a spot with an action later (hfl.6); nothing uses it yet
//   room       the room it is in (filled in)
// Classic script (no modules) so it works when the page is opened from file://.
(function () {
  const SCALE = 3;
  const PI = Math.PI;

  // The footprint and height of each model in model units: [width along x, depth along z, height], from
  // `node scripts/model-sizes.js furniture`. (world-house.js compares them with the built models.)
  const SIZE = {
    bedDouble: [0.96, 1.13, 0.38], books: [0.15, 0.09, 0.10],
    cabinetBedDrawerTable: [0.26, 0.21, 0.26], cabinetTelevision: [0.80, 0.25, 0.31], televisionModern: [0.68, 0.13, 0.45],
    loungeSofa: [0.98, 0.41, 0.46], tableCoffee: [0.66, 0.40, 0.23],
    lampRoundFloor: [0.15, 0.18, 0.86], lampRoundTable: [0.15, 0.18, 0.31], pottedPlant: [0.21, 0.24, 0.65], coatRackStanding: [0.27, 0.27, 0.77],
    rugDoormat: [0.43, 0.24, 0.01], rugRectangle: [1.57, 0.92, 0.01], rugRound: [0.92, 0.92, 0.01],
    kitchenCabinet: [0.43, 0.45, 0.45], kitchenCabinetDrawer: [0.43, 0.45, 0.45], kitchenSink: [0.43, 0.45, 0.49], kitchenStove: [0.43, 0.45, 0.45],
    kitchenFridgeLarge: [0.52, 0.40, 0.92], kitchenCabinetUpper: [0.43, 0.22, 0.39], hoodLarge: [0.43, 0.28, 0.37],
    table: [0.84, 0.45, 0.33], chair: [0.20, 0.20, 0.47], chairCushion: [0.20, 0.20, 0.46], trashcan: [0.21, 0.23, 0.43],
    bookcaseClosedWide: [0.80, 0.25, 0.79],
    bedSingle: [0.57, 1.13, 0.37], bedBunk: [0.57, 1.09, 0.85], bear: [0.39, 0.25, 0.45],
    bathtub: [1.19, 0.56, 0.42], bathroomSinkSquare: [0.43, 0.30, 0.58], toiletSquare: [0.30, 0.39, 0.45], showerRound: [0.56, 0.56, 1.09],
    bookcaseClosedDoors: [0.40, 0.25, 0.85], sideTable: [0.53, 0.22, 0.38],
    cabinetTelevisionDoors: [0.80, 0.26, 0.31], televisionVintage: [0.41, 0.27, 0.27], loungeDesignSofa: [1.12, 0.41, 0.40],
    tableCoffeeGlass: [0.66, 0.40, 0.23], lampSquareFloor: [0.12, 0.12, 0.86], lampSquareTable: [0.12, 0.12, 0.29], rugSquare: [0.90, 0.92, 0.01],
    kitchenFridge: [0.43, 0.29, 0.92], kitchenStoveElectric: [0.43, 0.45, 0.45], hoodModern: [0.43, 0.28, 0.40], kitchenCabinetUpperDouble: [0.43, 0.22, 0.39], kitchenCabinetUpperLow: [0.43, 0.22, 0.20],
    tableRound: [0.69, 0.80, 0.37], chairModernCushion: [0.20, 0.20, 0.46], toaster: [0.19, 0.10, 0.13], kitchenCoffeeMachine: [0.19, 0.24, 0.18],
    toilet: [0.31, 0.48, 0.45], bathroomSink: [0.34, 0.29, 0.56], bathroomMirror: [0.30, 0.15, 0.43], shower: [0.56, 0.58, 1.09], washer: [0.39, 0.39, 0.47],
  };

  // House styles. recolour: the Furniture Kit has no textures, only 15 named flat colours shared by every model, so a style
  // changes the look by recolouring those materials BY NAME on a copy (never the shared ones).
  const STYLES = {
    A: {
      name: 'cosy wooden cottage',
      sky: 0xf4e6c8, outside: 0x8c6a45, trim: 0xb98a55,
      sun: 0xfff0d0, hemi: [0xffffff, 0x9a7a5a, 1.7],
      recolour: { wood: 0xe0b078, woodDark: 0xa8723f, carpet: 0xd9604f, carpetDarker: 0xb04a3c },
    },
    // Style B, bright and modern: sky-blue light, white and pastel walls, pale birch wood, teal cabinets and bedding, pink sofa,
    // sunny yellow rugs and lamps (lamp material) (every rug is the kit's carpetDarker, so they are all one yellow).
    B: {
      name: 'bright modern flat',
      sky: 0xcfe8f8, outside: 0x4fb3bf, trim: 0xffffff, door: 0xf2b035, knob: 0xffffff,
      sun: 0xffffff, fill: 0xe6f0ff, hemi: [0xffffff, 0xd4e2f0, 1.9],
      recolour: { wood: 0xf3e9d2, woodDark: 0x3fb7ae, carpet: 0x2fb5b0, carpetDarker: 0xffc933, carpetBlue: 0xf2709f, lamp: 0xffd54a, metal: 0xe9eef2 },
    },
  };

  // The floor of one house: [x0, z0, x1, z1] of each room, in a 2 x 2 plan of about 7 x 6 units.
  const WEST = {
    id: 'house-west', style: 'A',
    bounds: { x0: -7, z0: -6, x1: 7, z1: 6 },
    rooms: [
      { id: 'bedroom', kind: 'bedroom', x0: -7, z0: -6, x1: 0, z1: 0, floor: { pattern: 'planks', a: '#c88f55', b: '#b98048' }, wall: 0xf1d3c4, spot: { x: -2.5, z: -2.4 } },
      { id: 'bathroom', kind: 'bathroom', x0: 0, z0: -6, x1: 7, z1: 0, floor: { pattern: 'tiles', a: '#f2eadb', b: '#8fc5c0' }, wall: 0xcfe8e0, spot: { x: 3.4, z: -1.6 } },
      { id: 'living', kind: 'living', x0: -7, z0: 0, x1: 0, z1: 6, floor: { pattern: 'planks', a: '#c88f55', b: '#b98048' }, wall: 0xf3e6c8, spot: { x: -2.5, z: 2.4 } },
      { id: 'kitchen', kind: 'kitchen', x0: 0, z0: 0, x1: 7, z1: 6, floor: { pattern: 'tiles', a: '#f1e2c4', b: '#d98f6a' }, wall: 0xf5dfa0, spot: { x: 1.6, z: 3.4 } },
    ],
    outerThickness: 0.4, dividerThickness: 0.3, tall: 3.6, stub: 0.6,
    // Dividers: the line x = 0 (back half taller than the front half, which steps down toward the camera) and the line
    // z = 0 (a knee-high partition: it faces the camera). Gaps are the doorways, each 3 wide.
    dividers: [
      { axis: 'x', at: 0, from: -6, to: 0, h: 3.0, gaps: [{ c: -3, w: 3, between: ['bedroom', 'bathroom'] }] },
      { axis: 'x', at: 0, from: 0, to: 6, h: 1.5, gaps: [{ c: 3.4, w: 3, between: ['living', 'kitchen'] }] },
      { axis: 'z', at: 0, from: -7, to: 7, h: 0.6, gaps: [{ c: -1.65, w: 3, between: ['bedroom', 'living'] }] },
    ],
    doorX: -2.0,
    // The furniture (see the header). Written with put(): x, z the middle of the footprint.
    items: [],
  };

  // ── Furniture, room by room ──────────────────────────────────────────────
  const items = WEST.items;
  const put = (name, x, z, rot = 0, o = {}) => items.push({ name, x, z, rot, ...o });

  // Living room (x -7..0, z 0..6): the front door at its south wall, a doormat, the sofa facing a TV on its cabinet over a rug.
  put('rugRectangle', -4.4, 2.4, 0, { s: 0.8, solid: false });
  put('cabinetTelevision', -4.4, 0.6);
  put('televisionModern', -4.4, 0.55, 0, { s: 0.8, y: 0.93, solid: false });
  put('tableCoffee', -4.4, 2.3);
  put('loungeSofa', -4.4, 4.0, PI, { use: 'sofa' });
  put('lampRoundFloor', -6.6, 0.65, 0, { box: [0.6, 0.6] });
  put('pottedPlant', -6.5, 1.35, 0, { box: [0.7, 0.7] });
  put('pottedPlant', -0.55, 5.45, 0, { box: [0.6, 0.6] });
  put('rugDoormat', -2.0, 5.35, 0, { solid: false });

  // Kitchen (x 0..7, z 0..6): counters along the north wall: cabinet, sink, stove, cabinet, big fridge; wall units over them;
  // a table with four chairs and a rug.
  const counter = [['kitchenCabinetDrawer', 0.85], ['kitchenSink', 2.14], ['kitchenStove', 3.43], ['kitchenCabinet', 4.72]];
  for (const [name, x] of counter) put(name, x, 0.15 + 0.675, 0, name === 'kitchenStove' ? { use: 'stove' } : {});
  put('kitchenFridgeLarge', 6.2, 0.15 + 0.6);
  put('kitchenCabinetUpper', 0.85, 0.15 + 0.33, 0, { y: 2.3, solid: false });
  put('kitchenCabinetUpper', 2.14, 0.15 + 0.33, 0, { y: 2.3, solid: false });
  put('hoodLarge', 3.43, 0.15 + 0.42, 0, { y: 2.3, solid: false });
  put('kitchenCabinetUpper', 4.72, 0.15 + 0.33, 0, { y: 2.3, solid: false });
  put('rugRectangle', 4.2, 3.98, 0, { s: 0.9, solid: false });
  put('table', 4.2, 3.98);
  put('chairCushion', 3.6, 2.95, 0);
  put('chairCushion', 4.8, 2.95, 0);
  put('chairCushion', 3.6, 5.0, PI);
  put('chairCushion', 4.8, 5.0, PI);
  put('pottedPlant', 0.9, 5.45, 0, { box: [0.7, 0.7] });

  // Bedroom (x -7..0, z -6..0): the bed head against the north wall in the corner, a bedside table with a lamp, a bookcase beside it, a rug at the
  // foot of the bed, a plant.
  put('rugRectangle', -4.4, -1.8, 0, { s: 0.8, solid: false });
  put('bedDouble', -5.5, -4.3, 0, { use: 'bed' });
  put('cabinetBedDrawerTable', -3.6, -5.65);
  put('lampRoundTable', -3.6, -5.65, 0, { y: 0.78, solid: false });
  put('bookcaseClosedWide', -1.7, -5.62);
  put('books', -1.2, -5.62, 0, { y: 2.37, solid: false });
  put('pottedPlant', -6.5, -0.9, 0, { box: [0.7, 0.7] });

  // Bathroom (x 0..7, z -6..0): toilet, sink with a mirror and the shower along the north wall, the washer on the east wall, mats.
  put('rugRound', 3.4, -3.2, 0, { s: 0.8, solid: false });
  put('toilet', 1.6, -6 + 0.72);
  put('bathroomSink', 3.4, -5.55);
  put('bathroomMirror', 3.4, -5.75, 0, { y: 2.2, solid: false });
  put('shower', 6.16, -6 + 0.87, 0, { use: 'shower' });
  put('rugDoormat', 6.16, -3.7, 0, { solid: false });
  put('washer', 6.4, -1.5, -PI / 2);
  put('trashcan', 4.7, -5.5, 0, { box: [0.6, 0.7] });


  // ── House east (style B): the same plan mirrored, so the front door is at the front right ─────────────
  // bathroom (back left) | bedroom (back right) / kitchen (front left) | living room (front right, the front door in its south wall).
  const EAST = {
    id: 'house-east', style: 'B',
    bounds: { x0: -7, z0: -6, x1: 7, z1: 6 },
    rooms: [
      { id: 'bathroom', kind: 'bathroom', x0: -7, z0: -6, x1: 0, z1: 0, floor: { pattern: 'tiles', a: '#ffffff', b: '#86d9d2' }, wall: 0xb5e8e4, spot: { x: -3.6, z: -2.4 } },
      { id: 'bedroom', kind: 'bedroom', x0: 0, z0: -6, x1: 7, z1: 0, floor: { pattern: 'planks', a: '#f3e4c4', b: '#ead6ae' }, wall: 0xf8c8dc, spot: { x: 1.3, z: -2.3 } },
      { id: 'kitchen', kind: 'kitchen', x0: -7, z0: 0, x1: 0, z1: 6, floor: { pattern: 'tiles', a: '#fff7d1', b: '#ffd75e' }, wall: 0xfff1a0, spot: { x: -5.7, z: 5.0 } },
      { id: 'living', kind: 'living', x0: 0, z0: 0, x1: 7, z1: 6, floor: { pattern: 'planks', a: '#f3e4c4', b: '#ead6ae' }, wall: 0xc8efd2, spot: { x: 1.3, z: 3.4 } },
    ],
    outerThickness: 0.4, dividerThickness: 0.3, tall: 3.6, stub: 0.6,
    dividers: [
      { axis: 'x', at: 0, from: -6, to: 0, h: 3.0, gaps: [{ c: -3, w: 3, between: ['bathroom', 'bedroom'] }] },
      { axis: 'x', at: 0, from: 0, to: 6, h: 1.5, gaps: [{ c: 3.4, w: 3, between: ['kitchen', 'living'] }] },
      { axis: 'z', at: 0, from: -7, to: 7, h: 0.6, gaps: [{ c: 1.65, w: 3, between: ['bedroom', 'living'] }] },
    ],
    doorX: 2.0,
    items: [],
  };
  {
    const put = (name, x, z, rot = 0, o = {}) => EAST.items.push({ name, x, z, rot, ...o });
    // Living room (x 0..7, z 0..6): a pink sofa facing a TV on a cabinet across a glass coffee table and a round yellow rug.
    put('rugRound', 4.7, 2.9, 0, { s: 1.1, solid: false });
    put('cabinetTelevisionDoors', 4.7, 0.55);
    put('televisionVintage', 4.7, 0.5, 0, { s: 1.1, y: 0.93, solid: false });
    put('tableCoffeeGlass', 4.7, 2.9, 0, { s: 0.7 });
    put('loungeDesignSofa', 4.7, 4.5, PI, { s: 0.8, use: 'sofa' });
    put('lampSquareFloor', 6.7, 0.7, 0, { box: [0.5, 0.5] });
    put('pottedPlant', 6.65, 4.4, 0, { box: [0.6, 0.6] });
    put('coatRackStanding', 0.55, 5.45, 0, { box: [0.6, 0.6] });
    put('rugDoormat', 2.0, 5.35, 0, { solid: false });

    // Kitchen (x -7..0, z 0..6): teal units along the north wall: fridge, drawers, electric stove, sink, cabinet; a modern hood and wall
    // units; a round table with two chairs on a yellow rug.
    const cz = 0.15 + 0.675;
    put('kitchenFridge', -6.35, 0.15 + 0.435);
    put('kitchenCabinetDrawer', -5.055, cz);
    put('kitchenStoveElectric', -3.765, cz, 0, { use: 'stove' });
    put('kitchenSink', -2.475, cz);
    put('kitchenCabinet', -1.185, cz);
    put('kitchenCabinetUpperDouble', -5.055, 0.15 + 0.33, 0, { y: 2.3, solid: false });
    put('hoodModern', -3.765, 0.15 + 0.42, 0, { y: 2.3, solid: false });
    put('kitchenCabinetUpperDouble', -2.475, 0.15 + 0.33, 0, { y: 2.3, solid: false });
    put('kitchenCabinetUpperLow', -1.185, 0.15 + 0.33, 0, { y: 2.3, solid: false });
    put('toaster', -1.4, 0.15 + 0.6, 0, { y: 1.35, solid: false });
    put('kitchenCoffeeMachine', -0.8, 0.15 + 0.6, 0, { y: 1.35, solid: false });
    put('rugRound', -3.6, 3.6, 0, { s: 1.3, solid: false });
    put('tableRound', -3.6, 3.6, 0, { s: 0.85 });
    put('chairModernCushion', -4.9, 3.6, PI / 2);
    put('chairModernCushion', -2.4, 3.6, -PI / 2);
    put('pottedPlant', -0.6, 5.4, 0, { box: [0.6, 0.6] });

    // Bedroom (x 0..7, z -6..0): a single bed (head north) and a bunk bed against the east wall, a side table with a lamp between
    // them, a wardrobe in the north-west corner, a yellow rug, a bear on the bed.
    put('rugSquare', 4.0, -1.9, 0, { s: 1.3, solid: false });
    put('bedSingle', 3.2, -4.3, 0, { use: 'bed' });
    put('bedBunk', 6.0, -4.35, 0);
    put('sideTable', 4.7, -5.6, 0, { s: 0.9 });
    put('lampSquareTable', 4.7, -5.6, 0, { s: 1.2, y: 1.02, solid: false });
    put('bookcaseClosedDoors', 1.1, -5.62);
    put('bear', 3.2, -2.9, 0, { s: 0.85, y: 1.05, solid: false });
    put('pottedPlant', 6.5, -0.8, 0, { box: [0.6, 0.6] });

    // Bathroom (x -7..0, z -6..0): a bath, a square sink with a mirror and the round shower along the north wall, the toilet and
    // the washer on the west wall, a yellow mat.
    put('rugRound', -3.4, -2.6, 0, { s: 0.9, solid: false });
    put('bathtub', -5.0, -6 + 0.84);
    put('bathroomSinkSquare', -2.52, -6 + 0.5);
    put('bathroomMirror', -2.52, -5.75, 0, { y: 2.2, solid: false });
    put('showerRound', -0.9, -6 + 0.715, 0, { s: 0.85, use: 'shower' });
    put('toiletSquare', -7 + 0.6, -3.0, PI / 2);
    put('washer', -7 + 0.6, -0.9, PI / 2);
  }

  // ── Expanding the data: solids, walls, spawn ──────────────────────────────
  const roomAt = (house, x, z) => house.rooms.find(r => x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1) || null;

  function expand(h) {
    h.items = h.items.map(it => {
      const size = SIZE[it.name];
      if (!size) throw new Error('interior.js: no SIZE for ' + it.name);
      const s = (it.s || 1) * SCALE, rot = it.rot || 0;
      const box = it.solid === false ? null : it.box || [size[0] * s, size[1] * s];
      const solid = box ? { x: it.x, z: it.z, hw: box[0] / 2, hd: box[1] / 2, rot } : null;
      const room = roomAt(h, it.x, it.z);
      return { pack: 'furniture', name: it.name, x: it.x, z: it.z, rot, s, y: it.y || 0, room: room && room.id, solid, use: it.use || null,
        footprint: [size[0] * s, size[1] * s, size[2] * s], shadow: it.shadow !== undefined ? it.shadow : it.y || /^rug/.test(it.name) ? 0 : 1 }   // (a rug lies flat on the floor: a pool under it would only fight it);
    });
    // Walls: the four outer ones just outside the floor, then the dividers with their doorways cut out.
    const b = h.bounds, ot = h.outerThickness, dt = h.dividerThickness;
    h.walls = [
      { x0: b.x0 - ot, z0: b.z0 - ot, x1: b.x1 + ot, z1: b.z0, h: h.tall, role: 'outer', side: 'north' },
      { x0: b.x0 - ot, z0: b.z1, x1: b.x1 + ot, z1: b.z1 + ot, h: h.stub, role: 'outer', side: 'south' },
      { x0: b.x0 - ot, z0: b.z0, x1: b.x0, z1: b.z1, h: h.tall, role: 'outer', side: 'west' },
      { x0: b.x1, z0: b.z0, x1: b.x1 + ot, z1: b.z1, h: h.tall, role: 'outer', side: 'east' },
    ];
    h.doorways = [];
    for (const d of h.dividers) {
      const cuts = d.gaps.map(g => [g.c - g.w / 2, g.c + g.w / 2]).sort((p, q) => p[0] - q[0]);
      let at = d.from;
      const piece = (a, c) => {
        if (c - a < 1e-6) return;
        h.walls.push(d.axis === 'x' ? { x0: d.at - dt / 2, z0: a, x1: d.at + dt / 2, z1: c, h: d.h, role: 'divider' } : { x0: a, z0: d.at - dt / 2, x1: c, z1: d.at + dt / 2, h: d.h, role: 'divider' });
      };
      for (const [a, c] of cuts) { piece(at, a); at = c; }
      piece(at, d.to);
      for (const g of d.gaps) h.doorways.push(d.axis === 'x' ? { x: d.at, z: g.c, axis: 'x', width: g.w, between: g.between } : { x: g.c, z: d.at, axis: 'z', width: g.w, between: g.between });
    }
    h.solids = [];
    for (const w of h.walls) h.solids.push({ x: (w.x0 + w.x1) / 2, z: (w.z0 + w.z1) / 2, hw: (w.x1 - w.x0) / 2, hd: (w.z1 - w.z0) / 2, rot: 0 });
    for (const it of h.items) if (it.solid) h.solids.push(it.solid);
    // The way out: in the south wall, a door as high as the stub, and where she stands when she comes in.
    h.door = { x: h.doorX, z: b.z1, nx: 0, nz: -1, width: 1.7, height: h.stub, wall: 'south' };
    h.spawn = { x: h.doorX, z: b.z1 - 1.6, facing: PI, camera: { yaw: 0 } };
    return h;
  }

  window.WORLD_INTERIOR = { SCALE, SIZE, STYLES, roomAt, houses: { [WEST.id]: expand(WEST), [EAST.id]: expand(EAST) } };
})();
