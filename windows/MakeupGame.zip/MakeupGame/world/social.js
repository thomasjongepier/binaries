// Friends meeting face to face (epic makeupgame-oq2, N8). Two characters meet when they are NEAR to FAR apart and
// each looks at the other (within FACING). It works between her and a friend, and between two friends.
//
//   with her:      the friend notices her, stands and looks at her for a moment (NOTICE), then does one of the
//                  INTERACTIONS (wave, say hi, cry, fart), then one follow-up: another interaction, or LEAVE (turns
//                  round and walks off in a random direction, 0 to LEAVE.far units). If she turns away (or walks off)
//                  before the friend did anything, the friend cries.
//   two friends:   they take turns: one starts, the other responds (an interaction, or LEAVE), and so on, at most
//                  MAX_TURNS, then one walks off.
//   a tap:         tapping a friend makes them turn to her and react again, whatever they were doing.
//
// After a meeting the same two do not meet again for AGAIN seconds. A bump (npcs.js) ends a meeting. To add an
// interaction, add an entry to INTERACTIONS: `weight` (0: only as an answer), `start(n)` sets `n.perf.dur` (and `n.perf.own = true` when it
// turns the friend itself), optional `update(n, dt)`, `pose(n, k, t)` (bones, on top of the clip; k fades it in and out) and `end(n)`.
// RESPONSES says what likes to follow what. The effects are fx.js, the sounds voices.js.
(() => {
  'use strict';
  const T = window.THREE;
  const NEAR = 1.2, FAR = 3.0;                       // face to face: this far apart (world units; she is 2.1 tall)...
  const FACING = Math.cos((45 * Math.PI) / 180);     // ...each looking at the other within 45 degrees
  const TURNED_AWAY = Math.cos((100 * Math.PI) / 180);   // she looks more than this far away from the friend: she turned away
  const LOST = 4.5;                                  // she is this far off: she walked away
  const NOTICE = [0.5, 2.5];                         // seconds a friend looks at her before doing something
  const BEAT = [0.3, 0.9];                           // seconds between two turns
  const AGAIN = 5;                                   // seconds before the same two can meet again
  const MAX_TURNS = 4;                               // two friends: turns before one of them walks off anyway
  const LEAVE = { weight: 2.5, far: 6, none: 0.25 }; // the follow-up "walks away": up to `far` units, 0 (only turns round) `none` of the time
  // What follows what. When somebody has just done `prev`, the odds of each next reaction are multiplied by these (1 where it is not
  // listed): a laugh follows a fart, a dancer gets danced along with, someone who was scared runs off or cries. `leave` is turning
  // round and walking off. A weight of 0 in INTERACTIONS means "never picked at random" (fright only follows a scare).
  const RESPONSES = {
    wave:  { wave: 2, hi: 2 },
    hi:    { hi: 2, wave: 2 },
    cry:   { laugh: 0.2, fart: 0.3, scare: 0.3, hi: 1.5, wave: 1.5 },
    fart:  { laugh: 4, fart: 1.5, cry: 0.5, hi: 0.6 },
    laugh: { laugh: 2, fart: 1.3, dance: 1.3, scare: 0.5 },
    dance: { dance: 4, jump: 2, laugh: 1.5, twirl: 1.5, cry: 0.3, scare: 0.5 },
    jump:  { jump: 2, dance: 1.5, laugh: 1.3, cry: 0.4 },
    twirl: { twirl: 2, dance: 1.5, laugh: 1.5 },
    scare: { laugh: 4, leave: 1.5 },                         // the scarer, if they get a turn: giggling
    fright: { leave: 4, cry: 2.5, laugh: 2, scare: 0.4 },
  };
  const DANCE_BEAT = 0.5;                            // dancing: seconds per beat (120 bpm). One clock for everybody, so two dancers keep the same beat
  const DANCE_JOIN = 0.6;                            // two friends: the other one dances along this often
  const HOP = 1.5;                                   // jumping for joy: the jump clip plays this much faster
  const TAP_REACH = 0.55;                            // a tap this close to a friend's middle (a line from feet to head) is a tap on them

  const HER = { her: true };
  let F = null, parts = null;
  const rnd = Math.random;
  const between = ([a, b]) => a + rnd() * (b - a);
  const posOf = x => (x === HER ? parts.hero.group.position : x.group.position);
  const headingOf = x => (x === HER ? parts.hero.pivot.rotation.y : x.pivot.rotation.y);
  const label = x => (x === HER ? 'her' : F.list.indexOf(x));
  const other = (E, n) => (E.a === n ? E.b : E.a);

  // ── What a friend can do ─────────────────────────────────────────────────
  const INTERACTIONS = {
    wave: {
      weight: 3,
      start(n) {
        const a = n.c.actions.Waving;
        a.reset();                                       // a wave after a wave starts again
        n.clip = 'Waving';
        n.perf.dur = a.getClip().duration;
      },
      end(n) { n.clip = null; },
    },
    hi: {
      weight: 3,
      start(n) {
        n.perf.dur = 1.5;
        const word = WORLD_VOICES.word();
        WORLD_FX.bubble(n, word);
        WORLD_VOICES.play('hi', n);
      },
      pose(n, k, t) { bow(n, 'head', 0.22 * Math.pow(Math.sin(Math.PI * Math.min(1, t / 0.7) * 2), 2) * k); },   // two little nods
    },
    cry: {
      weight: 1.5,
      start(n) {
        n.perf.dur = 3;
        n.c.setSad(true);
        WORLD_FX.tears(n, 2.8);
        WORLD_VOICES.play('cry', n, n.perf.dur);
      },
      pose(n, k, t) {                                    // head down, shoulders shaking with the sobs
        bow(n, 'chest', (0.14 + 0.06 * Math.abs(Math.sin(t * 7))) * k);
        bow(n, 'head', (0.32 + 0.08 * Math.sin(t * 14)) * k);
        twist(n, 'chest', 0.06 * Math.sin(t * 9) * k);
      },
      end(n) { n.c.setSad(false); },
    },
    fart: {
      weight: 2,
      start(n) {
        n.perf.dur = 1.8;
        WORLD_FX.puff(n);
        WORLD_VOICES.play('fart', n);
      },
      update(n) {                                        // a little hop as it comes out
        const t = n.perf.t;
        n.hop = t < 0.32 ? 0.13 * Math.sin((Math.PI * t) / 0.32) : 0;
      },
      pose(n, k, t) {                                    // leans forward and wiggles
        if (t > 0.9) return;
        bow(n, 'chest', 0.16 * Math.sin((Math.PI * t) / 0.9));
        twist(n, 'hips', 0.14 * Math.sin(t * 24) * (1 - t / 0.9));
      },
      end(n) { n.hop = 0; },
    },
  };

  Object.assign(INTERACTIONS, {
    laugh: {
      weight: 2,
      start(n) {
        n.perf.dur = 1.8 + rnd() * 0.9;
        n.c.setMood('laugh');
        WORLD_FX.bubble(n, 'Haha!', 'laugh');
        WORLD_VOICES.play('laugh', n, n.perf.dur);
      },
      update(n) {                                        // a little bounce with every "ha"
        const t = n.perf.t;
        n.hop = 0.05 * Math.max(0, Math.sin(t * 15)) * Math.min(1, t / 0.2, (n.perf.dur - t) / 0.3);
      },
      pose(n, k, t) {                                    // leans back, the shoulders bobbing
        bow(n, 'chest', (-0.1 + 0.05 * Math.sin(t * 15)) * k);
        bow(n, 'head', (-0.3 + 0.07 * Math.sin(t * 15 + 0.6)) * k);
      },
      end(n) { n.c.setMood(null); n.hop = 0; },
    },
    jump: {                                              // one to three happy hops, arms in the air (not the stroll's jump of npcs.js)
      weight: 2,
      start(n) {
        const J = WORLD.JUMP, P = n.perf;
        P.hops = 1 + Math.floor(rnd() * 3); P.len = J.TIME / HOP; P.at = -1;
        P.dur = P.hops * P.len + 0.15;
        n.clip = J.CLIP; n.clipScale = HOP; n.clipFade = 0.08;
        n.c.actions[J.CLIP].reset();
        WORLD_FX.bubble(n, 'Yay!', 'yay');
        WORLD_VOICES.play('yay', n);
      },
      update(n) {
        const J = WORLD.JUMP, P = n.perf, i = Math.floor(P.t / P.len);
        if (i >= P.hops) { n.hop = 0; return; }
        if (i !== P.at) { P.at = i; if (i > 0) n.c.actions[J.CLIP].reset(); }       // the next hop: the clip from its crouch again
        n.hop = J.HEIGHT * Math.sin(Math.PI * Math.min(1, Math.max(0, ((P.t - i * P.len) * HOP - J.FROM) / J.AIR)));
      },
      pose(n, k) { const up = 2.3 * k * (n.hop / WORLD.JUMP.HEIGHT); arms(n, up, up); },
      end(n) { n.clip = null; n.clipScale = 1; n.clipFade = 0; n.hop = 0; n.c.actions[WORLD.JUMP.CLIP].timeScale = 1; },
    },
    twirl: {                                             // round once or twice on the spot, arms out, and facing the other again
      weight: 1.5,
      start(n) {
        const P = n.perf;
        P.own = true; P.turns = rnd() < 0.3 ? 2 : 1; P.dir = rnd() < 0.5 ? 1 : -1; P.from = n.pivot.rotation.y;
        P.spin = 0.9 * P.turns + 0.2; P.dur = P.spin + 0.35;
        WORLD_FX.sparkles(n, P.dur);
        WORLD_VOICES.play('yay', n);
      },
      update(n) {
        const P = n.perf, u = Math.min(1, P.t / P.spin);
        n.pivot.rotation.y = P.from + P.dir * P.turns * 2 * Math.PI * u * u * (3 - 2 * u);
        n.hop = 0.1 * Math.sin(Math.PI * u);
      },
      pose(n, k) { arms(n, 1.45 * k, 1.45 * k); },
      end(n) { n.hop = 0; },
    },
    scare: {                                             // draws back, then leaps at the other one with claws up and a "Boo!"
      weight: 1,
      start(n) {
        n.perf.dur = 1.5; n.perf.hit = false;
        WORLD_FX.bubble(n, 'Boo!', 'boo');
        WORLD_VOICES.play('boo', n);
      },
      update(n) {
        const P = n.perf, t = P.t;
        if (!P.hit && t >= 0.45) {                       // the leap: now the other one gets a fright
          P.hit = true;
          n.c.setMood('laugh');                          // a big open roaring mouth
          const E = n.meet, o = E && other(E, n);
          if (o === HER) WORLD.startle();
          else if (o && !o.perf) perform(o, 'fright', 'scared', { join: true });
        }
        n.hop = t > 0.4 && t < 0.8 ? 0.07 * Math.sin(Math.PI * (t - 0.4) / 0.4) : 0;
      },
      pose(n, k, t) {
        const wind = Math.min(1, t / 0.4), lunge = t < 0.4 ? 0 : Math.min(1, (t - 0.4) / 0.12) * (t > 1.1 ? Math.max(0, 1 - (t - 1.1) / 0.3) : 1);
        const claws = (0.6 * wind * (1 - lunge) + 1.9 * lunge) * k;
        bow(n, 'chest', (-0.22 * wind * (1 - lunge) + 0.16 * lunge) * k);
        bow(n, 'head', -0.14 * lunge * k);                // chin up: the roaring face shows
        arms(n, claws, claws);
      },
      end(n) { n.c.setMood(null); n.hop = 0; },
    },
    fright: {                                            // scared (never picked at random): jumps back, arms up, shocked, "!"
      weight: 0,
      start(n) {
        const P = n.perf, E = n.meet, o = E && other(E, n), op = o && posOf(o), p = n.group.position;
        P.dur = 1.4;
        const d = op ? Math.hypot(p.x - op.x, p.z - op.z) || 1 : 1;
        P.away = op ? { x: (p.x - op.x) / d, z: (p.z - op.z) / d } : { x: 0, z: 0 };
        n.clip = 'Hit_B'; n.clipFade = 0.06;
        n.c.actions.Hit_B.reset();
        n.c.setMood('shock');
        WORLD_FX.bubble(n, '!', 'shock');
        WORLD_VOICES.play('scream', n);
      },
      update(n, dt) {
        const P = n.perf, t = P.t, p = n.group.position;
        n.hop = 0.22 * Math.sin(Math.PI * Math.min(1, t / 0.4));
        if (t < 0.4) { p.x += P.away.x * 1.5 * dt; p.z += P.away.z * 1.5 * dt; F.clearOfSolids(p); }     // a jump back, never into a wall
      },
      pose(n, k) { bow(n, 'chest', -0.2 * k); bow(n, 'head', -0.15 * k); arms(n, 1.1 * k, 1.1 * k); },
      end(n) { n.c.setMood(null); n.clip = null; n.clipFade = 0; n.hop = 0; },
    },
    dance: {                                             // a bouncy dance to the beat, with notes in the air; the one they meet may join in
      weight: 2,
      start(n) {
        const P = n.perf, order = [0, 1, 2];
        for (let i = 2; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
        P.order = order; P.dur = 4 + rnd() * 2;
        WORLD_FX.notes(n, P.dur);
        if (!P.joined) WORLD_VOICES.play('dance', n, P.dur);
        const E = n.meet, force = F.force || {};
        if (E && !E.withHer && !P.joined && rnd() < (force.join !== undefined ? force.join : DANCE_JOIN)) {
          const o = other(E, n);
          if (!o.perf) perform(o, 'dance', 'join', { join: true, dur: P.dur - 0.1 });
        }
      },
      update(n) {
        const t = n.perf.t, ph = beatClock / DANCE_BEAT;
        n.hop = 0.09 * Math.pow(Math.abs(Math.sin(Math.PI * ph)), 0.7) * Math.min(1, t / 0.25, (n.perf.dur - t) / 0.25);
      },
      pose(n, k, t) {
        const P = n.perf, i = Math.floor(t / 2), w = Math.min(1, (t - i * 2) / 0.4), ph = beatClock / DANCE_BEAT;
        DANCE_MOVES[P.order[i % 3]](n, k * (i > 0 ? w : 1), ph);
        if (i > 0 && w < 1) DANCE_MOVES[P.order[(i - 1) % 3]](n, k * (1 - w), ph);     // the last move fades out as the next comes in
      },
      end(n) { n.hop = 0; },
    },
  });

  // Dance moves: (n, k, ph) with k how much (fading in and out) and ph the beat (a whole number every beat).
  const DANCE_MOVES = [
    (n, k, ph) => {                                      // pump: the arms take turns
      const s = Math.sin(Math.PI * ph);
      arms(n, (1.3 + 1.1 * s) * k, (1.3 - 1.1 * s) * k);
      twist(n, 'chest', 0.22 * s * k); twist(n, 'hips', -0.28 * s * k); bow(n, 'head', 0.07 * Math.sin(2 * Math.PI * ph) * k);
    },
    (n, k, ph) => {                                      // sway: arms high, the hips swinging
      const s = Math.sin(Math.PI * ph);
      arms(n, (2.3 + 0.25 * s) * k, (2.3 - 0.25 * s) * k);
      twist(n, 'hips', 0.4 * s * k); twist(n, 'chest', -0.25 * s * k);
    },
    (n, k, ph) => {                                      // disco: one arm up at a time
      const s = Math.sin(Math.PI * ph);
      arms(n, (1.1 + 1.5 * Math.max(0, s)) * k, (1.1 + 1.5 * Math.max(0, -s)) * k);
      twist(n, 'hips', 0.3 * s * k); bow(n, 'chest', 0.1 * Math.abs(s) * k);
    },
  ];

  // ── Bones on top of the clip ────────────────────────────────────────────
  // Turn a bone about an axis in the world (so it does not matter how the rig's bones are oriented).
  const qp = new T.Quaternion(), qr = new T.Quaternion(), qi = new T.Quaternion(), axis = new T.Vector3();
  function turnBone(b, ax, angle) {
    if (!b || !angle) return;
    b.parent.getWorldQuaternion(qp);
    qr.setFromAxisAngle(ax, angle);
    b.quaternion.premultiply(qi.copy(qp).invert().multiply(qr).multiply(qp));   // qr in the world is qp^-1 qr qp in the parent's frame
  }
  function bow(n, bone, angle) {                     // forward, about the friend's own left-right axis
    const h = n.pivot.rotation.y;
    turnBone(n.bones[bone], axis.set(Math.cos(h), 0, -Math.sin(h)), angle);
  }
  function twist(n, bone, angle) { turnBone(n.bones[bone], axis.set(0, 1, 0), angle); }
  // Both arms up (sideways, then overhead) by these angles, about the friend's forward direction: 0 hangs, 1.57 is out, 3 is up.
  function arms(n, left, right) {
    const h = n.pivot.rotation.y;
    turnBone(n.bones.upperarml, axis.set(Math.sin(h), 0, Math.cos(h)), left);
    turnBone(n.bones.upperarmr, axis.set(Math.sin(h), 0, Math.cos(h)), -right);
  }

  function pose(n) {
    const P = n.perf, I = P && INTERACTIONS[P.kind];
    if (!I || !I.pose) return;
    const k = Math.max(0, Math.min(1, P.t / 0.25, (P.dur - P.t) / 0.25));
    I.pose(n, k, P.t);
  }

  // ── Performing ───────────────────────────────────────────────────────────
  // `opts.join`: they join in what the other does (no turn of their own, no sound); `opts.dur` how long.
  function perform(n, kind, why, opts = {}) {
    stop(n);
    n.perf = { kind, t: 0, dur: 1, joined: !!opts.join };
    n.lastKind = kind;
    INTERACTIONS[kind].start(n);
    if (opts.dur) n.perf.dur = opts.dur;
    F.note(n, kind, n.meet ? label(other(n.meet, n)) : null, why);
  }
  function stop(n) {
    const P = n.perf;
    if (!P) return;
    n.perf = null;
    const I = INTERACTIONS[P.kind];
    if (I.end) I.end(n);
  }
  // Runs the performance; true when it is over.
  function runPerf(n, dt) {
    const P = n.perf;
    P.t += dt;
    const I = INTERACTIONS[P.kind];
    if (I.update) I.update(n, dt);
    if (P.t < P.dur) return false;
    stop(n);
    return true;
  }

  // The odds of every next reaction: [[kind, weight], ...] (the `leave` of a follow-up included when `canLeave`). `avoid`: not that one (a
  // tap wants something new). `prev`: what was just done (RESPONSES). Reactions with weight 0 are left out.
  function weigh(canLeave, avoid, prev) {
    const R = RESPONSES[prev] || {};
    const opts = Object.keys(INTERACTIONS).filter(k => k !== avoid && INTERACTIONS[k].weight > 0).map(k => [k, INTERACTIONS[k].weight * (R[k] === undefined ? 1 : R[k])]);
    if (canLeave) opts.push(['leave', LEAVE.weight * (R.leave === undefined ? 1 : R.leave)]);
    return opts;
  }
  // An interaction at random (weights), or 'leave' when `canLeave`.
  function choose(canLeave, avoid, prev) {
    const force = F.force || {};
    if (canLeave && force.follow) return force.follow;
    if (!canLeave && force.pick) return force.pick;
    const opts = weigh(canLeave, avoid, prev);
    let r = rnd() * opts.reduce((s, o) => s + o[1], 0);
    for (const [k, w] of opts) { r -= w; if (r <= 0) return k; }
    return opts[0][0];
  }

  // ── Meetings ─────────────────────────────────────────────────────────────
  // A meeting E: { a, b (a friend or HER), withHer, speaker (whose turn), phase 'notice' | 'act', t, next, turns, tapped }.
  const MEET = { weight: 0, update: step };

  function begin(a, b, opts = {}) {
    const withHer = b === HER;
    const E = { a, b, withHer, speaker: withHer || rnd() < 0.5 ? a : b, phase: 'notice', next: null, turns: 0, tapped: !!opts.tapped };
    E.t = (F.force && F.force.notice !== undefined) ? F.force.notice : between(withHer ? NOTICE : BEAT);
    for (const m of [a, b]) {
      if (m === HER) continue;
      m.meet = E; m.action = MEET; m.route = null; m.off = null; m.jump = null; m.clip = null;
    }
    F.note(a, 'meet', label(b));
    return E;
  }

  function end(E) {
    for (const m of [E.a, E.b]) {
      if (m === HER || m.meet !== E) continue;
      stop(m);
      m.meet = null;
      if (m.action === MEET) m.action = null;            // back to their own brain (npcs.js)
      cool(m, other(E, m));
    }
  }

  // Turn round and walk off: away from whom they met, give or take 70 degrees.
  function leave(n, E) {
    const o = posOf(other(E, n)), p = n.group.position;
    const away = Math.atan2(p.x - o.x, p.z - o.z) + (rnd() * 2 - 1) * 1.2;
    const force = F.force || {};
    const afraid = n.lastKind === 'fright';               // scared: runs off, a good way
    const dist = force.dist !== undefined ? force.dist : afraid ? 2.5 + rnd() * 3.5 : rnd() < LEAVE.none ? 0 : rnd() * LEAVE.far;
    F.note(n, 'leave', label(other(E, n)), dist.toFixed(1));
    end(E);
    F.walkOff(n, away, dist, afraid);
  }

  // A friend's part in a meeting, every frame (their action while they meet). Always false: a meeting ends with end() or leave().
  function step(n, dt) {
    const E = n.meet;
    if (!E) return true;
    const o = other(E, n), op = posOf(o), p = n.group.position;
    if (!(n.perf && n.perf.own)) n.want = Math.atan2(op.x - p.x, op.z - p.z);     // they look at each other (a twirl turns on its own)
    if (n.perf) {
      const joined = n.perf.joined;
      if (!runPerf(n, dt)) return false;
      if (!joined) afterTurn(E, n);                           // (somebody who joined in leaves the turns to the one they joined)
      return false;
    }
    if (E.speaker !== n) return false;                      // listening
    if (E.phase === 'notice' && E.withHer && E.turns === 0 && !E.tapped && herTurnedAway(n)) {
      E.phase = 'act';
      perform(n, 'cry', 'ignored');                          // she turned away before they did anything
      return false;
    }
    E.t -= dt;
    if (E.t > 0) return false;
    E.phase = 'act';
    const kind = E.next || choose(false);
    E.next = null;
    if (kind === 'leave') leave(n, E); else perform(n, kind);
    return false;
  }

  function afterTurn(E, n) {
    E.turns++;
    if (E.withHer) {
      if (E.turns >= 2 || Math.hypot(posOf(HER).x - n.group.position.x, posOf(HER).z - n.group.position.z) > LOST) { end(E); return; }
    } else {
      E.speaker = other(E, n);                              // the other one's turn to respond
    }
    E.phase = 'notice';
    E.t = between(BEAT);
    // answers what was just done (the one who was scared is already doing "fright": their answer is to that)
    E.next = !E.withHer && E.turns >= MAX_TURNS ? 'leave' : choose(true, undefined, !E.withHer && n.lastKind === 'scare' ? 'fright' : n.lastKind);
  }

  function herTurnedAway(n) {
    const h = parts.hero.group.position, p = n.group.position;
    const dx = p.x - h.x, dz = p.z - h.z, d = Math.hypot(dx, dz);
    if (d > LOST) return true;
    const a = headingOf(HER);
    return (Math.sin(a) * dx + Math.cos(a) * dz) / (d || 1) < TURNED_AWAY;
  }

  // Do a and b look at each other, close enough?
  function facing(a, b) {
    const pa = posOf(a), pb = posOf(b);
    const dx = pb.x - pa.x, dz = pb.z - pa.z, d = Math.hypot(dx, dz);
    if (d < NEAR || d > FAR) return false;
    const ha = headingOf(a), hb = headingOf(b);
    return (Math.sin(ha) * dx + Math.cos(ha) * dz) / d > FACING && -(Math.sin(hb) * dx + Math.cos(hb) * dz) / d > FACING;
  }

  function cool(n, whom) { (n.cool || (n.cool = new Map())).set(whom, AGAIN); }
  const cooling = (n, whom) => n.cool && n.cool.has(whom);
  // Free to meet someone: not meeting, walking off, stepping aside, jumping or just popping in.
  const free = n => !n.meet && n.pop >= 1 && !n.jump && n.action !== F.WALK_OFF && n.meeting !== 'step' && n.bumpWait <= 0;

  // Every frame (from npcs.js, before the friends' brains): who starts meeting whom.
  let beatClock = 0;
  function update(active, dt) {
    beatClock += dt;
    for (const n of active) {
      if (!n.cool) continue;
      for (const [k, v] of n.cool) { if (v - dt <= 0) n.cool.delete(k); else n.cool.set(k, v - dt); }
    }
    const heroFree = parts.hero.model && !parts.hero.state.jump;
    for (const n of active) {
      if (heroFree && free(n) && !cooling(n, HER) && facing(n, HER)) begin(n, HER);
    }
    for (let i = 0; i < active.length; i++) {
      for (let j = i + 1; j < active.length; j++) {
        const a = active[i], b = active[j];
        if (free(a) && free(b) && !cooling(a, b) && facing(a, b)) begin(a, b);
      }
    }
    // she looks at the nearest friend she is meeting (world.js), not at the camera
    let near = null, best = Infinity;
    const h = parts.hero.group.position;
    for (const n of active) {
      if (!n.meet || !n.meet.withHer) continue;
      const d = Math.hypot(n.group.position.x - h.x, n.group.position.z - h.z);
      if (d < best) { best = d; near = n; }
    }
    WORLD.heroLook = near ? near.group.position : null;
  }

  // Bumped (npcs.js): whatever meeting they were in is over.
  function part(n) {
    if (n.meet) end(n.meet);
    stop(n);
    WORLD_VOICES.hush(n);                                 // what they were saying stops
  }

  // A tap on a friend: they turn to her and do something (not the same as last time).
  function tap(n) {
    if (n.meet && !n.meet.withHer) end(n.meet);
    stop(n);
    WORLD_VOICES.hush(n);
    const E = n.meet || begin(n, HER, { tapped: true });
    E.tapped = true; E.turns = 0; E.speaker = n; E.phase = 'act'; E.next = null;
    n.action = MEET; n.off = null; n.route = null; n.jump = null; n.hop = 0;
    perform(n, choose(false, n.lastKind), 'tap');
  }

  const near = new T.Vector3(), foot = new T.Vector3(), top = new T.Vector3();
  function onTap(ray) {
    if (!F) return false;
    let hit = null, best = Infinity;
    for (const n of F.list) {
      if (!n.active || !n.ready || !n.group.visible) continue;
      const p = n.group.position;
      foot.set(p.x, p.y + 0.2, p.z); top.set(p.x, p.y + 1.9, p.z);
      if (ray.distanceSqToSegment(foot, top, near) > TAP_REACH * TAP_REACH) continue;
      const along = near.distanceTo(ray.origin);
      if (along < best) { best = along; hit = n; }
    }
    if (!hit) return false;
    tap(hit);
    return true;
  }

  WORLD.onBuilt.push(p => {
    parts = p;
    F = WORLD.friends;
    WORLD.onTap.push(onTap);
  });
  WORLD.onOpen.push(async () => { WORLD.heroLook = null; });

  window.WORLD_SOCIAL = { update, part, pose, tap, weigh, perform, stop, INTERACTIONS, RESPONSES, MEET, HER, NEAR, FAR };
})();
