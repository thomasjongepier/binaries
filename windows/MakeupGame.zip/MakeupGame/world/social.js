// Friends meeting face to face (epic makeupgame-oq2, N8). Two characters meet when they are NEAR to FAR apart and
// each looks at the other (within FACING). It works between her and a friend, and between two friends.
//
//   with her:      the friend notices her, stands and looks at her for a moment (NOTICE), then does one of the
//                  INTERACTIONS (wave, say hi, cry, fart), then one follow-up: another interaction, or LEAVE (turns
//                  round and walks off in a random direction, 0 to LEAVE.far units). If she turns away (or walks off)
//                  before the friend did anything, the friend cries.
//   two friends:   they take turns: one starts, the other responds (an interaction, or LEAVE), and so on, at most
//                  MAX_TURNS, then one walks off.
//   a tap:         tapping a friend makes them turn to her and react again, whatever they were doing.
//
// After a meeting the same two do not meet again for AGAIN seconds. A bump (npcs.js) ends a meeting. To add an
// interaction, add an entry to INTERACTIONS: `start(n)` sets `n.perf.dur`, optional `update(n, dt)`, `pose(n, k)`
// (bones, on top of the clip; k fades it in and out) and `end(n)`. The effects are fx.js, the sounds voices.js.
(() => {
  'use strict';
  const T = window.THREE;
  const NEAR = 1.2, FAR = 3.0;                       // face to face: this far apart (world units; she is 2.1 tall)...
  const FACING = Math.cos((45 * Math.PI) / 180);     // ...each looking at the other within 45 degrees
  const TURNED_AWAY = Math.cos((100 * Math.PI) / 180);   // she looks more than this far away from the friend: she turned away
  const LOST = 4.5;                                  // she is this far off: she walked away
  const NOTICE = [0.5, 2.5];                         // seconds a friend looks at her before doing something
  const BEAT = [0.3, 0.9];                           // seconds between two turns
  const AGAIN = 5;                                   // seconds before the same two can meet again
  const MAX_TURNS = 4;                               // two friends: turns before one of them walks off anyway
  const LEAVE = { weight: 2.5, far: 6, none: 0.25 }; // the follow-up "walks away": up to `far` units, 0 (only turns round) `none` of the time
  const TAP_REACH = 0.55;                            // a tap this close to a friend's middle (a line from feet to head) is a tap on them

  const HER = { her: true };
  let F = null, parts = null;
  const rnd = Math.random;
  const between = ([a, b]) => a + rnd() * (b - a);
  const posOf = x => (x === HER ? parts.hero.group.position : x.group.position);
  const headingOf = x => (x === HER ? parts.hero.pivot.rotation.y : x.pivot.rotation.y);
  const label = x => (x === HER ? 'her' : F.list.indexOf(x));
  const other = (E, n) => (E.a === n ? E.b : E.a);

  // ── What a friend can do ─────────────────────────────────────────────────
  const INTERACTIONS = {
    wave: {
      weight: 3,
      start(n) {
        const a = n.c.actions.Waving;
        a.reset();                                       // a wave after a wave starts again
        n.clip = 'Waving';
        n.perf.dur = a.getClip().duration;
      },
      end(n) { n.clip = null; },
    },
    hi: {
      weight: 3,
      start(n) {
        n.perf.dur = 1.5;
        const word = WORLD_VOICES.word();
        WORLD_FX.bubble(n, word);
        WORLD_VOICES.play('hi', n);
      },
      pose(n, k, t) { bow(n, 'head', 0.22 * Math.pow(Math.sin(Math.PI * Math.min(1, t / 0.7) * 2), 2) * k); },   // two little nods
    },
    cry: {
      weight: 1.5,
      start(n) {
        n.perf.dur = 3;
        n.c.setSad(true);
        WORLD_FX.tears(n, 2.8);
        WORLD_VOICES.play('cry', n);
      },
      pose(n, k, t) {                                    // head down, shoulders shaking with the sobs
        bow(n, 'chest', (0.14 + 0.06 * Math.abs(Math.sin(t * 7))) * k);
        bow(n, 'head', (0.32 + 0.08 * Math.sin(t * 14)) * k);
        twist(n, 'chest', 0.06 * Math.sin(t * 9) * k);
      },
      end(n) { n.c.setSad(false); },
    },
    fart: {
      weight: 2,
      start(n) {
        n.perf.dur = 1.8;
        WORLD_FX.puff(n);
        WORLD_VOICES.play('fart', n);
      },
      update(n) {                                        // a little hop as it comes out
        const t = n.perf.t;
        n.hop = t < 0.32 ? 0.13 * Math.sin((Math.PI * t) / 0.32) : 0;
      },
      pose(n, k, t) {                                    // leans forward and wiggles
        if (t > 0.9) return;
        bow(n, 'chest', 0.16 * Math.sin((Math.PI * t) / 0.9));
        twist(n, 'hips', 0.14 * Math.sin(t * 24) * (1 - t / 0.9));
      },
      end(n) { n.hop = 0; },
    },
  };

  // ── Bones on top of the clip ────────────────────────────────────────────
  // Turn a bone about an axis in the world (so it does not matter how the rig's bones are oriented).
  const qp = new T.Quaternion(), qr = new T.Quaternion(), qi = new T.Quaternion(), axis = new T.Vector3();
  function turnBone(b, ax, angle) {
    if (!b || !angle) return;
    b.parent.getWorldQuaternion(qp);
    qr.setFromAxisAngle(ax, angle);
    b.quaternion.premultiply(qi.copy(qp).invert().multiply(qr).multiply(qp));   // qr in the world is qp^-1 qr qp in the parent's frame
  }
  function bow(n, bone, angle) {                     // forward, about the friend's own left-right axis
    const h = n.pivot.rotation.y;
    turnBone(n.bones[bone], axis.set(Math.cos(h), 0, -Math.sin(h)), angle);
  }
  function twist(n, bone, angle) { turnBone(n.bones[bone], axis.set(0, 1, 0), angle); }

  function pose(n) {
    const P = n.perf, I = P && INTERACTIONS[P.kind];
    if (!I || !I.pose) return;
    const k = Math.max(0, Math.min(1, P.t / 0.25, (P.dur - P.t) / 0.25));
    I.pose(n, k, P.t);
  }

  // ── Performing ───────────────────────────────────────────────────────────
  function perform(n, kind, why) {
    stop(n);
    n.perf = { kind, t: 0, dur: 1 };
    n.lastKind = kind;
    INTERACTIONS[kind].start(n);
    F.note(n, kind, n.meet ? label(other(n.meet, n)) : null, why);
  }
  function stop(n) {
    const P = n.perf;
    if (!P) return;
    n.perf = null;
    const I = INTERACTIONS[P.kind];
    if (I.end) I.end(n);
  }
  // Runs the performance; true when it is over.
  function runPerf(n, dt) {
    const P = n.perf;
    P.t += dt;
    const I = INTERACTIONS[P.kind];
    if (I.update) I.update(n, dt);
    if (P.t < P.dur) return false;
    stop(n);
    return true;
  }

  // An interaction at random (weights), or 'leave' when `canLeave`. `avoid`: not that one (a tap wants something new).
  function choose(canLeave, avoid) {
    const force = F.force || {};
    if (canLeave && force.follow) return force.follow;
    if (!canLeave && force.pick) return force.pick;
    const opts = Object.keys(INTERACTIONS).filter(k => k !== avoid).map(k => [k, INTERACTIONS[k].weight]);
    if (canLeave) opts.push(['leave', LEAVE.weight]);
    let r = rnd() * opts.reduce((s, o) => s + o[1], 0);
    for (const [k, w] of opts) { r -= w; if (r <= 0) return k; }
    return opts[0][0];
  }

  // ── Meetings ─────────────────────────────────────────────────────────────
  // A meeting E: { a, b (a friend or HER), withHer, speaker (whose turn), phase 'notice' | 'act', t, next, turns, tapped }.
  const MEET = { weight: 0, update: step };

  function begin(a, b, opts = {}) {
    const withHer = b === HER;
    const E = { a, b, withHer, speaker: withHer || rnd() < 0.5 ? a : b, phase: 'notice', next: null, turns: 0, tapped: !!opts.tapped };
    E.t = (F.force && F.force.notice !== undefined) ? F.force.notice : between(withHer ? NOTICE : BEAT);
    for (const m of [a, b]) {
      if (m === HER) continue;
      m.meet = E; m.action = MEET; m.route = null; m.off = null; m.jump = null; m.clip = null;
    }
    F.note(a, 'meet', label(b));
    return E;
  }

  function end(E) {
    for (const m of [E.a, E.b]) {
      if (m === HER || m.meet !== E) continue;
      stop(m);
      m.meet = null;
      if (m.action === MEET) m.action = null;            // back to their own brain (npcs.js)
      cool(m, other(E, m));
    }
  }

  // Turn round and walk off: away from whom they met, give or take 70 degrees.
  function leave(n, E) {
    const o = posOf(other(E, n)), p = n.group.position;
    const away = Math.atan2(p.x - o.x, p.z - o.z) + (rnd() * 2 - 1) * 1.2;
    const force = F.force || {};
    const dist = force.dist !== undefined ? force.dist : rnd() < LEAVE.none ? 0 : rnd() * LEAVE.far;
    F.note(n, 'leave', label(other(E, n)), dist.toFixed(1));
    end(E);
    F.walkOff(n, away, dist);
  }

  // A friend's part in a meeting, every frame (their action while they meet). Always false: a meeting ends with end() or leave().
  function step(n, dt) {
    const E = n.meet;
    if (!E) return true;
    const o = other(E, n), op = posOf(o), p = n.group.position;
    n.want = Math.atan2(op.x - p.x, op.z - p.z);           // they look at each other
    if (n.perf) {
      if (!runPerf(n, dt)) return false;
      afterTurn(E, n);
      return false;
    }
    if (E.speaker !== n) return false;                      // listening
    if (E.phase === 'notice' && E.withHer && E.turns === 0 && !E.tapped && herTurnedAway(n)) {
      E.phase = 'act';
      perform(n, 'cry', 'ignored');                          // she turned away before they did anything
      return false;
    }
    E.t -= dt;
    if (E.t > 0) return false;
    E.phase = 'act';
    const kind = E.next || choose(false);
    E.next = null;
    if (kind === 'leave') leave(n, E); else perform(n, kind);
    return false;
  }

  function afterTurn(E, n) {
    E.turns++;
    if (E.withHer) {
      if (E.turns >= 2 || Math.hypot(posOf(HER).x - n.group.position.x, posOf(HER).z - n.group.position.z) > LOST) { end(E); return; }
    } else {
      E.speaker = other(E, n);                              // the other one's turn to respond
    }
    E.phase = 'notice';
    E.t = between(BEAT);
    E.next = !E.withHer && E.turns >= MAX_TURNS ? 'leave' : choose(true);
  }

  function herTurnedAway(n) {
    const h = parts.hero.group.position, p = n.group.position;
    const dx = p.x - h.x, dz = p.z - h.z, d = Math.hypot(dx, dz);
    if (d > LOST) return true;
    const a = headingOf(HER);
    return (Math.sin(a) * dx + Math.cos(a) * dz) / (d || 1) < TURNED_AWAY;
  }

  // Do a and b look at each other, close enough?
  function facing(a, b) {
    const pa = posOf(a), pb = posOf(b);
    const dx = pb.x - pa.x, dz = pb.z - pa.z, d = Math.hypot(dx, dz);
    if (d < NEAR || d > FAR) return false;
    const ha = headingOf(a), hb = headingOf(b);
    return (Math.sin(ha) * dx + Math.cos(ha) * dz) / d > FACING && -(Math.sin(hb) * dx + Math.cos(hb) * dz) / d > FACING;
  }

  function cool(n, whom) { (n.cool || (n.cool = new Map())).set(whom, AGAIN); }
  const cooling = (n, whom) => n.cool && n.cool.has(whom);
  // Free to meet someone: not meeting, walking off, stepping aside, jumping or just popping in.
  const free = n => !n.meet && n.pop >= 1 && !n.jump && n.action !== F.WALK_OFF && n.meeting !== 'step' && n.bumpWait <= 0;

  // Every frame (from npcs.js, before the friends' brains): who starts meeting whom.
  function update(active, dt) {
    for (const n of active) {
      if (!n.cool) continue;
      for (const [k, v] of n.cool) { if (v - dt <= 0) n.cool.delete(k); else n.cool.set(k, v - dt); }
    }
    const heroFree = parts.hero.model && !parts.hero.state.jump;
    for (const n of active) {
      if (heroFree && free(n) && !cooling(n, HER) && facing(n, HER)) begin(n, HER);
    }
    for (let i = 0; i < active.length; i++) {
      for (let j = i + 1; j < active.length; j++) {
        const a = active[i], b = active[j];
        if (free(a) && free(b) && !cooling(a, b) && facing(a, b)) begin(a, b);
      }
    }
    // she looks at the nearest friend she is meeting (world.js), not at the camera
    let near = null, best = Infinity;
    const h = parts.hero.group.position;
    for (const n of active) {
      if (!n.meet || !n.meet.withHer) continue;
      const d = Math.hypot(n.group.position.x - h.x, n.group.position.z - h.z);
      if (d < best) { best = d; near = n; }
    }
    WORLD.heroLook = near ? near.group.position : null;
  }

  // Bumped (npcs.js): whatever meeting they were in is over.
  function part(n) {
    if (n.meet) end(n.meet);
    stop(n);
  }

  // A tap on a friend: they turn to her and do something (not the same as last time).
  function tap(n) {
    if (n.meet && !n.meet.withHer) end(n.meet);
    stop(n);
    const E = n.meet || begin(n, HER, { tapped: true });
    E.tapped = true; E.turns = 0; E.speaker = n; E.phase = 'act'; E.next = null;
    n.action = MEET; n.off = null; n.route = null; n.jump = null; n.hop = 0;
    perform(n, choose(false, n.lastKind), 'tap');
  }

  const near = new T.Vector3(), foot = new T.Vector3(), top = new T.Vector3();
  function onTap(ray) {
    if (!F) return false;
    let hit = null, best = Infinity;
    for (const n of F.list) {
      if (!n.active || !n.ready || !n.group.visible) continue;
      const p = n.group.position;
      foot.set(p.x, p.y + 0.2, p.z); top.set(p.x, p.y + 1.9, p.z);
      if (ray.distanceSqToSegment(foot, top, near) > TAP_REACH * TAP_REACH) continue;
      const along = near.distanceTo(ray.origin);
      if (along < best) { best = along; hit = n; }
    }
    if (!hit) return false;
    tap(hit);
    return true;
  }

  WORLD.onBuilt.push(p => {
    parts = p;
    F = WORLD.friends;
    WORLD.onTap.push(onTap);
  });
  WORLD.onOpen.push(async () => { WORLD.heroLook = null; });

  window.WORLD_SOCIAL = { update, part, pose, tap, INTERACTIONS, MEET, HER, NEAR, FAR };
})();
