// One thing to do in each room (makeupgame-hfl.6): lie in the bed, sit on the sofa and watch TV, cook on the stove, take a shower.
//
// Any item inside a house (world/interior.js) that carries a `use` tag is a spot, and ROOM_ACTIONS below says what that tag means:
// adding an action is adding an entry (see world/README.md). She starts one by walking into the item (pressing against it
// for a moment) or by a left tap on it from within reach; a tap from further away is an ordinary walk-to tap. While it runs she does
// not walk: any walk input (a key, a tap, a drag) ends it, and she steps out to a free spot beside the item, the one in the
// direction she asked to go. Only she does these (friends stay outside). Leaving the house, closing the world or opening it again
// ends it on the spot with her put back where she stood.
//
// One entry of ROOM_ACTIONS (all optional but `seat` and `clips`):
//   reach    how near she must be (to the item's edge) for a tap on it to start the action
//   seat     fn(spot) -> { x, z, y, face }  where her feet go, in the item's own frame (x right, z toward its front, rotated with it),
//            the height of the model above the floor (a mattress, a cushion), and the turn from the item's front (PI: facing it).
//            Use `scaled(spot, {...})`: x, z and y are for an item at the usual size and grow or shrink with the item's `s`
//   clips    { in, speed, loop }  the clip played once on the way in (at `speed`), then the clip that loops
//   glide    seconds she takes to move onto the seat (default 0.5)
//   seconds  the action ends by itself after this long (the shower); omitted: it goes on until she walks off
//   start(run)   props and effects (run.props, run.alive(), run.sound(...)); stop(run) as she steps out; update(run, dt) every frame
//   unwind(run)  called when everything is over: remove what start() added (run.props are removed for you)
// `run` is { spot, item, action, place, phase 'in' | 'on' | 'out', t (seconds since the action began), props, ... }.
//
//   WORLD_ROOMS.ACTIONS     the table
//   WORLD_ROOMS.active      the run in progress, or null
//   WORLD_ROOMS.using()     the item she is using (the dollhouse camera leaves it as it is), or null
//   WORLD_ROOMS.spots(place) the spots in a place
//   WORLD_ROOMS.log         { use, how: 'walk' | 'tap', ended: 'walk' | 'done' | 'abort' | null, sounds: [...] } per action
// Classic script (no modules).
(function () {
  const T = window.THREE;
  const PI = Math.PI;
  const R = () => WORLD.HERO_RADIUS;
  const PUSH_FOR = 0.12;           // seconds of pressing into an item before it starts
  const OUT = 0.3;                 // seconds she takes to step out to the free spot
  const clamp01 = x => Math.max(0, Math.min(1, x));
  const smooth = x => { x = clamp01(x); return x * x * (3 - 2 * x); };
  const rnd = (a, b) => a + Math.random() * (b - a);

  // ── Sounds: made with Web Audio (no recordings; works from file://) ──────────────────────────────────────────────
  // Loops: a buffer of noise shaped on the spot (sizzle: sparse crackles over a hiss; shower: a broad rushing), through filters, with a
  // fade in and out. The TV plays small random notes of a pentatonic scale. Silent when muted (game.js sound.muted) or in the screenshot tools.
  let ctx = null, master = null;
  const sounds = [];
  const quiet = () => (typeof sound !== 'undefined' && sound.muted) || !!window.__STILL;
  function audio() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 0.5; master.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume().catch(() => { /* before the first tap: stays silent */ });
    return ctx;
  }
  function loopBuffer(a, fill) {
    const n = a.sampleRate * 2, buf = a.createBuffer(1, n, a.sampleRate);
    fill(buf.getChannelData(0), a.sampleRate);
    return buf;
  }
  const SOUNDS = {
    // a pan: crackling bursts (about 30 a second) over a faint hiss
    sizzle(a, out) {
      const buf = loopBuffer(a, (d, sr) => {
        let left = 0, len = 1;
        for (let i = 0; i < d.length; i++) {
          if (Math.random() < 30 / sr) { len = Math.floor(sr * rnd(0.003, 0.016)); left = len; }
          const amp = left > 0 ? 0.25 + 0.75 * (left-- / len) : 0;
          d[i] = (Math.random() * 2 - 1) * (0.035 + 0.9 * amp * amp);
        }
      });
      const src = a.createBufferSource(), hp = a.createBiquadFilter(), g = a.createGain();
      src.buffer = buf; src.loop = true; hp.type = 'highpass'; hp.frequency.value = 1800; g.gain.value = 0.7;
      src.connect(hp).connect(g).connect(out); src.start();
      return () => { try { src.stop(a.currentTime + 0.05); } catch (e) { /* stopped */ } };
    },
    // water on tiles: broad rushing noise, a little lower and softer at the edges
    water(a, out) {
      const buf = loopBuffer(a, d => { for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; });
      const src = a.createBufferSource(), bp = a.createBiquadFilter(), lp = a.createBiquadFilter(), g = a.createGain();
      src.buffer = buf; src.loop = true; bp.type = 'bandpass'; bp.frequency.value = 3200; bp.Q.value = 0.35; lp.type = 'lowpass'; lp.frequency.value = 7500; g.gain.value = 0.8;
      src.connect(bp).connect(lp).connect(g).connect(out); src.start();
      return () => { try { src.stop(a.currentTime + 0.05); } catch (e) { /* stopped */ } };
    },
    // the television: small soft notes at random, a cartoon tune that never ends
    tv(a, out) {
      const scale = [0, 2, 4, 7, 9, 12, 14], root = 262;
      let step = 3;
      const note = () => {
        step = Math.max(0, Math.min(scale.length - 1, step + Math.floor(Math.random() * 5) - 2));
        const t = a.currentTime + 0.02, osc = a.createOscillator(), g = a.createGain();
        osc.type = 'triangle'; osc.frequency.value = root * Math.pow(2, scale[step] / 12);
        g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.5, t + 0.02); g.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
        osc.connect(g).connect(out); osc.start(t); osc.stop(t + 0.4);
      };
      const timer = setInterval(() => { if (Math.random() < 0.8) note(); }, 280);
      return () => clearInterval(timer);
    },
  };
  // Start a sound for the run: fades in, and fades out when the run stops it. Returns its log entry.
  function startSound(run, kind, volume = 0.5) {
    const entry = { kind, heard: false };
    run.log.sounds.push(entry);
    if (quiet() || !SOUNDS[kind]) return entry;
    const a = audio();
    if (!a) return entry;
    const out = a.createGain(), t = a.currentTime;
    out.gain.setValueAtTime(0, t); out.gain.linearRampToValueAtTime(volume, t + 0.4); out.connect(master);
    const stop = SOUNDS[kind](a, out);
    entry.heard = true;
    run.stops.push(() => {
      const now = a.currentTime;
      out.gain.cancelScheduledValues(now); out.gain.setValueAtTime(out.gain.value, now); out.gain.linearRampToValueAtTime(0, now + 0.35);
      setTimeout(() => { stop(); out.disconnect(); }, 450);
    });
    return entry;
  }

  // ── Props: things a room action adds to the scene ────────────────────────────────────────────────────────────────
  const world = (item, lx, lz) => {                    // a point in the item's frame -> world x, z
    const c = Math.cos(item.rot), s = Math.sin(item.rot);
    return { x: item.x + lx * c + lz * s, z: item.z - lx * s + lz * c };
  };
  const frontOf = item => ({ x: Math.sin(item.rot), z: Math.cos(item.rot) });

  // The television in the item's room: the nearest item whose model is a television. Its screen gets a picture of colour that moves.
  function findTV(spot) {
    const furniture = spot.place.scene.getObjectByName('furniture');
    let best = null, bestD = Infinity;
    for (const o of furniture ? furniture.children : []) {
      const it = o.userData.item;
      if (!it || !/^television/i.test(it.name)) continue;
      const d = Math.hypot(it.x - spot.item.x, it.z - spot.item.z) + (it.room === spot.item.room ? 0 : 100);
      if (d < bestD) { best = o; bestD = d; }
    }
    return best;
  }
  function tvScreen(run, obj) {
    const it = obj.userData.item, box = new T.Box3().setFromObject(obj), f = frontOf(it), size = box.getSize(new T.Vector3()), mid = box.getCenter(new T.Vector3());
    const wide = Math.abs(f.x) > 0.5 ? size.z : size.x, deep = Math.abs(f.x) > 0.5 ? size.x : size.z, w = wide * 0.86, h = size.y * 0.66;
    const canvas = document.createElement('canvas'); canvas.width = 128; canvas.height = 80;
    const tex = new T.CanvasTexture(canvas); tex.colorSpace = T.SRGBColorSpace;
    const mesh = new T.Mesh(new T.PlaneGeometry(w, h), new T.MeshBasicMaterial({ map: tex, toneMapped: false }));
    mesh.position.set(mid.x + f.x * (deep / 2 + 0.012), box.min.y + size.y * 0.62, mid.z + f.z * (deep / 2 + 0.012));
    mesh.rotation.y = it.rot; mesh.name = 'tv-screen';
    run.place.scene.add(mesh);
    run.props.push(mesh, tex);
    const g = canvas.getContext('2d');
    let clock = 0, drawn = -1;
    return dt => {                                                     // colourful and changing: moving bars, bouncing balls, a hue that drifts
      clock += dt;
      const frame = Math.floor(clock * 8);
      if (frame === drawn) return;
      drawn = frame;
      const t = clock, hue = (t * 40) % 360;
      for (let i = 0; i < 8; i++) { g.fillStyle = `hsl(${(hue + i * 45) % 360},85%,${52 + 8 * Math.sin(t * 2 + i)}%)`; g.fillRect(i * 16, 0, 16, 80); }
      g.fillStyle = 'rgba(255,255,255,0.18)'; g.fillRect(0, ((t * 50) % 100) - 10, 128, 12);
      for (let b = 0; b < 3; b++) {
        const x = 64 + 48 * Math.sin(t * (1.3 + b * 0.7) + b * 2), y = 40 + 26 * Math.cos(t * (1.7 + b * 0.5) + b);
        g.fillStyle = `hsl(${(hue + 180 + b * 70) % 360},95%,${75 - b * 8}%)`; g.beginPath(); g.arc(x, y, 12 + 4 * b, 0, PI * 2); g.fill();
      }
      tex.needsUpdate = true;
    };
  }

  // A frying pan with an egg, on the stove's front left burner.
  function pan(run) {
    const it = run.item, top = run.spot.footprint[2], g = new T.Group();
    const dark = new T.MeshLambertMaterial({ color: 0x2c2c32 }), metal = new T.MeshLambertMaterial({ color: 0x55555e });
    const body = new T.Mesh(new T.CylinderGeometry(0.33, 0.28, 0.1, 20), dark); body.position.y = 0.05;
    const inner = new T.Mesh(new T.CircleGeometry(0.28, 20).rotateX(-PI / 2), metal); inner.position.y = 0.102;
    const handle = new T.Mesh(new T.BoxGeometry(0.1, 0.05, 0.55), dark); handle.position.set(0, 0.07, 0.55);
    const white = new T.Mesh(new T.CircleGeometry(0.19, 16).rotateX(-PI / 2), new T.MeshLambertMaterial({ color: 0xfffdf4 })); white.position.y = 0.108;
    const yolk = new T.Mesh(new T.SphereGeometry(0.07, 12, 8).scale(1, 0.55, 1), new T.MeshLambertMaterial({ color: 0xffbf1f })); yolk.position.set(0.02, 0.12, 0);
    g.add(body, inner, handle, white, yolk);
    const at = world(it, -0.3, 0.08);
    g.position.set(at.x, top + 0.01, at.z); g.rotation.y = it.rot - 0.5;
    g.name = 'pan';
    run.place.scene.add(g);
    run.props.push(g);
    return { x: at.x, y: top + 0.15, z: at.z, g };
  }

  // The shower's frosted door: a pane in front of its glass that slides shut from the left, so she is only a shape behind it.
  function frost(run) {
    const it = run.item, w = run.spot.footprint[0] * 0.9, h = run.spot.footprint[2] * 0.86;
    const canvas = document.createElement('canvas'); canvas.width = 128; canvas.height = 256;
    const g = canvas.getContext('2d'), grad = g.createLinearGradient(0, 0, 128, 256);
    grad.addColorStop(0, 'rgba(235,248,255,0.92)'); grad.addColorStop(0.5, 'rgba(205,232,250,0.85)'); grad.addColorStop(1, 'rgba(235,248,255,0.92)');
    g.fillStyle = grad; g.fillRect(0, 0, 128, 256);
    for (let i = 0; i < 14; i++) { g.fillStyle = `rgba(255,255,255,${rnd(0.2, 0.5)})`; g.fillRect(rnd(4, 120), rnd(0, 180), rnd(1.5, 3), rnd(30, 90)); }   // streaks of water
    const tex = new T.CanvasTexture(canvas); tex.colorSpace = T.SRGBColorSpace;
    const mat = new T.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0.5, depthWrite: false, side: T.DoubleSide });
    const pane = new T.Mesh(new T.PlaneGeometry(w, h).translate(w / 2, h / 2, 0), mat);
    const holder = new T.Group(), at = world(it, -w / 2, run.spot.box.hd + 0.03);
    holder.add(pane); holder.position.set(at.x, run.spot.footprint[2] * 0.1, at.z); holder.rotation.y = it.rot; holder.scale.x = 0.001; holder.name = 'shower-frost';
    run.place.scene.add(holder);
    run.props.push(holder, tex, mat);
    return holder;
  }

  // A seat given for an item at the usual size (interior.js SCALE 3), fitted to this item's size.
  const scaled = (spot, seat) => { const k = spot.item.s / 3; return { x: (seat.x || 0) * k, z: (seat.z || 0) * k, y: (seat.y || 0) * k, face: seat.face || 0 }; };

  // ── The table ────────────────────────────────────────────────────────────────────────────────────────────────────
  // (items' `use` tags: world/interior.js)
  const ACTIONS = {
    // She lies down on the bed with her head on the pillow, under a drift of Z z z.
    bed: {
      reach: 2.4,
      seat: spot => scaled(spot, { x: 0, z: -0.5, y: 0.6, face: 0 }),
      clips: { in: 'Lie_Down', speed: 1.6, loop: 'Lie_Idle' },
      start(run) {
        const bone = WORLD.parts.hero.model.model.getObjectByName('head');
        WORLD_FX.zzz({ bones: { head: bone }, group: WORLD.parts.hero.group }, run.alive);
      },
    },
    // She sits on the sofa and the television comes on: a screen of moving colour and a bouncy little tune.
    sofa: {
      reach: 2.2,
      seat: spot => scaled(spot, { x: 0, z: 0.05, y: 0.28, face: 0 }),
      clips: { in: 'Sit_Chair_Down', speed: 1, loop: 'Sit_Chair_Idle' },
      start(run) {
        const tv = findTV(run.spot);
        run.draw = tv ? tvScreen(run, tv) : null;
        startSound(run, 'tv', 0.3);
      },
      update(run, dt) { if (run.draw) run.draw(dt); },
    },
    // She stands at the stove and cooks: an egg in a pan that sizzles and steams, her hands busy.
    stove: {
      reach: 2.4,
      seat: spot => ({ x: -0.1 * spot.box.hw, z: spot.box.hd + R() + 0.1, y: 0, face: PI }),     // in front of the stove, looking at it
      clips: { loop: 'Use_Item' },
      start(run) {
        run.pan = pan(run);
        WORLD_FX.steam((out) => out.set(run.pan.x + rnd(-0.12, 0.12), run.pan.y + 0.05, run.pan.z + rnd(-0.12, 0.12)), run.alive, { rate: 9, size: 0.45, rise: 1.1, spread: 0.3 });
        startSound(run, 'sizzle', 0.45);
      },
      update(run, dt) { run.pan.g.rotation.z = 0.012 * Math.sin(run.t * 40); },        // it shivers in its heat
    },
    // She steps in and the frosted door slides shut; water, steam and soap bubbles; after a few seconds she steps out again.
    shower: {
      reach: 2.4,
      seat: () => ({ x: 0, z: 0, y: 0, face: 0 }),                                                  // in the middle of the shower, facing out
      clips: { loop: 'Idle_B' },
      seconds: 6.5,
      glide: 0.6,
      start(run) {
        run.door = frost(run);
        const c = run.spot, mid = { x: run.item.x, z: run.item.z }, spread = Math.min(c.box.hw, c.box.hd) * 0.7;
        WORLD_FX.steam(out => out.set(mid.x + rnd(-spread, spread), rnd(1.2, 2.6), mid.z + rnd(-spread * 0.6, spread * 0.6)), run.alive, { rate: 8, size: 0.7, rise: 0.8, spread: 0.4 });
        WORLD_FX.bubbles(out => out.set(mid.x + rnd(-spread, spread), rnd(0.3, 1.8), mid.z + rnd(-spread * 0.6, spread * 0.6)), run.alive, { rate: 6, size: 0.3, rise: 1.0 });
        startSound(run, 'water', 0.4);
      },
      update(run, dt) {
        const close = run.phase === 'out' ? 1 - smooth(run.outT / OUT) : smooth((run.t - 0.2) / 0.5);          // slides shut as she settles, opens as she leaves
        run.door.scale.x = Math.max(0.001, close);
      },
    },
  };

  // ── Spots ────────────────────────────────────────────────────────────────────────────────────────────────────────
  // The items of a place that carry a tag in ACTIONS. Found again whenever the furniture changes (it arrives after the room is built).
  const spotCache = new WeakMap();
  function spots(place) {
    const furniture = place.scene.getObjectByName('furniture');
    if (!furniture) return [];
    const cached = spotCache.get(place);
    if (cached && cached.n === furniture.children.length) return cached.list;
    const list = [];
    for (const obj of furniture.children) {
      const item = obj.userData.item;
      if (!item || !item.use || !ACTIONS[item.use]) continue;
      const box = item.solid || { x: item.x, z: item.z, hw: item.footprint[0] / 2, hd: item.footprint[1] / 2, rot: item.rot };
      obj.updateMatrixWorld(true);
      list.push({ use: item.use, item, obj, place, box, footprint: item.footprint, world: new T.Box3().setFromObject(obj), action: ACTIONS[item.use] });
    }
    spotCache.set(place, { n: furniture.children.length, list });
    return list;
  }
  // Distance from (x, z) to the turned box, and the unit vector from the point toward the nearest point of the box.
  function toBox(b, x, z) {
    const c = Math.cos(b.rot), s = Math.sin(b.rot), dx = x - b.x, dz = z - b.z;
    const lx = dx * c - dz * s, lz = dx * s + dz * c;                            // the point in the box's frame
    const ox = Math.max(Math.abs(lx) - b.hw, 0), oz = Math.max(Math.abs(lz) - b.hd, 0), d = Math.hypot(ox, oz);
    if (d < 1e-6) return { dist: 0, nx: 0, nz: 0 };
    const nlx = -Math.sign(lx) * ox / d, nlz = -Math.sign(lz) * oz / d;         // toward the box, in its frame
    return { dist: d, nx: nlx * c + nlz * s, nz: -nlx * s + nlz * c };
  }

  // Is the straight way from (x, z) to the item free (no wall or furniture between: a tap through the low partition is no use)?
  function reachable(spot, x, z) {
    const d = toBox(spot.box, x, z), n = Math.max(1, Math.ceil(d.dist / 0.15));
    for (let i = 0; i <= n; i++) {
      const sx = x + d.nx * d.dist * i / n, sz = z + d.nz * d.dist * i / n;
      if (toBox(spot.box, sx, sz).dist < R()) break;                       // (close enough to touch it)
      if (!WORLD.canStand(sx, sz)) return false;
    }
    return true;
  }

  // ── Running an action ────────────────────────────────────────────────────────────────────────────────────────────
  let run = null, cooling = false, pushing = null, pushT = 0;
  const log = [];
  const heroNow = () => WORLD.parts.hero;
  const turned = (from, to, k) => { let d = to - from; d = Math.atan2(Math.sin(d), Math.cos(d)); return from + d * k; };

  function start(spot, how, dir) {
    const H = heroNow(), p = H.group.position, c = H.model, act = spot.action, seat = act.seat(spot);
    const at = world(spot.item, seat.x, seat.z);
    const entry = { log: { use: spot.use, how, ended: null, sounds: [] } };
    log.push(entry.log);
    run = {
      spot, item: spot.item, action: act, place: spot.place, phase: 'in', t: 0, outT: 0, props: [], stops: [], log: entry.log,
      from: { x: p.x, z: p.z, yaw: H.pivot.rotation.y, dy: 0 },
      seat: { x: at.x, z: at.z, yaw: spot.item.rot + seat.face, dy: seat.y },
      base: { y: c.model.position.y, contact: H.contact ? H.contact.visible : true, shadow: H.shadow.visible },
      entryDir: dir || null, released: !dir, exit: null, alive: () => !!run && run.phase !== 'out' && !run.dead, dead: false,
    };
    const r = run;
    r.alive = () => run === r && r.phase !== 'out';
    H.state.hold = { animate };
    H.state.jump = null;
    if (H.contact) H.contact.visible = false;
    H.shadow.visible = false;
    walkReset();
    const cl = act.clips;
    if (cl.in) { const a = c.actions[cl.in]; a.setLoop(T.LoopOnce, 1); a.clampWhenFinished = true; c.play(cl.in, 0.15); a.timeScale = cl.speed || 1; r.inClip = a; }
    else c.play(cl.loop, 0.2);
    if (act.start) act.start(r);
    return r;
  }
  function walkReset() { pushT = 0; pushing = null; }

  // Where she steps out to: a free spot beside the item, in the direction she wants to go, else on its front side.
  function pickExit(r, dir) {
    const b = r.spot.box, m = R() + 0.15, cos = Math.cos(b.rot), sin = Math.sin(b.rot);
    const toWorld = (lx, lz) => ({ x: b.x + lx * cos + lz * sin, z: b.z - lx * sin + lz * cos });
    let best = null;
    for (const [nx, nz] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) {
      for (let t = -1; t <= 1.001; t += 0.25) {
        const lx = nx ? nx * (b.hw + m) : t * b.hw, lz = nz ? nz * (b.hd + m) : t * b.hd, w = toWorld(lx, lz);
        if (!WORLD.canStand(w.x, w.z)) continue;
        const len = Math.hypot(w.x - b.x, w.z - b.z) || 1, front = nx === 0 && nz === 1;
        const score = (dir ? ((w.x - b.x) / len) * dir.x + ((w.z - b.z) / len) * dir.z : 0) + (front ? 0.3 : 0) - 0.15 * Math.abs(t) - 0.05 * Math.hypot(w.x - r.from.x, w.z - r.from.z);
        if (!best || score > best.score) best = { x: w.x, z: w.z, score };
      }
    }
    return best || { x: r.from.x, z: r.from.z };
  }

  // She steps out (phase 'out': a short glide), effects stop.
  function end(why, dir) {
    if (!run || run.phase === 'out') return;
    const r = run;
    r.log.ended = why;
    r.exit = pickExit(r, dir);
    r.exit.yaw = dir ? Math.atan2(dir.x, dir.z) : Math.atan2(r.exit.x - r.item.x, r.exit.z - r.item.z);
    r.phase = 'out'; r.outT = 0;
    r.at = { x: heroNow().group.position.x, z: heroNow().group.position.z, yaw: heroNow().pivot.rotation.y, dy: r.dyNow || 0 };
    for (const stop of r.stops.splice(0)) stop();
    if (r.action.stop) r.action.stop(r);
    const c = heroNow().model;
    c.play('Idle_A', 0.2);
    cooling = true;
  }
  // Everything over: she is hers again, props gone.
  function finish(r) {
    const H = heroNow(), c = H.model;
    for (const stop of r.stops.splice(0)) stop();
    if (r.action.unwind) r.action.unwind(r);
    for (const o of r.props) {
      if (o.isObject3D) { if (o.parent) o.parent.remove(o); o.traverse(m => { if (m.geometry) m.geometry.dispose(); if (m.material) [].concat(m.material).forEach(x => x.dispose()); }); }
      else if (o.dispose) o.dispose();
    }
    r.props.length = 0;
    c.model.position.y = r.base.y;
    if (H.contact) H.contact.visible = r.base.contact;
    H.shadow.visible = r.base.shadow;
    const cl = r.action.clips;
    for (const name of [cl.in, cl.loop]) if (name && c.actions[name]) { const a = c.actions[name]; a.setLoop(T.LoopRepeat, Infinity); a.clampWhenFinished = false; a.timeScale = 1; }
    H.state.hold = null;
    r.dead = true;
    const w = WORLD.walking;                               // a tap that ended it was planned from the seat (inside the furniture): plan it again from here
    if (r.phase === 'out' && r.place === WORLD.place && w.hasTarget && w.requested) WORLD.walkTo(w.requested.x, w.requested.z);
    if (run === r) run = null;
  }
  // On the spot, from anywhere: she goes back to where she stood when it began (leaving the house, closing the world).
  function abort(why = 'abort') {
    if (!run) return;
    const r = run, H = heroNow();
    if (r.phase !== 'out') { r.log.ended = why; for (const stop of r.stops.splice(0)) stop(); }
    if (r.place === WORLD.place) H.group.position.set(r.from.x, WORLD.heightAt(r.from.x, r.from.z), r.from.z);
    H.pivot.rotation.y = r.from.yaw;
    r.place.returnTo = { x: r.from.x, y: 0, z: r.from.z };
    H.model.play('Idle_A', 0);
    finish(r);
    cooling = true;
  }

  // The hold: her pose, every frame (world.js animateHero). Position and turn glide between where she was, the seat and the free spot.
  function animate(c, dt) {
    const r = run, H = heroNow();
    if (!r) return;
    r.t += dt;
    const p = H.group.position, act = r.action, cl = act.clips;
    let a, b, k;
    if (r.phase === 'out') {
      r.outT += dt;
      a = r.at; b = r.exit; k = smooth(r.outT / OUT); b.dy = 0;
    } else {
      a = r.from; b = r.seat; k = smooth(r.t / (act.glide || 0.5));
    }
    p.x = a.x + (b.x - a.x) * k; p.z = a.z + (b.z - a.z) * k;
    H.pivot.rotation.y = turned(a.yaw, b.yaw, k);
    r.dyNow = a.dy + (b.dy - a.dy) * k;
    c.model.position.y = r.base.y + r.dyNow;
    if (r.phase === 'in' && r.inClip && r.inClip.time >= r.inClip.getClip().duration - 0.05) {       // down: now the clip that loops
      r.phase = 'on'; r.t = Math.max(r.t, act.glide || 0.5);
      c.play(cl.loop, 0.15);
    } else if (r.phase === 'in' && !cl.in) r.phase = 'on';
    if (r.phase === 'out' && r.outT >= OUT) { finish(r); return; }
  }

  // ── Every frame, in each house ───────────────────────────────────────────────────────────────────────────────────
  function update(place, dt) {
    const H = heroNow();
    if (!H.model) return;
    const intent = WORLD.heroIntent;
    if (run) {
      const r = run;
      if (r.place !== place) return;
      if (r.phase !== 'out') {
        if (intent) {                                    // any walk input ends it, unless it is only the press that began it, still held
          if (r.released || !r.entryDir || intent.x * r.entryDir.x + intent.z * r.entryDir.z < 0.3) end('walk', intent);
        } else r.released = true;
        if (r.phase !== 'out' && r.action.seconds && r.t > r.action.seconds) end('done', null);
      }
      if (r.action.update) r.action.update(r, dt);
      return;
    }
    if (cooling) { if (!intent) cooling = false; else return; }       // right after stepping out, wait until she lets go of the keys
    if (!intent || H.state.fright || H.state.jump) { walkReset(); return; }
    const p = H.group.position;
    for (const spot of spots(place)) {
      const d = toBox(spot.box, p.x, p.z);
      if (d.dist > R() + 0.14 || intent.x * d.nx + intent.z * d.nz < 0.5) continue;
      if (pushing !== spot) { pushing = spot; pushT = 0; }
      pushT += dt;
      if (pushT >= PUSH_FOR) start(spot, 'walk', { x: intent.x, z: intent.z });
      return;
    }
    walkReset();
  }

  // A left tap on a spot, from within reach: starts it. (Any tap while one runs is a walk input; the item itself is not one.)
  const hit = new T.Vector3();
  function tap(place, ray) {
    const H = heroNow();
    if (!H.model) return false;
    if (run) return run.place === place && run.phase !== 'out' && !!ray.intersectBox(run.spot.world, hit);
    const p = H.group.position;
    for (const spot of spots(place)) {
      if (!ray.intersectBox(spot.world, hit) || toBox(spot.box, p.x, p.z).dist > spot.action.reach || !reachable(spot, p.x, p.z)) continue;
      start(spot, 'tap', null);
      return true;
    }
    return false;
  }

  function setup() {
    for (const place of WORLD.places.values()) {
      if (place.id === 'outdoors') continue;
      place.updaters.push(dt => update(place, dt), WORLD_FX.update);          // (the effects update where she is)
      place.onTap.push(ray => tap(place, ray));
    }
  }
  WORLD.onBuilt.push(setup);
  WORLD.onEnter.push((next, prev) => { if (run && run.place === prev) abort('left'); cooling = false; });
  WORLD.onOpen.push(async () => { abort('open'); cooling = false; });
  WORLD.onClose.push(() => abort('close'));

  window.WORLD_ROOMS = { ACTIONS, spots, log, abort, reachable, using: () => (run ? run.item : null), get active() { return run; }, OUT, PUSH_FOR };
})();
