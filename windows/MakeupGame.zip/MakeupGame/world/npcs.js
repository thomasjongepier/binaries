// Friends (NPCs, epic makeupgame-oq2): other characters in the world, each with a look of their own.
// The dressing room sets how many (friendCount(), 0 to 12). They are made once, kept, and dressed
// again with new random looks on every visit. Each has a small brain: an ACTIONS table, one entry per
// thing a friend can do. To add a new action (wave, cheer, sit...) add an entry there.
//
// They walk on routes from nav.js, keep clear of each other, and when she walks up to one a coin is
// tossed: the friend either steps out of her way, or stays put and she slides round them. A friend who
// bumps into something (her, another friend, a solid thing) turns away from it and walks off 0 to 4 units.
// Meeting face to face (waving, saying hi, crying, farting) is social.js; it drives a friend through `n.meet`.
(() => {
  'use strict';
  const T = window.THREE;
  const MAX = 12;
  const RADIUS = 0.4;                // how much room a friend takes up
  const REACH = 1.5;                 // she is "walking up to" a friend this close
  const BUMP_DIST = 0.45 + RADIUS;   // she is pushed out of a friend who stays put (her radius + theirs)
  const STROLL = { speed: 1.5, clip: 'Walking_A', ground: 1.0 };   // Walking_A carries a body about 1 unit/s at timeScale 1 (jko.4 notes)
  const HURRY = { speed: 2.4, clip: 'Running_A', ground: 2.16 };   // stepping out of her way
  const TURN = 9;
  const STAY_FOR = 2.5;              // seconds a friend who "stays put" stands their ground, if she does not push
  const BUMP_WALK = 4;               // after a bump a friend walks off up to this far (0 too: then they only turn away)
  const BUMP_AGAIN = 1.5;            // seconds before a bumped friend notices another bump
  const STUCK_AFTER = 1.2;           // seconds of walking without getting anywhere before a friend gives up that walk
  const CLEAR = 0.35;                // a friend keeps this far from solid things
  const HIDE_NEAR_CAMERA = 1.6;      // a friend this close to the camera would fill the picture
  const OUTLINES_FAR = [14, 17];     // beyond this far from the camera the outline is too thin to see: skip drawing it (back on inside the first)
  const OFFSCREEN_STEP = 0.2;        // a friend nobody can see animates only this often
  const FEET = 0.05, FOOT_DROP = 0.028;

  let parts = null, nav = null, JUMP = null;
  const friends = [];                // the pool, at most MAX, made once
  let run = 0, busy = Promise.resolve();
  const rnd = Math.random;
  const pick = a => a[Math.floor(rnd() * a.length)];
  const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));

  // ── Actions ──────────────────────────────────────────────────────────────
  // start(n) begins it; update(n, dt) runs it and returns true when it is over.
  const ACTIONS = {
    stand: {
      weight: 3,
      start(n) {
        n.t = 2 + rnd() * 4;
        n.clip = rnd() < 0.7 ? 'Idle_A' : 'Idle_B';
        n.lookAtHer = rnd() < 0.5;
      },
      update(n, dt) {
        n.t -= dt;
        if (n.lookAtHer) {
          const h = parts.hero.group.position, p = n.group.position;
          if (Math.hypot(h.x - p.x, h.z - p.z) < 6) n.want = Math.atan2(h.x - p.x, h.z - p.z);
        }
        return n.t <= 0;
      },
    },
    walk: {
      weight: 5,
      start(n) {
        const others = friends.filter(f => f !== n && f.active).map(f => f.group.position);
        const goal = nav.randomPoint(rnd, { awayFrom: [n.group.position, ...others], minDist: 3 });
        n.route = goal && nav.path(n.group.position, goal);
        if (!n.route) { n.route = null; return; }
        n.gait = STROLL;
        n.clip = null;
      },
      update(n, dt) { return !n.route || follow(n, dt); },
    },
    jump: {
      weight: 1.5,
      start(n) { n.jump = { t: 0 }; n.clip = null; },
      update(n, dt) {
        n.jump.t += dt;
        if (n.jump.t >= JUMP.TIME) { n.jump = null; return true; }
        return false;
      },
    },
  };

  function chooseAction(n) {
    const names = Object.keys(ACTIONS).filter(k => !(k === n.last && k !== 'walk'));
    let r = rnd() * names.reduce((s, k) => s + ACTIONS[k].weight, 0), name = names[0];
    for (const k of names) { r -= ACTIONS[k].weight; if (r <= 0) { name = k; break; } }
    n.last = name; n.action = ACTIONS[name]; n.route = null; n.jump = null;
    n.action.start(n);
    if (!n.route && name === 'walk') { n.action = ACTIONS.stand; ACTIONS.stand.start(n); n.last = 'stand'; }   // nowhere to go: stand a while
  }

  // Walk along the route; true on arrival.
  function follow(n, dt) {
    const p = n.group.position, g = n.gait;
    let left = g.speed * dt;
    while (left > 0 && n.route.length) {
      const w = n.route[0], dx = w.x - p.x, dz = w.z - p.z, d = Math.hypot(dx, dz);
      if (d < 0.05) { n.route.shift(); continue; }
      const step = Math.min(left, d);
      p.x += (dx / d) * step; p.z += (dz / d) * step;
      n.want = Math.atan2(dx, dz);
      n.moved = true;
      left -= step;
      if (step >= d - 1e-6) n.route.shift();
    }
    return !n.route.length;
  }

  // ── Meeting her ──────────────────────────────────────────────────────────
  // Within reach, a coin decides, once per meeting: step aside, or stay put and be walked round.
  function stepAside(n, dx, dz, d) {
    const p = n.group.position;
    // out of her way: to the side of the line between us, whichever side is free
    const ax = dx / (d || 1), az = dz / (d || 1), px = -az, pz = ax;
    const cands = [1, -1].map(s => ({ x: p.x + ax * 0.9 + px * s * 1.9, z: p.z + az * 0.9 + pz * s * 1.9 }))
      .filter(c => nav.reachable(c.x, c.z));
    const goal = cands.length ? pick(cands) : nav.nearestReachable(p.x + ax * 2, p.z + az * 2);
    const route = goal && nav.path(p, goal);
    if (!route) return false;
    if (window.WORLD_SOCIAL) WORLD_SOCIAL.part(n);          // out of her way first: a meeting with another friend is over
    n.action = { weight: 0, update: (m, t) => !m.route || follow(m, t) };
    n.route = route; n.gait = HURRY; n.jump = null; n.last = 'walk';
    return true;
  }

  function meetHer(n, dt) {
    const h = parts.hero.group.position, p = n.group.position;
    const dx = p.x - h.x, dz = p.z - h.z, d = Math.hypot(dx, dz);
    if (d > REACH * 2.2) { n.meeting = null; n.stayFor = 0; return; }
    if (n.meet && n.meet.withHer) { if (n.meeting !== 'step') n.meeting = 'over'; return; }   // face to face with her (social.js): no coin toss while they meet, nor right after
    if (!n.meeting && d < REACH) {
      n.stayFor = 0;
      n.meeting = rnd() < 0.5 && stepAside(n, dx, dz, d) ? 'step' : 'stay';
    }
    if (n.meeting === 'stay') {
      n.stayFor += dt;
      if (n.stayFor > STAY_FOR) n.meeting = 'over';          // enough: carry on (she may be standing still right beside them)
    }
    if (n.meeting === 'stay' && d < BUMP_DIST) {
      // she cannot walk through a friend who stays put: pushed out along the line between us, so she slides round;
      // and she bumped into them: they turn away from her (and may walk off)
      h.x = p.x - (dx / (d || 1)) * BUMP_DIST; h.z = p.z - (dz / (d || 1)) * BUMP_DIST;
      n.bumped = { x: dx, z: dz, by: 'her' };
      n.meeting = 'over';
    }
  }

  // ── Bumps ────────────────────────────────────────────────────────────────
  // Bumped (by her, another friend or a solid thing): turn away from it, then walk off a random 0 to BUMP_WALK units.
  // (x, z) points away from what they bumped into.
  function bump(n, x, z, by) {
    if (n.bumpWait > 0 || n.jump || n.pop < 1) return;
    n.bumpWait = BUMP_AGAIN;
    if (window.WORLD_SOCIAL) WORLD_SOCIAL.part(n);        // a bump ends a meeting
    const f = WORLD.friends.force || {};
    walkOff(n, Math.atan2(x, z), f.bumpDist !== undefined ? f.bumpDist : rnd() < 0.2 ? 0 : rnd() * BUMP_WALK);
    note(n, 'bump', by);
  }

  // Turn to `heading`, walk `dist` that way (along a route, so round what is in the way), then stand a moment.
  // Also the "turns around and walks away" of a meeting (social.js).
  function walkOff(n, heading, dist) {
    n.route = null; n.jump = null; n.clip = null;
    n.off = { heading, dist, t: 0, phase: 'turn' };
    n.action = WALK_OFF; n.last = 'walk';
  }
  const WALK_OFF = {
    weight: 0,
    update(n, dt) {
      const o = n.off;
      if (!o) return true;
      o.t += dt;
      if (o.phase === 'turn') {
        n.want = o.heading;
        if (Math.abs(wrap(o.heading - n.pivot.rotation.y)) > 0.25 && o.t < 0.8) return false;
        o.phase = 'walk'; o.t = 0;
        if (o.dist > 0.3) {
          const p = n.group.position, goal = nav.nearestReachable(p.x + Math.sin(o.heading) * o.dist, p.z + Math.cos(o.heading) * o.dist);
          n.route = goal && nav.path(p, goal);
          n.gait = STROLL;
        }
      }
      if (o.phase === 'walk') {
        if (n.route && n.route.length && !follow(n, dt)) return false;
        n.route = null; o.phase = 'rest'; o.t = 0; o.rest = 0.6 + rnd() * 1.4;
      }
      if (o.t < o.rest) return false;
      n.off = null;
      return true;
    },
  };

  // What happened, for the tests and for watching them: { t, who (index), what, with ('her', an index or 'solid'), why }.
  function note(n, what, withWhom, why) {
    const log = WORLD.friends.log;
    log.push({ t: Math.round(performance.now()), who: friends.indexOf(n), what, with: withWhom, why });
    if (log.length > 300) log.splice(0, log.length - 300);
  }

  // Pushed by another friend or by her, a friend may end up in a wall or a tree: push them back out. Returns how they
  // were moved ({ x, z }), or null.
  function clearOfSolids(p) {
    const x0 = p.x, z0 = p.z;
    for (let pass = 0; pass < 3; pass++) {
      for (const c of WORLD.colliders) {
        const out = WORLD_SOLID.push(c, p.x, p.z, CLEAR);
        if (out) { p.x = out.x; p.z = out.z; }
      }
    }
    return p.x !== x0 || p.z !== z0 ? { x: p.x - x0, z: p.z - z0 } : null;
  }

  // ── Per frame ────────────────────────────────────────────────────────────
  function setClip(n, clip, scale = 1, fade = 0.2) {
    if (!clip) return;
    n.c.play(clip, fade);
    n.c.actions[clip].timeScale = scale;
  }

  // Outlines double a friend's triangles. Far away they are hair-thin, so they are left out there.
  function outlinesOf(n) {
    const L = n.c.look;
    return [...L.outlines, ...Object.values(L.extras || {}).flatMap(it => it.outlines || [])];
  }
  function showOutlines(n, on) {
    if (n.outlinesOn === on) return;
    n.outlinesOn = on;
    if (!on) { n.hidden = outlinesOf(n).filter(o => o.visible); for (const o of n.hidden) o.visible = false; }
    else { for (const o of n.hidden || []) o.visible = true; n.hidden = []; }
  }

  const frustum = new T.Frustum(), pv = new T.Matrix4(), sphere = new T.Sphere();
  function update(dt) {
    if (!friends.some(f => f.active && f.ready)) return;
    const cam = parts.camera.position;
    parts.camera.updateMatrixWorld();
    pv.multiplyMatrices(parts.camera.projectionMatrix, parts.camera.matrixWorldInverse);
    frustum.setFromProjectionMatrix(pv);
    const active = friends.filter(f => f.active && f.ready);
    for (const n of active) {
      n.moved = false;
      n.want = null;
      n.pushed = false;
      n.bumped = null;
      n.bumpWait -= dt;
      n.px = n.group.position.x; n.pz = n.group.position.z;
      meetHer(n, dt);
    }
    if (window.WORLD_SOCIAL && !WORLD.friends.freeze) WORLD_SOCIAL.update(active, dt);   // who meets whom, face to face
    for (const n of active) {
      const frozen = (n.meeting === 'stay' && !n.meet) || WORLD.friends.freeze;      // (freeze: a test hook)
      if (frozen) {
        n.want = null;
      } else {
        if (!n.action || n.action.update(n, dt)) chooseAction(n);
      }
    }
    // keep clear of each other (and a walking friend from her)
    for (let i = 0; i < active.length; i++) {
      for (let j = i + 1; j < active.length; j++) {
        const a = active[i].group.position, b = active[j].group.position;
        const dx = b.x - a.x, dz = b.z - a.z, d = Math.hypot(dx, dz), min = RADIUS * 2;
        if (d < min) {
          const k = (min - d) / 2 / (d || 1), ox = d ? dx * k : min / 2, oz = d ? dz * k : 0;
          a.x -= ox; a.z -= oz; b.x += ox; b.z += oz;
          active[i].pushed = active[j].pushed = true;
          active[i].bumped = { x: -ox, z: -oz, by: friends.indexOf(active[j]) };     // they bumped into each other
          active[j].bumped = { x: ox, z: oz, by: friends.indexOf(active[i]) };
        }
      }
    }
    for (const n of active) {
      const p = n.group.position, hit = parts.hero.group.position;
      if (n.meeting !== 'stay') {                  // a friend who walks into her goes round, never through
        const dx = p.x - hit.x, dz = p.z - hit.z, d = Math.hypot(dx, dz);
        if (d < BUMP_DIST) {
          p.x = hit.x + (dx / (d || 1)) * BUMP_DIST; p.z = hit.z + (dz / (d || 1)) * BUMP_DIST; n.pushed = true;
          n.bumped = { x: dx, z: dz, by: 'her' };
        }
      }
      if (n.pushed || n.moved) {                             // (routes keep clear of solid things, so walking into one is rare)
        const out = clearOfSolids(p);
        if (out && !n.bumped) n.bumped = { x: out.x, z: out.z, by: 'solid' };
      }
      if (n.route && n.route.length && !n.jump) {            // walking but not getting anywhere: something is in the way
        n.stuck = Math.hypot(p.x - n.px, p.z - n.pz) < n.gait.speed * dt * 0.25 ? n.stuck + dt : 0;
        if (n.stuck > STUCK_AFTER) {
          n.route = null; n.stuck = 0;
          const h = n.pivot.rotation.y;
          if (!n.bumped) n.bumped = { x: -Math.sin(h), z: -Math.cos(h), by: 'solid' };
        }
      } else n.stuck = 0;
      if (n.bumped && !WORLD.friends.freeze) bump(n, n.bumped.x, n.bumped.z, n.bumped.by);
      const floor = WORLD.heightAt(p.x, p.z);
      p.y += (floor - p.y) * (1 - Math.exp(-18 * dt));
      // the jump
      let lift = 0;
      if (n.jump) {
        lift = JUMP.HEIGHT * Math.sin(Math.PI * Math.min(1, Math.max(0, (n.jump.t - JUMP.FROM) / JUMP.AIR)));
        if (n.jump.t - dt <= 0) n.c.actions[JUMP.CLIP].reset();
        n.c.play(JUMP.CLIP, 0.08);
      } else if (n.moved) {
        setClip(n, n.gait.clip, n.gait.speed / n.gait.ground, 0.2);
      } else {
        setClip(n, n.clip || 'Idle_A', 1, 0.25);
      }
      lift += n.hop || 0;                                    // a little hop of their own (social.js: a fart)
      n.pivot.position.y = FEET + lift;
      n.contact.position.y = 0.014 - lift;
      n.contact.material.opacity = 1 - 0.6 * lift / JUMP.HEIGHT;
      n.shadow.scale.setScalar(1 - 0.4 * lift / JUMP.HEIGHT);
      if (n.want !== null) n.pivot.rotation.y += wrap(n.want - n.pivot.rotation.y) * (1 - Math.exp(-TURN * dt));
      if (!window.__STILL) {
        n.blinkIn -= dt;
        if (n.blinkIn <= 0) { n.c.blink(); n.blinkIn = 2.5 + rnd() * 3.5; }
      }
      // popping in
      if (n.pop < 1) { n.pop = Math.min(1, n.pop + dt * 3.5); n.pivot.scale.setScalar(Math.max(0.01, 1 - Math.pow(1 - n.pop, 3) * 0.8 + Math.sin(n.pop * Math.PI) * 0.12)); }
      const far = Math.hypot(p.x - cam.x, p.y - cam.y, p.z - cam.z);
      showOutlines(n, n.outlinesOn === false ? far < OUTLINES_FAR[0] : far < OUTLINES_FAR[1]);
      sphere.set(p, 2);
      let posed = true;
      if (frustum.intersectsSphere(sphere) || n.pop < 1) { n.c.update(dt + n.idle); n.idle = 0; }
      else { n.idle += dt; posed = n.idle >= OFFSCREEN_STEP; if (posed) { n.c.update(n.idle); n.idle = 0; } }   // out of sight: a few updates a second
      if (posed && n.perf && window.WORLD_SOCIAL) WORLD_SOCIAL.pose(n);       // crying, nodding: on top of the clip
      n.group.visible = Math.hypot(p.x - cam.x, p.z - cam.z) > HIDE_NEAR_CAMERA || cam.y - p.y > 4;
    }
  }

  // ── The pool ─────────────────────────────────────────────────────────────
  let blobTex = null;
  function blobTexture() {
    if (blobTex) return blobTex;
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g = c.getContext('2d'), grad = g.createRadialGradient(64, 64, 4, 64, 64, 62);
    grad.addColorStop(0, 'rgba(40,60,20,0.6)'); grad.addColorStop(0.4, 'rgba(40,60,20,0.38)'); grad.addColorStop(1, 'rgba(40,60,20,0)');
    g.fillStyle = grad; g.fillRect(0, 0, 128, 128);
    return (blobTex = new T.CanvasTexture(c));
  }

  async function makeFriend() {
    const c = await CHARACTER3D.create();
    const group = new T.Group(), pivot = new T.Group();
    pivot.position.y = FEET;
    const shadow = new T.Mesh(new T.PlaneGeometry(1.7, 1.1), new T.MeshBasicMaterial({ map: blobTexture(), transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2; shadow.position.y = FEET + 0.01;
    c.model.position.y = -FOOT_DROP;
    const contact = TOON.contactShadow('40,60,20', 1.1);
    contact.position.set(0, 0.014, 0.04);
    pivot.add(c.model, contact);
    group.add(shadow, pivot);
    group.visible = false;
    parts.scene.add(group);
    c.play('Idle_A', 0);
    for (const clip of [JUMP.CLIP, 'Waving']) { c.actions[clip].setLoop(T.LoopOnce, 1); c.actions[clip].clampWhenFinished = true; }
    const bones = {};
    for (const b of ['head', 'chest', 'spine', 'hips']) bones[b] = c.model.getObjectByName(b);
    return { c, group, pivot, shadow, contact, bones, active: false, ready: false, pop: 1, idle: 0, outlinesOn: true, hidden: [], blinkIn: 2 + rnd() * 3, moved: false, meeting: null, stayFor: 0, stuck: 0, pushed: false, px: 0, pz: 0,
      bumpWait: 0, meet: null, perf: null, off: null, hop: 0, voice: 0.85 + rnd() * 0.4 };
  }

  function count() {
    if (parts.hero.model === null || WORLD.heroMode !== '3d') return 0;
    const n = typeof window.__FRIENDS === 'number' ? window.__FRIENDS : (typeof friendCount === 'function' ? friendCount() : 4);
    return Math.max(0, Math.min(MAX, Math.floor(n)));
  }

  // Every visit: new looks, dress them one after another (so the world opens at once and they pop in).
  function refresh() {
    const my = ++run;
    const n = count();
    for (const f of friends) { f.active = false; f.ready = false; f.group.visible = false; }
    const prev = busy;
    busy = (async () => {
      try { await prev; } catch (e) { /* the earlier run's problem */ }
      if (my !== run) return;
      const looks = n ? friendLooks(n, state) : [];
      for (let i = 0; i < n; i++) {
        if (my !== run) return;
        if (!friends[i]) friends[i] = await makeFriend();
        const f = friends[i];
        f.look = looks[i];
        await dressFriend(f, looks[i]);
        if (my !== run) return;
        place(f, i);
        f.active = true; f.ready = true; f.pop = 0;
        f.pivot.scale.setScalar(0.01);
        f.group.visible = true;
        WORLD.friends.ready = friends.filter(x => x.ready).length;
      }
      WORLD.friends.settled = my;
    })().catch(err => console.error('friends:', err));
  }

  function dressFriend(f, look) {
    showOutlines(f, true);          // dressing shows and hides meshes by name, so the outlines must be as they were made
    return f.c.dress(parts.renderer, {}, look, { faceScale: 0.5, sad: true });
  }

  function place(f, i) {
    const start = WORLD_LAYOUT.start;
    const others = friends.filter(x => x !== f && x.ready).map(x => x.group.position);
    const at = nav.randomPoint(rnd, { awayFrom: [start, ...others], minDist: 4 }) || nav.nearestReachable(start.x + 4, start.z);
    f.group.position.set(at.x, WORLD.heightAt(at.x, at.z), at.z);
    f.pivot.rotation.y = rnd() * Math.PI * 2;
    f.action = null; f.route = null; f.jump = null; f.meeting = null; f.last = null;
    f.meet = null; f.perf = null; f.off = null; f.hop = 0; f.bumpWait = 0; f.clip = null;
    f.c.setSad(false);
  }

  WORLD.onBuilt.push(p => {
    parts = p;
    JUMP = WORLD.JUMP;
    nav = WORLD_NAV.build(window.WORLD_LAYOUT, WORLD.colliders, { radius: WORLD.HERO_RADIUS });
    WORLD.friends = { max: MAX, ready: 0, settled: 0, list: friends, nav, ACTIONS, log: [], force: null,
      follow, walkOff, note, STROLL, RADIUS, WALK_OFF };
    WORLD.updaters.push(update);
  });
  WORLD.onOpen.push(async () => { WORLD.friends.log.length = 0; refresh(); });
})();
