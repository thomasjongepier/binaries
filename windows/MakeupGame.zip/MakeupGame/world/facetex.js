// Her face as pictures for the 3D head, drawn from the live dress-up SVG (so every eye style, every
// makeup and every colour she picked is in it, and it never needs its own copy of the options).
// The route is the cut-out's: characterSvgText() -> a blob: URL -> <img> -> canvas, which keeps the
// canvas free of file:// taint.
//
//   base       skin, cheeks, nose, mouth, lipstick, face paint        (on the head, opaque)
//   over.open  eyeshadow, eyes, brows                                  (on a thin shell, transparent)
//   over.blink the same with the eyes shut (the 2D blink: scaleY .07 around the eye line)
// The eyes and brows are separate because in the 2D art they are drawn over the fringe.
//
// The picture frame must match world/character-src/build.py (FRAME_*): a square of the SVG, so the head's
// flat front projection lines up. The face outline and ears are left out: the 3D outline draws the
// silhouette, and the ears are modelled.
(function () {
  const FRAME = { x: 60, y: 64, size: 280 };          // SVG units
  const OVER = { y: 120, h: 150 };                    // the band of the frame that holds eyes and brows
  const BASE_PX = 768;                                // pixels across the 280 units
  const OVER_PX = 1024;

  const ALL_LAYERS = ['background', 'hair-back', 'neck', 'face', 'clothing', 'cheeks', 'nose', 'mouth', 'lipstick',
    'marks', 'hair-front', 'eyeshadow', 'eyes', 'brows', 'accessories'];
  const BASE_LAYERS = ['face', 'cheeks', 'nose', 'mouth', 'lipstick', 'marks'];
  const OVER_LAYERS = ['eyeshadow', 'eyes', 'brows'];
  const BLINK = 'translate(200 216) scale(1 0.07) translate(-200 -216)';   // style.css: .blinking .eye-anim
  // Moods (social.js, world.js): the face drawn crying, shocked or laughing, instead of whatever mouth and lipstick they have, drawn big and
  // dark so it reads from afar. Eyes are at x 149 and 251, y 220 in character.js. A mood is a base picture (the mouth, tears) and
  // maybe a picture of the eyes and brows (`eyes`: 'shut' reuses the blink, 'open' the open eyes, 'wide' and 'happy' are drawn).
  //   sad    a big open mouth turned down, wet tracks running down from both eyes, eyes shut
  //   shock  a round O of a mouth, tall wide eyes, brows up
  //   laugh  a big open smile with teeth and tongue, eyes squeezed into happy arcs
  const SAD_MOUTH = `
    <path d="M174,312 C173,288 186,278 200,278 C214,278 227,288 226,312 C214,305 186,305 174,312 Z" fill="#7A2338" stroke="#4a1020" stroke-width="3.5" stroke-linejoin="round"/>
    <path d="M184,306 C190,300 210,300 216,306 C210,305 190,305 184,306 Z" fill="#ef8aa0"/>
    <path d="M187,284 C194,281 206,281 213,284" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity="0.8"/>`;
  const SHOCK_MOUTH = `
    <ellipse cx="200" cy="304" rx="15" ry="21" fill="#7A2338" stroke="#4a1020" stroke-width="3.5"/>
    <ellipse cx="200" cy="314" rx="9" ry="8" fill="#ef8aa0"/>
    <path d="M190,290 C195,287 205,287 210,290" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity="0.7"/>`;
  const LAUGH_MOUTH = `
    <path d="M160,288 C166,334 234,334 240,288 C222,297 178,297 160,288 Z" fill="#7A2338" stroke="#4a1020" stroke-width="3.5" stroke-linejoin="round"/>
    <path d="M168,291 C186,299 214,299 232,291 L230,302 C212,307 188,307 170,302 Z" fill="#fff"/>
    <ellipse cx="200" cy="320" rx="16" ry="8" fill="#ef8aa0"/>`;
  const HAPPY_EYES = [149, 251].map(x => `<path d="M${x - 19},229 Q${x},203 ${x + 19},229" fill="none" stroke="#3a2430" stroke-width="7.5" stroke-linecap="round"/>`).join('');
  const TEARS = [149, 251].map(x => `
    <path d="M${x - 6},238 C${x - 8},256 ${x - 4},272 ${x - 7},292 L${x + 5},292 C${x + 8},272 ${x + 5},256 ${x + 6},238 Z" fill="#8fd8ff" opacity="0.9"/>
    <path d="M${x - 2},244 C${x - 3},258 ${x - 1},270 ${x - 2},284" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" opacity="0.85"/>
    <ellipse cx="${x}" cy="296" rx="8" ry="9" fill="#8fd8ff" opacity="0.95"/>`).join('');
  const MOODS = {
    sad: { mouth: SAD_MOUTH, tears: true, eyes: 'shut' },
    shock: { mouth: SHOCK_MOUTH, eyes: 'wide' },
    laugh: { mouth: LAUGH_MOUTH, eyes: 'happy' },
  };
  function paintMouth(clone, mood) {
    const M = MOODS[mood], mouth = clone.querySelector('#layer-mouth'), lipstick = clone.querySelector('#layer-lipstick'), eyes = clone.querySelector('#layer-eyes');
    mouth.innerHTML = `<g transform="translate(200 296) scale(1.3) translate(-200 -296)">${M.mouth}</g>`;   // the layer keeps its own place and size (the mouth's Adjust)
    lipstick.innerHTML = '';
    if (M.tears) clone.querySelector('#layer-marks').insertAdjacentHTML('afterend', `<g transform="${eyes.getAttribute('transform') || ''}">${TEARS}</g>`);
  }
  // The eyes and brows of a mood that draws them: wide = taller eyes and brows lifted, happy = arcs instead of eyes, brows lifted a little.
  function paintEyes(clone, how) {
    const brows = clone.querySelector('#layer-brows');
    brows.innerHTML = `<g transform="translate(0 ${how === 'wide' ? -10 : -5})">${brows.innerHTML}</g>`;
    if (how === 'wide') {
      clone.querySelectorAll('.eye-anim').forEach(g => g.setAttribute('transform', 'translate(200 216) scale(1 1.4) translate(-200 -216)'));
    } else {
      clone.querySelector('#layer-eyes').innerHTML = `<g class="eye-anim">${HAPPY_EYES}</g>`;
    }
  }

  // The 3D head is narrower than the 2D face and the bob and long hair fall over its sides, so cheek blush and the face paint
  // on the cheeks (SVG x 90 to 140) sat under the hair or smeared across the head's side when she turned (the flat front
  // projection stretches whatever is out at the sides). The picture for the head moves what is out to the sides IN by this much
  // (SVG units; both halves, the middle strip stays), so the makeup lies where it can be seen.
  const CHEEK_IN = { layers: ['cheeks', 'marks'], by: 32, from: 170 };
  function moveCheeksIn(clone) {
    const { by, from } = CHEEK_IN;
    const strips = [[-2000, from, by], [from, 400 - from, 0], [400 - from, 2400, -by]];     // x from, x to, how far it moves
    for (const id of CHEEK_IN.layers) {
      const layer = clone.querySelector('#layer-' + id);
      if (!layer || !layer.innerHTML.trim()) continue;
      const here = layer.innerHTML;
      layer.innerHTML = '<defs>' + strips.map(([a, b], i) => `<clipPath id="cheek-in-${id}-${i}"><rect x="${a}" y="-2000" width="${b - a}" height="5000"/></clipPath>`).join('') + '</defs>' +
        strips.map(([, , d], i) => `<g clip-path="url(#cheek-in-${id}-${i})"><g transform="translate(${d} 0)">${here}</g></g>`).join('');
    }
  }

  // The character as svg text, changed by `mutate(clone)`. `source` is the text of one character (a friend's, from lookSvgText)
  // or null for the live one (hers, drawn level). A clone of text is made the way the live one is: in this document.
  function svgFrom(source, mutate) {
    if (source === null || source === undefined) return characterSvgText(mutate, { level: true });
    const host = document.createElement('div');
    host.innerHTML = source;
    const clone = host.firstElementChild;
    mutate(clone);
    return new XMLSerializer().serializeToString(clone);
  }

  // Draw only `keep` layers of the character into a canvas.
  async function render(source, keep, view, px, { blink = false, skin = false, before = '', cheeksIn = false, mood = null, eyes = null } = {}) {
    const w = px, h = Math.round(px * view.h / view.w);
    const xml = svgFrom(source, clone => {
      clone.setAttribute('viewBox', `${view.x} ${view.y} ${view.w} ${view.h}`);
      clone.setAttribute('width', w);
      clone.setAttribute('height', h);
      for (const id of ALL_LAYERS) {
        if (!keep.includes(id)) clone.querySelector('#layer-' + id).innerHTML = '';
      }
      // A skin-coloured sheet instead of the face drawing: its outline, shadow crescent and ears are not wanted.
      // Huge, because the face layer carries the face's own size and position.
      if (skin) clone.querySelector('#layer-face').innerHTML = '<rect x="-1000" y="-1000" width="3000" height="3000" fill="var(--skin)"/>';
      if (cheeksIn) moveCheeksIn(clone);
      if (mood) paintMouth(clone, mood);
      if (eyes) paintEyes(clone, eyes);
      if (before) clone.querySelector('#layer-clothing').insertAdjacentHTML('afterbegin', before);
      if (blink) clone.querySelectorAll('.eye-anim').forEach(g => g.setAttribute('transform', BLINK));
    });
    const img = await svgTextToImage(xml);
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    canvas.getContext('2d').drawImage(img, 0, 0, w, h);
    return canvas;
  }

  // `svgText`: whose face (null: the live character's). `faceScale` shrinks the pictures for characters that are seen small
  // (the friends): 0.5 is 384 and 512 pixels instead of 768 and 1024.
  async function renderFace(svgText = null, { faceScale = 1 } = {}) {
    const full = { x: FRAME.x, y: FRAME.y, w: FRAME.size, h: FRAME.size };
    const band = { x: FRAME.x, y: OVER.y, w: FRAME.size, h: OVER.h };
    const basePx = Math.round(BASE_PX * faceScale), overPx = Math.round(OVER_PX * faceScale);
    const [base, open, blink] = await Promise.all([
      render(svgText, BASE_LAYERS, full, basePx, { skin: true, cheeksIn: true }),
      render(svgText, OVER_LAYERS, band, overPx),
      render(svgText, OVER_LAYERS, band, overPx, { blink: true }),
    ]);
    return {
      base, over: { open, blink },
      // The head's UVs cover the whole frame; the band is a crop of it: uv * scale + offset.
      overUv: { scale: [1, FRAME.size / OVER.h], offset: [0, (FRAME.y - OVER.y) / OVER.h] },
    };
  }

  // One mood's pictures (MOODS), drawn when somebody first needs it: { base, over, eyes }. `over` is a picture of the eyes and brows, or null
  // when the mood uses the character's own: `eyes` 'shut' (the blink) or 'open'.
  async function renderMood(svgText, mood, { faceScale = 1 } = {}) {
    const M = MOODS[mood];
    if (!M) throw new Error('No mood ' + mood);
    const full = { x: FRAME.x, y: FRAME.y, w: FRAME.size, h: FRAME.size };
    const band = { x: FRAME.x, y: OVER.y, w: FRAME.size, h: OVER.h };
    const drawn = M.eyes === 'wide' || M.eyes === 'happy';
    const [base, over] = await Promise.all([
      render(svgText, BASE_LAYERS, full, Math.round(BASE_PX * faceScale), { skin: true, cheeksIn: true, mood }),
      drawn ? render(svgText, OVER_LAYERS, band, Math.round(OVER_PX * faceScale), { eyes: M.eyes }) : null,
    ]);
    return { base, over, eyes: drawn ? 'open' : M.eyes };
  }

  // The rainbow hair colour: the 2D gradient (hair-rainbow, SVG y 20..480) as a narrow picture, top to bottom. The hair meshes
  // have u = 0.5 and v = how far down that gradient a point is (hair.py add_uvs), so one stripe of it colours them.
  const RAINBOW = { y: 20, h: 460 };
  async function renderRainbow(svgText = null) {
    const xml = svgFrom(svgText, clone => {
      clone.setAttribute('viewBox', `0 ${RAINBOW.y} 8 ${RAINBOW.h}`);
      clone.setAttribute('width', 8);
      clone.setAttribute('height', 256);
      clone.setAttribute('preserveAspectRatio', 'none');     // fill all 8 columns: the hair's u is its brightness, any column may be read
      for (const id of ALL_LAYERS) clone.querySelector('#layer-' + id).innerHTML = '';
      clone.querySelector('#layer-background').innerHTML = `<rect x="0" y="${RAINBOW.y}" width="8" height="${RAINBOW.h}" fill="url(#hair-rainbow)"/>`;
    });
    const img = await svgTextToImage(xml);
    const canvas = document.createElement('canvas');
    canvas.width = 8; canvas.height = 256;
    canvas.getContext('2d').drawImage(img, 0, 0, 8, 256);
    return canvas;
  }

  // The fabric pattern (state.clothingPattern, in the outfit colour's dark shade) as one tile of the repeat, for the 3D
  // outfits: they tile it over the cloth (toon.js). null when there is no pattern. `period` is the tile's size in SVG
  // units (a pattern is a tile of that many units), `px` the picture's size.
  const PATTERN_PX = 256;
  async function renderPattern(id, svgText = null) {
    const el = id && id !== 'none' && document.getElementById('pat-' + id);
    if (!el) return null;
    const period = +el.getAttribute('width');
    const xml = svgFrom(svgText, clone => {
      clone.setAttribute('viewBox', `0 0 ${period} ${period}`);
      clone.setAttribute('width', PATTERN_PX);
      clone.setAttribute('height', PATTERN_PX);
      for (const layer of ALL_LAYERS) clone.querySelector('#layer-' + layer).innerHTML = '';
      clone.querySelector('#layer-background').innerHTML = `<rect x="0" y="0" width="${period}" height="${period}" fill="var(--pattern)"/>`;
    });
    const img = await svgTextToImage(xml);
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = PATTERN_PX;
    canvas.getContext('2d').drawImage(img, 0, 0, PATTERN_PX, PATTERN_PX);
    return { canvas, period };
  }

  window.FACETEX = { renderFace, renderMood, renderRainbow, renderPattern, FRAME, OVER, MOODS: Object.keys(MOODS) };
})();
