// Her face as pictures for the 3D head, drawn from the live dress-up SVG (so every eye style, every
// makeup and every colour she picked is in it, and it never needs its own copy of the options).
// The route is the cut-out's: characterSvgText() -> a blob: URL -> <img> -> canvas, which keeps the
// canvas free of file:// taint.
//
//   base       skin, cheeks, nose, mouth, lipstick, face paint        (on the head, opaque)
//   over.open  eyeshadow, eyes, brows                                  (on a thin shell, transparent)
//   over.blink the same with the eyes shut (the 2D blink: scaleY .07 around the eye line)
// The eyes and brows are separate because in the 2D art they are drawn over the fringe.
//
// The picture frame must match world/character-src/build.py (FRAME_*): a square of the SVG, so the head's
// flat front projection lines up. The face outline and ears are left out: the 3D outline draws the
// silhouette, and the ears are modelled.
(function () {
  const FRAME = { x: 60, y: 64, size: 280 };          // SVG units
  const OVER = { y: 120, h: 150 };                    // the band of the frame that holds eyes and brows
  const BASE_PX = 768;                                // pixels across the 280 units
  const OVER_PX = 1024;

  const ALL_LAYERS = ['background', 'hair-back', 'neck', 'face', 'clothing', 'cheeks', 'nose', 'mouth', 'lipstick',
    'marks', 'hair-front', 'eyeshadow', 'eyes', 'brows', 'accessories'];
  const BASE_LAYERS = ['face', 'cheeks', 'nose', 'mouth', 'lipstick', 'marks'];
  const OVER_LAYERS = ['eyeshadow', 'eyes', 'brows'];
  const BLINK = 'translate(200 216) scale(1 0.07) translate(-200 -216)';   // style.css: .blinking .eye-anim
  // A crying friend's face (social.js): a big open mouth turned down instead of whatever mouth and lipstick they have, and wet
  // tracks running down from both eyes (eyes at x 149 and 251, y 220 in character.js). Drawn big and dark so it reads from afar.
  const SAD_MOUTH = `
    <path d="M174,312 C173,288 186,278 200,278 C214,278 227,288 226,312 C214,305 186,305 174,312 Z" fill="#7A2338" stroke="#4a1020" stroke-width="3.5" stroke-linejoin="round"/>
    <path d="M184,306 C190,300 210,300 216,306 C210,305 190,305 184,306 Z" fill="#ef8aa0"/>
    <path d="M187,284 C194,281 206,281 213,284" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" opacity="0.8"/>`;
  const TEARS = [149, 251].map(x => `
    <path d="M${x - 6},238 C${x - 8},256 ${x - 4},272 ${x - 7},292 L${x + 5},292 C${x + 8},272 ${x + 5},256 ${x + 6},238 Z" fill="#8fd8ff" opacity="0.9"/>
    <path d="M${x - 2},244 C${x - 3},258 ${x - 1},270 ${x - 2},284" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" opacity="0.85"/>
    <ellipse cx="${x}" cy="296" rx="8" ry="9" fill="#8fd8ff" opacity="0.95"/>`).join('');
  function makeSad(clone) {
    const mouth = clone.querySelector('#layer-mouth'), lipstick = clone.querySelector('#layer-lipstick'), eyes = clone.querySelector('#layer-eyes');
    mouth.innerHTML = `<g transform="translate(200 296) scale(1.3) translate(-200 -296)">${SAD_MOUTH}</g>`;   // the layer keeps its own place and size (the mouth's Adjust)
    lipstick.innerHTML = '';
    clone.querySelector('#layer-marks').insertAdjacentHTML('afterend', `<g transform="${eyes.getAttribute('transform') || ''}">${TEARS}</g>`);
  }

  // The 3D head is narrower than the 2D face and the bob and long hair fall over its sides, so cheek blush and the face paint
  // on the cheeks (SVG x 90 to 140) sat under the hair or smeared across the head's side when she turned (the flat front
  // projection stretches whatever is out at the sides). The picture for the head moves what is out to the sides IN by this much
  // (SVG units; both halves, the middle strip stays), so the makeup lies where it can be seen.
  const CHEEK_IN = { layers: ['cheeks', 'marks'], by: 32, from: 170 };
  function moveCheeksIn(clone) {
    const { by, from } = CHEEK_IN;
    const strips = [[-2000, from, by], [from, 400 - from, 0], [400 - from, 2400, -by]];     // x from, x to, how far it moves
    for (const id of CHEEK_IN.layers) {
      const layer = clone.querySelector('#layer-' + id);
      if (!layer || !layer.innerHTML.trim()) continue;
      const here = layer.innerHTML;
      layer.innerHTML = '<defs>' + strips.map(([a, b], i) => `<clipPath id="cheek-in-${id}-${i}"><rect x="${a}" y="-2000" width="${b - a}" height="5000"/></clipPath>`).join('') + '</defs>' +
        strips.map(([, , d], i) => `<g clip-path="url(#cheek-in-${id}-${i})"><g transform="translate(${d} 0)">${here}</g></g>`).join('');
    }
  }

  // The character as svg text, changed by `mutate(clone)`. `source` is the text of one character (a friend's, from lookSvgText)
  // or null for the live one (hers, drawn level). A clone of text is made the way the live one is: in this document.
  function svgFrom(source, mutate) {
    if (source === null || source === undefined) return characterSvgText(mutate, { level: true });
    const host = document.createElement('div');
    host.innerHTML = source;
    const clone = host.firstElementChild;
    mutate(clone);
    return new XMLSerializer().serializeToString(clone);
  }

  // Draw only `keep` layers of the character into a canvas.
  async function render(source, keep, view, px, { blink = false, skin = false, before = '', cheeksIn = false, sad = false } = {}) {
    const w = px, h = Math.round(px * view.h / view.w);
    const xml = svgFrom(source, clone => {
      clone.setAttribute('viewBox', `${view.x} ${view.y} ${view.w} ${view.h}`);
      clone.setAttribute('width', w);
      clone.setAttribute('height', h);
      for (const id of ALL_LAYERS) {
        if (!keep.includes(id)) clone.querySelector('#layer-' + id).innerHTML = '';
      }
      // A skin-coloured sheet instead of the face drawing: its outline, shadow crescent and ears are not wanted.
      // Huge, because the face layer carries the face's own size and position.
      if (skin) clone.querySelector('#layer-face').innerHTML = '<rect x="-1000" y="-1000" width="3000" height="3000" fill="var(--skin)"/>';
      if (cheeksIn) moveCheeksIn(clone);
      if (sad) makeSad(clone);
      if (before) clone.querySelector('#layer-clothing').insertAdjacentHTML('afterbegin', before);
      if (blink) clone.querySelectorAll('.eye-anim').forEach(g => g.setAttribute('transform', BLINK));
    });
    const img = await svgTextToImage(xml);
    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    canvas.getContext('2d').drawImage(img, 0, 0, w, h);
    return canvas;
  }

  // `svgText`: whose face (null: the live character's). `faceScale` shrinks the pictures for characters that are seen small
  // (the friends): 0.5 is 384 and 512 pixels instead of 768 and 1024. `sad` also draws `sad`: the base picture crying.
  async function renderFace(svgText = null, { faceScale = 1, sad = false } = {}) {
    const full = { x: FRAME.x, y: FRAME.y, w: FRAME.size, h: FRAME.size };
    const band = { x: FRAME.x, y: OVER.y, w: FRAME.size, h: OVER.h };
    const basePx = Math.round(BASE_PX * faceScale), overPx = Math.round(OVER_PX * faceScale);
    const [base, open, blink, sadBase] = await Promise.all([
      render(svgText, BASE_LAYERS, full, basePx, { skin: true, cheeksIn: true }),
      render(svgText, OVER_LAYERS, band, overPx),
      render(svgText, OVER_LAYERS, band, overPx, { blink: true }),
      sad ? render(svgText, BASE_LAYERS, full, basePx, { skin: true, cheeksIn: true, sad: true }) : null,
    ]);
    return {
      base, over: { open, blink }, sad: sadBase,
      // The head's UVs cover the whole frame; the band is a crop of it: uv * scale + offset.
      overUv: { scale: [1, FRAME.size / OVER.h], offset: [0, (FRAME.y - OVER.y) / OVER.h] },
    };
  }

  // The rainbow hair colour: the 2D gradient (hair-rainbow, SVG y 20..480) as a narrow picture, top to bottom. The hair meshes
  // have u = 0.5 and v = how far down that gradient a point is (hair.py add_uvs), so one stripe of it colours them.
  const RAINBOW = { y: 20, h: 460 };
  async function renderRainbow(svgText = null) {
    const xml = svgFrom(svgText, clone => {
      clone.setAttribute('viewBox', `0 ${RAINBOW.y} 8 ${RAINBOW.h}`);
      clone.setAttribute('width', 8);
      clone.setAttribute('height', 256);
      clone.setAttribute('preserveAspectRatio', 'none');     // fill all 8 columns: the hair's u is its brightness, any column may be read
      for (const id of ALL_LAYERS) clone.querySelector('#layer-' + id).innerHTML = '';
      clone.querySelector('#layer-background').innerHTML = `<rect x="0" y="${RAINBOW.y}" width="8" height="${RAINBOW.h}" fill="url(#hair-rainbow)"/>`;
    });
    const img = await svgTextToImage(xml);
    const canvas = document.createElement('canvas');
    canvas.width = 8; canvas.height = 256;
    canvas.getContext('2d').drawImage(img, 0, 0, 8, 256);
    return canvas;
  }

  // The fabric pattern (state.clothingPattern, in the outfit colour's dark shade) as one tile of the repeat, for the 3D
  // outfits: they tile it over the cloth (toon.js). null when there is no pattern. `period` is the tile's size in SVG
  // units (a pattern is a tile of that many units), `px` the picture's size.
  const PATTERN_PX = 256;
  async function renderPattern(id, svgText = null) {
    const el = id && id !== 'none' && document.getElementById('pat-' + id);
    if (!el) return null;
    const period = +el.getAttribute('width');
    const xml = svgFrom(svgText, clone => {
      clone.setAttribute('viewBox', `0 0 ${period} ${period}`);
      clone.setAttribute('width', PATTERN_PX);
      clone.setAttribute('height', PATTERN_PX);
      for (const layer of ALL_LAYERS) clone.querySelector('#layer-' + layer).innerHTML = '';
      clone.querySelector('#layer-background').innerHTML = `<rect x="0" y="0" width="${period}" height="${period}" fill="var(--pattern)"/>`;
    });
    const img = await svgTextToImage(xml);
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = PATTERN_PX;
    canvas.getContext('2d').drawImage(img, 0, 0, PATTERN_PX, PATTERN_PX);
    return { canvas, period };
  }

  window.FACETEX = { renderFace, renderRainbow, renderPattern, FRAME, OVER };
})();
