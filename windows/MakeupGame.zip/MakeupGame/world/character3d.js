// The 3D character: loads the packed model and KayKit's clips (world/assets/packs/character.js), makes
// playable copies and dresses them from the live dress-up game. Needs window.THREE (with SkeletonUtils),
// WORLD_PACKS.character, TOON (toon.js) and FACETEX (facetex.js).
//
// The model (world/character-src/, made with Blender) is one skeleton, KayKit's Rig_Medium, with these meshes:
//   Head, Face_overlay                     the head: her face is its texture; the overlay carries eyes and brows. That is the oval;
//   Head_<shape>, Face_overlay_<shape>     the other face shapes (round, heart, wide), same face picture, only the shape differs
//   Hair_<style>                           one hair style each (ids as in character.js; the one she chose is shown);
//                                          styles not built yet show Hair_placeholder, a plain bob
//   Extra_<id>[_skin|_front]               the Extras (glasses, hats, ears, horns, scarf, wands; ids as in character.js): rigid meshes on the
//                                          skeleton, coloured from a palette that comes with the model (the Extras_palette node); `_skin` ones
//                                          are drawn with her skin, `_front` ones (glasses) over her eyes and fringe. Their custom property
//                                          `group` says where they are worn: top, face, ear (on the head: they follow its shape and, on top,
//                                          the hair's height), neck, hand. Socket_<head|face|neck|hand_l|hand_r> nodes sit on the bones.
//   Body, Shoe_L, Shoe_R                   the chibi body and shoes
//   Outfit_<id>_<part>                     the 12 outfits, a few pieces each (shells cut from the body, skirts, trims, flat
//                                          decals; garments.py). Their colours come from a palette (see OUTFIT_CODES) and
//                                          the fabric pattern is tiled over palette colour 0; the one she wears is shown.
//
//   const c = await CHARACTER3D.create();   // { model, mixer, play(name, fade), update(dt), clips, ... }
//   await c.dress(renderer);                // her current look (call again when it changed)
//   await c.dress(renderer, {}, look, { faceScale: 0.5 });   // anyone's look (randomLook / friendLooks in game.js), smaller face pictures
//   scene.add(c.model); c.play('Walking_A'); ... c.update(dt) every frame.
// Bone names lose their dots when loaded: KayKit's 'handslot.l' is model.getObjectByName('handslotl').
(function () {
  const T = window.THREE;
  let assets = null;

  const FACE_BIAS = { over: 0.12, under: 0.01 };   // how far the eyes' shell slides toward the camera (world units)
  const OUTLINE_PX = 2.2;
  const FRONT_BIAS = 0.17;                         // glasses lenses and rims are drawn over the eyes' shell (FACE_BIAS.over) and the fringe
  const HAIR_TOP = 0.435;                          // extras.py's "hair dome": the typical height of her hair over the middle of the head (m)
  const LIFT_MIN = -0.03, LIFT_MAX = 0.16;         // how far a hat may sink into short hair or rise over big hair (m)
  // The four face shapes (character.js CHAR.slots.face): a mesh each, the oval's have no suffix. `fit` is how much wider, taller and
  // deeper the head is than the oval's, as a stretch for what sits on it (hair, worn extras: toon.js uStretch): the hair kit was built
  // on the oval.
  const SHAPES = { oval: { fit: [1, 1, 1] }, round: { fit: [1.05, 0.985, 1.05] }, heart: { fit: [1.015, 1, 1.015] }, wide: { fit: [1.07, 0.98, 1.07] } };
  const headName = id => id === 'oval' ? 'Head' : 'Head_' + id;
  const overlayName = id => id === 'oval' ? 'Face_overlay' : 'Face_overlay_' + id;
  const HAIR_SHINE = 0.26, HAIR_SHINE_AT = 0.955;   // the glossy streak on the hair: how white, and how big (higher = smaller)
  const HAIR_SHADE = 0.74;                         // hair's shadow side (darker than cloth: hair is a deeper mass)
  const HAIR_ROUND = 0.35;                         // locks are lit partly as one round mass (big light and shadow shapes)
  const HAIR_LINE = 0.5;                           // hair's outline is darker than others: it draws the lines between locks
  const HAIR_CREASE = [0.78, 0.5];                 // the dark line along the edges of every lock (hair.py `across`): its multiplier on dark / on light hair
  const HAIR_LIFT = 0.03;                          // black hair's sunny side is this much lighter (linear light), so a lock reads as a shape on it
  const HAIR_BAND = [0.55, 0.42];                  // the white band on some locks (hair.py `gloss`): how white on dark / on light hair
  const HAIR_DEEP = 0.52;                          // the gaps between locks and their undersides (hair.py: `lit`)
  const ROUND_NORMALS = 0.85;                      // 0 = the modelled normals, 1 = a perfect sphere
  const SKIN_SHADOW = -0.65;                       // n . sun below this is in shadow; low, so only the jaw and the far cheek are
  const CLOTH_SHADOW = -0.4;
  const CLOTH_SHADE = 0.85;                        // the 2D art darkens cloth and hair by about 15 percent in shadow
  const SHOE_COLOUR = '#f7f7f7';
  const FABRIC_TILE_M = 0.0052;                    // metres per SVG unit of the pattern: a tile of the 2D pattern, this big on her
  // Palette codes of an outfit's vertices (COLOR_0.r * 32): the order is world/character-src/outfits.py CODES. 'fabric' is
  // the outfit colour with the pattern over it, 'plain' the outfit colour, 'dark' its shadow shade; the rest are fixed (as in character.js).
  const OUTFIT_CODES = ['fabric', 'plain', 'dark', 'white', 'gold', 'golddk', 'cream', 'creamdk', 'red', 'reddk', 'rb1', 'rb2', 'rb3', 'rb4', 'rb5', 'pink', 'pinkdk', 'whitedk',
    'hi', 'stitch', 'ribbon', 'pearl'];
  // D5: material of each outfit code, for toon.js uSheen: 1 satin (bows, ribbon, the tie, the belt's heart), 2 metal (buttons, belt, trims), 3 gloss (pearls).
  // D5: the same for the extras' palette names (extras.py PALETTE): metals shine hard, ribbon and wings softly, gems, lacquer and pearls in a small point.
  const EXTRA_SHEEN = { gold: 2, gold2: 2, goldbright: 2, golddk: 2, pink: 1, hot: 1, hotlight: 1, rose: 1, rosy: 1, blush: 1, wandpink: 1, ribbonw: 1, wing1: 1, wing2: 1, wing3: 1, wing4: 1,
    ruby: 3, sapph: 3, emer: 3, ice: 3, crystal: 3, navy: 3, plum: 3, demon: 3, dragon: 3, pearl: 3, white: 0 };
  const SPIKY = ['Hair_mohawk', 'Hair_messy'], HATS = ['hat', 'wizard-hat', 'sorting-hat'];   // hair whose spikes poke through a hat, and the hats
  const LENS_OPACITY = 0.34;                       // glasses: how much of the tint covers her eyes
  const OUTFIT_SHEEN = { gold: 2, golddk: 2, red: 1, pink: 1, pinkdk: 1, ribbon: 1, pearl: 3 };
  const OUTFIT_FIXED = { white: '#ffffff', gold: '#F5C542', golddk: '#B8860B', cream: '#FFF6EE', creamdk: '#CDBFD0', red: '#B3202A', reddk: '#6E1018',
    rb1: '#FF5E5E', rb2: '#FFA94D', rb3: '#FFE14D', rb4: '#6BD66B', rb5: '#4DB8FF', pink: '#FF6FA3', pinkdk: '#C44A78', whitedk: '#D9D2E0', ribbon: '#FFFFFF', pearl: '#FFF8F2' };
  // 'hi' and 'stitch' are the outfit colour lightened (the light companion of a seam, the thread of a stitch row): they follow every recolour.
  const OUTFIT_LIGHTEN = { hi: 0.4, stitch: 0.85 };
  const outfitColour = (name, vars) => name === 'fabric' || name === 'plain' ? vars['--clothing'] : name === 'dark' ? vars['--clothing-dk']
    : OUTFIT_LIGHTEN[name] ? new T.Color(vars['--clothing']).lerp(new T.Color('#ffffff'), OUTFIT_LIGHTEN[name]) : OUTFIT_FIXED[name];

  function parse(name) {
    return new Promise((resolve, reject) => new T.GLTFLoader().parse(WORLD_PACKS.decode('character', name), '', resolve, reject));
  }

  // Cartoon faces are shaded as if they were round: each normal is pulled toward "straight out from the
  // middle of the head", so the shadow edge is one clean arc instead of following every bump of the cheek.
  // (The outline uses the same normals; rounder is better there too.)
  function spherize(mesh, amount, around = null) {
    const g = mesh.geometry;
    if (g.userData.spherized) return;
    g.computeBoundingBox();
    const centre = around || g.boundingBox.getCenter(new T.Vector3());
    const pos = g.attributes.position, nor = g.attributes.normal, v = new T.Vector3(), n = new T.Vector3();
    for (let i = 0; i < pos.count; i++) {
      v.fromBufferAttribute(pos, i).sub(centre).normalize();
      n.fromBufferAttribute(nor, i).lerp(v, amount).normalize();
      nor.setXYZ(i, n.x, n.y, n.z);
    }
    nor.needsUpdate = true;
    g.userData.spherized = true;
  }

  // Parsed once; every copy shares the geometry and the clips.
  async function load() {
    if (!assets) {
      const [model, clips] = await Promise.all([parse('model'), parse('clips')]);
      model.scene.traverse(o => { if (o.material) o.material.metalness = 0; });   // glTF defaults can render black without an environment map
      const pal = model.scene.getObjectByName('Extras_palette');
      const palette = pal ? { entries: JSON.parse(pal.userData.palette), steps: pal.userData.steps } : null;
      for (const n of [...Object.keys(SHAPES).map(headName), 'Hair_placeholder']) spherize(model.scene.getObjectByName(n), ROUND_NORMALS);
      assets = { body: model.scene, clips: clips.animations, palette };
    }
    return assets;
  }

  function canvasTexture(canvas, renderer, alpha) {
    const t = new T.CanvasTexture(canvas);
    t.colorSpace = T.SRGBColorSpace;
    t.flipY = false;                       // glTF UVs have their origin at the top left, like a canvas
    t.premultiplyAlpha = alpha;
    t.generateMipmaps = true;
    t.minFilter = T.LinearMipmapLinearFilter;
    t.anisotropy = renderer ? renderer.capabilities.getMaxAnisotropy() : 1;
    t.wrapS = t.wrapT = T.ClampToEdgeWrapping;
    t.needsUpdate = true;
    return t;
  }

  // `outlinePx`: outline width in pixels at 768 px tall (the small picture in the dress-up page wants thicker ones).
  async function create({ outlinePx = OUTLINE_PX } = {}) {
    const a = await load();
    const model = T.SkeletonUtils.clone(a.body);       // a plain clone() would stay bound to the original's bones
    const mixer = new T.AnimationMixer(model);
    const actions = {};
    for (const clip of a.clips) actions[clip.name] = mixer.clipAction(clip);
    let current = null;
    const part = n => model.getObjectByName(n);
    const look = { outlinePx, tex: null, mats: null, outlines: [], blinkLeft: 0, faceMode: 'over', pattern: null, palette: null, face: 'oval', hairScale: { x: 1, y: 1 } };

    const c = {
      model, mixer, actions,
      clips: a.clips.map(c => c.name),
      get playing() { return current && current.getClip().name; },
      get look() { return look; },
      // Crossfade to a clip (the first call just starts it).
      play(name, fade = 0.2) {
        const next = actions[name];
        if (!next) throw new Error('No clip ' + name);
        if (next === current) return;
        next.reset().play();
        if (current) current.crossFadeTo(next, fade, false);
        current = next;
      },
      // Freeze on a moment of a clip, for pictures.
      pose(name, seconds) {
        c.play(name, 0);
        actions[name].time = seconds;
        mixer.update(0);
      },
      update(dt) {
        mixer.update(dt);
        if (look.blinkLeft > 0) {
          look.blinkLeft -= dt;
          if (look.blinkLeft <= 0) setOverTexture(look.tex.over.open);
        }
      },

      // Her face and colours from the live dress-up game. Draws the SVG again, so call it when the
      // look changed (the world does on every open), not every frame.
      // `redraw` ({ face, cloth }) says which pictures to draw again; the colours are always updated. The
      // dress-up page passes what changed, so a new lipstick does not redraw the dress. The first call draws both.
      // `want` is whose look it is: the live state (hers, drawn from the live dress-up svg) or any look object
      // (a friend's, from randomLook; drawn from lookSvgText). Nothing else is read, also after the awaits, and hers is never touched.
      // `opts.faceScale` (0.5, say) draws the face pictures smaller, for characters that are seen small. `opts.sad` also draws the face
      // crying (setSad: the friends, social.js).
      async dress(renderer, redraw = {}, want = state, opts = {}) {
        const vars = colorVars(want);
        const first = !look.tex;
        const wantFace = first || redraw.face !== false, wantCloth = first || redraw.cloth !== false;
        const rainbow = typeof CHAR.colors.hair[want.hairIdx] === 'object';       // the rainbow is a gradient, not a colour
        look.lookSource = want === state ? null : want;                            // where userPlace reads the Extras' sizes and places
        const svgText = want === state || !(wantFace || wantCloth || rainbow) ? null : lookSvgText(want);
        const [face, pattern, rainbowPic] = await Promise.all([wantFace ? FACETEX.renderFace(svgText, { faceScale: opts.faceScale || 1, sad: !!opts.sad }) : null,
          wantCloth ? FACETEX.renderPattern(want.clothingPattern, svgText) : null,
          rainbow && !look.rainbow ? FACETEX.renderRainbow(svgText) : null]);
        if (rainbowPic) look.rainbow = canvasTexture(rainbowPic, renderer, false);
        look.white = look.white || canvasTexture(Object.assign(document.createElement('canvas'), { width: 1, height: 1 }), renderer, false);
        if (!look.whiteDrawn) { const g = look.white.image.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, 1, 1); look.whiteDrawn = look.white.needsUpdate = true; }
        const old = look.tex;
        look.tex = {
          base: face ? canvasTexture(face.base, renderer, false) : old.base,
          over: face ? { open: canvasTexture(face.over.open, renderer, true), blink: canvasTexture(face.over.blink, renderer, true) } : old.over,
          sad: face ? face.sad && canvasTexture(face.sad, renderer, false) : old.sad,
        };
        if (wantCloth) {                              // the fabric pattern: one tile, premultiplied, repeated; none = a clear texel
          if (look.pattern) look.pattern.dispose();
          look.pattern = null;
          if (pattern) {
            look.pattern = canvasTexture(pattern.canvas, renderer, true);
            look.pattern.wrapS = look.pattern.wrapT = T.RepeatWrapping;
            look.patternScale = 1 / (pattern.period * FABRIC_TILE_M);
          }
        }
        const skinLight = vars['--skin'], skinDark = vars['--skin-dk'];
        let hairColour = vars['--brow'], hairDark = shade(vars['--brow'], HAIR_LINE);
        if (want.hair === 'baldish') {   // the 2D picture shows only a faint tint where the hair would be
          hairColour = '#' + new T.Color(hairColour).lerp(new T.Color(vars['--skin']), 0.82).getHexString(T.SRGBColorSpace);
          hairDark = vars['--skin-dk'];
        }   // --brow is the hair's plain colour; the rainbow is a picture on the hair (renderRainbow)
        if (!look.clear) look.clear = canvasTexture(Object.assign(document.createElement('canvas'), { width: 1, height: 1 }), renderer, true);
        if (!look.palette) look.palette = Array.from({ length: 24 }, () => new T.Color());
        OUTFIT_CODES.forEach((name, i) => look.palette[i].set(outfitColour(name, vars)));
        const skinShade = TOON.shadeOf(skinLight, skinDark);

        if (!look.mats) {
          look.mats = {
            head: TOON.material({ color: '#ffffff', map: look.tex.base, shade: skinShade, threshold: SKIN_SHADOW }),
            over: TOON.material({ color: '#ffffff', map: look.tex.over.open, bias: FACE_BIAS[look.faceMode], transparent: true, premultiplied: true }),
            hair: TOON.material({ color: hairColour, map: look.white, shade: TOON.shadeBy(HAIR_SHADE), spec: HAIR_SHINE, specAt: HAIR_SHINE_AT, deep: HAIR_DEEP, round: HAIR_ROUND, lock: true }),
            body: TOON.material({ color: skinLight, shade: skinShade, threshold: SKIN_SHADOW }),
            shoe: TOON.material({ color: SHOE_COLOUR, shade: TOON.shadeBy(CLOTH_SHADE), threshold: CLOTH_SHADOW }),
            outfit: TOON.material({ color: '#ffffff', palette: look.palette, fabric: look.pattern || look.clear, shade: TOON.shadeBy(CLOTH_SHADE), threshold: CLOTH_SHADOW,
              sheen: Float32Array.from(look.palette, (_, i) => OUTFIT_SHEEN[OUTFIT_CODES[i]] || 0) }),
          };
          look.mats.over.uniforms.uUvScale.value.fromArray(face.overUv.scale);     // the band of the frame never changes, so only the first picture sets it
          look.mats.over.uniforms.uUvOffset.value.fromArray(face.overUv.offset);
          const meshes = { Body: 'body', Shoe_L: 'shoe', Shoe_R: 'shoe' };
          for (const id of Object.keys(SHAPES)) { meshes[headName(id)] = 'head'; meshes[overlayName(id)] = 'over'; }
          look.hairNames = [];
          look.outfitNames = [];
          model.traverse(o => {
            if (!o.isMesh) return;
            if (/^Hair_/.test(o.name)) { meshes[o.name] = 'hair'; look.hairNames.push(o.name); }
            if (/^Outfit_/.test(o.name)) { meshes[o.name] = 'outfit'; look.outfitNames.push(o.name); }
          });
          for (const [name, mat] of Object.entries(meshes)) {
            const m = part(name);
            m.material = look.mats[mat];
            TOON.trackViewport(m);
          }
          for (const id of Object.keys(SHAPES)) part(overlayName(id)).renderOrder = 2;
          // An outline for every mass (not the eyes' shell), in a darker shade of its own fill.
          const outlined = { Body: skinDark, Shoe_L: shade(SHOE_COLOUR), Shoe_R: shade(SHOE_COLOUR) };
          for (const id of Object.keys(SHAPES)) outlined[headName(id)] = skinDark;
          for (const n of look.hairNames) outlined[n] = hairDark;
          look.outfitOutline = {};                      // the outline of a piece is a palette colour (the mesh's `outline`); flat decals have none
          for (const n of look.outfitNames) {
            const ud = part(n).userData;
            if (ud.decal) continue;
            look.outfitOutline[n] = ud.outline || 'dark';
            outlined[n] = outfitColour(look.outfitOutline[n], vars);
          }
          look.outlines = Object.entries(outlined).map(([name, colour]) => { const o = TOON.addOutline(part(name), colour, outlinePx); o.userData.of = name; return o; });
          if (a.palette) c.buildExtras(skinLight, skinDark, skinShade);
        } else {
          const M = look.mats;
          M.head.uniforms.uMap.value = look.sad && look.tex.sad ? look.tex.sad : look.tex.base;
          M.head.uniforms.uShade.value.copy(skinShade);
          M.over.uniforms.uMap.value = look.sad ? look.tex.over.blink : look.tex.over.open;
          M.hair.uniforms.uColor.value.set(hairColour);
          M.body.uniforms.uColor.value.set(skinLight);
          M.body.uniforms.uShade.value.copy(skinShade);
          const colours = { Body: skinDark };
          for (const id of Object.keys(SHAPES)) colours[headName(id)] = skinDark;
          for (const n of look.hairNames) colours[n] = hairDark;
          for (const [n, name] of Object.entries(look.outfitOutline)) colours[n] = outfitColour(name, vars);
          for (const o of look.outlines) if (colours[o.userData.of]) o.material.uniforms.uColor.value.set(colours[o.userData.of]);
        }
        if (look.extras) c.colourExtras(vars, skinLight, skinDark, skinShade);
        look.mats.outfit.uniforms.uFabric.value = look.pattern || look.clear;
        look.mats.outfit.uniforms.uFabricOn.value = look.pattern ? 1 : 0;
        look.mats.outfit.uniforms.uFabricScale.value = look.patternScale || 1;
        c.setOutfit(want.clothing);
        look.mats.hair.uniforms.uMap.value = rainbow ? look.rainbow : look.white;
        if (rainbow) look.mats.hair.uniforms.uColor.value.set('#ffffff');
        {   // lock lines and gloss bands: dark hair gets a lighter band (a dark line does not show on it), light hair a darker line
          const hu = look.mats.hair.uniforms, c = rainbow ? new T.Color('#9a7ac0') : new T.Color(hairColour);
          const k = T.MathUtils.smoothstep(c.r * 0.2126 + c.g * 0.7152 + c.b * 0.0722, 0.02, 0.5);
          hu.uCrease.value = T.MathUtils.lerp(HAIR_CREASE[0], HAIR_CREASE[1], k);
          hu.uBand.value = T.MathUtils.lerp(HAIR_BAND[0], HAIR_BAND[1], k);
          hu.uLift.value = HAIR_LIFT * (1 - T.MathUtils.smoothstep(c.r * 0.2126 + c.g * 0.7152 + c.b * 0.0722, 0.004, 0.05));
        }
        c.setHair(want.hair);
        c.setFace(want.face);
        const hs = (want.scales && want.scales.hair) || { x: 1, y: 1 };
        c.setHairScale(hs.x, hs.y);               // the Adjust sliders
        c.setExtras(want.accessories);
        if (old) {
          if (face) { old.base.dispose(); old.over.open.dispose(); old.over.blink.dispose(); if (old.sad) old.sad.dispose(); }
        }
        return c;
      },

      // Show one outfit (its id in character.js), and hide the rest. The default dress if there is no such outfit.
      setOutfit(id) {
        const has = n => look.outfitNames.some(o => o.startsWith('Outfit_' + n + '_'));
        const want = 'Outfit_' + (has(id) ? id : 'dress') + '_';
        model.traverse(o => { if (/^Outfit_/.test(o.name.replace(/_outline$/, ''))) o.visible = o.name.startsWith(want); });
        look.outfit = id;
      },

      // Show one hair style (its id in character.js), and hide the rest. One that has no model yet shows the plain bob.
      setHair(id) {
        const want = look.hairNames.includes('Hair_' + id) ? 'Hair_' + id : 'Hair_placeholder';
        model.traverse(o => { if (/^Hair_/.test(o.name.replace(/_outline$/, ''))) o.visible = o.name.replace(/_outline$/, '') === want; });
        look.hair = want;
        placeExtras();
      },

      // Show these extras (ids as in character.js) and hide the rest.
      setExtras(ids) {
        look.extraIds = ids || [];
        for (const it of Object.values(look.extras || {})) for (const m of it.meshes) m.visible = look.extraIds.includes(it.id);
        placeExtras();
      },

      // Show one face shape (oval, round, heart, wide), and hide the rest. The hair is stretched to fit it.
      setFace(id) {
        if (!SHAPES[id]) id = 'oval';
        model.traverse(o => {
          const n = o.name.replace(/_outline$/, '');
          for (const s of Object.keys(SHAPES)) if (n === headName(s) || n === overlayName(s)) o.visible = s === id;
        });
        look.face = id;
        c.setHairScale(look.hairScale.x, look.hairScale.y);
      },

      // Make the hair wider / taller about the middle of the head (the Adjust sliders), in the vertex shader. What fits the
      // face shape comes on top of it.
      setHairScale(w, h) {
        look.hairScale = { x: w, y: h };
        const mid = look.headMid || (look.headMid = part('Head').geometry.boundingBox.getCenter(new T.Vector3()));
        const fit = SHAPES[look.face || 'oval'].fit;
        const mats = [look.mats.hair, ...look.outlines.filter(o => /^Hair_/.test(o.userData.of)).map(o => o.material)];
        const hg = part('Head').geometry.boundingBox, he = hg.getSize(new T.Vector3()).multiplyScalar(0.5);
        const shrink = Math.min(w * fit[0], h * fit[1], w * fit[2]) < 0.995 ? 1 : 0;      // smaller than modelled: toon.js keeps it on the head
        for (const m of mats) {
          m.uniforms.uStretch.value.set(w * fit[0], h * fit[1], w * fit[2]); m.uniforms.uStretchAt.value.copy(mid);
          m.uniforms.uShrink.value = shrink; m.uniforms.uCrownY.value = hg.max.y - mid.y; m.uniforms.uHeadE.value.copy(he);
        }
        placeExtras();
      },

      // 'over': eyes and brows are drawn over the fringe, as in the 2D art. 'under': the fringe covers them.
      setFaceMode(mode) {
        look.faceMode = mode;
        if (look.mats) look.mats.over.uniforms.uBias.value = FACE_BIAS[mode];
      },
      blink(seconds = 0.15) {
        if (!look.tex || look.sad) return;
        setOverTexture(look.tex.over.blink);
        look.blinkLeft = seconds;
      },

      // Crying (a friend, social.js): the sad face picture (dress with opts.sad) and the eyes shut, until setSad(false).
      setSad(on) {
        look.sad = !!on;
        if (!look.mats) return;
        look.mats.head.uniforms.uMap.value = on && look.tex.sad ? look.tex.sad : look.tex.base;
        look.blinkLeft = 0;
        setOverTexture(on ? look.tex.over.blink : look.tex.over.open);
      },

      dispose() {
        mixer.stopAllAction();
        model.traverse(o => { if (o.isSkinnedMesh) o.skeleton.dispose(); });
        if (look.tex) { look.tex.base.dispose(); look.tex.over.open.dispose(); look.tex.over.blink.dispose(); if (look.tex.sad) look.tex.sad.dispose(); }
        if (look.pattern) look.pattern.dispose();
        if (look.clear) look.clear.dispose();
        for (const m of Object.values(look.mats || {})) m.dispose();
        if (look.white) look.white.dispose();
        if (look.rainbow) look.rainbow.dispose();
        for (const o of look.outlines) o.material.dispose();
      },
    };

    function setOverTexture(t) { if (look.mats) look.mats.over.uniforms.uMap.value = t; }

    // ── Extras ──────────────────────────────────────────────────────────────────────────────────────────
    // Each extra is one to three meshes (and their outlines) with materials of their own, so each can be stretched and
    // moved on its own (the face shape, the hair's height).
    function buildExtras(skinLight, skinDark, skinShade) {
      const pal = a.palette;
      look.xFill = pal.entries.map(() => new T.Color());
      look.xLine = pal.entries.map(() => new T.Color());
      look.extras = {};
      const meshes = [];
      model.traverse(o => { if (o.isSkinnedMesh && /^Extra_/.test(o.name)) meshes.push(o); });
      for (const m of meshes) {
        const [, id, kind = 'main'] = m.name.split('_');
        const it = look.extras[id] || (look.extras[id] = { id, group: m.userData.group, lift: m.userData.lift === undefined ? 1 : m.userData.lift, meshes: [], outlines: [], mats: [], skinMats: [] });
        let mat, line;
        if (kind === 'lens') {                                   // glasses: a tinted see-through disc over each eye, no outline
          mat = TOON.material({ color: '#ffffff', palette: look.xFill, paletteSteps: pal.steps, flatCode: true, shade: new T.Vector3(1, 1, 1), threshold: -2, bias: FRONT_BIAS - 0.02, transparent: true, opacity: LENS_OPACITY });
          m.material = mat;
          m.renderOrder = 3;
          TOON.trackViewport(m);
          it.meshes.push(m);
          it.mats.push(mat);
          m.visible = false;
          continue;
        }
        if (kind === 'skin') {
          mat = TOON.material({ color: skinLight, shade: skinShade, threshold: SKIN_SHADOW });
          line = TOON.addOutline(m, skinDark, look.outlinePx);
          it.skinMats.push(mat, line.material);
        } else {
          mat = TOON.material({ color: '#ffffff', palette: look.xFill, paletteSteps: pal.steps, flatCode: true, shade: TOON.shadeBy(CLOTH_SHADE), threshold: CLOTH_SHADOW, bias: kind === 'front' ? FRONT_BIAS : 0,
            sheen: Float32Array.from(pal.entries, ([name]) => EXTRA_SHEEN[name] || 0) });
          line = TOON.addOutline(m, '#000000', look.outlinePx, { colours: look.xLine, steps: pal.steps, flat: true });
          if (kind === 'front') line.material.uniforms.uBias.value = FRONT_BIAS;
        }
        m.material = mat;
        TOON.trackViewport(m);
        line.userData.of = m.name;
        it.meshes.push(m, line);
        it.mats.push(mat, line.material);
        m.visible = line.visible = false;
      }
    }

    function colourExtras(vars, skinLight, skinDark, skinShade) {
      a.palette.entries.forEach(([, fill, line], i) => {
        look.xFill[i].set(fill.startsWith('--') ? vars[fill] : fill);
        look.xLine[i].set(line.startsWith('--') ? vars[line] : line);
      });
      for (const it of Object.values(look.extras)) {
        for (const m of it.skinMats) {
          if (m.defines.OUTLINE === undefined) { m.uniforms.uColor.value.set(skinLight); m.uniforms.uShade.value.copy(skinShade); }
          else m.uniforms.uColor.value.set(skinDark);
        }
      }
    }

    // How high the hair's crown stands over the middle of the head (m), measured on the hair's own mesh once.
    function crownHeight(hairName) {
      const cache = look.crown || (look.crown = {});
      if (cache[hairName] === undefined) {
        const mesh = part(hairName), pos = mesh.geometry.attributes.position, mid = headMid();
        let top = -1;
        for (let i = 0; i < pos.count; i++) {
          if (Math.hypot(pos.getX(i) - mid.x, pos.getZ(i) - mid.z) < 0.17) top = Math.max(top, pos.getY(i) - mid.y);
        }
        cache[hairName] = top;
      }
      return cache[hairName];
    }
    function headMid() { return look.headMid || (look.headMid = part('Head').geometry.boundingBox.getCenter(new T.Vector3())); }

    // What she did to an extra in the Extras tab (size sliders, dragging), in metres about the middle of the head; null if nothing.
    const M_PER_UNIT = 0.8 / 248;                      // the 2D face: 248 units are 0.8 m (world/character-src/build.py K)
    function userPlace(id) {
      const src = look.lookSource || state;                // the look this character was dressed in; the live state for her
      if (typeof src !== 'object' || !src.scales || !src.offsets) return null;
      const sc = src.scales['accessories::' + id], of = src.offsets['accessories::' + id];
      if (!sc && !of) return null;
      const sx = sc ? sc.x : 1, sy = sc ? sc.y : 1, dx = of ? of.x : 0, dy = of ? of.y : 0;
      if (sx === 1 && sy === 1 && !dx && !dy) return null;
      const opt = CHAR.slots.accessories.options.find(o => o.id === id);
      const pv = (opt && opt.pivot) || [200, 204];
      return { sx, sy, pivot: [(pv[0] - 200) * M_PER_UNIT, (204 - pv[1]) * M_PER_UNIT], dx: dx * M_PER_UNIT, dy: -dy * M_PER_UNIT };
    }

    // Fit every extra to the head: stretched like the hair for the face shape, and what is on top lifted onto her hair.
    function placeExtras() {
      if (!look.extras) return;
      const mid = headMid(), fit = SHAPES[look.face || 'oval'].fit;
      const hs = look.hairScale, crown = crownHeight(look.hair || 'Hair_placeholder') * hs.y * fit[1];
      const lift = Math.min(Math.max(crown - HAIR_TOP, LIFT_MIN), LIFT_MAX);
      // D6: spiky hair (mohawk, messy) would poke through a hat's cone and brim: what is higher than the brim is cut away.
      let clip = 1e4;
      if (SPIKY.includes(look.hair)) {
        for (const id of HATS) {
          const it = look.extras[id];
          if (!it || !(look.extraIds || []).includes(id)) continue;
          const g = it.meshes[0].geometry;
          if (!g.boundingBox) g.computeBoundingBox();
          clip = Math.min(clip, mid.y + (g.boundingBox.min.y - mid.y) * fit[1] + lift * it.lift + 0.015);
        }
      }
      for (const m of [look.mats.hair, ...look.outlines.filter(o => /^Hair_/.test(o.userData.of)).map(o => o.material)]) m.uniforms.uClipAbove.value = clip;
      for (const it of Object.values(look.extras)) {
        const onHead = it.group === 'top' || it.group === 'face' || it.group === 'ear';
        // p' = at + (p - at) * stretch + shift, with at = 0: the face shape's fit about the middle of the head, then her own size and
        // place for this extra (the Extras tab's sliders and dragging, about the extra's pivot), then the lift onto her hair.
        const st = new T.Vector3(1, 1, 1), sh = new T.Vector3();
        if (onHead) {
          st.set(...fit);
          sh.set(mid.x * (1 - fit[0]), mid.y * (1 - fit[1]) + (it.group === 'top' ? lift * it.lift : 0), mid.z * (1 - fit[2]));
          const own = userPlace(it.id);
          if (own) {
            const piv = new T.Vector3(mid.x + own.pivot[0], mid.y + own.pivot[1], mid.z);
            const k = new T.Vector3(own.sx, own.sy, (own.sx + own.sy) / 2);
            // x -> piv + (x - piv) * k + offset, applied to what is there already (st * p + sh)
            st.multiply(k);
            sh.multiply(k).add(piv.clone().multiply(new T.Vector3(1 - k.x, 1 - k.y, 1 - k.z))).add(new T.Vector3(own.dx, own.dy, 0));
          }
        }
        for (const m of it.mats) {
          m.uniforms.uStretch.value.copy(st);
          m.uniforms.uStretchAt.value.set(0, 0, 0);
          m.uniforms.uShift.value.copy(sh);
        }
      }
    }
    // How far her hair and what she wears on her head stick out, in metres in the model's frame: { top: the highest point, half: the widest
    // half width }, for framing the dressing room's camera (the face tabs zoom in, but must not cut off a hat or a big hairdo). The
    // hair counts with its size sliders and the face shape's fit; extras on the head (and the ears) with the hair's lift and their own size.
    function extent() {
      const mid = headMid(), fit = SHAPES[look.face || 'oval'].fit, hs = look.hairScale;
      const hb = part(look.hair || 'Hair_placeholder').geometry.boundingBox || (part(look.hair || 'Hair_placeholder').geometry.computeBoundingBox(), part(look.hair || 'Hair_placeholder').geometry.boundingBox);
      const headTop = part('Head').geometry.boundingBox.max.y, headHalf = part('Head').geometry.boundingBox.max.x;
      let top = Math.max(mid.y + (hb.max.y - mid.y) * hs.y * fit[1], headTop), half = Math.max(Math.max(-hb.min.x, hb.max.x) * hs.x * fit[0], headHalf * fit[0]);
      const crown = crownHeight(look.hair || 'Hair_placeholder') * hs.y * fit[1];
      const lift = Math.min(Math.max(crown - HAIR_TOP, LIFT_MIN), LIFT_MAX);
      for (const it of Object.values(look.extras || {})) {
        if (!(look.extraIds || []).includes(it.id) || !['top', 'face', 'ear'].includes(it.group)) continue;
        const g = it.meshes[0].geometry;
        if (!g.boundingBox) g.computeBoundingBox();
        const own = userPlace(it.id), sx = own ? own.sx : 1, sy = own ? own.sy : 1;
        top = Math.max(top, mid.y + (g.boundingBox.max.y - mid.y) * fit[1] * sy + (it.group === 'top' ? lift * it.lift : 0) + (own ? own.dy : 0));
        half = Math.max(half, Math.max(-g.boundingBox.min.x, g.boundingBox.max.x) * fit[0] * sx + (own ? Math.abs(own.dx) : 0));
      }
      return { top, half, mid: mid.y };
    }
    c.extent = extent;
    c.placeExtras = placeExtras;
    c.buildExtras = buildExtras;
    c.colourExtras = colourExtras;
    return c;
  }

  window.CHARACTER3D = { load, create };
})();
