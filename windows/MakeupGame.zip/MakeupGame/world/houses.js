// The front doors (makeupgame-hfl.2): going into a house and coming out again.
//
// The houses are closed shells. Each has a door (layout.js: building.door) with a lantern above it. When she comes within
// reach the lantern lights, the door glows and pulses softly, and a pool of light spreads on the ground in front of it; when
// she walks away it all fades out again. She goes in when she pushes into the door (walking or holding a key toward it,
// inside its width) or when a left tap hits the door while she is within reach. A tap on the door from further away is an
// ordinary walk-to tap. Going in is immediate: WORLD.enter() switches the scene in the same call.
//
// Inside is another place (world.js: places) with a door of its own that takes her back out to building.door.spawnOutside,
// facing away from the house, with the outdoor camera reset to the usual view. The entry spot is the same every time: the
// inside door's spawn inside, the outside door's spawnOutside outside.
//
// The room behind each door comes from `INTERIOR_BUILDERS`: furnishedRoom builds the four rooms of house-west from
// world/interior.js (makeupgame-hfl.4); the other houses still get bareRoom, one bare test room (floor, four walls, a door),
// until their own interior exists (hfl.7). A builder is fn(building) -> { def, exit, ready? }:
//   def   what WORLD.addPlace takes: { id, scene (with its own lights), solids, standOn, edge, start, camBlockers, ... }
//   ready optional promise: the furniture models are in (they are parsed after the room is built)
//   exit  the door inside: { x, z, nx, nz, width, height, groundY, spawn: { x, z, facing } }. (x, z) is where the door meets
//         the room's floor, (nx, nz) the way it faces into the room, spawn where she stands when she comes in.
// Classic script (no modules).
(function () {
  const T = window.THREE;
  const WARM = new T.Color(0xffb347);
  const smooth = (a, b, k) => a + (b - a) * k;

  // ── What a lit door looks like: the glow on the door, a pool of light before it, a halo round the lantern ──
  function softTexture(draw) {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    draw(c.getContext('2d'));
    const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; return t;
  }
  let textures = null;
  function glowTextures() {
    if (textures) return textures;
    const radial = stops => softTexture(g => {
      const grad = g.createRadialGradient(64, 64, 2, 64, 64, 62);
      stops.forEach(([at, col]) => grad.addColorStop(at, col));
      g.fillStyle = grad; g.fillRect(0, 0, 128, 128);
    });
    textures = {
      halo: radial([[0, 'rgba(255,230,160,1)'], [0.25, 'rgba(255,190,90,0.55)'], [1, 'rgba(255,170,60,0)']]),
      pool: radial([[0, 'rgba(255,200,110,0.9)'], [0.55, 'rgba(255,180,80,0.35)'], [1, 'rgba(255,170,60,0)']]),
      // the door itself: a warm panel that is brightest in the middle and soft at its edges
      panel: softTexture(g => {
        const v = g.createLinearGradient(0, 0, 0, 128);
        v.addColorStop(0, 'rgba(255,190,90,0.0)'); v.addColorStop(0.12, 'rgba(255,200,110,0.85)'); v.addColorStop(0.55, 'rgba(255,215,140,1)'); v.addColorStop(1, 'rgba(255,190,90,0.7)');
        g.fillStyle = v; g.fillRect(0, 0, 128, 128);
        const h = g.createLinearGradient(0, 0, 128, 0);
        h.addColorStop(0, 'rgba(0,0,0,0.6)'); h.addColorStop(0.2, 'rgba(0,0,0,0)'); h.addColorStop(0.8, 'rgba(0,0,0,0)'); h.addColorStop(1, 'rgba(0,0,0,0.6)');
        g.globalCompositeOperation = 'destination-out'; g.fillStyle = h; g.fillRect(0, 0, 128, 128);
      }),
    };
    return textures;
  }
  const additive = map => new T.MeshBasicMaterial({ map, color: 0xffffff, transparent: true, opacity: 0, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide, fog: false });

  // A lantern hanging on an arm from the wall: dark iron cap and base, a glass body that lights. door.lantern is the middle of
  // the glass; (nx, nz) points away from the wall. Returns the glass material.
  function makeLantern(group, door) {
    const L = door.lantern, iron = new T.MeshLambertMaterial({ color: 0x3b3430 });
    const glass = new T.MeshLambertMaterial({ color: 0xc9b98a, emissive: 0x000000 });
    const lamp = new T.Group();
    lamp.position.set(L.x + door.nx * 0.42, L.y, L.z + door.nz * 0.42);
    const add = (geo, mat, y) => { const m = new T.Mesh(geo, mat); m.position.y = y; lamp.add(m); return m; };
    add(new T.BoxGeometry(0.32, 0.42, 0.32), glass, 0);
    add(new T.BoxGeometry(0.4, 0.06, 0.4), iron, -0.24);
    add(new T.ConeGeometry(0.28, 0.2, 4).rotateY(Math.PI / 4), iron, 0.31);
    add(new T.CylinderGeometry(0.012, 0.012, 0.3, 6), iron, 0.56);
    const arm = new T.Mesh(new T.BoxGeometry(0.07, 0.07, 0.5), iron);       // from the wall out over the lantern, along (nx, nz)
    arm.position.set(L.x + door.nx * 0.25, L.y + 0.7, L.z + door.nz * 0.25); arm.rotation.y = Math.atan2(door.nx, door.nz);
    group.add(lamp, arm);
    return glass;
  }

  // The pieces that light up, in `scene`. door: { x, z, nx, nz, width, height, groundY, lantern? { x, y, z } }.
  // Returns fn(level 0..1, seconds) that sets how lit they are (0 hides them).
  function makeGlow(scene, door) {
    const tex = glowTextures(), group = new T.Group();
    group.visible = false; group.name = 'door-glow';
    const yaw = Math.atan2(door.nx, door.nz);
    const panel = new T.Mesh(new T.PlaneGeometry(door.width * 0.72, door.height), additive(tex.panel));
    panel.position.set(door.x + door.nx * 0.05, door.height / 2 + door.groundY, door.z + door.nz * 0.05); panel.rotation.y = yaw;
    const pool = new T.Mesh(new T.PlaneGeometry(6, 6).rotateX(-Math.PI / 2), additive(tex.pool));
    pool.position.set(door.x + door.nx * 2.2, door.groundY + 0.07, door.z + door.nz * 2.2);
    group.add(panel, pool);
    let halo = null, glass = null;
    if (door.lantern) {
      glass = makeLantern(scene, door);                            // (always drawn; only its glass lights up)
      halo = new T.Sprite(new T.SpriteMaterial({ map: tex.halo, transparent: true, opacity: 0, blending: T.AdditiveBlending, depthWrite: false, fog: false }));
      halo.position.set(door.lantern.x + door.nx * 0.5, door.lantern.y, door.lantern.z + door.nz * 0.5); halo.scale.set(2.4, 2.4, 1);
      group.add(halo);
    }
    scene.add(group);
    const set = (level, seconds) => {
      const pulse = 0.5 + 0.5 * Math.sin(seconds * 3.2);          // a soft pulse, about two seconds a breath
      group.visible = level > 0.003;
      panel.material.opacity = level * (0.34 + 0.2 * pulse);
      pool.material.opacity = level * (0.5 + 0.12 * pulse);
      if (halo) halo.material.opacity = level * (0.75 + 0.2 * pulse);
      if (glass) {                                                  // the lantern's glass
        glass.emissive.setRGB(0, 0, 0).lerp(WARM, level);
        glass.emissiveIntensity = 1.1 + 0.35 * pulse;
      }
    };
    set.glass = glass;
    return set;
  }

  // ── The dollhouse camera inside (makeupgame-hfl.5) ───────────────────────────────────────────────────
  // A fixed view: yaw 0 (looking north into the house), pitch 55 degrees, never turned. The camera glides to frame the room she is in:
  // its distance is solved so the whole floor of the room, the back wall up to its top and her whole dressed height (hat, hair:
  // character3d extent()) stand inside the picture wherever she is in the room, at the screen's real aspect. Zoom steps (world.js
  // fixedView): 0 closer (follows her), 1 the room, 2 wider (toward the whole house). She is always kept in the picture, also in the
  // middle of a glide. Whatever stands between the camera and her (furniture, walls) fades to a ghost until it is out of the way, and so
  // do the units hung high on a wall while she is in another room (they would hang over that room's floor).
  // spec: { rooms: [{ x0, z0, x1, z1 }], bounds: { x0, z0, x1, z1 }, tall (the back wall's height), scene }
  const DOLL = {
    PITCH: (55 * Math.PI) / 180, TAN: Math.tan((22.5 * Math.PI) / 180),     // (the camera's field of view is 45 degrees)
    LEVELS: [0.62, 1, 1.5],            // distance factor at zoom steps 0 (closer), 1, 2 (wider)
    GLIDE: 2.6,                        // how quickly the camera settles on a room (per second); two filters one after the other, so it starts and ends softly
    KEEP: { x: 0.86, top: 0.9, bottom: 0.78 },     // where she must stay in the picture (ndc); the bottom keeps the buttons clear
    GHOST: 0.22, GHOST_RATE: 9,        // opacity of something in the way, and how fast it fades
  };
  // Project world point q seen from a camera at look + dist * (0, sin, cos) looking at look: ndc [x, y], or null behind the camera.
  function dollNdc(q, lx, lz, dist, aspect) {
    const s = Math.sin(DOLL.PITCH), c = Math.cos(DOLL.PITCH);
    const vx = q[0] - lx, vy = q[1] - dist * s, vz = q[2] - (lz + dist * c);
    const depth = -(vy * s + vz * c), up = vy * c - vz * s;
    if (depth < 0.05) return null;
    return [vx / (depth * DOLL.TAN * aspect), up / (depth * DOLL.TAN)];
  }
  // The look point and distance that frame a room (see above) at this aspect, for a character `top` high and `half` wide.
  function dollFrame(room, spec, aspect, top, half) {
    const b = spec.bounds, r = WORLD.HERO_RADIUS, K = DOLL.KEEP;
    const x0 = Math.max(room.x0, b.x0 + r), x1 = Math.min(room.x1, b.x1 - r), z0 = Math.max(room.z0, b.z0 + r), z1 = Math.min(room.z1, b.z1 - r);
    const pts = [];                                                           // [x, y, z, limit x, limit top, limit bottom]
    for (const x of [room.x0, room.x1]) for (const z of [room.z0, room.z1]) pts.push([x, 0, z, 0.97, 0.97, 0.78]);   // the floor of the room
    for (const x of [room.x0, room.x1]) pts.push([x, spec.tall, room.z0, 0.98, 0.98, 1]);                           // the back wall's top
    for (const x of [x0 - half, x1 + half]) for (const z of [z0, z1]) { pts.push([x, top, z, K.x, K.top, 1]); pts.push([x, 0, z, K.x, 1, K.bottom]); }
    const fits = (lx, lz, d) => pts.every(p => { const n = dollNdc(p, lx, lz, d, aspect); return n && Math.abs(n[0]) <= p[3] && n[1] <= p[4] && n[1] >= -p[5]; });
    let lx = (room.x0 + room.x1) / 2, lz = (room.z0 + room.z1) / 2, dist = 10;
    for (let it = 0; it < 8; it++) {
      let lo = 2, hi = 90;
      for (let k = 0; k < 28; k++) { const mid = (lo + hi) / 2; if (fits(lx, lz, mid)) hi = mid; else lo = mid; }
      dist = hi;
      let slackTop = Infinity, slackBottom = Infinity;                          // centre the picture: equal room above and below
      for (const p of pts) { const n = dollNdc(p, lx, lz, dist, aspect); slackTop = Math.min(slackTop, p[4] - n[1]); slackBottom = Math.min(slackBottom, n[1] + p[5]); }
      lz += ((slackTop - slackBottom) / 2) * dist * DOLL.TAN / Math.sin(DOLL.PITCH);
    }
    return { x: lx, z: lz, dist: dist * 1.02 };
  }
  const segHitsBox = (a, b, box) => {                                            // does the segment a -> b cross the box?
    let t0 = 0, t1 = 1;
    for (const k of ['x', 'y', 'z']) {
      const d = b[k] - a[k];
      if (Math.abs(d) < 1e-9) { if (a[k] < box.min[k] || a[k] > box.max[k]) return false; continue; }
      let u = (box.min[k] - a[k]) / d, v = (box.max[k] - a[k]) / d;
      if (u > v) [u, v] = [v, u];
      t0 = Math.max(t0, u); t1 = Math.min(t1, v);
      if (t0 > t1) return false;
    }
    return true;
  };
  function dollhouseRig(spec) {
    const st = { ready: false, look: { x: 0, z: 0 }, aim: { x: 0, z: 0, dist: 10 }, dist: 10, lvl: 1, frames: new Map(), key: '', top: 2.2, half: 0.4, since: 99, ghosts: null, ghostCount: -1 };
    const house = { x: (spec.bounds.x0 + spec.bounds.x1) / 2, z: (spec.bounds.z0 + spec.bounds.z1) / 2 };
    const roomOf = (x, z) => spec.rooms.find(r => x >= r.x0 && x <= r.x1 && z >= r.z0 && z <= r.z1)
      || spec.rooms.reduce((a, r) => { const d = Math.hypot(Math.max(r.x0 - x, 0, x - r.x1), Math.max(r.z0 - z, 0, z - r.z1)); return !a || d < a.d ? { r, d } : a; }, null).r;
    // Things that can get in the way: furniture items and walls, each with its own materials (a copy, so fading one fades only it).
    function ghostList() {
      const furniture = spec.scene.getObjectByName('furniture');
      // (only walls and furniture count: the scene also gains and loses effect sprites (steam, bubbles, Z z z) all the time, and rebuilding
      // the list for those reset every fade to opaque for a frame: the flicker of makeupgame-wio)
      const count = (furniture ? furniture.children.length : 0) + spec.scene.children.reduce((n, o) => n + (o.name.startsWith('wall-') ? 1 : 0), 0);
      if (st.ghosts && count === st.ghostCount) return st.ghosts;
      const before = new Map((st.ghosts || []).map(g => [g.obj, g]));          // a rebuilt list keeps what it knew of the pieces still there
      st.ghostCount = count; st.ghosts = [];
      const add = obj => {
        const box = new T.Box3().setFromObject(obj), mats = [];
        obj.traverse(o => { if (o.isMesh) mats.push(...[].concat(o.material)); });
        if (box.max.y < 0.45 || !mats.length) return;                           // rugs and the like never hide her
        const it = obj.userData && obj.userData.item;
        const old = before.get(obj);
        st.ghosts.push(old ? Object.assign(old, { box, mats }) : { obj, box, mats, level: 1, set: 1, unit: !!it && it.y >= 1.5, room: it && it.room, item: it });   // unit: a wall unit, hung up high
      };
      for (const o of spec.scene.children) if (o.name.startsWith('wall-')) add(o);
      if (furniture) for (const o of furniture.children) if (o.name.startsWith('item-')) add(o);
      return st.ghosts;
    }
    return function rig(dt, snap) {
      const camera = WORLD.parts.camera, pos = WORLD.parts.hero.group.position, model = WORLD.parts.hero.model;
      const aspect = camera.aspect, hx = pos.x, hz = pos.z;
      st.since += dt;
      if (snap || st.since > 0.5) {                                              // her dressed size (a new hat or hair shows within half a second)
        st.since = 0;
        const e = model && model.extent ? model.extent() : null;
        st.top = Math.max(WORLD.HERO_HEIGHT, e ? e.top * (model.model.scale.y || 1) + 0.08 : 0);
        st.half = Math.max(0.35, e ? e.half * (model.model.scale.x || 1) : 0);
      }
      const key = aspect.toFixed(3) + '/' + st.top.toFixed(2) + '/' + st.half.toFixed(2);
      if (key !== st.key) { st.key = key; st.frames.clear(); }
      const room = roomOf(hx, hz);
      let fr = st.frames.get(room);
      if (!fr) st.frames.set(room, fr = dollFrame(room, spec, aspect, st.top, st.half));
      // The zoom step, as a number that glides: 0 closer, 1 the room, 2 wider.
      const wantLvl = Math.round(WORLD.viewZoom * 2), kk = snap || !st.ready ? 1 : 1 - Math.exp(-6 * dt);
      st.lvl += (wantLvl - st.lvl) * kk;
      const near = Math.max(0, 1 - st.lvl), wide = Math.max(0, st.lvl - 1);
      const f = st.lvl <= 1 ? DOLL.LEVELS[0] + (1 - DOLL.LEVELS[0]) * st.lvl : 1 + (DOLL.LEVELS[2] - 1) * (st.lvl - 1);
      const tx = fr.x + (hx - fr.x) * near * 0.8 + (house.x - fr.x) * wide * 0.5;
      const tz = fr.z + (hz - fr.z) * near * 0.8 + (house.z - fr.z) * wide * 0.5;
      const k = snap || !st.ready ? 1 : 1 - Math.exp(-DOLL.GLIDE * dt);
      st.aim.x += (tx - st.aim.x) * k; st.aim.z += (tz - st.aim.z) * k; st.aim.dist += (fr.dist * f - st.aim.dist) * k;
      st.look.x += (st.aim.x - st.look.x) * k; st.look.z += (st.aim.z - st.look.z) * k; st.dist += (st.aim.dist - st.dist) * k;
      st.ready = true;
      // She stays in the picture, also in the middle of a glide: shift the look point if her feet or her head are out of bounds.
      const K = DOLL.KEEP;
      for (let it = 0; it < 4; it++) {
        const feet = dollNdc([hx, 0, hz], st.look.x, st.look.z, st.dist, aspect), head = dollNdc([hx, st.top, hz], st.look.x, st.look.z, st.dist, aspect);
        if (!feet || !head) break;
        const unit = st.dist * DOLL.TAN, side = Math.abs(feet[0]) > K.x ? feet[0] - Math.sign(feet[0]) * K.x : 0;
        const over = head[1] > K.top ? head[1] - K.top : 0, under = feet[1] < -K.bottom ? feet[1] + K.bottom : 0;
        if (!side && !over && !under) break;
        st.look.x += side * unit * aspect;
        st.look.z += (under - over) * unit / Math.sin(DOLL.PITCH);
      }
      const s = Math.sin(DOLL.PITCH), c = Math.cos(DOLL.PITCH);
      camera.position.set(st.look.x, st.dist * s, st.look.z + st.dist * c);
      camera.lookAt(st.look.x, 0, st.look.z);
      camera.updateMatrixWorld();
      // Fade what is between the camera and her (feet, middle, head), and bring back what is not.
      const from = camera.position, spots = [new T.Vector3(hx, 0.15, hz), new T.Vector3(hx, st.top * 0.5, hz), new T.Vector3(hx, st.top - 0.1, hz)];
      for (const g of ghostList()) {
        // (wall units, the hood and the like fade while she is in another room: from the camera they hang over the next room's floor)
        const using = window.WORLD_ROOMS && WORLD_ROOMS.using();      // the bed she lies in, the sofa she sits on (roomactions.js): stays as it is
        const inTheWay = !(using && g.item === using) && ((g.unit && g.room !== room.id) || spots.some(p => segHitsBox(from, p, g.box)));
        const want = inTheWay ? DOLL.GHOST : 1;
        g.level = snap ? want : g.level + (want - g.level) * (1 - Math.exp(-DOLL.GHOST_RATE * dt));
        if (Math.abs(g.level - want) < 0.01) g.level = want;
        if (g.level === g.set) continue;
        g.set = g.level;
        for (const m of g.mats) { m.transparent = g.level < 1; m.opacity = g.level; m.depthWrite = g.level >= 0.99; }
      }
      rig.state = st;
    };
  }

  // ── Doors that work: lit near, enter by pushing or by a near tap ──────────
  // door: { id, x, z, nx, nz, width, height, reach, groundY, lantern?, to, spawn }. (nx, nz) points to the side she
  // approaches from. `place` is the place the door is in; its updaters and taps carry the door.
  const doors = [];
  function addDoor(place, scene, door) {
    door.level = 0; door.entering = 0;
    const light = makeGlow(scene, door);
    door.glass = light.glass;                                      // the lantern's glass (null for a door without a lantern)
    const seconds = () => performance.now() / 1000;
    const hero = () => WORLD.parts.hero.group.position;
    const dist = () => { const p = hero(); return Math.hypot(p.x - door.x, p.z - door.z); };
    const enter = () => { door.entering++; WORLD.enter(door.to, door.spawn); };
    doors.push(door);

    place.updaters.push(dt => {
      const p = hero(), near = dist() <= door.reach;
      door.level = smooth(door.level, near ? 1 : 0, 1 - Math.exp(-5 * dt));
      if (!near && door.level < 0.003) door.level = 0;
      light(door.level, seconds());
      // Pushing into the door: against it (her edge touching it), inside its width, and trying to go on into it.
      const intent = WORLD.heroIntent;
      if (!intent) return;
      const rx = p.x - door.x, rz = p.z - door.z, depth = rx * door.nx + rz * door.nz, along = rx * -door.nz + rz * door.nx;
      if (Math.abs(along) <= door.width / 2 && depth >= -0.1 && depth <= WORLD.HERO_RADIUS + 0.12 && intent.x * door.nx + intent.z * door.nz <= -0.5) enter();
    });

    // A left tap on the door, from within reach (the ray meets the door's own plane inside its width and height).
    place.onTap.push(ray => {
      if (dist() > door.reach) return false;                       // from further away it is an ordinary walk-to tap
      const d = ray.direction.x * door.nx + ray.direction.z * door.nz;
      if (Math.abs(d) < 1e-6) return false;                        // edge on
      const t = ((door.x - ray.origin.x) * door.nx + (door.z - ray.origin.z) * door.nz) / d;
      if (t <= 0) return false;
      const x = ray.origin.x + ray.direction.x * t, y = ray.origin.y + ray.direction.y * t, z = ray.origin.z + ray.direction.z * t;
      const along = (x - door.x) * -door.nz + (z - door.z) * door.nx;
      if (Math.abs(along) > door.width / 2 || y < door.groundY || y > door.groundY + door.height + 0.3) return false;
      enter();
      return true;
    });
    return door;
  }

  // ── The bare test room behind each door (replaced by interior.js in makeupgame-hfl.4) ──────────────
  // 12 x 10 inside, one floor, four walls and a door in the south wall. The south wall (the camera's side) is only a knee-high stub
  // (the door as high as the stub) until the dollhouse camera exists (hfl.5), so the default camera sees into the room. A different tint per house, so the two can be told apart.
  const BARE = { halfW: 6, halfD: 5, wall: 0.4, tall: 3.2, stub: 0.9, doorWidth: 1.7, doorHeight: 0.9, step: 1.6 };
  const BARE_LOOK = { 'house-west': { wall: 0xe8d2a8, floor: 0xc89658, sky: 0xf4e6c8 }, 'house-east': { wall: 0xc9d6e8, floor: 0x9d8fb8, sky: 0xdce8f4 } };
  function bareRoom(building) {
    const look = BARE_LOOK[building.id] || BARE_LOOK['house-west'], { halfW, halfD, wall, tall } = BARE;
    const scene = new T.Scene();
    scene.background = new T.Color(look.sky);
    scene.add(new T.HemisphereLight(0xffffff, 0x998877, 1.9));
    const sun = new T.DirectionalLight(0xfff0d0, 1.2); sun.position.set(-5, 10, 8); scene.add(sun);
    const floor = new T.Mesh(new T.PlaneGeometry(halfW * 2, halfD * 2).rotateX(-Math.PI / 2), new T.MeshLambertMaterial({ color: look.floor }));
    floor.name = building.id + '-inside-floor';
    scene.add(floor);
    const wallMat = new T.MeshLambertMaterial({ color: look.wall });
    const rects = [                                                // outside the floor: x0, z0, x1, z1
      [-halfW - wall, -halfD - wall, halfW + wall, -halfD], [-halfW - wall, halfD, halfW + wall, halfD + wall],
      [-halfW - wall, -halfD, -halfW, halfD], [halfW, -halfD, halfW + wall, halfD],
    ];
    const solids = [], camBlockers = [];
    rects.forEach(([x0, z0, x1, z1], k) => {
      const h = k === 1 ? BARE.stub : tall;                              // rects[1] is the south wall
      const m = new T.Mesh(new T.BoxGeometry(x1 - x0, h, z1 - z0), wallMat.clone());     // (a copy each: the dollhouse camera fades the one in the way)
      m.name = 'wall-' + k;
      m.position.set((x0 + x1) / 2, h / 2, (z0 + z1) / 2); scene.add(m);
      solids.push({ x: (x0 + x1) / 2, z: (z0 + z1) / 2, hw: (x1 - x0) / 2, hd: (z1 - z0) / 2, rot: 0 });
      if (k !== 1) camBlockers.push({ x: (x0 + x1) / 2, z: (z0 + z1) / 2, x0, z0, x1, z1, reach: Math.hypot(x1 - x0, z1 - z0) / 2, top: tall });
    });
    // The door, in the middle of the south wall: a wooden panel as high as the stub, set a little proud of it, facing north.
    const slab = new T.Mesh(new T.BoxGeometry(BARE.doorWidth * 0.8, BARE.doorHeight, 0.1), new T.MeshLambertMaterial({ color: 0x8a5a32 }));
    slab.position.set(0, BARE.doorHeight / 2, halfD - 0.04); scene.add(slab);
    return {
      def: { id: building.interior, scene, solids, standOn: [floor], camBlockers, edge: { shape: 'rect', x0: -halfW, z0: -halfD, x1: halfW, z1: halfD }, start: { x: 0, z: halfD - BARE.step },
        fixedView: true, cameraRig: dollhouseRig({ rooms: [{ x0: -halfW, z0: -halfD, x1: halfW, z1: halfD }], bounds: { x0: -halfW, z0: -halfD, x1: halfW, z1: halfD }, tall, scene }) },
      exit: { x: 0, z: halfD, nx: 0, nz: -1, width: BARE.doorWidth, height: BARE.doorHeight, groundY: 0, spawn: { x: 0, z: halfD - BARE.step, facing: Math.PI, camera: { yaw: 0 } } },
    };
  }

  // ── A furnished house, built from world/interior.js (makeupgame-hfl.4) ──────────────────────────────
  // Floors per room (planks or tiles, drawn on a canvas), walls as boxes whose faces take the colour of the room they face, and
  // the furniture: each Furniture Kit model is parsed once, then copied per item with its materials copied too and recoloured
  // BY NAME for the house's style (the kit is flat colours with 15 shared material names), centred on its footprint and stood
  // on the floor (the kit's origins sit at a corner, some below the floor). The models arrive a moment after the room does
  // (parsing is asynchronous): `ready` resolves when they are all in.
  const canvasTexture = draw => {
    const c = document.createElement('canvas'); c.width = c.height = 256;
    draw(c.getContext('2d'));
    const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; t.wrapS = t.wrapT = T.RepeatWrapping; t.anisotropy = 4;
    return t;
  };
  const FLOORS = {
    planks: { size: 4, make: (a, b) => canvasTexture(g => {              // four boards across, joints staggered
      g.fillStyle = a; g.fillRect(0, 0, 256, 256);
      for (let i = 0; i < 4; i++) {
        g.fillStyle = i % 2 ? b : a; g.fillRect(0, i * 64, 256, 64);
        g.fillStyle = 'rgba(255,235,200,0.10)'; g.fillRect(0, i * 64 + 3, 256, 10);       // a lighter grain streak per board
        g.fillStyle = 'rgba(70,35,10,0.32)'; g.fillRect(0, i * 64, 256, 3);
        g.fillRect((i * 83 + 40) % 256, i * 64, 3, 64);
      }
    }) },
    tiles: { size: 3, make: (a, b) => canvasTexture(g => {                // 2 x 2 tiles of a chequer, grouted
      for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { g.fillStyle = (i + j) % 2 ? b : a; g.fillRect(i * 128, j * 128, 128, 128); }
      g.fillStyle = 'rgba(255,255,255,0.55)'; g.fillRect(0, 0, 256, 3); g.fillRect(0, 126, 256, 4); g.fillRect(0, 0, 3, 256); g.fillRect(126, 0, 4, 256);
    }) },
  };
  let blobTexture = null;
  const blob = () => blobTexture || (blobTexture = (() => {                 // a soft dark pool under furniture
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d'), grad = g.createRadialGradient(32, 32, 4, 32, 32, 31);
    grad.addColorStop(0, 'rgba(40,20,5,0.55)'); grad.addColorStop(1, 'rgba(40,20,5,0)');
    g.fillStyle = grad; g.fillRect(0, 0, 64, 64);
    return new T.CanvasTexture(c);
  })());
  const BLOB_Y = 0.05;
  const parsedModels = new Map();                                          // 'pack/name' -> Promise of the parsed scene (shared by all houses)
  const parseModel = (pack, name) => {
    const key = pack + '/' + name;
    if (!parsedModels.has(key)) parsedModels.set(key, new Promise((resolve, reject) => new T.GLTFLoader().parse(WORLD_PACKS.decode(pack, name), '', g => resolve(g.scene), reject)));
    return parsedModels.get(key);
  };
  // One piece of furniture: a Group at the item's spot, turned and sized, holding a copy of the model centred on its footprint.
  function furnitureObject(model, it, style) {
    const copy = model.clone(true);
    copy.traverse(o => {
      if (!o.isMesh) return;
      const one = m => { const c = m.clone(); c.metalness = 0; if (style.recolour[c.name] !== undefined) c.color.setHex(style.recolour[c.name]); return c; };
      o.material = Array.isArray(o.material) ? o.material.map(one) : one(o.material);
    });
    copy.updateMatrixWorld(true);
    const box = new T.Box3().setFromObject(copy), mid = box.getCenter(new T.Vector3());
    copy.position.set(-mid.x, -box.min.y, -mid.z);
    const g = new T.Group(); g.add(copy);
    g.scale.setScalar(it.s); g.rotation.y = it.rot; g.position.set(it.x, it.y, it.z);
    g.name = 'item-' + it.name;
    g.userData = { item: it, size: box.getSize(new T.Vector3()) };
    return g;
  }

  function furnishedRoom(building) {
    const H = WORLD_INTERIOR.houses[building.id], style = WORLD_INTERIOR.STYLES[H.style], b = H.bounds;
    const scene = new T.Scene();
    scene.background = new T.Color(style.sky);
    scene.add(new T.HemisphereLight(style.hemi[0], style.hemi[1], style.hemi[2]));
    const sun = new T.DirectionalLight(style.sun, 1.2); sun.position.set(-5, 10, 8); scene.add(sun);
    const fill = new T.DirectionalLight(style.fill || 0xffe8d0, 0.55); fill.position.set(7, 6, 4); scene.add(fill);   // from the other side, so the west walls are not dim
    const standOn = [];
    for (const r of H.rooms) {                                              // one floor per room, tiling the house
      const kind = FLOORS[r.floor.pattern], w = r.x1 - r.x0, d = r.z1 - r.z0;
      const tex = kind.make(r.floor.a, r.floor.b);
      const geo = new T.PlaneGeometry(w, d).rotateX(-Math.PI / 2).translate((r.x0 + r.x1) / 2, 0, (r.z0 + r.z1) / 2);
      const uv = geo.attributes.uv; for (let k = 0; k < uv.count; k++) uv.setXY(k, uv.getX(k) * w / kind.size, uv.getY(k) * d / kind.size);
      const floor = new T.Mesh(geo, new T.MeshLambertMaterial({ map: tex }));
      floor.name = r.id + '-floor'; scene.add(floor); standOn.push(floor);
    }
    // Walls: the faces (+x, -x, top, bottom, +z, -z) take the colour of the room they look into; the outside is the house's own.
    const cols = new Map(), mat = hex => cols.get(hex) || (cols.set(hex, new T.MeshLambertMaterial({ color: hex })), cols.get(hex));
    const camBlockers = [];
    const cuts = (a, b, axis) => [...new Set(H.rooms.flatMap(r => axis === 'x' ? [r.x0, r.x1] : [r.z0, r.z1]))].filter(v => v > a + 0.01 && v < b - 0.01).sort((p, q) => p - q);
    for (const w of H.walls) {
      // (a long wall is drawn in pieces, one per room it runs along, so each piece takes its own room's colour)
      const alongX = w.x1 - w.x0 > w.z1 - w.z0, edges = alongX ? [w.x0, ...cuts(w.x0, w.x1, 'x'), w.x1] : [w.z0, ...cuts(w.z0, w.z1, 'z'), w.z1];
      for (let k = 0; k + 1 < edges.length; k++) {
        const x0 = alongX ? edges[k] : w.x0, x1 = alongX ? edges[k + 1] : w.x1, z0 = alongX ? w.z0 : edges[k], z1 = alongX ? w.z1 : edges[k + 1];
        const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2, face = (x, z) => { const r = WORLD_INTERIOR.roomAt(H, x, z); return mat(r ? r.wall : style.outside).clone(); };   // (copies: the dollhouse camera fades the piece in the way)
        const m = new T.Mesh(new T.BoxGeometry(x1 - x0, w.h, z1 - z0), [face(x1 + 0.3, cz), face(x0 - 0.3, cz), mat(style.trim).clone(), mat(style.outside).clone(), face(cx, z1 + 0.3), face(cx, z0 - 0.3)]);
        m.position.set(cx, w.h / 2, cz); m.name = 'wall-' + (w.side || w.role); scene.add(m);
      }
      if (w.h > 1.6) camBlockers.push({ x: (w.x0 + w.x1) / 2, z: (w.z0 + w.z1) / 2, x0: w.x0, z0: w.z0, x1: w.x1, z1: w.z1, reach: Math.hypot(w.x1 - w.x0, w.z1 - w.z0) / 2, top: w.h });
    }
    // Tall furniture, and the units on the walls, are things the camera must stay out of too (it lifts over them).
    for (const it of H.items) {
      const top = it.y + it.footprint[2];
      if (top < 1.6) continue;
      const hw = (it.solid ? it.solid.hw : it.footprint[0] / 2), hd = (it.solid ? it.solid.hd : it.footprint[1] / 2);
      camBlockers.push({ x: it.x, z: it.z, hw, hd, rot: it.rot, reach: Math.hypot(hw, hd), top });
    }
    // The way out, in the south wall: a wooden panel as high as the stub, set a little proud of it, facing north, with a knob.
    const dr = H.door;
    const slab = new T.Mesh(new T.BoxGeometry(dr.width * 0.8, dr.height, 0.1), new T.MeshLambertMaterial({ color: style.door || 0x8a5a32 }));
    slab.position.set(dr.x, dr.height / 2, dr.z - 0.04); scene.add(slab);
    const knob = new T.Mesh(new T.SphereGeometry(0.07, 10, 8), new T.MeshLambertMaterial({ color: style.knob || 0xe8c66a }));
    knob.position.set(dr.x + dr.width * 0.28, dr.height * 0.5, dr.z - 0.12); scene.add(knob);
    // The furniture, once the models are parsed.
    const furniture = new T.Group(); furniture.name = 'furniture'; scene.add(furniture);
    const ready = Promise.all([...new Set(H.items.map(i => i.name))].map(n => parseModel('furniture', n).then(m => [n, m]))).then(list => {
      const models = new Map(list), shadow = new T.MeshBasicMaterial({ map: blob(), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });   // (the pool lies above every rug (at most 0.04 thick) and a doormat, and never fights one)
      for (const it of H.items) {
        furniture.add(furnitureObject(models.get(it.name), it, style));
        if (it.shadow) {                                                    // a soft pool on the floor under the big pieces
          const sh = new T.Mesh(new T.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), shadow);
          sh.scale.set(it.footprint[0] + 0.8, 1, it.footprint[1] + 0.8); sh.rotation.y = it.rot; sh.position.set(it.x, BLOB_Y, it.z); sh.name = 'shadow';
          furniture.add(sh);
        }
      }
    });
    return {
      def: { id: building.interior, scene, solids: H.solids.slice(), standOn, camBlockers, edge: { shape: 'rect', x0: b.x0, z0: b.z0, x1: b.x1, z1: b.z1 }, start: { x: H.spawn.x, z: H.spawn.z },
        fixedView: true, cameraRig: dollhouseRig({ rooms: H.rooms, bounds: b, tall: H.tall, scene }) },
      exit: { x: dr.x, z: dr.z, nx: dr.nx, nz: dr.nz, width: dr.width, height: dr.height, groundY: 0, spawn: { ...H.spawn } },
      ready,
    };
  }
  // hfl.7: the east house is furnished too, in style B.
  const INTERIOR_BUILDERS = { default: bareRoom, 'house-west': furnishedRoom, 'house-east': furnishedRoom };
  const ready = [];                                                         // promises: the furniture of every house is in

  // ── Setup: once the world is built ───────────────────────────────────────
  function setup(parts, layout) {
    const outdoors = WORLD.place;
    for (const b of layout.buildings || []) {
      const d = b.door, out = d.face === 'E' ? 1 : -1;
      const { def, exit, ready: built } = (INTERIOR_BUILDERS[b.id] || INTERIOR_BUILDERS.default)(b);
      if (built) ready.push(built);
      const inside = WORLD.addPlace(def);
      // Going in: she stands where exit.spawn says, facing into the room, with the camera reset behind her.
      addDoor(outdoors, parts.scene, {
        id: b.id, place: 'outdoors', x: d.x, z: d.z, nx: out, nz: 0, width: d.width, height: d.height, reach: d.reach, groundY: 0,
        lantern: d.lantern, to: b.interior, spawn: exit.spawn,
      });
      // Coming out: at building.door.spawnOutside, facing away from the house, the camera reset to the usual view (cameraYaw: behind her is the house).
      addDoor(inside, inside.scene, {
        id: b.interior, place: b.interior, x: exit.x, z: exit.z, nx: exit.nx, nz: exit.nz, width: exit.width, height: exit.height, reach: d.reach, groundY: exit.groundY || 0,
        to: 'outdoors', spawn: { x: d.spawnOutside.x, z: d.spawnOutside.z, facing: d.spawnOutside.facing, camera: { yaw: d.spawnOutside.cameraYaw } },
      });
    }
  }

  WORLD.onBuilt.push(setup);
  WORLD.houses = { dollhouseRig, DOLL, doors, INTERIOR_BUILDERS, bareRoom, furnishedRoom, ready: () => Promise.all(ready), door: id => doors.find(d => d.id === id) };
})();
