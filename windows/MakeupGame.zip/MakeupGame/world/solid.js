// Solid things she cannot walk through, and the one question walking asks of them. Shared by
// layout.js (keeping scattered flowers out of them), world.js (walking) and
// scripts/world-layout-check.js (can she still get everywhere), so all three agree.
//
//   { x, z, r }                 a circle
//   { x, z, hw, hd, rot }       a rectangle: half its width (along x) and depth (along z), turned by
//                               `rot` around the vertical axis exactly as layout items are
//
//   WORLD_SOLID.push(c, x, z, R)      where a circle of radius R at (x, z) must move to so it no
//                                     longer overlaps c (straight out, the shortest way), or null
//   WORLD_SOLID.overlaps(c, x, z, R)  does it overlap?
//
// Classic script (no modules) so it works when the page is opened from file://.
(function () {
  function push(c, x, z, R) {
    const dx = x - c.x, dz = z - c.z;
    if (c.r !== undefined) {
      const d = Math.hypot(dx, dz), min = c.r + R;
      if (d >= min) return null;
      const nx = d > 1e-6 ? dx / d : 1, nz = d > 1e-6 ? dz / d : 0;
      return { x: c.x + nx * min, z: c.z + nz * min };
    }
    const cs = Math.cos(c.rot || 0), sn = Math.sin(c.rot || 0);
    let lx = dx * cs - dz * sn, lz = dx * sn + dz * cs;              // into the rectangle's own frame
    const qx = Math.max(-c.hw, Math.min(c.hw, lx)), qz = Math.max(-c.hd, Math.min(c.hd, lz));
    const ox = lx - qx, oz = lz - qz, d = Math.hypot(ox, oz);        // from the nearest point of it
    if (d >= R) return null;
    if (d > 1e-6) { lx = qx + (ox / d) * R; lz = qz + (oz / d) * R; }
    else if (c.hw - Math.abs(lx) < c.hd - Math.abs(lz)) lx = (lx < 0 ? -1 : 1) * (c.hw + R);   // inside: out of the nearest side
    else lz = (lz < 0 ? -1 : 1) * (c.hd + R);
    return { x: c.x + lx * cs + lz * sn, z: c.z - lx * sn + lz * cs };
  }

  window.WORLD_SOLID = { push, overlaps: (c, x, z, R) => push(c, x, z, R) !== null };
})();
