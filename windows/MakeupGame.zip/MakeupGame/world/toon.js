// The character's look: a two-tone "cel" shading and an outline, as in ART_DIRECTION.md.
//   - Lit side = the colour, shadow side = a darker shade of it, one hard edge between (no gradient).
//     Light comes from the world's sun, the upper left.
//   - Outline = the same mesh again, a little bigger and drawn inside out, in a darker shade of the
//     fill (never black), so only a rim shows around the silhouette. Its width is in screen pixels.
// Stock MeshToonMaterial is not used: in three.js only direct light goes through its steps, and the
// world's own hemisphere light is as strong as its sun, so the steps would hardly show.
// Both materials work on skinned meshes and take the world's fog.
(function () {
  const T = window.THREE;

  // Where the sun is (world.js: DirectionalLight at (-8, 14, 6)).
  const SUN = new T.Vector3(-8, 14, 6).normalize();
  // D6: the key light of the CHARACTER is fixed to the camera, not to the world, so she is lit from the upper left of the picture in the
  // dressing room, in the saved picture and in the world, however the world camera turns or tilts. SUN_VIEW is the world sun as the
  // dressing room's camera sees it (looking a little down, pitch .07), so that picture is as it always was. aimSun(camera) sets SUN
  // (the one vector every toon material shares) for the frame about to be drawn.
  const SUN_VIEW = SUN.clone().applyAxisAngle(new T.Vector3(1, 0, 0), 0.07);
  function aimSun(camera) {
    camera.updateMatrixWorld();
    SUN.copy(SUN_VIEW).transformDirection(camera.matrixWorld);
  }

  const VERT = /* glsl */`
    uniform vec3 uSun;
    uniform float uBias;
    uniform float uOutline;       // outline width in pixels at 768 px tall, 0 = none
    uniform vec2 uViewport;
    uniform float uOutlineNear;   // > 0: the outline thins as the camera goes further than this (sqrt of the ratio, 0.5 to 1.3 times), so a small far figure is not all line; 0 = always the same width
    uniform vec3 uStretch;        // makes the mesh wider / taller about uStretchAt (the hair size sliders); 1,1,1 = as modelled
    uniform vec3 uStretchAt;
    uniform vec3 uShift;          // moves the mesh (hats on top of tall hair); 0,0,0 = as modelled
    uniform float uShrink;        // hair made smaller than modelled (the size sliders below 1): 1 = it shrinks toward the crown and stays on top of the head, 0 = plain scaling
    uniform float uCrownY;        // the top of the head above uStretchAt
    uniform float uClipAbove;     // hair: what is higher than this (in the model's frame) is not drawn (spikes that would poke through a hat); 1e4 = all of it
    uniform vec3 uHeadE;          // the half sizes of the head around uStretchAt: what a smaller hair must not sink into
    varying vec3 vNormalV;
    varying vec3 vRoundV;         // straight out from uStretchAt (the middle of the head, for hair), in view space
    varying vec3 vSunV;
    varying vec2 vUv;
    varying float vClipY;
    #ifdef USE_TOON_LOCK
      attribute vec2 uv1;           // hair: x = across the lock (+1 / -1 its edges, 0 in the middle), y = along it (0..1, +2 = a lock with a gloss band)
      varying vec2 vLock;
    #endif
    #ifdef USE_TOON_PALETTE
      #ifdef TOON_FLAT_CODE
        flat varying float vCode;   // the same, but not blended between vertices (every triangle has the colour of one vertex)
      #else
        varying float vCode;        // outfit pieces: which palette colour a vertex has (COLOR_0.r * TOON_PAL_STEPS), see OUTFIT_PALETTE
      #endif
      varying vec3 vObjPos;         // the bind-pose position and normal, for the fabric pattern (it sticks to the cloth)
      varying vec3 vObjNrm;
    #endif
    #include <common>
    #include <skinning_pars_vertex>
    #include <fog_pars_vertex>
    void main() {
      vUv = uv;
      vClipY = uStretchAt.y + (position.y - uStretchAt.y) * uStretch.y + uShift.y - uClipAbove;      // > 0: cut away
      #ifdef USE_TOON_LOCK
        vLock = uv1;
      #endif
      #ifdef USE_TOON_PALETTE
        vCode = color.r * float(TOON_PAL_STEPS);
        vObjPos = position;
        vObjNrm = normal;
      #endif
      #include <beginnormal_vertex>
      #include <skinbase_vertex>
      #include <skinnormal_vertex>
      #include <defaultnormal_vertex>
      #include <begin_vertex>
      #include <skinning_vertex>
      if (uShrink > 0.5) {
        // Plain scaling about the middle of the head would sink a hair below 0.9 times into the skull. Smaller hair shrinks
        // toward the crown instead (what is lower on the head moves up), and what would still be inside the head is moved out onto it.
        vec3 pp = transformed - uStretchAt;
        float pivY = uStretch.y < 1.0 ? uCrownY : 0.0;
        vec3 q = vec3(pp.x * uStretch.x, (pp.y - pivY) * uStretch.y + pivY, pp.z * uStretch.z);
        vec3 qe = pow(abs(q) / uHeadE, vec3(2.4));
        float r = pow(qe.x + qe.y + qe.z, 1.0 / 2.4);
        if (r < 1.05) q *= 1.05 / max(r, 0.05);
        transformed = uStretchAt + q + uShift;
      } else {
        transformed = uStretchAt + (transformed - uStretchAt) * uStretch + uShift;
      }
      vRoundV = normalize(normalMatrix * (transformed - uStretchAt));
      vec4 mvPosition = modelViewMatrix * vec4(transformed, 1.0);
      // Slide toward the camera along the line of sight: the picture does not move, but the surface
      // wins the depth test against what is just in front of it (eyes over the fringe).
      mvPosition.xyz -= normalize(mvPosition.xyz) * uBias;
      vec4 clip = projectionMatrix * mvPosition;
      vec3 n = normalize(transformedNormal);
      #ifdef FLIP_SIDED
        n = -n;                   // three.js flips the normal of a back-face material; the outline needs the outward one
      #endif
      if (uOutline > 0.0) {
        vec2 dir = normalize((projectionMatrix * vec4(n, 0.0)).xy + 1e-6);
        float k = uOutlineNear > 0.0 ? clamp(sqrt(uOutlineNear / max(clip.w, 0.01)), 0.5, 1.3) : 1.0;
        clip.xy += dir * (uOutline * k * uViewport.y / 768.0 * 2.0 / uViewport) * clip.w;
      }
      gl_Position = clip;
      vNormalV = n;
      vSunV = normalize(mat3(viewMatrix) * uSun);
      #include <fog_vertex>
    }`;

  const FRAG = /* glsl */`
    uniform vec3 uColor;
    uniform vec3 uShade;          // multiplies the colour on the shadow side (1 = no shadow)
    uniform float uThreshold;     // n . sun below this is shadow
    uniform float uOpacity;
    uniform float uSpec;          // a hard-edged shine (hair): how white it goes, 0 = none
    uniform float uSpecAt;        // n . half-way(sun, eye) above this is shine (higher = a smaller one)
    uniform float uDeep;          // a third, deepest tone where the UV's u is low (the gaps between locks of hair); 0 = none
    #ifdef USE_TOON_LOCK
      uniform float uCrease;      // hair: the colour is multiplied by this along both edges of every lock (the lines between locks); 1 = none
      uniform float uBand;        // hair: how white the gloss band along some locks goes; 0 = none
      uniform float uLift;        // hair: black hair gets this much lighter on its sunny side (a dark line and a dark mass do not show on it)
      varying vec2 vLock;
    #endif
    #ifdef USE_TOON_MAP
      uniform sampler2D uMap;
      uniform vec2 uUvScale;
      uniform vec2 uUvOffset;
    #endif
    #ifdef USE_TOON_PALETTE
      uniform vec3 uPal[TOON_PAL_N];  // the colour of each palette code (outfits, extras)
      #ifdef USE_TOON_FABRIC
        uniform sampler2D uFabric;    // the fabric pattern: one tile, premultiplied, drawn over palette colour 0
        uniform float uFabricOn;
        uniform float uFabricScale;   // tiles per metre
      #endif
      #ifdef USE_TOON_SHEEN
        uniform float uSheen[TOON_PAL_N];   // per palette code: 0 matte cloth, 1 satin (a broad pale crescent), 2 metal (stepped bands and a hard core), 3 gloss (a small hard core)
        uniform float uSheenK;
      #endif
      #ifdef TOON_FLAT_CODE
        flat varying float vCode;
      #else
        varying float vCode;
      #endif
      varying vec3 vObjPos;
      varying vec3 vObjNrm;
    #endif
    uniform float uRound;         // light as if the surface were the round mass around uStretchAt: 0 = its own normals, 1 = fully
    varying vec3 vNormalV;
    varying vec3 vRoundV;
    varying vec3 vSunV;
    varying vec2 vUv;
    varying float vClipY;
    #include <common>
    #include <fog_pars_fragment>
    void main() {
      if (vClipY > 0.0) discard;
      vec4 base = vec4(uColor, 1.0);
      #ifdef USE_TOON_MAP
        vec4 t = texture2D(uMap, vUv * uUvScale + uUvOffset);
        base = vec4(uColor * t.rgb, t.a);
      #endif
      #ifdef USE_TOON_PALETTE
        int code = int(vCode + 0.5);
        vec3 pc = uPal[code];
        #ifdef USE_TOON_FABRIC
          if (code == 0 && uFabricOn > 0.5) {
            // Three planes, each used where the cloth faces it: the pattern is not stretched on any side of the body.
            vec3 w = pow(abs(normalize(vObjNrm)), vec3(8.0));
            w /= (w.x + w.y + w.z);
            vec4 p = w.x * texture2D(uFabric, vec2(vObjPos.z, -vObjPos.y) * uFabricScale)
                   + w.y * texture2D(uFabric, vec2(vObjPos.x, vObjPos.z) * uFabricScale)
                   + w.z * texture2D(uFabric, vec2(vObjPos.x, -vObjPos.y) * uFabricScale);
            pc = pc * (1.0 - p.a) + p.rgb;
          }
        #endif
        base = vec4(pc, 1.0);
      #endif
      #ifdef ALPHA_CUT
        if (base.a < ALPHA_CUT) discard;
      #endif
      #ifdef OUTLINE
        #ifdef USE_TOON_PALETTE
          gl_FragColor = vec4(uPal[int(vCode + 0.5)], 1.0);   // the outline of a palette piece: the palette's own outline colour
        #else
          gl_FragColor = vec4(uColor, 1.0);
        #endif
      #else
        // Hair: each lock is lit partly as the whole round mass, so light and shadow make big shapes, not one per lock.
        vec3 nl = uRound > 0.0 ? normalize(mix(normalize(vNormalV), normalize(vRoundV), uRound)) : normalize(vNormalV);
        float lit = smoothstep(uThreshold - 0.02, uThreshold + 0.02, dot(nl, vSunV));
        vec3 col = mix(base.rgb * uShade, base.rgb, lit);
        float open = 1.0;
        if (uDeep > 0.0) {
          open = smoothstep(0.45, 0.55, vUv.x);
          col *= mix(uDeep, 1.0, open);
        }
        #ifdef USE_TOON_LOCK
          // Locks: a bold dark line along both edges, and on some locks a pale band just inside the edge on the sunny side.
          // the across value is read like a position on the screen (the tube is flat), so both are as wide on a thin lock as on a fat one.
          float puff = step(3.5, vLock.y);                              // a curl or bun: a glint on its sunny side instead
          float gloss = step(1.5, vLock.y) * (1.0 - puff);
          float along = vLock.y - 2.0 * gloss - 4.0 * puff;
          float crease = smoothstep(0.66, 0.84, abs(vLock.x)) * smoothstep(0.02, 0.1, along);
          col *= mix(1.0, uCrease, crease);
          col += vec3(uLift) * lit * open;
          float width = 0.17 * (1.0 - 0.45 * along);                  // the band thins toward the tip
          float band = gloss * (1.0 - smoothstep(width, width + 0.09, abs(vLock.x - 0.4)))
                     * smoothstep(0.05, 0.2, along) * (1.0 - smoothstep(0.6, 0.9, along));
          col = mix(col, vec3(1.0), uBand * band * open * mix(0.6, 1.0, lit));
          if (puff > 0.5) {
            vec3 hh = normalize(vSunV + vec3(0.0, 0.0, 1.0));
            vec3 np = normalize(vNormalV);
            vec3 h2p = normalize(hh + vec3(0.2, -0.16, 0.0));
            float dab = smoothstep(0.93, 0.945, dot(np, hh)) * (1.0 - smoothstep(0.93, 0.945, dot(np, h2p)));   // a small crescent, like the big shine
            col = mix(col, vec3(1.0), uBand * 0.95 * dab * lit);
          }
        #endif
        #ifdef USE_TOON_SHEEN
          float shn = uSheen[code];
          if (shn > 0.5) {
            // Restrained cel highlights by material, lit side only (the eye is taken to be straight ahead, as for the hair).
            vec3 hs = normalize(vSunV + vec3(0.0, 0.0, 1.0));
            vec3 ns = normalize(vNormalV);
            float dh = dot(ns, hs);
            if (shn < 1.5) {                                     // satin: one broad crescent
              vec3 hs2 = normalize(hs + vec3(0.2, -0.17, 0.0));
              float cres = smoothstep(0.86, 0.875, dh) * (1.0 - smoothstep(0.86, 0.875, dot(ns, hs2)));
              col = mix(col, vec3(1.0), 0.5 * uSheenK * cres * lit);
            } else if (shn < 2.5) {                              // metal: a broad pale band, a bright core and a darker reflection on the far side
              col = mix(col, vec3(1.0), 0.38 * uSheenK * smoothstep(0.80, 0.815, dh) * lit);
              col = mix(col, vec3(1.0), 0.95 * uSheenK * smoothstep(0.955, 0.965, dh) * lit);
              col *= 1.0 - 0.16 * uSheenK * (1.0 - smoothstep(-0.55, -0.25, ns.y));
            } else {                                             // gloss: a small hard core and a tiny second glint
              col = mix(col, vec3(1.0), 0.85 * uSheenK * smoothstep(0.93, 0.945, dh) * lit);
            }
          }
        #endif
        if (uSpec > 0.0) {            // the eye is taken to be straight ahead, which is near enough for a cartoon shine
          vec3 h = normalize(vSunV + vec3(0.0, 0.0, 1.0));
          vec3 n = uRound > 0.0 ? normalize(vRoundV) : normalize(vNormalV);   // one crescent over the whole mass, like the 2D art's streak
          vec3 h2 = normalize(h + vec3(0.11, -0.09, 0.0));    // minus the same disc a little lower right
          float crescent = smoothstep(uSpecAt - 0.004, uSpecAt + 0.004, dot(n, h)) * (1.0 - smoothstep(uSpecAt - 0.004, uSpecAt + 0.004, dot(n, h2)));
          col = mix(col, vec3(1.0), uSpec * lit * open * crescent);
        }
        gl_FragColor = vec4(col, base.a * uOpacity);   // a premultiplied map stays premultiplied
      #endif
      #include <colorspace_fragment>
      #include <fog_fragment>
    }`;

  const viewport = new T.Vector2(1366, 768);
  const outlineNear = { value: 0 };      // shared by every outline: see uOutlineNear (the world sets it, the dressing room leaves it 0)
  // Every toon mesh reads the drawing-buffer size just before it is drawn.
  function trackViewport(mesh) {
    mesh.onBeforeRender = renderer => renderer.getDrawingBufferSize(viewport);
  }

  // `shade` is how much darker the shadow side is, per channel in linear light (see shadeOf).
  function material({ color, shade, map = null, bias = 0, threshold = 0.0, premultiplied = false, transparent = false, alphaTest = 0, outline = 0, sun = SUN, spec = 0, specAt = 0.96, deep = 0, round = 0, lock = false, palette = null, paletteSteps = 32, flatCode = false, fabric = null, fabricScale = 1, sheen = null, opacity = 1 }) {
    const defines = {};
    if (map) defines.USE_TOON_MAP = '';
    if (lock) defines.USE_TOON_LOCK = '';
    if (palette) { defines.USE_TOON_PALETTE = ''; defines.TOON_PAL_STEPS = paletteSteps; defines.TOON_PAL_N = palette.length; }
    if (palette && flatCode) defines.TOON_FLAT_CODE = '';
    if (palette && fabric) defines.USE_TOON_FABRIC = '';
    if (palette && sheen) defines.USE_TOON_SHEEN = '';
    if (alphaTest) defines.ALPHA_CUT = alphaTest.toFixed(3);      // pixels of the map less opaque than this are not drawn
    const m = new T.ShaderMaterial({
      defines,
      uniforms: T.UniformsUtils.merge([T.UniformsLib.fog, {
        uSun: { value: sun }, uBias: { value: bias }, uOutline: { value: outline }, uViewport: { value: viewport }, uOutlineNear: outlineNear,
        uColor: { value: new T.Color(color) }, uShade: { value: shade || new T.Vector3(1, 1, 1) },
        uThreshold: { value: threshold }, uOpacity: { value: opacity }, uSheenK: { value: 1 }, uSpec: { value: spec }, uSpecAt: { value: specAt }, uDeep: { value: deep }, uRound: { value: round }, uCrease: { value: 1 }, uBand: { value: 0 }, uLift: { value: 0 },
        uStretch: { value: new T.Vector3(1, 1, 1) }, uStretchAt: { value: new T.Vector3() }, uShift: { value: new T.Vector3() },
        uShrink: { value: 0 }, uClipAbove: { value: 1e4 }, uCrownY: { value: 0 }, uHeadE: { value: new T.Vector3(1, 1, 1) },
        uMap: { value: map }, uUvScale: { value: new T.Vector2(1, 1) }, uUvOffset: { value: new T.Vector2(0, 0) },
        uFabricOn: { value: fabric ? 1 : 0 }, uFabricScale: { value: fabricScale },
      }]),
      vertexShader: VERT, fragmentShader: FRAG,
      fog: true, transparent, depthWrite: !transparent,
      vertexColors: !!palette,
    });
    if (palette) { m.uniforms.uPal = { value: palette }; m.uniforms.uFabric = { value: fabric }; }
    if (palette && sheen) m.uniforms.uSheen = { value: sheen };
    if (premultiplied) m.premultipliedAlpha = true;
    // UniformsUtils.merge clones what it is given. Not wanted for the drawing-buffer size (every toon mesh updates the
    // one shared value) and not for the picture (a clone would be a second copy on the graphics card).
    m.uniforms.uViewport = { value: viewport };
    m.uniforms.uOutlineNear = outlineNear;
    m.uniforms.uMap = { value: map };
    return m;
  }

  // The inside-out copy that makes the outline: `color` is the darker shade of the fill.
  // `palette` ({ colours, steps, flat }): an outline whose colour is taken per vertex from the palette (pieces made of several colours).
  function outlineMaterial(color, widthPx = 2.2, palette = null) {
    const defines = { OUTLINE: '' };
    if (palette) { defines.USE_TOON_PALETTE = ''; defines.TOON_PAL_STEPS = palette.steps; defines.TOON_PAL_N = palette.colours.length; if (palette.flat) defines.TOON_FLAT_CODE = ''; }
    const m = new T.ShaderMaterial({
      defines,
      uniforms: T.UniformsUtils.merge([T.UniformsLib.fog, {
        uSun: { value: SUN }, uBias: { value: 0 }, uOutline: { value: widthPx }, uViewport: { value: viewport }, uOutlineNear: outlineNear,
        uColor: { value: new T.Color(color) }, uShade: { value: new T.Vector3(1, 1, 1) },
        uThreshold: { value: 0 }, uOpacity: { value: 1 },
        uStretch: { value: new T.Vector3(1, 1, 1) }, uStretchAt: { value: new T.Vector3() }, uShift: { value: new T.Vector3() },
        uShrink: { value: 0 }, uClipAbove: { value: 1e4 }, uCrownY: { value: 0 }, uHeadE: { value: new T.Vector3(1, 1, 1) },
      }]),
      vertexShader: VERT, fragmentShader: FRAG,
      fog: true, side: T.BackSide, vertexColors: !!palette,
    });
    if (palette) m.uniforms.uPal = { value: palette.colours };
    m.uniforms.uViewport = { value: viewport };
    m.uniforms.uOutlineNear = outlineNear;
    return m;
  }

  // An outlined twin of a skinned mesh, sharing its geometry and its skeleton. Added next to it.
  function addOutline(mesh, color, widthPx, palette = null) {
    const o = new T.SkinnedMesh(mesh.geometry, outlineMaterial(color, widthPx, palette));
    o.name = mesh.name + '_outline';
    o.bind(mesh.skeleton, mesh.bindMatrix);
    o.frustumCulled = false;
    trackViewport(o);
    mesh.parent.add(o);
    return o;
  }

  // Shadow colour as a multiplier: dark / light for a hand-picked pair (skin), or `k` for "k times as
  // bright as seen" (the 2D art darkens hair and cloth by about 15 percent). Both in linear light.
  function shadeOf(light, dark) {
    const a = new T.Color(light), b = new T.Color(dark);
    return new T.Vector3(Math.min(1, b.r / Math.max(a.r, 1e-4)), Math.min(1, b.g / Math.max(a.g, 1e-4)), Math.min(1, b.b / Math.max(a.b, 1e-4)));
  }
  function shadeBy(k) { const l = Math.pow(k, 2.2); return new T.Vector3(l, l, l); }

  // D6: restrained contact shading for the 3D character: one broad soft blot and a tight dark one under each shoe, so the soles sit
  // on the ground. A flat plane 1.3 m by 0.65 m for the model's feet (they are at x +-0.215, z -0.15 to 0.23 in Idle_A); put it at the
  // ground under her (its middle is z = 0.04 on her). `rgb` is the shadow's colour, `k` how strong.
  function contactShadow(rgb = '110,70,160', k = 1) {
    const c = document.createElement('canvas'); c.width = 256; c.height = 128;
    const g = c.getContext('2d');
    const blot = (cx, cy, rx, ry, a0, a1) => {
      g.save(); g.translate(cx, cy); g.scale(rx, ry);
      const grad = g.createRadialGradient(0, 0, 0.05, 0, 0, 1);
      grad.addColorStop(0, `rgba(${rgb},${a0 * k})`); grad.addColorStop(0.55, `rgba(${rgb},${a1 * k})`); grad.addColorStop(1, `rgba(${rgb},0)`);
      g.fillStyle = grad; g.fillRect(-1, -1, 2, 2); g.restore();
    };
    blot(128, 64, 120, 54, 0.2, 0.12);                     // the broad one
    for (const x of [86, 170]) blot(x, 64, 30, 40, 0.42, 0.24);   // under each shoe
    const t = new T.CanvasTexture(c);
    const m = new T.Mesh(new T.PlaneGeometry(1.3, 0.65).rotateX(-Math.PI / 2), new T.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false }));
    m.name = 'contact_shadow';
    return m;
  }

  window.TOON = { contactShadow, outlineNear, aimSun, SUN_VIEW, material, outlineMaterial, addOutline, trackViewport, shadeOf, shadeBy, SUN, viewport };
})();
