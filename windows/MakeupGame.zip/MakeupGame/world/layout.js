// What is in the world and where. Pure data: world.js builds whatever this describes, so adding a
// tree, a tent or a whole new corner means adding an entry here and nothing else.
//
// Coordinates are world units on the ground: x runs right, z runs toward the camera, so "north"
// (away from the camera) is negative z. She starts at (0, 0), looking north. She is about 2.1
// units tall; the Kenney models are drawn about 1 unit big, so SCALE brings them up to her size.
//
// An item is { pack, name, x, z, rot, s, block, box, stand, shadow }:
//   pack, name  a model in WORLD_PACKS (world/assets/packs), e.g. 'nature', 'tree_default'
//   rot         turn around the vertical axis, in radians (0 = as modelled, front toward +z)
//   s           extra size on top of SCALE
//   sy, sz      stretch on top of s, up and along the model's z (house walls and their door)
//   block       she cannot walk closer than this (+ her own radius) to the item's middle. Rocks and
//               bushes get one from their size (ROUND below) unless it is given.
//   box         [w, d]: she cannot walk into this rectangle (world units, w along the model's x,
//               turned with it), for long things such as a canoe or a log. Instead of block.
//   stand       she walks on top of it (the bridge): her height there comes from
//               the model's own shape
//   shadow      width of the soft shadow on the ground (default: from block or box)
//   touch       'wiggle': it sways and sparkles when she walks through it (see life.js)
//   cover       space the camera must stay out of, up to height `top`: { r, top } (round, around the
//               item) or { x0, z0, x1, z1, top } (a rectangle). Every model taller than 1.6 that she
//               cannot walk through gets a round one from its own size; set it by hand for things
//               built of parts (false: none).
//
// Everything solid also lands in `solids` (circles and rectangles, see solid.js), which is what
// walking uses. Classic script (no modules) so it works when the page is opened from file://.
(function () {
  const SOLID = window.WORLD_SOLID;          // solid.js, loaded first
  const SCALE = 3;
  const BOUNDS = 29.5;                       // room for the enlarged houses and the forest edge
  // Kenney wall-wood-doorway-square-wide.glb is a 1 x 1 panel whose opening runs from its jamb at
  // z = -0.2 to its open edge at +0.5 (the next panel closes it), 0.75 high.
  const DOOR_OPENING = { z0: -0.2, z1: 0.5, height: 0.75 };
  const HOUSE_TALL = 1.2;                     // house walls stretched up: 3.6 high, so the opening is 2.7
  const DOOR_WIDE = 1.2;                      // the door panel stretched along the wall: a 2.52-wide opening
  const items = [];
  const solids = [];                         // what she cannot walk through
  const buildings = [];                      // { id, x, z, width, depth, floorY, entrance, ... }
  const water = [];                          // { x, z, w, d } strips and { x, z, r } discs
  const features = [];                       // living things (life.js): fountain, fire, butterflies
  const keepClear = [];                      // circles / rects that scatter must not drop things in
  // Rocks and bushes are solid: about this far round (model units, before SCALE and s).
  const ROUND = {
    rock_smallA: 0.18, rock_smallB: 0.18, rock_smallC: 0.18, rock_smallD: 0.19, rock_smallE: 0.17, rock_smallF: 0.16,
    rock_smallG: 0.3, rock_smallH: 0.23, rock_largeA: 0.42, plant_bush: 0.2, plant_bushDetailed: 0.3,
  };

  // A small seeded random generator, so the world is the same every time.
  let seed = 20261002;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  const between = (a, b) => a + (b - a) * rnd();
  const pick = list => list[Math.floor(rnd() * list.length)];

  function add(pack, name, x, z, o = {}) {
    const s = (o.s || 1) * SCALE, rot = o.rot || 0;
    const block = o.block !== undefined ? o.block : ROUND[name] ? ROUND[name] * s * 0.85 : 0;   // a rock's edge is lower than its middle
    const solid = o.box ? { x, z, hw: o.box[0] / 2, hd: o.box[1] / 2, rot } : block ? { x, z, r: block } : null;
    if (solid) solids.push(solid);
    const shadow = o.shadow !== undefined ? o.shadow : o.box ? Math.sqrt(o.box[0] * o.box[1]) * 1.3 : block * 2.6;
    items.push({ pack, name, x, z, rot, s, sy: o.sy || 1, sz: o.sz || 1, y: o.y || 0, solid, stand: !!o.stand, shadow, touch: o.touch || null, cover: o.cover, buildingId: o.buildingId || null, role: o.role || null });
  }
  const solidRect = (x0, z0, x1, z1) => solids.push({ x: (x0 + x1) / 2, z: (z0 + z1) / 2, hw: (x1 - x0) / 2, hd: (z1 - z0) / 2, rot: 0 });
  const clear = (x, z, r) => keepClear.push({ x, z, r });
  const clearRect = (x0, z0, x1, z1) => keepClear.push({ x0, z0, x1, z1 });
  const isClear = (x, z, pad = 0) => !keepClear.some(c => c.r !== undefined
    ? Math.hypot(x - c.x, z - c.z) < c.r + pad
    : x > c.x0 - pad && x < c.x1 + pad && z > c.z0 - pad && z < c.z1 + pad);

  // ── The path she starts on: stepping stones north, over the bridge, into the village ─────
  clear(0, 0, 2);                            // her starting spot
  for (let z = -2, k = 0; z > -13; z -= 2.1, k++) {   // (the paving of the village starts at -13.5)
    if (Math.abs(z + 9) < 2.3) continue;     // the bridge is here
    const x = Math.sin(z * 0.45) * 1.7;
    add('nature', k % 3 === 2 ? 'path_stoneCircle' : 'path_stone', x, z, { rot: Math.cos(z * 0.45) * 0.5 + (k % 2 ? 0.1 : -0.1), y: 0.03, shadow: 0 });   // flat: she walks over them, no step up
    clear(x, z, 1.3);
  }

  // ── The stream and its bridge ────────────────────────────────────────────
  // She cannot wade into the water (her toes may reach its edge). The only gap is the bridge: she
  // walks up its steps and over its deck, between the rails.
  const STREAM_Z = -9, STREAM_W = 3.4, BRIDGE_GAP = 1.2;   // half the width she may walk on the bridge
  water.push({ x: 0, z: STREAM_Z, w: 70, d: STREAM_W });
  add('nature', 'bridge_wood', 0, STREAM_Z, { rot: Math.PI / 2, s: 1.12, stand: true });
  clearRect(-60, STREAM_Z - 2.3, 60, STREAM_Z + 2.3);
  const bank = STREAM_W / 2 - 0.25;
  solidRect(-40, STREAM_Z - bank, -BRIDGE_GAP, STREAM_Z + bank);
  solidRect(BRIDGE_GAP, STREAM_Z - bank, 40, STREAM_Z + bank);
  for (const sx of [-1, 1]) {                         // reeds and rocks on the banks
    for (let k = 0; k < 7; k++) {
      const x = sx * between(4, 22);
      add('nature', pick(['rock_smallA', 'rock_smallF', 'rock_smallG', 'plant_bushDetailed']), x, STREAM_Z + pick([-1, 1]) * between(1.9, 2.4), { rot: between(0, 6.28), s: between(0.9, 1.4), shadow: 1.2 });
    }
  }

  // ── The pond to the east, with rocks and a canoe ─────────────
  const POND = { x: 14, z: -1.5, r: 4.3 };
  water.push({ x: POND.x, z: POND.z, r: POND.r });
  clear(POND.x, POND.z, POND.r + 1.6);
  solids.push({ x: POND.x, z: POND.z, r: POND.r - 0.2 });
  for (let k = 0; k < 11; k++) {
    if (k === 9) continue;                   // a gap on the south-east side: the south shore is not shut in
    const a = (k / 11) * Math.PI * 2 + 0.3;
    // (the rock at k = 5 sits 0.2 nearer the water: at its old spot it left a sliver of ground between it and the next rock)
    const inset = k === 5 ? 0.2 : 0;
    add('nature', pick(['rock_smallA', 'rock_smallB', 'rock_smallD', 'rock_smallG', 'rock_largeA']), POND.x + Math.cos(a) * (POND.r + 0.3 - inset), POND.z + Math.sin(a) * (POND.r + 0.3 - inset), { rot: between(0, 6.28), s: between(1, 1.5), shadow: 1.6 });
  }
  add('nature', 'canoe', POND.x - POND.r - 1.6, POND.z + 2.6, { rot: 0.6, s: 1.4, box: [1.2, 4.6] });
  add('nature', 'canoe_paddle', POND.x - POND.r - 0.4, POND.z + 4.4, { rot: 1.1, s: 1.4, shadow: 0.8 });

  // ── The camp to the west: two tents, a fire, log seats ──────────────────
  const CAMP = { x: -14, z: -3 };
  clear(CAMP.x, CAMP.z, 6.5);
  add('nature', 'tent_detailedOpen', CAMP.x - 1.5, CAMP.z - 3.2, { rot: 0.25, s: 1.35, box: [3.4, 2.6] });
  add('nature', 'tent_smallOpen', CAMP.x + 3.6, CAMP.z - 2.6, { rot: -0.35, s: 1.35, box: [2.1, 2.6] });
  add('nature', 'campfire_stones', CAMP.x + 0.4, CAMP.z + 1.5, { s: 1.4, block: 0.8, shadow: 0 });
  for (let k = 0; k < 4; k++) {
    const a = 0.7 + k * 1.45, log = k % 2 === 0;
    add('nature', log ? 'log' : 'stump_round', CAMP.x + 0.4 + Math.cos(a) * 2.4, CAMP.z + 1.5 + Math.sin(a) * 2.4, { rot: a + 1.57, s: 1.2, ...(log ? { box: [0.8, 2.5] } : { block: 0.55 }) });
  }
  add('nature', 'sign', CAMP.x + 5.5, CAMP.z + 2.5, { rot: -0.6, s: 1.3, box: [1.1, 0.3] });

  // ── The village square, north of the bridge ──────────────────────────────
  clearRect(-10, -26.5, 10, -13.5);          // the paving ends at -25.5: trees may stand behind it, on the north edge
  clearRect(-2.5, -13.5, 2.5, -10.2);        // the path from the bridge to the stalls stays clear
  for (let x = -7.5; x <= 7.5; x += 3) for (let z = -15; z >= -24; z -= 3) add('town', 'road', x, z, { y: -0.06, shadow: 0 });
  add('town', 'fountain-round-detail', 0, -21, { s: 1, block: 3, shadow: 0, cover: { r: 3.1, top: 4.2 } });   // the cover keeps the camera above the spray
  add('town', 'stall-red', -3.8, -14.2, { rot: 0.2, box: [3, 3] });
  add('town', 'stall-green', 3.8, -14.2, { rot: -0.2, box: [3, 3] });
  add('town', 'stall-bench', -6.9, -12.3, { rot: 0, s: 1, box: [0.8, 2.8] });
  add('town', 'stall-stool', 7.5, -12.5, { rot: 0.2, s: 1, block: 0.35 });
  add('town', 'cart', -5.4, -26, { rot: 1.1, box: [1.9, 4] });

  // Three by three house cells. Wall pieces sit one half-cell inside their outside face; turning the
  // panel chooses the face. Every wall is HOUSE_TALL high. The door panel is the middle one of its
  // side, DOOR_WIDE long, and its two neighbours are shortened to fill the rest of that side.
  const FACE = { E: 0, N: Math.PI / 2, W: Math.PI, S: -Math.PI / 2 };
  function house(id, hx, hz, doorFace, wallSet) {
    const CELL = SCALE, WALL = CELL * HOUSE_TALL;
    const width = CELL * 3, depth = CELL * 3;
    const halfW = width / 2, halfD = depth / 2, thickness = 0.3;
    const side = doorFace === 'E' ? 1 : -1;      // the panel's z runs along +z on the east side, -z on the west
    const doorLength = CELL * DOOR_WIDE, rest = (width - doorLength) / 2;
    const doorWidth = (DOOR_OPENING.z1 - DOOR_OPENING.z0) * doorLength;
    const doorZ = hz + side * (DOOR_OPENING.z0 + DOOR_OPENING.z1) / 2 * doorLength;
    const doorHalf = doorWidth / 2;
    const building = {
      id, x: hx, z: hz, rot: 0, width, depth, floorY: 0.02, wallHeight: WALL, wallThickness: thickness,
      bounds: { x0: hx - halfW, z0: hz - halfD, x1: hx + halfW, z1: hz + halfD },
      interior: { x0: hx - halfW + thickness, z0: hz - halfD + thickness, x1: hx + halfW - thickness, z1: hz + halfD - thickness },
      entrance: { face: doorFace, x: hx + side * halfW, z: doorZ, width: doorWidth, height: DOOR_OPENING.height * WALL, approach: 1.5 },
      roofY: WALL, camera: {
        lookHeight: 1.2, lead: 0.12, distance: 5.2, minDistance: 4.2, maxDistance: 5.8,
        pitch: 42, minPitch: 37, maxPitch: 49,
        yaw: doorFace === 'E' ? -Math.PI / 4 : Math.PI / 4,
      }, shell: [],
    };
    buildings.push(building);
    clearRect(hx - halfW - 0.4, hz - halfD - 0.4, hx + halfW + 0.4, hz + halfD + 0.4);
    clear(hx + Math.sign(hx) * halfW, hz - halfD, 2.5);   // the outer north corner: no tree in the way of the path round the house
    const wallBlock = (face, x0, z0, x1, z1) => {
      if (x1 <= x0 || z1 <= z0) return;
      const block = { x: (x0 + x1) / 2, z: (z0 + z1) / 2, hw: (x1 - x0) / 2, hd: (z1 - z0) / 2, rot: 0 };
      solids.push(block);
      building.shell.push({ ...block, x0, z0, x1, z1, top: WALL, role: `wall-${face.toLowerCase()}` });
    };
    wallBlock('N', hx - halfW + thickness, hz - halfD, hx + halfW - thickness, hz - halfD + thickness);
    wallBlock('S', hx - halfW + thickness, hz + halfD - thickness, hx + halfW - thickness, hz + halfD);
    for (const face of ['E', 'W']) {
      const x0 = face === 'E' ? hx + halfW - thickness : hx - halfW;
      const x1 = face === 'E' ? hx + halfW : hx - halfW + thickness;
      const z0 = hz - halfD + thickness, z1 = hz + halfD - thickness;
      if (face === doorFace) {
        wallBlock(face, x0, z0, x1, doorZ - doorHalf);
        wallBlock(face, x0, doorZ + doorHalf, x1, z1);
      } else wallBlock(face, x0, z0, x1, z1);
    }
    let n = 0;
    for (const offset of [-CELL, 0, CELL]) {
      const x = hx + offset, z = hz + offset;
      for (const [face, px, pz] of [
        ['N', x, hz - halfD + CELL / 2], ['S', x, hz + halfD - CELL / 2],
        ['W', hx - halfW + CELL / 2, z], ['E', hx + halfW - CELL / 2, z],
      ]) {
        const onDoorSide = face === doorFace, door = onDoorSide && offset === 0;
        const name = door ? 'wall-wood-doorway-square-wide' : wallSet[n++ % wallSet.length];
        const sz = !onDoorSide ? 1 : door ? DOOR_WIDE : rest / CELL;
        const itemZ = onDoorSide && !door ? hz + Math.sign(offset) * (doorLength + rest) / 2 : pz;
        add('town', name, px, itemZ, { rot: FACE[face], sy: HOUSE_TALL, sz, shadow: 0, cover: false, buildingId: id, role: `wall-${face.toLowerCase()}` });
      }
      for (const roofX of [-CELL, 0, CELL]) add('town', 'roof-gable', hx + roofX, z, { y: WALL, shadow: 0, cover: false, buildingId: id, role: 'roof' });
    }
    add('town', 'chimney', hx + halfW - CELL / 2, hz - halfD + CELL / 2, { y: WALL, shadow: 0, cover: false, buildingId: id, role: 'roof' });
  }
  house('house-west', -12, -18, 'E', ['wall-wood', 'wall-wood-window-glass', 'wall-wood-window-shutters']);
  house('house-east', 12, -18, 'W', ['wall-wood-window-glass', 'wall-wood', 'wall-wood-window-small']);
  // The view from the south: at a door the camera stands about 6.5 units south of her, centred on her, so a strip there stays
  // free of scatter (a grass clump at that spot hid her from the house-east approach view).
  for (const b of buildings) { const ax = b.entrance.x + (b.entrance.face === 'E' ? 1 : -1) * 2.4; clearRect(ax - 2, b.bounds.z1 + 0.5, ax + 2, b.bounds.z1 + 7.5); }

  // ── Trees ──────────────────────────────────────────────────────────────
  const TREES = [['town', 'tree', 0.72], ['town', 'tree-high', 0.55], ['town', 'tree-crooked', 0.72], ['town', 'tree-high-round', 0.55]];
  const tree = (x, z) => { const [pack, name, s] = pick(TREES); add(pack, name, x, z, { rot: between(0, 6.28), s: s * between(0.9, 1.15), block: 0.55, shadow: 2.6 }); };
  for (let k = 0; k < 64; k++) {                       // a ring around the edge: the end of the world
    const a = (k / 64) * Math.PI * 2 + between(-0.03, 0.03), r = between(27.3, 29.1);
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (isClear(x, z, 1) === false) continue;
    tree(x, z);
  }
  for (let k = 0, tries = 0; k < 16 && tries < 400; tries++) {   // a few in the meadows
    const a = between(0, 6.28), r = between(8, 26), x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (!isClear(x, z, 2.5) || solids.some(c => SOLID.overlaps(c, x, z, 3.4))) continue;
    tree(x, z); k++;
  }

  // ── Flowers, grass and mushrooms to wander through ───────────────────────
  const FLOWERS = ['flower_redA', 'flower_redB', 'flower_redC', 'flower_yellowA', 'flower_yellowB', 'flower_yellowC', 'flower_purpleA', 'flower_purpleB', 'flower_purpleC'];
  const scatter = (n, names, rMin, rMax, sMin, sMax, touch = null) => {
    for (let k = 0, tries = 0; k < n && tries < n * 20; tries++) {
      const a = between(0, 6.28), r = Math.sqrt(between(rMin * rMin, rMax * rMax)), x = Math.cos(a) * r, z = Math.sin(a) * r;
      if (!isClear(x, z) || solids.some(c => SOLID.overlaps(c, x, z, 0.4))) continue;
      add('nature', pick(names), x, z, { rot: between(0, 6.28), s: between(sMin, sMax), shadow: 0, touch });
      k++;
    }
  };
  scatter(260, FLOWERS, 1, 26, 0.55, 0.9, 'wiggle');
  scatter(150, ['grass', 'grass_large', 'grass_leafs', 'grass_leafsLarge'], 1, 26, 0.6, 1, 'wiggle');
  scatter(12, ['mushroom_red', 'mushroom_redGroup', 'mushroom_tan', 'mushroom_tanGroup'], 6, 26, 1, 1.5, 'wiggle');
  scatter(14, ['rock_smallA', 'rock_smallC', 'rock_smallE', 'rock_smallH', 'plant_bush', 'plant_bushDetailed'], 5, 26, 0.8, 1.3);

  // Detail added last, so the random sequence above (and with it every solid) stays the same.
  // Small flower groups mark the edge of the stepping-stone route; none is solid.
  const freeSpot = (x, z) => isClear(x, z) && !solids.some(c => SOLID.overlaps(c, x, z, 0.4));
  [-4.1, -6.2, -11.3, -3.2].forEach((z, k) => {
    const side = k % 2 ? 1 : -1, cx = Math.sin(z * 0.45) * 1.7 + side * 2.1;
    for (let n = 0, tries = 0; n < 5 && tries < 30; tries++) {
      const a = between(0, 6.28), r = between(0.1, 0.5), x = cx + Math.cos(a) * r, fz = z + Math.sin(a) * r;
      if (!freeSpot(x, fz)) continue;
      add('nature', FLOWERS[(k * 3 + n) % 6], x, fz, { rot: between(0, 6.28), s: between(0.6, 0.8), shadow: 0, touch: 'wiggle' });
      n++;
    }
  });

  features.push({ type: 'fountain', x: 0, z: -21, r: 3 });
  features.push({ type: 'fire', x: CAMP.x + 0.4, z: CAMP.z + 1.5 });
  features.push({ type: 'butterflies', x: 1, z: 5, r: 10, n: 6 });
  features.push({ type: 'butterflies', x: POND.x, z: POND.z, r: 5, n: 3 });
  features.push({ type: 'butterflies', x: -3, z: -17, r: 8, n: 3 });

  // The doorway zone of a house: where going in or out counts. Outward from its outer wall it runs from
  // -wallThickness - r (the room's edge) to approach + r (so standing about 1.5 units outside a door is entering),
  // and across the opening within width / 2 + r. r is the walker's radius: world.js (her) and npcs.js (a friend)
  // both ask this, so they agree on the zone.
  function inDoorway(b, x, z, r) {
    const e = b.entrance, outward = e.face === 'E' ? 1 : -1, depth = (x - e.x) * outward;
    return Math.abs(z - e.z) <= e.width / 2 + r && depth >= -b.wallThickness - r && depth <= e.approach + r;
  }

  // Cracks no one can walk into: free ground between rocks, water, trees and the world's edge that the walking map cannot
  // reach. Each gets a small rock (a tiny block, so it only fills that cell). Added last, so nothing above moves;
  // scripts/world-layout-check.js fails if a free cell of the 0.5 grid is unreachable, so this list follows any layout change.
  add('nature', 'rock_smallA', -28.5, -5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -28.5, -4.5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -28.5, -4, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -20.5, 20.5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -13, -5.5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -12.5, -5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -12, -6.5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -12, -6, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -11.5, -7, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -6, -28, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -5.5, -28.5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', 12, 25.5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', 12.5, -26, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', 12.5, -25.5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', 12.5, 26, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', 13, -25.5, { block: 0.05, shadow: 0 });

  add('nature', 'rock_smallA', -28.5, -5.5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -13, -5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', -12.5, -5.5, { block: 0.05, shadow: 0 });
  add('nature', 'rock_smallA', 13.5, -25.5, { block: 0.05, shadow: 0 });

  window.WORLD_LAYOUT = { scale: SCALE, bounds: BOUNDS, start: { x: 0, z: 0 }, items, solids, water, features, buildings, inDoorway };
})();
