// What is in the world and where. Pure data: world.js builds whatever this describes, so adding a
// tree, a tent or a whole new corner means adding an entry here and nothing else.
//
// Coordinates are world units on the ground: x runs right, z runs toward the camera, so "north"
// (away from the camera) is negative z. She starts at (0, 0), looking north. She is about 2.1
// units tall; the Kenney models are drawn about 1 unit big, so SCALE brings them up to her size.
//
// An item is { pack, name, x, z, rot, s, block, box, stand, shadow }:
//   pack, name  a model in WORLD_PACKS (world/assets/packs), e.g. 'nature', 'tree_default'
//   rot         turn around the vertical axis, in radians (0 = as modelled, front toward +z)
//   s           extra size on top of SCALE
//   block       she cannot walk closer than this (+ her own radius) to the item's middle. Rocks and
//               bushes get one from their size (ROUND below) unless it is given.
//   box         [w, d]: she cannot walk into this rectangle (world units, w along the model's x,
//               turned with it), for long things such as a canoe or a log. Instead of block.
//   stand       she walks on top of it (the bridge): her height there comes from
//               the model's own shape
//   shadow      width of the soft shadow on the ground (default: from block or box)
//   touch       'wiggle': it sways and sparkles when she walks through it (see life.js)
//   cover       space the camera must stay out of, up to height `top`: { r, top } (round, around the
//               item) or { x0, z0, x1, z1, top } (a rectangle). Every model taller than 1.6 that she
//               cannot walk through gets a round one from its own size; set it by hand for things
//               built of parts (false: none).
//
// Everything solid also lands in `solids` (circles and rectangles, see solid.js), which is what
// walking uses. Classic script (no modules) so it works when the page is opened from file://.
(function () {
  const SOLID = window.WORLD_SOLID;          // solid.js, loaded first
  const SCALE = 3;
  const BOUNDS = 25.5;                       // she can walk inside a circle this big
  const items = [];
  const solids = [];                         // what she cannot walk through
  const water = [];                          // { x, z, w, d } strips and { x, z, r } discs
  const features = [];                       // living things (life.js): fountain, fire, butterflies
  const keepClear = [];                      // circles / rects that scatter must not drop things in
  // Rocks and bushes are solid: about this far round (model units, before SCALE and s).
  const ROUND = {
    rock_smallA: 0.18, rock_smallB: 0.18, rock_smallC: 0.18, rock_smallD: 0.19, rock_smallE: 0.17, rock_smallF: 0.16,
    rock_smallG: 0.3, rock_smallH: 0.23, rock_largeA: 0.42, plant_bush: 0.2, plant_bushDetailed: 0.3,
  };

  // A small seeded random generator, so the world is the same every time.
  let seed = 20261002;
  const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
  const between = (a, b) => a + (b - a) * rnd();
  const pick = list => list[Math.floor(rnd() * list.length)];

  function add(pack, name, x, z, o = {}) {
    const s = (o.s || 1) * SCALE, rot = o.rot || 0;
    const block = o.block !== undefined ? o.block : ROUND[name] ? ROUND[name] * s * 0.85 : 0;   // a rock's edge is lower than its middle
    const solid = o.box ? { x, z, hw: o.box[0] / 2, hd: o.box[1] / 2, rot } : block ? { x, z, r: block } : null;
    if (solid) solids.push(solid);
    const shadow = o.shadow !== undefined ? o.shadow : o.box ? Math.sqrt(o.box[0] * o.box[1]) * 1.3 : block * 2.6;
    items.push({ pack, name, x, z, rot, s, y: o.y || 0, solid, stand: !!o.stand, shadow, touch: o.touch || null, cover: o.cover });
  }
  const solidRect = (x0, z0, x1, z1) => solids.push({ x: (x0 + x1) / 2, z: (z0 + z1) / 2, hw: (x1 - x0) / 2, hd: (z1 - z0) / 2, rot: 0 });
  const clear = (x, z, r) => keepClear.push({ x, z, r });
  const clearRect = (x0, z0, x1, z1) => keepClear.push({ x0, z0, x1, z1 });
  const isClear = (x, z, pad = 0) => !keepClear.some(c => c.r !== undefined
    ? Math.hypot(x - c.x, z - c.z) < c.r + pad
    : x > c.x0 - pad && x < c.x1 + pad && z > c.z0 - pad && z < c.z1 + pad);

  // ── The path she starts on: stepping stones north, over the bridge, into the village ─────
  clear(0, 0, 2);                            // her starting spot
  for (let z = -2, k = 0; z > -13; z -= 2.1, k++) {   // (the paving of the village starts at -13.5)
    if (Math.abs(z + 9) < 2.3) continue;     // the bridge is here
    const x = Math.sin(z * 0.45) * 1.7;
    add('nature', k % 3 === 2 ? 'path_stoneCircle' : 'path_stone', x, z, { rot: Math.cos(z * 0.45) * 0.5 + (k % 2 ? 0.1 : -0.1), y: 0.03, shadow: 0 });   // flat: she walks over them, no step up
    clear(x, z, 1.3);
  }

  // ── The stream and its bridge ────────────────────────────────────────────
  // She cannot wade into the water (her toes may reach its edge). The only gap is the bridge: she
  // walks up its steps and over its deck, between the rails.
  const STREAM_Z = -9, STREAM_W = 3.4, BRIDGE_GAP = 1.2;   // half the width she may walk on the bridge
  water.push({ x: 0, z: STREAM_Z, w: 70, d: STREAM_W });
  add('nature', 'bridge_wood', 0, STREAM_Z, { rot: Math.PI / 2, s: 1.12, stand: true });
  clearRect(-60, STREAM_Z - 2.3, 60, STREAM_Z + 2.3);
  const bank = STREAM_W / 2 - 0.25;
  solidRect(-40, STREAM_Z - bank, -BRIDGE_GAP, STREAM_Z + bank);
  solidRect(BRIDGE_GAP, STREAM_Z - bank, 40, STREAM_Z + bank);
  for (const sx of [-1, 1]) {                         // reeds and rocks on the banks
    for (let k = 0; k < 7; k++) {
      const x = sx * between(4, 22);
      add('nature', pick(['rock_smallA', 'rock_smallF', 'rock_smallG', 'plant_bushDetailed']), x, STREAM_Z + pick([-1, 1]) * between(1.9, 2.4), { rot: between(0, 6.28), s: between(0.9, 1.4), shadow: 1.2 });
    }
  }

  // ── The pond to the east, with rocks and a canoe ─────────────
  const POND = { x: 14, z: -1.5, r: 4.3 };
  water.push({ x: POND.x, z: POND.z, r: POND.r });
  clear(POND.x, POND.z, POND.r + 1.6);
  solids.push({ x: POND.x, z: POND.z, r: POND.r - 0.2 });
  for (let k = 0; k < 11; k++) {
    const a = (k / 11) * Math.PI * 2 + 0.3;
    add('nature', pick(['rock_smallA', 'rock_smallB', 'rock_smallD', 'rock_smallG', 'rock_largeA']), POND.x + Math.cos(a) * (POND.r + 0.3), POND.z + Math.sin(a) * (POND.r + 0.3), { rot: between(0, 6.28), s: between(1, 1.5), shadow: 1.6 });
  }
  add('nature', 'canoe', POND.x - POND.r - 1.6, POND.z + 2.6, { rot: 0.6, s: 1.4, box: [1.2, 4.6] });
  add('nature', 'canoe_paddle', POND.x - POND.r - 0.4, POND.z + 4.4, { rot: 1.1, s: 1.4, shadow: 0.8 });

  // ── The camp to the west: two tents, a fire, log seats ──────────────────
  const CAMP = { x: -14, z: -3 };
  clear(CAMP.x, CAMP.z, 6.5);
  add('nature', 'tent_detailedOpen', CAMP.x - 1.5, CAMP.z - 3.2, { rot: 0.25, s: 1.35, box: [3.4, 2.6] });
  add('nature', 'tent_smallOpen', CAMP.x + 3.6, CAMP.z - 2.6, { rot: -0.35, s: 1.35, box: [2.1, 2.6] });
  add('nature', 'campfire_stones', CAMP.x + 0.4, CAMP.z + 1.5, { s: 1.4, block: 0.8, shadow: 0 });
  for (let k = 0; k < 4; k++) {
    const a = 0.7 + k * 1.45, log = k % 2 === 0;
    add('nature', log ? 'log' : 'stump_round', CAMP.x + 0.4 + Math.cos(a) * 2.4, CAMP.z + 1.5 + Math.sin(a) * 2.4, { rot: a + 1.57, s: 1.2, ...(log ? { box: [0.8, 2.5] } : { block: 0.55 }) });
  }
  add('nature', 'sign', CAMP.x + 5.5, CAMP.z + 2.5, { rot: -0.6, s: 1.3, box: [1.1, 0.3] });

  // ── The village square, north of the bridge ──────────────────────────────
  clearRect(-10, -29, 10, -13.5);
  for (let x = -7.5; x <= 7.5; x += 3) for (let z = -15; z >= -27; z -= 3) add('town', 'road', x, z, { y: -0.06, shadow: 0 });
  add('town', 'fountain-round-detail', 0, -21, { s: 1, block: 3, shadow: 0, cover: { r: 3.1, top: 4.2 } });   // the cover keeps the camera above the spray
  add('town', 'stall-red', -7.2, -18.2, { rot: 0.5, box: [3, 3] });
  add('town', 'stall-green', 7.2, -18.2, { rot: -0.5, box: [3, 3] });
  add('town', 'stall-bench', -6, -16, { rot: 0.5, s: 1, box: [0.8, 2.8] });
  add('town', 'stall-stool', 6, -15.8, { rot: 0.2, s: 1, block: 0.35 });
  add('town', 'cart', 8.6, -24, { rot: 1.1, box: [1.9, 4] });

  // A little house: 2 x 2 cells of wall panels and a gable roof on each cell. A wall panel sits on
  // the +x face of its cell (model origin = cell centre), so turning it picks which face it is on.
  const FACE = { E: 0, N: Math.PI / 2, W: Math.PI, S: -Math.PI / 2 };
  function house(hx, hz, doorFace, wallSet) {
    const CELL = SCALE;
    let n = 0;
    for (const [cx, cz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
      const px = hx + cx * CELL / 2, pz = hz + cz * CELL / 2;
      for (const f of [cx > 0 ? 'E' : 'W', cz > 0 ? 'S' : 'N']) {
        const door = f === doorFace && cz > 0;               // the door is in the southern cell of that side
        add('town', door ? 'wall-wood-door' : wallSet[n++ % wallSet.length], px, pz, { rot: FACE[f], shadow: 0, cover: false });
      }
      add('town', 'roof-gable', px, pz, { y: CELL, shadow: 0, cover: false });
    }
    add('town', 'chimney', hx + CELL / 2, hz - CELL / 2, { y: CELL, shadow: 0, cover: false });
    solidRect(hx - CELL, hz - CELL, hx + CELL, hz + CELL);   // she cannot walk into it: the walls are its edges
    // The camera stays out of the house (up to the top of the roof), and the house's shadow.
    const half = CELL + 0.2;
    items.push({ pack: null, name: null, x: hx, z: hz, rot: 0, s: 1, y: 0, solid: null, shadow: CELL * 3.2, cover: { x0: hx - half, z0: hz - half, x1: hx + half, z1: hz + half, top: CELL * 1.6 } });
  }
  house(-13.5, -21.5, 'E', ['wall-wood', 'wall-wood-window-glass', 'wall-wood-window-shutters']);
  house(13.5, -21.5, 'W', ['wall-wood-window-glass', 'wall-wood', 'wall-wood-window-small']);

  // ── Trees ──────────────────────────────────────────────────────────────
  const TREES = [['town', 'tree', 0.72], ['town', 'tree-high', 0.55], ['town', 'tree-crooked', 0.72], ['town', 'tree-high-round', 0.55]];
  const tree = (x, z) => { const [pack, name, s] = pick(TREES); add(pack, name, x, z, { rot: between(0, 6.28), s: s * between(0.9, 1.15), block: 0.55, shadow: 2.6 }); };
  for (let k = 0; k < 64; k++) {                       // a ring around the edge: the end of the world
    const a = (k / 64) * Math.PI * 2 + between(-0.03, 0.03), r = between(23.6, 26.4);
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (isClear(x, z, 1) === false) continue;
    tree(x, z);
  }
  for (let k = 0, tries = 0; k < 16 && tries < 400; tries++) {   // a few in the meadows
    const a = between(0, 6.28), r = between(8, 21), x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (!isClear(x, z, 2.5) || solids.some(c => SOLID.overlaps(c, x, z, 3.4))) continue;
    tree(x, z); k++;
  }

  // ── Flowers, grass and mushrooms to wander through ───────────────────────
  const FLOWERS = ['flower_redA', 'flower_redB', 'flower_redC', 'flower_yellowA', 'flower_yellowB', 'flower_yellowC', 'flower_purpleA', 'flower_purpleB', 'flower_purpleC'];
  const scatter = (n, names, rMin, rMax, sMin, sMax, touch = null) => {
    for (let k = 0, tries = 0; k < n && tries < n * 20; tries++) {
      const a = between(0, 6.28), r = Math.sqrt(between(rMin * rMin, rMax * rMax)), x = Math.cos(a) * r, z = Math.sin(a) * r;
      if (!isClear(x, z) || solids.some(c => SOLID.overlaps(c, x, z, 0.4))) continue;
      add('nature', pick(names), x, z, { rot: between(0, 6.28), s: between(sMin, sMax), shadow: 0, touch });
      k++;
    }
  };
  scatter(260, FLOWERS, 1, 22, 0.55, 0.9, 'wiggle');
  scatter(150, ['grass', 'grass_large', 'grass_leafs', 'grass_leafsLarge'], 1, 23, 0.6, 1, 'wiggle');
  scatter(12, ['mushroom_red', 'mushroom_redGroup', 'mushroom_tan', 'mushroom_tanGroup'], 6, 21, 1, 1.5, 'wiggle');
  scatter(14, ['rock_smallA', 'rock_smallC', 'rock_smallE', 'rock_smallH', 'plant_bush', 'plant_bushDetailed'], 5, 22, 0.8, 1.3);

  // Detail added last, so the random sequence above (and with it every solid) stays the same.
  // Small flower groups mark the edge of the stepping-stone route; none is solid.
  const freeSpot = (x, z) => isClear(x, z) && !solids.some(c => SOLID.overlaps(c, x, z, 0.4));
  [-4.1, -6.2, -11.3, -3.2].forEach((z, k) => {
    const side = k % 2 ? 1 : -1, cx = Math.sin(z * 0.45) * 1.7 + side * 2.1;
    for (let n = 0, tries = 0; n < 5 && tries < 30; tries++) {
      const a = between(0, 6.28), r = between(0.1, 0.5), x = cx + Math.cos(a) * r, fz = z + Math.sin(a) * r;
      if (!freeSpot(x, fz)) continue;
      add('nature', FLOWERS[(k * 3 + n) % 6], x, fz, { rot: between(0, 6.28), s: between(0.6, 0.8), shadow: 0, touch: 'wiggle' });
      n++;
    }
  });

  features.push({ type: 'fountain', x: 0, z: -21, r: 3 });
  features.push({ type: 'fire', x: CAMP.x + 0.4, z: CAMP.z + 1.5 });
  features.push({ type: 'butterflies', x: 1, z: 5, r: 10, n: 6 });
  features.push({ type: 'butterflies', x: POND.x, z: POND.z, r: 5, n: 3 });
  features.push({ type: 'butterflies', x: -3, z: -17, r: 8, n: 3 });

  window.WORLD_LAYOUT = { scale: SCALE, bounds: BOUNDS, start: { x: 0, z: 0 }, items, solids, water, features };
})();
