// What you see when friends meet (epic makeupgame-oq2, N10): a speech bubble, tears, fart clouds. Flat pictures that
// always face the camera (sprites), drawn once into small canvases and shared, from a pool that only grows to the most
// ever shown at once, so a visit adds no textures and no materials.
//
//   WORLD_FX.bubble(n, 'Hi!', 'hi')   a bubble over a friend's head that pops up, stays a moment and fades (style: hi, laugh, yay, boo, shock)
//   WORLD_FX.notes(n, seconds)   music notes floating up from a dancing friend
//   WORLD_FX.sparkles(n, seconds)   little stars flying round a twirling friend
//   WORLD_FX.tears(n, seconds)   drops shooting out sideways from both eyes, the cartoon way
//   WORLD_FX.puff(n)             little green clouds from behind that swell, float up and fade
//   WORLD_FX.zzz(n, alive)       Z z z drifting up from a sleeper's head while alive() is true (room actions, world/roomactions.js)
//   WORLD_FX.steam(at, alive, o) soft white puffs rising from at(out) (a pan, a shower) while alive() is true; o: { rate, size, rise, spread }
//   WORLD_FX.bubbles(at, alive, o) soap bubbles wobbling up from at(out) while alive() is true; o: { rate, size, rise }
(() => {
  'use strict';
  const T = window.THREE;
  // Where a friend's eyes are, from the head bone (the base of the skull), in world units: up, forward, apart.
  const EYES = { up: 0.36, fwd: 0.3, apart: 0.17 };
  const BUBBLE = { up: 1.05, w: 1.2, h: 0.75 };
  const TEAR = { rate: 18, size: 0.17, life: 0.8, gravity: 6 };
  const STYLES = {                 // the bubble's outline and its word
    hi: { line: '#e0629a', text: '#c2185b' },
    laugh: { line: '#f0a000', text: '#d46a00' },
    yay: { line: '#3fb56a', text: '#1f8f4a' },
    boo: { line: '#7e3fc4', text: '#5b1fa0' },
    shock: { line: '#e0452f', text: '#c62828' },
  };
  const NOTES = { rate: 3.2, life: 1.5, size: 0.34, colours: ['#ff5ea8', '#ffb400', '#3fb5ff', '#7bd44a', '#b070ff'] };
  const STARS = { rate: 16, life: 0.55, size: 0.3, reach: 0.75, colours: ['#fff2a0', '#ffd23f', '#ffffff', '#ffb6e0'] };
  const ZEDS = { rate: 1.1, life: 2.2, size: 0.4, rise: 0.8, colours: ['#7a6cff', '#b070ff', '#5aa8ff'] };
  const PUFF = { count: 10, over: 0.6, life: 2.0, from: 0.45, to: 1.5, colours: ['#a8d64a', '#c4dc3c', '#94c84a', '#b8c95a'] };

  const sceneNow = () => WORLD.parts.scene;      // the scene she is in now: sprites from a room action show inside a house too
  const live = [];                 // { s (the sprite), t, life, step(it, dt) -> false when done }
  const spare = [];
  const tex = {};

  function canvasTex(w, h, draw) {
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h);
    const t = new T.CanvasTexture(c);
    t.colorSpace = T.SRGBColorSpace;
    return t;
  }
  function textures() {
    if (tex.drop) return tex;
    tex.drop = canvasTex(48, 64, (g) => {          // a tear: a drop with a shine
      g.beginPath(); g.moveTo(24, 2); g.bezierCurveTo(30, 18, 44, 32, 44, 43); g.arc(24, 43, 20, 0, Math.PI); g.bezierCurveTo(4, 32, 18, 18, 24, 2);
      g.fillStyle = '#6cc8ff'; g.fill(); g.lineWidth = 3; g.strokeStyle = '#2f8fd8'; g.stroke();
      g.beginPath(); g.ellipse(17, 42, 4, 8, -0.3, 0, Math.PI * 2); g.fillStyle = 'rgba(255,255,255,0.85)'; g.fill();
    });
    tex.puff = canvasTex(128, 128, (g) => {        // a lumpy cloud, white (each puff is tinted)
      for (const [x, y, r] of [[64, 70, 38], [40, 62, 26], [88, 60, 28], [60, 42, 26], [78, 86, 24], [44, 86, 22]]) {
        const grad = g.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r);
        grad.addColorStop(0, 'rgba(255,255,255,1)'); grad.addColorStop(0.7, 'rgba(215,225,200,1)'); grad.addColorStop(0.92, 'rgba(150,165,120,0.9)'); grad.addColorStop(1, 'rgba(150,165,120,0)');
        g.fillStyle = grad; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
      }
    });
    tex.note = canvasTex(64, 96, (g) => {          // an eighth note, white (each one is tinted)
      g.fillStyle = '#ffffff'; g.strokeStyle = '#ffffff'; g.lineCap = 'round';
      g.beginPath(); g.ellipse(22, 72, 15, 11, -0.4, 0, Math.PI * 2); g.fill();
      g.lineWidth = 7; g.beginPath(); g.moveTo(34, 68); g.lineTo(34, 14); g.stroke();
      g.beginPath(); g.moveTo(34, 14); g.bezierCurveTo(40, 34, 58, 36, 54, 60); g.lineWidth = 9; g.stroke();
    });
    tex.zed = canvasTex(64, 64, (g) => {           // a fat letter Z, white with a dark edge (each one is tinted)
      g.font = 'bold 52px "Comic Sans MS", "Chalkboard SE", sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.lineWidth = 8; g.lineJoin = 'round'; g.strokeStyle = 'rgba(40,30,90,0.9)'; g.strokeText('Z', 32, 36);
      g.fillStyle = '#ffffff'; g.fillText('Z', 32, 36);
    });
    tex.soft = canvasTex(64, 64, (g) => {          // a soft round puff of steam, white
      const grad = g.createRadialGradient(32, 32, 2, 32, 32, 31);
      grad.addColorStop(0, 'rgba(255,255,255,0.95)'); grad.addColorStop(0.5, 'rgba(255,255,255,0.5)'); grad.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = grad; g.fillRect(0, 0, 64, 64);
    });
    tex.bubble = canvasTex(64, 64, (g) => {        // a soap bubble: a thin ring with a shine, a pale tint inside
      const grad = g.createRadialGradient(32, 32, 14, 32, 32, 30);
      grad.addColorStop(0, 'rgba(180,225,255,0.10)'); grad.addColorStop(0.85, 'rgba(190,230,255,0.45)'); grad.addColorStop(1, 'rgba(255,255,255,0.9)');
      g.fillStyle = grad; g.beginPath(); g.arc(32, 32, 29, 0, Math.PI * 2); g.fill();
      g.strokeStyle = 'rgba(120,190,255,0.9)'; g.lineWidth = 2.5; g.stroke();
      g.fillStyle = 'rgba(255,255,255,0.95)'; g.beginPath(); g.ellipse(22, 20, 7, 4, -0.7, 0, Math.PI * 2); g.fill();
    });
    tex.star = canvasTex(64, 64, (g) => {          // a four-pointed star, white
      g.fillStyle = '#ffffff';
      g.beginPath();
      for (let i = 0; i < 8; i++) { const r = i % 2 ? 9 : 30, a = (i * Math.PI) / 4 - Math.PI / 2; g.lineTo(32 + r * Math.cos(a), 32 + r * Math.sin(a)); }
      g.closePath(); g.fill();
    });
    return tex;
  }
  function bubbleTex(word, style = 'hi') {
    const key = 'bubble:' + style + ':' + word, S = STYLES[style] || STYLES.hi;
    return tex[key] || (tex[key] = canvasTex(256, 160, (g, w) => {
      g.beginPath(); g.roundRect(8, 8, w - 16, 112, 48);
      g.moveTo(104, 116); g.lineTo(100, 154); g.lineTo(140, 116);           // the tail, down to the head
      g.fillStyle = '#ffffff'; g.fill(); g.lineWidth = 6; g.strokeStyle = S.line; g.stroke();
      g.fillStyle = '#ffffff'; g.fillRect(100, 108, 44, 12);                  // no line between the bubble and its tail
      g.font = 'bold 72px "Comic Sans MS", "Chalkboard SE", sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillStyle = S.text; g.fillText(word, w / 2, 66);
    }));
  }

  function sprite(map) {
    let s = spare.pop();
    if (!s) s = new T.Sprite(new T.SpriteMaterial({ map, transparent: true, depthWrite: false }));
    s.material.map = map; s.material.opacity = 1; s.material.rotation = 0; s.material.color.set('#ffffff');
    s.renderOrder = 4;
    s.visible = true;
    sceneNow().add(s);
    return s;
  }
  function add(it) { live.push(it); return it; }

  // ── Where on a friend ────────────────────────────────────────────────────
  const v = new T.Vector3();
  function head(n, out) { return n.bones.head ? n.bones.head.getWorldPosition(out) : out.copy(n.group.position).setY(n.group.position.y + 1.4); }
  const fwdOf = n => ({ x: Math.sin(n.pivot.rotation.y), z: Math.cos(n.pivot.rotation.y) });

  // ── The effects ──────────────────────────────────────────────────────────
  function bubble(n, word, style) {
    const s = sprite(bubbleTex(word, style));
    add({ s, t: 0, life: 1.6, step(it) {
      head(n, v);
      s.position.set(v.x, v.y + BUBBLE.up, v.z);
      const t = it.t, pop = t < 0.18 ? 1.15 * t / 0.18 : t < 0.3 ? 1.15 - 0.15 * (t - 0.18) / 0.12 : 1;   // pops up, a little too big, then settles
      s.scale.set(BUBBLE.w * pop, BUBBLE.h * pop, 1);
      s.material.opacity = t > it.life - 0.3 ? (it.life - t) / 0.3 : 1;
      return t < it.life;
    } });
  }

  function tears(n, seconds) {
    textures();
    add({ s: null, t: 0, life: seconds, due: 0, side: 1, step(it, dt) {
      if (!n.perf || n.perf.kind !== 'cry') return false;   // stopped crying (a bump, a tap)
      it.due -= dt;
      while (it.due <= 0) { it.due += 1 / TEAR.rate; it.side = -it.side; drop(n, it.side); }
      return it.t < it.life;
    } });
  }
  function drop(n, side) {
    const f = fwdOf(n), rx = f.z, rz = -f.x;                // the friend's right
    head(n, v);
    const s = sprite(tex.drop);
    s.position.set(v.x + f.x * EYES.fwd + rx * EYES.apart * side, v.y + EYES.up, v.z + f.z * EYES.fwd + rz * EYES.apart * side);
    const out = 1.1 + Math.random() * 0.6, up = 0.9 + Math.random() * 0.6;
    const vel = new T.Vector3(rx * side * out + f.x * 0.35, up, rz * side * out + f.z * 0.35);
    s.scale.set(TEAR.size * 0.75, TEAR.size, 1);
    add({ s, t: 0, life: TEAR.life * (0.8 + Math.random() * 0.4), step(it, dt) {
      vel.y -= TEAR.gravity * dt;
      s.position.addScaledVector(vel, dt);
      s.material.opacity = Math.min(1, (it.life - it.t) / 0.2);
      return it.t < it.life;
    } });
  }

  // Music notes: one every so often from above the head, drifting up and to the side, while the friend dances.
  function notes(n, seconds) {
    textures();
    add({ s: null, t: 0, life: seconds, due: 0, step(it, dt) {
      if (!n.perf || n.perf.kind !== 'dance') return false;
      it.due -= dt;
      while (it.due <= 0) { it.due += 1 / NOTES.rate; note(n); }
      return it.t < it.life;
    } });
  }
  function note(n) {
    head(n, v);
    const s = sprite(tex.note), side = Math.random() < 0.5 ? -1 : 1, rx = Math.cos(n.pivot.rotation.y), rz = -Math.sin(n.pivot.rotation.y);
    s.material.color.set(NOTES.colours[Math.floor(Math.random() * NOTES.colours.length)]);
    s.position.set(v.x + rx * side * 0.35, v.y + 0.6, v.z + rz * side * 0.35);
    const x0 = s.position.x, y0 = v.y + 0.6, z0 = s.position.z, sway = 0.15 + Math.random() * 0.2, rate = 3 + Math.random() * 2, ph = Math.random() * 6, up = 0.7 + Math.random() * 0.4;
    s.scale.set(NOTES.size * 0.67, NOTES.size, 1);
    add({ s, t: 0, life: NOTES.life * (0.8 + Math.random() * 0.4), step(it) {
      const t = it.t;
      s.position.set(x0 + rx * side * t * 0.5 + rx * Math.sin(t * rate + ph) * sway, y0 + up * t, z0 + rz * side * t * 0.5 + rz * Math.sin(t * rate + ph) * sway);
      s.material.rotation = 0.25 * Math.sin(t * rate + ph);
      s.material.opacity = Math.min(1, (it.life - t) / 0.4);
      return t < it.life;
    } });
  }

  // Stars flying out round a twirling friend: they spin and shrink away.
  function sparkles(n, seconds) {
    textures();
    add({ s: null, t: 0, life: seconds, due: 0, step(it, dt) {
      if (!n.perf || n.perf.kind !== 'twirl') return false;
      it.due -= dt;
      while (it.due <= 0) { it.due += 1 / STARS.rate; star(n); }
      return it.t < it.life;
    } });
  }
  function star(n) {
    const p = n.group.position, a = Math.random() * Math.PI * 2, r = STARS.reach * (0.7 + Math.random() * 0.5);
    const s = sprite(tex.star);
    s.material.color.set(STARS.colours[Math.floor(Math.random() * STARS.colours.length)]);
    s.position.set(p.x + Math.cos(a) * r * 0.6, p.y + 0.3 + Math.random() * 1.5, p.z + Math.sin(a) * r * 0.6);
    const out = new T.Vector3(Math.cos(a) * 0.7, 0.2 + Math.random() * 0.4, Math.sin(a) * 0.7), spin = (Math.random() - 0.5) * 6, size = STARS.size * (0.6 + Math.random() * 0.6);
    add({ s, t: 0, life: STARS.life * (0.8 + Math.random() * 0.4), step(it, dt) {
      const k = it.t / it.life;
      s.position.addScaledVector(out, dt);
      s.scale.setScalar(size * (k < 0.25 ? k / 0.25 : 1 - (k - 0.25) / 0.75));
      s.material.rotation += spin * dt;
      return it.t < it.life;
    } });
  }

  function puff(n) {
    textures();
    let made = 0;
    add({ s: null, t: 0, life: PUFF.over, step(it) {
      while (made < PUFF.count * Math.min(1, it.t / PUFF.over)) { made++; cloud(n); }
      return it.t < it.life;
    } });
  }
  function cloud(n) {
    const f = fwdOf(n), p = n.group.position, rx = f.z, rz = -f.x, side = (Math.random() < 0.5 ? -1 : 1) * (0.4 + Math.random() * 0.6);   // billowing out to both sides, so they show round the friend
    const s = sprite(tex.puff);
    s.material.color.set(PUFF.colours[Math.floor(Math.random() * PUFF.colours.length)]);
    s.material.rotation = Math.random() * Math.PI * 2;
    s.position.set(p.x - f.x * 0.38 + rx * side * 0.15, p.y + 0.62 + Math.random() * 0.12, p.z - f.z * 0.38 + rz * side * 0.15);
    const back = 0.3 + Math.random() * 0.4;
    const vel = new T.Vector3(-f.x * back + rx * side * 1.3, 0.35 + Math.random() * 0.5, -f.z * back + rz * side * 1.3);
    const spin = (Math.random() - 0.5) * 1.5, life = PUFF.life * (0.8 + Math.random() * 0.4);
    add({ s, t: 0, life, step(it, dt) {
      const k = it.t / it.life;
      vel.multiplyScalar(Math.exp(-1.6 * dt));            // they slow down and hang in the air
      s.position.addScaledVector(vel, dt);
      s.position.y += 0.15 * dt;
      const size = PUFF.from + (PUFF.to - PUFF.from) * (1 - Math.pow(1 - k, 2));
      s.scale.set(size, size, 1);
      s.material.rotation += spin * dt;
      s.material.opacity = 0.9 * (k < 0.6 ? 1 : (1 - k) / 0.4);
      return it.t < it.life;
    } });
  }

  // ── Room actions (world/roomactions.js): effects that run for as long as alive() says so ──
  // `at` is a point { x, y, z } or a function filling a vector, called for every particle.
  const place = (at, out) => (typeof at === 'function' ? (at(out), out) : out.set(at.x, at.y, at.z));
  function zzz(n, alive) {
    textures();
    add({ s: null, t: 0, life: Infinity, due: 0, step(it, dt) {
      if (!alive()) return false;
      it.due -= dt;
      while (it.due <= 0) { it.due += 1 / ZEDS.rate; zed(n); }
      return true;
    } });
  }
  function zed(n) {
    head(n, v);
    const s = sprite(tex.zed), x0 = v.x + 0.25, y0 = v.y + 0.35, z0 = v.z + 0.1, ph = Math.random() * 6, life = ZEDS.life * (0.9 + Math.random() * 0.2);
    s.material.color.set(ZEDS.colours[Math.floor(Math.random() * ZEDS.colours.length)]);
    add({ s, t: 0, life, step(it) {
      const k = it.t / life;
      s.position.set(x0 + 0.25 * k + 0.07 * Math.sin(it.t * 3 + ph), y0 + ZEDS.rise * k, z0);
      const size = ZEDS.size * (0.45 + 0.75 * k);
      s.scale.set(size, size, 1);
      s.material.rotation = 0.25 * Math.sin(it.t * 2 + ph);
      s.material.opacity = k < 0.15 ? k / 0.15 : k > 0.7 ? (1 - k) / 0.3 : 1;
      return it.t < life;
    } });
  }
  function steam(at, alive, o = {}) {
    textures();
    const rate = o.rate || 7;
    add({ s: null, t: 0, life: Infinity, due: 0, step(it, dt) {
      if (!alive()) return false;
      it.due -= dt;
      while (it.due <= 0) { it.due += 1 / rate; wisp(at, o); }
      return true;
    } });
  }
  function wisp(at, o) {
    const s = sprite(tex.soft), p = place(at, new T.Vector3()), size = o.size || 0.5, rise = o.rise || 1.0, spread = o.spread || 0.2, life = 1.4 * (0.8 + Math.random() * 0.4);
    const dx = (Math.random() - 0.5) * spread, dz = (Math.random() - 0.5) * spread, x0 = p.x, y0 = p.y, z0 = p.z, drift = (Math.random() - 0.5) * 0.3;
    s.material.rotation = Math.random() * 6;
    add({ s, t: 0, life, step(it) {
      const k = it.t / life;
      s.position.set(x0 + dx * k + drift * k, y0 + rise * k, z0 + dz * k);
      const sz = size * (0.5 + 0.9 * k);
      s.scale.set(sz, sz, 1);
      s.material.opacity = 0.7 * (k < 0.2 ? k / 0.2 : (1 - k) / 0.8);
      return it.t < life;
    } });
  }
  function bubbles(at, alive, o = {}) {
    textures();
    const rate = o.rate || 5;
    add({ s: null, t: 0, life: Infinity, due: 0, step(it, dt) {
      if (!alive()) return false;
      it.due -= dt;
      while (it.due <= 0) { it.due += 1 / rate; bubble1(at, o); }
      return true;
    } });
  }
  function bubble1(at, o) {
    const s = sprite(tex.bubble), p = place(at, new T.Vector3()), size = (o.size || 0.3) * (0.5 + Math.random() * 0.8), rise = (o.rise || 1.2) * (0.8 + Math.random() * 0.5), life = 1.8 * (0.8 + Math.random() * 0.5);
    const x0 = p.x, y0 = p.y, z0 = p.z, ph = Math.random() * 6, sway = 0.1 + Math.random() * 0.15;
    s.material.color.set(['#ffffff', '#ffd6f0', '#d6f0ff', '#e6ffd6'][Math.floor(Math.random() * 4)]);
    add({ s, t: 0, life, step(it) {
      const k = it.t / life;
      s.position.set(x0 + sway * Math.sin(it.t * 3 + ph), y0 + rise * k, z0 + sway * 0.6 * Math.cos(it.t * 2.3 + ph));
      s.scale.setScalar(size * (k < 0.15 ? 0.4 + 4 * k : 1));
      s.material.opacity = k > 0.85 ? (1 - k) / 0.15 : 0.95;     // (they pop at the end)
      return it.t < life;
    } });
  }

  // ── Every frame ──────────────────────────────────────────────────────────
  function update(dt) {
    for (let i = live.length - 1; i >= 0; i--) {
      const it = live[i];
      it.t += dt;
      if (it.step(it, dt)) continue;                     // still going
      live.splice(i, 1);
      if (it.s) { it.s.visible = false; if (it.s.parent) it.s.parent.remove(it.s); spare.push(it.s); }
    }
  }
  function clear() {
    for (const it of live) if (it.s) { it.s.visible = false; if (it.s.parent) it.s.parent.remove(it.s); spare.push(it.s); }
    live.length = 0;
  }

  WORLD.onBuilt.push(() => { WORLD.updaters.push(update); });
  WORLD.onOpen.push(async () => { clear(); });

  window.WORLD_FX = { bubble, tears, puff, notes, sparkles, zzz, steam, bubbles, clear, update, get live() { return live.length; }, get sprites() { return live.filter(it => it.s).length + spare.length; }, EYES };
})();
