// What you see when friends meet (epic makeupgame-oq2, N10): a speech bubble, tears, fart clouds. Flat pictures that
// always face the camera (sprites), drawn once into small canvases and shared, from a pool that only grows to the most
// ever shown at once, so a visit adds no textures and no materials.
//
//   WORLD_FX.bubble(n, 'Hi!')    a bubble over a friend's head that pops up, stays a moment and fades
//   WORLD_FX.tears(n, seconds)   drops shooting out sideways from both eyes, the cartoon way
//   WORLD_FX.puff(n)             little green clouds from behind that swell, float up and fade
(() => {
  'use strict';
  const T = window.THREE;
  // Where a friend's eyes are, from the head bone (the base of the skull), in world units: up, forward, apart.
  const EYES = { up: 0.36, fwd: 0.3, apart: 0.17 };
  const BUBBLE = { up: 1.05, w: 1.2, h: 0.75 };
  const TEAR = { rate: 18, size: 0.17, life: 0.8, gravity: 6 };
  const PUFF = { count: 10, over: 0.6, life: 2.0, from: 0.45, to: 1.5, colours: ['#a8d64a', '#c4dc3c', '#94c84a', '#b8c95a'] };

  let scene = null;
  const live = [];                 // { s (the sprite), t, life, step(it, dt) -> false when done }
  const spare = [];
  const tex = {};

  function canvasTex(w, h, draw) {
    const c = document.createElement('canvas'); c.width = w; c.height = h;
    draw(c.getContext('2d'), w, h);
    const t = new T.CanvasTexture(c);
    t.colorSpace = T.SRGBColorSpace;
    return t;
  }
  function textures() {
    if (tex.drop) return tex;
    tex.drop = canvasTex(48, 64, (g) => {          // a tear: a drop with a shine
      g.beginPath(); g.moveTo(24, 2); g.bezierCurveTo(30, 18, 44, 32, 44, 43); g.arc(24, 43, 20, 0, Math.PI); g.bezierCurveTo(4, 32, 18, 18, 24, 2);
      g.fillStyle = '#6cc8ff'; g.fill(); g.lineWidth = 3; g.strokeStyle = '#2f8fd8'; g.stroke();
      g.beginPath(); g.ellipse(17, 42, 4, 8, -0.3, 0, Math.PI * 2); g.fillStyle = 'rgba(255,255,255,0.85)'; g.fill();
    });
    tex.puff = canvasTex(128, 128, (g) => {        // a lumpy cloud, white (each puff is tinted)
      for (const [x, y, r] of [[64, 70, 38], [40, 62, 26], [88, 60, 28], [60, 42, 26], [78, 86, 24], [44, 86, 22]]) {
        const grad = g.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r);
        grad.addColorStop(0, 'rgba(255,255,255,1)'); grad.addColorStop(0.7, 'rgba(215,225,200,1)'); grad.addColorStop(0.92, 'rgba(150,165,120,0.9)'); grad.addColorStop(1, 'rgba(150,165,120,0)');
        g.fillStyle = grad; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
      }
    });
    return tex;
  }
  function bubbleTex(word) {
    const key = 'bubble:' + word;
    return tex[key] || (tex[key] = canvasTex(256, 160, (g, w) => {
      g.beginPath(); g.roundRect(8, 8, w - 16, 112, 48);
      g.moveTo(104, 116); g.lineTo(100, 154); g.lineTo(140, 116);           // the tail, down to the head
      g.fillStyle = '#ffffff'; g.fill(); g.lineWidth = 6; g.strokeStyle = '#e0629a'; g.stroke();
      g.fillStyle = '#ffffff'; g.fillRect(100, 108, 44, 12);                  // no line between the bubble and its tail
      g.font = 'bold 72px "Comic Sans MS", "Chalkboard SE", sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillStyle = '#c2185b'; g.fillText(word, w / 2, 66);
    }));
  }

  function sprite(map) {
    let s = spare.pop();
    if (!s) s = new T.Sprite(new T.SpriteMaterial({ map, transparent: true, depthWrite: false }));
    s.material.map = map; s.material.opacity = 1; s.material.rotation = 0; s.material.color.set('#ffffff');
    s.renderOrder = 4;
    s.visible = true;
    scene.add(s);
    return s;
  }
  function add(it) { live.push(it); return it; }

  // ── Where on a friend ────────────────────────────────────────────────────
  const v = new T.Vector3();
  function head(n, out) { return n.bones.head ? n.bones.head.getWorldPosition(out) : out.copy(n.group.position).setY(n.group.position.y + 1.4); }
  const fwdOf = n => ({ x: Math.sin(n.pivot.rotation.y), z: Math.cos(n.pivot.rotation.y) });

  // ── The effects ──────────────────────────────────────────────────────────
  function bubble(n, word) {
    const s = sprite(bubbleTex(word));
    add({ s, t: 0, life: 1.6, step(it) {
      head(n, v);
      s.position.set(v.x, v.y + BUBBLE.up, v.z);
      const t = it.t, pop = t < 0.18 ? 1.15 * t / 0.18 : t < 0.3 ? 1.15 - 0.15 * (t - 0.18) / 0.12 : 1;   // pops up, a little too big, then settles
      s.scale.set(BUBBLE.w * pop, BUBBLE.h * pop, 1);
      s.material.opacity = t > it.life - 0.3 ? (it.life - t) / 0.3 : 1;
      return t < it.life;
    } });
  }

  function tears(n, seconds) {
    textures();
    add({ s: null, t: 0, life: seconds, due: 0, side: 1, step(it, dt) {
      if (!n.perf || n.perf.kind !== 'cry') return false;   // stopped crying (a bump, a tap)
      it.due -= dt;
      while (it.due <= 0) { it.due += 1 / TEAR.rate; it.side = -it.side; drop(n, it.side); }
      return it.t < it.life;
    } });
  }
  function drop(n, side) {
    const f = fwdOf(n), rx = f.z, rz = -f.x;                // the friend's right
    head(n, v);
    const s = sprite(tex.drop);
    s.position.set(v.x + f.x * EYES.fwd + rx * EYES.apart * side, v.y + EYES.up, v.z + f.z * EYES.fwd + rz * EYES.apart * side);
    const out = 1.1 + Math.random() * 0.6, up = 0.9 + Math.random() * 0.6;
    const vel = new T.Vector3(rx * side * out + f.x * 0.35, up, rz * side * out + f.z * 0.35);
    s.scale.set(TEAR.size * 0.75, TEAR.size, 1);
    add({ s, t: 0, life: TEAR.life * (0.8 + Math.random() * 0.4), step(it, dt) {
      vel.y -= TEAR.gravity * dt;
      s.position.addScaledVector(vel, dt);
      s.material.opacity = Math.min(1, (it.life - it.t) / 0.2);
      return it.t < it.life;
    } });
  }

  function puff(n) {
    textures();
    let made = 0;
    add({ s: null, t: 0, life: PUFF.over, step(it) {
      while (made < PUFF.count * Math.min(1, it.t / PUFF.over)) { made++; cloud(n); }
      return it.t < it.life;
    } });
  }
  function cloud(n) {
    const f = fwdOf(n), p = n.group.position, rx = f.z, rz = -f.x, side = (Math.random() < 0.5 ? -1 : 1) * (0.4 + Math.random() * 0.6);   // billowing out to both sides, so they show round the friend
    const s = sprite(tex.puff);
    s.material.color.set(PUFF.colours[Math.floor(Math.random() * PUFF.colours.length)]);
    s.material.rotation = Math.random() * Math.PI * 2;
    s.position.set(p.x - f.x * 0.38 + rx * side * 0.15, p.y + 0.62 + Math.random() * 0.12, p.z - f.z * 0.38 + rz * side * 0.15);
    const back = 0.3 + Math.random() * 0.4;
    const vel = new T.Vector3(-f.x * back + rx * side * 1.3, 0.35 + Math.random() * 0.5, -f.z * back + rz * side * 1.3);
    const spin = (Math.random() - 0.5) * 1.5, life = PUFF.life * (0.8 + Math.random() * 0.4);
    add({ s, t: 0, life, step(it, dt) {
      const k = it.t / it.life;
      vel.multiplyScalar(Math.exp(-1.6 * dt));            // they slow down and hang in the air
      s.position.addScaledVector(vel, dt);
      s.position.y += 0.15 * dt;
      const size = PUFF.from + (PUFF.to - PUFF.from) * (1 - Math.pow(1 - k, 2));
      s.scale.set(size, size, 1);
      s.material.rotation += spin * dt;
      s.material.opacity = 0.9 * (k < 0.6 ? 1 : (1 - k) / 0.4);
      return it.t < it.life;
    } });
  }

  // ── Every frame ──────────────────────────────────────────────────────────
  function update(dt) {
    for (let i = live.length - 1; i >= 0; i--) {
      const it = live[i];
      it.t += dt;
      if (it.step(it, dt)) continue;                     // still going
      live.splice(i, 1);
      if (it.s) { it.s.visible = false; scene.remove(it.s); spare.push(it.s); }
    }
  }
  function clear() {
    for (const it of live) if (it.s) { it.s.visible = false; scene.remove(it.s); spare.push(it.s); }
    live.length = 0;
  }

  WORLD.onBuilt.push(p => { scene = p.scene; WORLD.updaters.push(update); });
  WORLD.onOpen.push(async () => { clear(); });

  window.WORLD_FX = { bubble, tears, puff, clear, get live() { return live.length; }, get sprites() { return live.filter(it => it.s).length + spare.length; }, EYES };
})();
