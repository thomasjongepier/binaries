// The character as the 3D world needs her: the dress-up picture plus legs, drawn in the same
// style (3-unit outlines in a darker shade of the fill, cel shadow lower right), in four walk
// frames packed side by side into one canvas. The world turns the canvas into a texture.
//
//   const cut = await characterCutout();   // { canvas, frames, frameW, frameH, aspect, ... }
//
// Reads the live look through characterSvgText() in game.js, so it always matches the preview.
// Classic script (no modules) so it also works when the page is opened from file://.
(function () {
  const W = 400;            // same width as the dress-up picture
  const TORSO_END = 520;    // the dress-up picture is cut here (bottom of its viewBox)
  const H = 735;            // picture + legs; the feet's outline ends at GROUND
  const GROUND = 731;
  const FRAME_ORDER = ['stand', 'left', 'stand', 'right'];  // the walk cycle, in atlas order

  // ── Which lower body goes with which outfit ──────────────────────────────
  // A new outfit that is not listed gets jeans.
  const LOWER_FOR_OUTFIT = {
    dress: 'skirt', tshirt: 'jeans', rainbowtee: 'jeans', overalls: 'pants', hoodie: 'jeans',
    gown: 'gown', princess: 'gown', tutu: 'tutu', pyjamas: 'pants', raincoat: 'coat',
    robes: 'gown', jersey: 'shorts',
  };
  const lowerFor = id => LOWER_FOR_OUTFIT[id] || 'jeans';

  // ── Drawing helpers ──────────────────────────────────────────────────────
  let uid = 0;
  const f1 = n => Math.round(n * 10) / 10;

  // A mass: fill, hard shadow crescent on the lower right, optional fabric pattern, outline.
  // `defs` collects the clipPaths this piece needs. kind: 'cloth' | 'skin' | 'fixed'.
  function mass(defs, d, { kind = 'cloth', fill, outline, pattern = false, flat = false } = {}) {
    const id = `cut-m${uid++}`;
    defs.push(`<clipPath id="${id}"><path d="${d}"/></clipPath>`);
    const base = kind === 'skin' ? 'class="fill-skin"' : kind === 'cloth' ? 'class="fill-clothing"' : `fill="${fill}"`;
    const line = kind === 'skin' ? 'class="ol-skin"' : kind === 'cloth' ? 'class="ol-cloth"'
      : `stroke="${outline}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"`;
    const shade = kind === 'skin' ? '<path d="' + d + '" fill="var(--skin-dk)" opacity="0.55"/>'
      : '<path d="' + d + '" fill="#000" opacity="0.15"/>';
    return `<path ${base} d="${d}"/>` +
      (flat ? '' : `<g clip-path="url(#${id})">${shade}<path ${base} transform="translate(-9 -5)" d="${d}"/></g>`) +
      (pattern ? `<g clip-path="url(#${id})"><rect x="0" y="480" width="${W}" height="${H - 480}" fill="var(--pattern)"/></g>` : '') +
      `<path d="${d}" fill="none" ${line}/>`;
  }

  // A rounded tube from (cx, top) to (cx, bottom), `w` wide, round at the bottom.
  const tube = (cx, top, bot, w) => {
    const x0 = cx - w / 2, x1 = cx + w / 2, r = Math.min(w / 2, 20);
    return `M${x0},${top} L${x1},${top} L${x1},${f1(bot - r)} Q${x1},${bot} ${cx},${bot} Q${x0},${bot} ${x0},${f1(bot - r)} Z`;
  };
  // An ellipse as four curves.
  const blob = (cx, cy, rx, ry) => {
    const k = 0.5523;
    return `M${cx - rx},${cy} C${cx - rx},${f1(cy - k * ry)} ${f1(cx - k * rx)},${cy - ry} ${cx},${cy - ry} ` +
      `C${f1(cx + k * rx)},${cy - ry} ${cx + rx},${f1(cy - k * ry)} ${cx + rx},${cy} ` +
      `C${cx + rx},${f1(cy + k * ry)} ${f1(cx + k * rx)},${cy + ry} ${cx},${cy + ry} ` +
      `C${f1(cx - k * rx)},${cy + ry} ${cx - rx},${f1(cy + k * ry)} ${cx - rx},${cy} Z`;
  };

  // Walk poses. Each leg: how far its foot is lifted and pushed sideways (the world is seen from
  // the front, so a step reads as one foot coming up and out). `sway` leans the skirt a little.
  const POSES = {
    stand: { l: { lift: 0, out: 0 }, r: { lift: 0, out: 0 }, sway: 0 },
    left:  { l: { lift: 20, out: -7 }, r: { lift: 0, out: 0 }, sway: -2.5 },
    right: { l: { lift: 0, out: 0 }, r: { lift: 20, out: 7 }, sway: 2.5 },
  };
  const HIP_X = { l: 168, r: 232 };
  const ANKLE = 702;  // bottom of a planted leg

  // Shoes: white trainers with a coloured sole, outlined in the outfit's dark shade.
  function shoe(defs, side, leg) {
    const cx = HIP_X[side] + leg.out + (side === 'l' ? -3 : 3), cy = ANKLE - leg.lift + 12;
    return mass(defs, blob(cx, cy, 31, 17), { kind: 'fixed', fill: '#FFFFFF', outline: 'var(--clothing-dk)' }) +
      `<path d="M${cx - 27},${cy + 8} Q${cx},${cy + 16} ${cx + 27},${cy + 8}" fill="none" stroke="var(--clothing)" stroke-width="5" stroke-linecap="round"/>`;
  }
  const leg = (defs, side, l) =>
    mass(defs, tube(HIP_X[side] + l.out, 560, ANKLE - l.lift, 38), { kind: 'skin' });

  // Each builder returns SVG for the lower body. Legs and shoes first, the garment on top.
  const BUILD = {
    skirt(defs, p) {
      const g = mass(defs, 'M116,496 L284,496 C300,540 332,584 342,622 Q200,646 58,622 C68,584 100,540 116,496 Z', { pattern: true });
      return legs(defs, p) + sway(p, g + `<path d="M64,616 Q200,640 336,616" fill="none" stroke="var(--clothing-dk)" stroke-width="2" opacity="0.4"/>`);
    },
    tutu(defs, p) {
      const back = mass(defs, 'M112,496 L288,496 C318,530 352,566 360,604 ' + scallops(360, 40, 604, 8, 16) + ' C48,566 82,530 112,496 Z', { pattern: false });
      const front = mass(defs, 'M122,496 L278,496 C300,530 326,560 332,594 ' + scallops(332, 68, 594, 6, 14) + ' C74,560 100,530 122,496 Z', { pattern: true });
      return legs(defs, p) + sway(p, back + front);
    },
    gown(defs, p) {
      const g = mass(defs, 'M112,496 L288,496 C312,560 344,640 352,708 Q200,740 48,708 C56,640 88,560 112,496 Z', { pattern: true });
      // Only the toes show under a long gown, in front of the hem.
      const toes = ['l', 'r'].map(s => {
        const l = p[s], cx = HIP_X[s] + l.out * 0.6 + (s === 'l' ? -4 : 4);
        return mass(defs, blob(cx, 722 - l.lift * 0.55, 24, 10), { kind: 'fixed', fill: '#FFFFFF', outline: 'var(--clothing-dk)' });
      }).join('');
      return sway(p, g + `<path d="M52,706 Q200,738 348,706" fill="none" stroke="var(--clothing-dk)" stroke-width="2" opacity="0.4"/>`) + toes;
    },
    coat(defs, p) {
      const g = mass(defs, 'M114,496 L286,496 C298,540 308,590 312,640 Q200,656 88,640 C92,590 102,540 114,496 Z', { pattern: true });
      return legs(defs, p) + sway(p, g + `<path d="M200,500 L200,646" stroke="var(--clothing-dk)" stroke-width="2.5" opacity="0.5"/>`);
    },
    shorts: (defs, p) => legs(defs, p) + pantLegs(defs, p, 640),
    pants: (defs, p) => legs(defs, p) + pantLegs(defs, p, 692),
    jeans: (defs, p) => legs(defs, p) + pantLegs(defs, p, 692, true),
  };

  // Skin legs and shoes, drawn first: the garment is drawn over their tops.
  function legs(defs, p) {
    return ['l', 'r'].map(s => leg(defs, s, p[s])).join('') + ['l', 'r'].map(s => shoe(defs, s, p[s])).join('');
  }
  // Trouser legs ending at `hem`, one per leg so a step lifts one of them. `denim`: blue jeans
  // whatever the outfit colour; otherwise the outfit's own colour and fabric pattern.
  function pantLegs(defs, p, hem, denim) {
    const opt = denim ? { kind: 'fixed', fill: '#6F93D8', outline: '#3F5FA3' } : { pattern: true };
    return ['l', 'r'].map(s => mass(defs, tube(HIP_X[s] + p[s].out, 500, hem - p[s].lift, 54), opt)).join('');
  }
  const sway = (p, inner) => p.sway
    ? `<g transform="translate(200 500) skewX(${p.sway}) translate(-200 -500)">${inner}</g>` : inner;
  function scallops(x0, x1, y, n, down) {
    const w = (x1 - x0) / n;
    let d = '';
    for (let k = 0; k < n; k++) d += ` Q${f1(x0 + w * (k + 0.5))},${y + down} ${f1(x0 + w * (k + 1))},${y}`;
    return `L${x0},${y}` + d;
  }

  // The lower body for an outfit and pose, as a string ready to put in the character's <svg>.
  function lowerBodySvg(outfitId, poseName) {
    const defs = [];
    const body = BUILD[lowerFor(outfitId)](defs, POSES[poseName]);
    return `<g id="lower-body"><defs>${defs.join('')}</defs>${body}</g>`;
  }

  // ── The cut-out ──────────────────────────────────────────────────────────
  // Rendered `pxPerUnit` pixels per drawing unit. 1.4 gives 560x1029 frames: crisp at the sizes
  // she is shown at, and four frames still fit a 4096-wide texture.
  async function characterCutout({ pxPerUnit = 1.4 } = {}) {
    const frameW = Math.round(W * pxPerUnit), frameH = Math.round(H * pxPerUnit);
    const canvas = document.createElement('canvas');
    canvas.width = frameW * FRAME_ORDER.length;
    canvas.height = frameH;
    const ctx = canvas.getContext('2d');
    const rendered = {};
    for (const pose of new Set(FRAME_ORDER)) {
      const xml = characterSvgText(clone => {
        clone.setAttribute('viewBox', `0 0 ${W} ${H}`);
        clone.setAttribute('width', frameW);
        clone.setAttribute('height', frameH);
        clone.querySelector('#layer-background').innerHTML = '';
        clone.querySelector('#layer-clothing').insertAdjacentHTML('beforebegin', lowerBodySvg(state.clothing, pose));
      }, { level: true });
      rendered[pose] = await svgTextToImage(xml);
    }
    FRAME_ORDER.forEach((pose, i) => ctx.drawImage(rendered[pose], i * frameW, 0, frameW, frameH));
    return {
      canvas,
      frames: FRAME_ORDER.length,
      frameW, frameH,
      aspect: W / H,            // width / height of one frame
      units: { w: W, h: H },    // drawing units, so the world can size her: 1 unit = height / H
      feetY: GROUND,            // the soles, in drawing units from the top
    };
  }

  window.characterCutout = characterCutout;
  window.CUTOUT = { lowerFor, LOWER_FOR_OUTFIT, POSES, H, W, TORSO_END };
})();
