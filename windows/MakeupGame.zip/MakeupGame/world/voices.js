// What you hear when friends meet (epic makeupgame-oq2, N11). No sound files: farts and sobbing are made on the spot
// with Web Audio (works from file://, and no two are quite the same), and "Hoi!" / "Hi!" is said by the computer's own
// voice (speechSynthesis; a Dutch voice says "Hoi!", an English one "Hi!"). Without a voice, or while it is busy, a
// made-up "hai" chirp says it instead. Recorded files could replace any of these later.
//
//   WORLD_VOICES.play(kind, n)   'hi' | 'cry' | 'fart', from friend n: quieter further from her, panned to their side
//   WORLD_VOICES.word()          what the bubble should say: 'Hoi!' or 'Hi!', whichever the voice speaks
//
// The dress-up page's mute button silences them (game.js `sound.muted`). Every request is logged (`log`), heard or not.
(() => {
  'use strict';
  const T = window.THREE;
  const VOLUME = 0.55;
  const HEAR = [4, 16];             // full volume up to this far from her, silent beyond this
  const AT_ONCE = 3;                // more than this many at the same time is noise
  const log = [];
  let ctx = null, master = null, noise = null, playing = 0;
  let voice = null, word = 'Hi!';

  // ── The computer's voice ─────────────────────────────────────────────────
  function pickVoice() {
    const s = window.speechSynthesis;
    if (!s) return;
    const all = s.getVoices().filter(v => v.localService !== false);   // offline voices only: she may play without internet
    voice = all.find(v => /^nl/i.test(v.lang)) || all.find(v => /^en/i.test(v.lang)) || null;
    word = voice && /^nl/i.test(voice.lang) ? 'Hoi!' : 'Hi!';
  }
  if (window.speechSynthesis) {
    pickVoice();
    window.speechSynthesis.addEventListener?.('voiceschanged', pickVoice);
  }

  function speak(pitch, volume) {
    const s = window.speechSynthesis;
    if (!s || !voice || s.speaking || s.pending) return false;
    const u = new SpeechSynthesisUtterance(word);
    u.voice = voice; u.lang = voice.lang;
    u.pitch = Math.min(2, 1.5 * pitch); u.rate = 1.1; u.volume = volume;
    s.speak(u);
    return true;
  }

  // ── Web Audio ────────────────────────────────────────────────────────────
  function audio() {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = VOLUME; master.connect(ctx.destination);
      noise = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      const d = noise.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    if (ctx.state === 'suspended') ctx.resume().catch(() => { /* before the first tap: stays silent */ });
    return ctx;
  }
  const rnd = (a, b) => a + Math.random() * (b - a);
  function noiseSource(a) { const s = a.createBufferSource(); s.buffer = noise; s.loop = true; return s; }
  function envelope(a, out, t0, points) {          // points: [[time from t0, gain], ...]
    const g = a.createGain();
    g.gain.setValueAtTime(0, t0);
    for (const [t, v] of points) g.gain.linearRampToValueAtTime(v, t0 + t);
    g.connect(out);
    return g;
  }

  // A fart: a low buzz that flutters (pitch and loudness wobble together) over a breath of noise. Long and rumbly, or a short "pfft".
  function fart(a, out, size) {
    const t0 = a.currentTime + 0.02, long = Math.random() < 0.65, dur = long ? rnd(0.55, 1.1) : rnd(0.18, 0.32);
    const f0 = rnd(65, 115) / size;
    const env = envelope(a, out, t0, [[0.03, 1], [dur * 0.75, 0.85], [dur, 0]]);
    const osc = a.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(f0 * 1.2, t0);
    osc.frequency.exponentialRampToValueAtTime(f0 * 0.65, t0 + dur);
    const flutter = a.createOscillator(), depth = a.createGain(), wobble = a.createGain(), amp = a.createGain();
    flutter.type = 'sine'; flutter.frequency.value = rnd(16, 34);
    depth.gain.value = f0 * 0.4; flutter.connect(depth).connect(osc.frequency);
    amp.gain.value = 0.6; wobble.gain.value = 0.4; flutter.connect(wobble).connect(amp.gain);
    const low = a.createBiquadFilter(); low.type = 'lowpass'; low.frequency.value = rnd(380, 750); low.Q.value = 5;
    osc.connect(amp).connect(low).connect(env);
    const air = noiseSource(a), band = a.createBiquadFilter(), airGain = a.createGain();
    band.type = 'bandpass'; band.frequency.value = long ? 300 : 900; band.Q.value = 0.9;
    airGain.gain.value = long ? 0.25 : 0.7;
    air.connect(band).connect(airGain).connect(env);
    for (const s of [osc, flutter, air]) { s.start(t0); s.stop(t0 + dur + 0.05); }
    return dur;
  }

  // A child's voice: a buzz through the resonances of a vowel (formants). `parts`: [start, length, pitch from, pitch to, loudness].
  function voiced(a, out, pitch, parts, vowel) {
    const t0 = a.currentTime + 0.02, end = Math.max(...parts.map(p => p[0] + p[1]));
    const osc = a.createOscillator(); osc.type = 'sawtooth';
    const vib = a.createOscillator(), vibDepth = a.createGain();
    vib.frequency.value = 6.5; vibDepth.gain.value = pitch * 0.035; vib.connect(vibDepth).connect(osc.frequency);
    const env = a.createGain(); env.gain.setValueAtTime(0, t0); env.connect(out);
    osc.frequency.setValueAtTime(pitch * parts[0][2], t0);
    for (const [s, len, from, to, loud] of parts) {
      osc.frequency.setValueAtTime(pitch * from, t0 + s);
      osc.frequency.exponentialRampToValueAtTime(pitch * to, t0 + s + len);
      env.gain.setValueAtTime(0, t0 + s);
      env.gain.linearRampToValueAtTime(loud, t0 + s + 0.07);
      env.gain.setValueAtTime(loud * 0.9, t0 + s + len * 0.7);
      env.gain.linearRampToValueAtTime(0, t0 + s + len);
    }
    for (const [f, q, g] of vowel(t0)) {
      const bp = a.createBiquadFilter(), gain = a.createGain();
      bp.type = 'bandpass'; bp.Q.value = q;
      if (typeof f === 'function') f(bp.frequency); else bp.frequency.value = f;
      gain.gain.value = g;
      osc.connect(bp).connect(gain).connect(env);
    }
    for (const s of [osc, vib]) { s.start(t0); s.stop(t0 + end + 0.05); }
    return end;
  }

  // Crying: a long falling "waaah", then two shorter sobs.
  function cry(a, out, size) {
    const pitch = rnd(400, 480) / size;
    return voiced(a, out, pitch, [[0, 0.95, 1.05, 0.72, 1], [1.05, 0.38, 0.95, 0.8, 0.8], [1.5, 0.6, 0.98, 0.7, 0.75]],
      () => [[900, 5, 1], [1350, 7, 0.7], [2700, 9, 0.25]]);           // "aa"
  }

  // "hai": from "a" to "i", after a breath of "h". Only when the computer's voice cannot say it.
  function chirp(a, out, size) {
    const pitch = rnd(300, 360) / size, t0 = a.currentTime + 0.02;
    const h = noiseSource(a), hp = a.createBiquadFilter();
    hp.type = 'highpass'; hp.frequency.value = 1500;
    h.connect(hp).connect(envelope(a, out, t0, [[0.02, 0.18], [0.07, 0]]));
    h.start(t0); h.stop(t0 + 0.1);
    const glide = (from, to) => p => { p.setValueAtTime(from, t0 + 0.06); p.exponentialRampToValueAtTime(to, t0 + 0.3); };
    return voiced(a, out, pitch, [[0.05, 0.36, 1, 1.18, 1]], () => [[glide(780, 320), 6, 1], [glide(1200, 2300), 8, 0.6], [2900, 9, 0.2]]);
  }

  // ── Playing ──────────────────────────────────────────────────────────────
  const v = new T.Vector3();
  function placeOf(n) {                            // how loud (0..1) and where left to right (-1..1)
    const hero = WORLD.parts.hero.group.position, p = n.group.position;
    const d = Math.hypot(p.x - hero.x, p.z - hero.z);
    const loud = Math.max(0, Math.min(1, 1 - (d - HEAR[0]) / (HEAR[1] - HEAR[0])));
    v.copy(p).project(WORLD.parts.camera);
    return { loud, pan: Math.max(-1, Math.min(1, v.x)) * 0.7 };
  }
  const muted = () => (typeof sound !== 'undefined' && sound.muted) || !!window.__STILL;

  function play(kind, n) {
    const { loud, pan } = placeOf(n), size = n.voice || 1;
    const entry = { kind, who: WORLD.friends ? WORLD.friends.list.indexOf(n) : -1, loud: +loud.toFixed(2), heard: false, how: null };
    log.push(entry);
    if (log.length > 200) log.splice(0, log.length - 200);
    if (muted() || loud <= 0 || playing >= AT_ONCE) return entry;
    if (kind === 'hi' && speak(size, loud * VOLUME)) { entry.heard = true; entry.how = 'voice'; return entry; }
    const a = audio();
    if (!a) return entry;
    const out = a.createGain();
    out.gain.value = loud;
    const panner = a.createStereoPanner ? a.createStereoPanner() : null;
    if (panner) { panner.pan.value = pan; out.connect(panner).connect(master); } else out.connect(master);
    const dur = (kind === 'fart' ? fart : kind === 'cry' ? cry : chirp)(a, out, size);
    playing++;
    setTimeout(() => { playing--; out.disconnect(); }, (dur + 0.2) * 1000);
    entry.heard = true; entry.how = 'synth';
    return entry;
  }

  window.WORLD_VOICES = { play, word: () => word, log, get voice() { return voice && voice.name; } };
})();
