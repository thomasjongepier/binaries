// The walking map: where a character can stand, which of those places can be reached from the
// start, random places to go to, and routes there. Shared by scripts/world-layout-check.js (can she
// get everywhere) and the friends (npcs.js), so both agree on what counts as walkable.
//
//   const nav = WORLD_NAV.build(WORLD_LAYOUT, colliders, { radius: 0.45, cell: 0.5 });
//
//   nav.free(x, z)              exact test, same as WORLD.canStand: inside the world and clear of every
//                               collider by `radius`
//   nav.reachable(x, z)         can a character standing at (x, z) walk to / from the start region?
//   nav.nearestReachable(x, z)  (x, z) itself if reachable, else the middle of the nearest reachable cell
//   nav.randomPoint(rng, { awayFrom: [{x, z}], minDist })
//                               a uniformly chosen reachable place (jittered inside its cell), {x, z}.
//                               rng() returns [0, 1). If nothing is at least minDist from every awayFrom
//                               point it returns the farthest place it tried.
//   nav.path(from, to)          [{x, z}, ...] from `from` to `to`, or null if there is no route. The first
//                               point is `from` (or, when `from` is not free, the nearest reachable cell
//                               middle), the last is `to` (same rule). Straight where it can be (no
//                               zigzag), around the pond / houses / tree ring, over the bridge.
//   nav.cell, nav.radius, nav.buildMs, nav.reachableCount, nav.reachableCells() -> [{x, z}]
//
// Dynamic obstacles (other characters) are not in the map. Pass the same colliders the world walks
// with (WORLD.colliders; they are circles and turned rectangles, see solid.js). The map is only as
// current as the colliders at build time, so build it after the layout (and any debug colliders).
//
// Classic script (no modules) so it works when the page is opened from file://. Under Node,
// scripts/lib/world-layout.js loads it into the same sandbox as solid.js and layout.js.
(function () {
  const SQRT2 = Math.SQRT2;
  const NEIGHBOURS = [[1, 0, 1], [-1, 0, 1], [0, 1, 1], [0, -1, 1], [1, 1, SQRT2], [1, -1, SQRT2], [-1, 1, SQRT2], [-1, -1, SQRT2]];
  const NEIGHBOURS4 = NEIGHBOURS.slice(0, 4);
  const LOS_MARGIN = 0.03;       // straight-line shortcuts keep this much extra room, so they stay clear even between samples
  const EDGE_MARGIN = 0.005, EDGE_STEP = 0.05;   // a step between two neighbouring cells is checked every 5 cm with 5 mm to spare: no sliver of a solid slips between samples
  const WIDE = 1;                // how much room "room to spare" means (see build)
  const BUCKET = 2;             // size of the squares that remember which colliders are near

  function build(layout, colliders, opts = {}) {
    const t0 = (typeof performance !== 'undefined' ? performance : Date).now();
    const solid = opts.solid || window.WORLD_SOLID;
    const R = opts.radius !== undefined ? opts.radius : 0.45;
    const cell = opts.cell || 0.5;
    const bounds = layout.bounds;
    const N = Math.ceil(bounds / cell), W = 2 * N + 1;          // cells -N..N in both directions, (0, 0) is a cell middle

    // Which colliders could be within reach of a point, by square of the world: free() tests only those.
    const nb = Math.ceil((bounds + R) / BUCKET) + 1, bw = 2 * nb + 1;
    // Two tables: colliders within R + 0.05 of a square (the usual question), and within R + 1.1 (the
    // question "is there room to spare all around here?", which lets long straight lines skip ahead).
    const table = extra => {
      const t = new Array(bw * bw);
      for (let k = 0; k < t.length; k++) t[k] = [];
      for (const c of colliders) {
        const reach = (c.r !== undefined ? c.r : Math.hypot(c.hw, c.hd)) + R + extra;
        const i0 = Math.max(-nb, Math.floor((c.x - reach) / BUCKET)), i1 = Math.min(nb, Math.floor((c.x + reach) / BUCKET));
        const j0 = Math.max(-nb, Math.floor((c.z - reach) / BUCKET)), j1 = Math.min(nb, Math.floor((c.z + reach) / BUCKET));
        for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) t[(i + nb) * bw + j + nb].push(c);
      }
      return t;
    };
    const near = table(0.05), nearWide = table(WIDE + 0.1);
    function clear(x, z, r, slack, t = near) {                    // is a circle of radius r - slack at (x, z) clear of everything, inside the world?
      if (Math.hypot(x, z) > bounds - r + 1e-6) return false;
      const i = Math.floor(x / BUCKET), j = Math.floor(z / BUCKET);
      if (i < -nb || i > nb || j < -nb || j > nb) return false;
      const list = t[(i + nb) * bw + j + nb];
      for (let k = 0; k < list.length; k++) if (solid.overlaps(list[k], x, z, r - slack)) return false;
      return true;
    }
    const free = (x, z) => clear(x, z, R, 1e-6);                  // exactly WORLD.canStand

    // The walkable cells, then the ones reachable from the start (4 neighbours).
    const cellX = i => (i - N) * cell;
    const toI = v => Math.round(v / cell) + N;
    const inGrid = (i, j) => i >= 0 && j >= 0 && i < W && j < W;
    const walk = new Uint8Array(W * W), roomy = new Uint8Array(W * W);
    // roomy: clear by more than half a diagonal step, so any step from here to a neighbour is clear without sampling it.
    const roomyBy = cell * Math.SQRT1_2 + 0.01;
    for (let i = 0; i < W; i++) for (let j = 0; j < W; j++) {
      walk[i * W + j] = free(cellX(i), cellX(j)) ? 1 : 0;
      roomy[i * W + j] = walk[i * W + j] && roomyBy <= WIDE && clear(cellX(i), cellX(j), R + roomyBy + EDGE_MARGIN, 0, nearWide) ? 1 : 0;
    }

    let si = toI(layout.start.x), sj = toI(layout.start.z);
    if (!inGrid(si, sj) || !walk[si * W + sj]) {                   // start not on a walkable cell: the nearest one
      let best = Infinity;
      for (let i = 0; i < W; i++) for (let j = 0; j < W; j++) {
        const d = walk[i * W + j] ? Math.hypot(cellX(i) - layout.start.x, cellX(j) - layout.start.z) : Infinity;
        if (d < best) { best = d; si = i; sj = j; }
      }
    }
    // Can she step from cell (i, j) to the neighbouring cell (i + di, j + dj)? Both must be walkable and the
    // straight step between them clear all along (remembered: 0 unknown, 1 yes, 2 no, per direction).
    const edgeMemo = [new Uint8Array(W * W), new Uint8Array(W * W), new Uint8Array(W * W), new Uint8Array(W * W)];
    function step(i, j, di, dj) {
      if (di < 0 || (di === 0 && dj < 0)) { i += di; j += dj; di = -di; dj = -dj; }      // the same step seen from the other end
      const memo = edgeMemo[di === 0 ? 1 : dj === 0 ? 0 : dj > 0 ? 2 : 3], k = i * W + j;
      if (memo[k]) return memo[k] === 1;
      let ok = inGrid(i, j) && inGrid(i + di, j + dj) && walk[k] === 1 && walk[(i + di) * W + j + dj] === 1;
      if (ok && !(roomy[k] && roomy[(i + di) * W + j + dj])) {
        const ax = cellX(i), az = cellX(j), bx = cellX(i + di), bz = cellX(j + dj), n = Math.ceil(Math.hypot(bx - ax, bz - az) / EDGE_STEP);
        for (let s = 1; s < n && ok; s++) ok = clear(ax + (bx - ax) * s / n, az + (bz - az) * s / n, R + EDGE_MARGIN, 0);
      }
      memo[k] = ok ? 1 : 2;
      return ok;
    }
    const reach = new Uint8Array(W * W), list = [];                // list: indices of the reachable cells
    const stack = [si * W + sj];
    reach[stack[0]] = 1;
    while (stack.length) {
      const k = stack.pop(); list.push(k);
      const i = (k / W) | 0, j = k - i * W;
      for (const [di, dj] of NEIGHBOURS4) {
        const ni = i + di, nj = j + dj;
        if (!inGrid(ni, nj)) continue;
        const nk = ni * W + nj;
        if (walk[nk] && !reach[nk] && step(i, j, di, dj)) { reach[nk] = 1; stack.push(nk); }
      }
    }

    // Can she walk the straight line a -> b with `margin` to spare? Samples every `stepLen`, and skips ahead
    // where there is plenty of room, so a line across the open meadow costs a handful of questions.
    const losStep = cell / 4;
    function los(ax, az, bx, bz, margin = LOS_MARGIN, stepLen = losStep) {
      const len = Math.hypot(bx - ax, bz - az), ux = len ? (bx - ax) / len : 0, uz = len ? (bz - az) / len : 0;
      const r = R + margin, hop = WIDE - 0.05;
      for (let d = 0; ;) {
        const x = ax + ux * d, z = az + uz * d;
        if (!clear(x, z, r, 0)) return false;
        if (d >= len) return true;
        if (clear(x, z, r + hop, 0, nearWide)) d = Math.min(len, d + hop);   // everything within hop of here is clear too
        else d = Math.min(len, d + stepLen);
      }
    }
    // The reachable cell nearest to (x, z) that (x, z) can see: the way into the map. -1 if none close.
    function anchor(x, z) {
      const ci = toI(x), cj = toI(z);
      if (Math.abs(cellX(ci) - x) < 1e-9 && Math.abs(cellX(cj) - z) < 1e-9 && inGrid(ci, cj) && reach[ci * W + cj]) return ci * W + cj;   // on a cell middle
      for (const [margin, stepLen] of [[LOS_MARGIN, losStep], [EDGE_MARGIN, EDGE_STEP]]) {        // with a little room to spare if possible, else just clear
        let best = -1, bd = Infinity;
        for (let di = -2; di <= 2; di++) for (let dj = -2; dj <= 2; dj++) {
          const i = ci + di, j = cj + dj;
          if (!inGrid(i, j) || !reach[i * W + j]) continue;
          const d = Math.hypot(cellX(i) - x, cellX(j) - z);
          if (d < bd && los(x, z, cellX(i), cellX(j), margin, stepLen)) { bd = d; best = i * W + j; }
        }
        if (best >= 0) return best;
      }
      return -1;
    }
    const cellMid = k => { const i = (k / W) | 0; return { x: cellX(i), z: cellX(k - i * W) }; };
    const reachable = (x, z) => Number.isFinite(x + z) && free(x, z) && anchor(x, z) >= 0;

    function nearestCell(x, z) {                                   // index of the reachable cell middle nearest (x, z)
      let best = -1, bd = Infinity;
      const ci = toI(x), cj = toI(z);
      for (let ring = 0; ring <= W && !(best >= 0 && (ring - 1) * cell > bd); ring++) {
        for (let di = -ring; di <= ring; di++) for (let dj = -ring; dj <= ring; dj++) {
          if (Math.max(Math.abs(di), Math.abs(dj)) !== ring) continue;
          const i = ci + di, j = cj + dj;
          if (!inGrid(i, j) || !reach[i * W + j]) continue;
          const d = Math.hypot(cellX(i) - x, cellX(j) - z);
          if (d < bd) { bd = d; best = i * W + j; }
        }
      }
      return best;
    }
    function nearestReachable(x, z) {
      if (!Number.isFinite(x + z)) return null;
      if (reachable(x, z)) return { x, z };
      const k = nearestCell(x, z);
      return k < 0 ? null : cellMid(k);
    }

    function randomPoint(rng, o = {}) {
      const away = o.awayFrom || [], minDist = o.minDist || 0;
      if (!list.length) return null;
      let best = null, bestScore = -Infinity;
      for (let attempt = 0; attempt < 80; attempt++) {
        const k = list[Math.min(list.length - 1, Math.floor(rng() * list.length))], m = cellMid(k);
        let p = m;
        for (let tries = 0; tries < 6; tries++) {                  // jitter inside the cell, but only to places she can stand and see the middle from
          const q = { x: m.x + (rng() - 0.5) * cell, z: m.z + (rng() - 0.5) * cell };
          if (free(q.x, q.z) && los(q.x, q.z, m.x, m.z)) { p = q; break; }
        }
        let d = Infinity;
        for (const a of away) d = Math.min(d, Math.hypot(p.x - a.x, p.z - a.z));
        if (d >= minDist) return p;
        if (d > bestScore) { bestScore = d; best = p; }
      }
      return best;
    }

    // A* over the reachable cells, 8 neighbours, never cutting a corner of a blocked cell.
    const g = new Float32Array(W * W), came = new Int32Array(W * W), closed = new Uint32Array(W * W), stamp = new Uint32Array(W * W);
    let run = 0;
    function route(startK, goalK) {                                // cell indices -> cell indices, or null
      run++;
      const heap = [];                                             // binary heap of [f, k]
      const push = (fv, k) => { heap.push([fv, k]); let c = heap.length - 1; while (c > 0) { const p = (c - 1) >> 1; if (heap[p][0] <= heap[c][0]) break; [heap[p], heap[c]] = [heap[c], heap[p]]; c = p; } };
      const pop = () => { const top = heap[0], last = heap.pop(); if (heap.length) { heap[0] = last; let c = 0; for (;;) { const l = 2 * c + 1, r = l + 1; let m = c; if (l < heap.length && heap[l][0] < heap[m][0]) m = l; if (r < heap.length && heap[r][0] < heap[m][0]) m = r; if (m === c) break; [heap[m], heap[c]] = [heap[c], heap[m]]; c = m; } } return top; };
      const gi = (goalK / W) | 0, gj = goalK - gi * W;
      const h = (i, j) => { const dx = Math.abs(i - gi), dz = Math.abs(j - gj); return Math.max(dx, dz) + (SQRT2 - 1) * Math.min(dx, dz); };
      stamp[startK] = run; g[startK] = 0; came[startK] = -1; closed[startK] = 0;
      push(h((startK / W) | 0, startK % W), startK);
      while (heap.length) {
        const [, k] = pop();
        if (k === goalK) {
          const out = [];
          for (let c = k; c !== -1; c = came[c]) out.push(c);
          return out.reverse();
        }
        if (closed[k] === run) continue;
        closed[k] = run;
        const i = (k / W) | 0, j = k - i * W;
        for (const [di, dj, cost] of NEIGHBOURS) {
          const ni = i + di, nj = j + dj;
          if (!inGrid(ni, nj)) continue;
          const nk = ni * W + nj;
          if (!reach[nk] || closed[nk] === run) continue;
          if (di && dj && !(reach[(i + di) * W + j] && reach[i * W + j + dj])) continue;   // no corner cutting
          if (!step(i, j, di, dj)) continue;                                              // nor graze a solid on the way
          const ng = g[k] + cost;
          if (stamp[nk] !== run || ng < g[nk]) { stamp[nk] = run; g[nk] = ng; came[nk] = k; push(ng + h(ni, nj), nk); }
        }
      }
      return null;
    }

    function path(from, to) {
      if (!from || !to || !Number.isFinite(from.x + from.z + to.x + to.z)) return null;
      // Where the route starts and ends: the point itself when she can stand there and see a cell, else the nearest cell middle.
      const end = (p) => {
        const k = free(p.x, p.z) ? anchor(p.x, p.z) : -1;
        if (k >= 0) return { k, pt: { x: p.x, z: p.z } };
        const nk = nearestCell(p.x, p.z);
        return nk < 0 ? null : { k: nk, pt: cellMid(nk) };
      };
      const a = end(from), b = end(to);
      if (!a || !b) return null;
      if (los(a.pt.x, a.pt.z, b.pt.x, b.pt.z)) return [a.pt, b.pt];
      const cells = route(a.k, b.k);
      if (!cells) return null;
      const pts = [a.pt, ...cells.map(cellMid), b.pt];
      // String pulling: from each point jump ahead while the next one is still in sight.
      const out = [pts[0]];
      for (let i = 0; i < pts.length - 1;) {
        let j = i + 1;
        while (j + 1 < pts.length && los(pts[i].x, pts[i].z, pts[j + 1].x, pts[j + 1].z)) j++;   // as far as it can see
        out.push(pts[j]); i = j;
      }
      return out;
    }

    const nav = {
      cell, radius: R, bounds, free, reachable, nearestReachable, randomPoint, path, los,
      reachableCount: list.length,
      reachableCells: () => list.map(cellMid),
    };
    nav.buildMs = (typeof performance !== 'undefined' ? performance : Date).now() - t0;
    return nav;
  }

  const api = { build };
  if (typeof window !== 'undefined') window.WORLD_NAV = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
