// Game state
const state = {
  face:        'oval',
  eyes:        'round',
  brows:       'arched',
  nose:        'dot',
  mouth:       'bigsmile',
  cheeks:      'round',
  hair:        'bob',
  clothing:    'dress',
  accessories: [],     // multi-select: array of option ids
  marks:       'none',
  activeAccessoryId: null,
  skinIdx:       0,
  eyeIdx:        0,
  hairIdx:       1,
  lipIdx:        1,
  clothingIdx:   0,
  clothingPattern: 'none',
  background:    'dreamy',
  eyeshadow:     'none',
  lipstick:      'natural',
  shadowIdx:     0,
  blushIdx:      0,
  activeTab:    'face',
  adjustOpen:   false,
  // Per-slot size: { slotKey: {x, y} } scale factors (1 = original size).
  scales:       {},
  // Per-slot drag offsets in SVG user units.
  offsets:      {},
};

const svg = document.getElementById('character-svg');

// Pivot point (SVG user coords) each part scales around, so it grows/shrinks
// in place. For mirrored pairs (eyes, brows, cheeks) the pivot sits on the
// centre line x=200, so widening also spreads the pair apart symmetrically.
const SLOT_PIVOTS = {
  face:        [200, 204],
  eyes:        [200, 216],
  brows:       [200, 168],
  nose:        [200, 258],
  mouth:       [200, 295],
  cheeks:      [200, 264],
  hair:        [200, 160],
  clothing:    [200, 400],
  accessories: [200, 190],
  marks:       [200, 216],
};

// These slots follow the face when its size changes (they sit on the face).
// Clothing is excluded — it starts below the face at the neck.
const FACE_FOLLOW_SLOTS = new Set(['hair', 'eyes', 'brows', 'nose', 'mouth', 'cheeks', 'marks', 'accessories']);

// Per-slot pseudo-depth used for interactive 3D parallax.
// Positive values feel closer to camera, negative values farther away.
const SLOT_DEPTH = {
  background: -0.8,
  clothing:   -0.55,
  face:       -0.18,
  cheeks:      0.14,
  nose:        0.22,
  marks:       0.28,
  mouth:       0.34,
  eyes:        0.52,
  brows:       0.58,
  hair:        0.64,
  accessories: 0.76,
};

const scene3D = {
  x: 0, // [-1..1]
  y: 0, // [-1..1]
};

const ACCESSORY_TRANSFORM_PREFIX = 'accessories::';

// ── Apply a slot option ────────────────────────────────────────────────────
function applyOption(slotKey, optionId) {
  const slot = CHAR.slots[slotKey];

  if (slot.multiSelect) {
    // optionId may be an array (init/reset) or a single string (user click).
    if (Array.isArray(optionId)) {
      state[slotKey] = [...optionId];
    } else if (optionId === 'none') {
      state[slotKey] = [];
    } else {
      const arr = state[slotKey];
      const idx = arr.indexOf(optionId);
      if (idx >= 0) arr.splice(idx, 1); else arr.push(optionId);
    }

    if (slotKey === 'accessories') {
      if (!Array.isArray(optionId) && optionId !== 'none' && state.accessories.includes(optionId)) {
        state.activeAccessoryId = optionId;
      }
      normalizeAccessoryFocus();
      pruneAccessoryTransforms();
      state.accessories.forEach(id => {
        getScale('accessories', id);
        getOffset('accessories', id);
      });
      renderAccessoryLayer();
      applyTransform('accessories');
    } else {
      const combined = state[slotKey].map(id => {
        const o = slot.options.find(x => x.id === id);
        return o ? (o.svg || '') : '';
      }).join('');
      slot.layerIds.forEach(id => {
        const el = document.getElementById('layer-' + id);
        if (el) el.innerHTML = combined;
      });
    }
    return;
  }

  const opt = slot.options.find(o => o.id === optionId);
  if (!opt) return;
  state[slotKey] = optionId;

  if (slotKey === 'hair') {
    document.getElementById('layer-hair-back').innerHTML  = opt.svgBack  || '';
    document.getElementById('layer-hair-front').innerHTML = opt.svgFront || '';
  } else {
    const svgStr = typeof opt.svg === 'function' ? opt.svg(state) : (opt.svg || '');
    // Eyes and eyeshadow blink together. The animation goes on an inner group: the layer group
    // itself carries the size/drag/tilt transform, which applyTransform() rewrites every frame.
    const blinks = slotKey === 'eyes' || slotKey === 'eyeshadow';
    document.getElementById('layer-' + slotKey).innerHTML = blinks ? `<g class="eye-anim">${svgStr}</g>` : svgStr;
  }
  // The lipstick finish is clipped to the current mouth, so a new mouth means a new lipstick.
  if (slotKey === 'mouth' && CHAR.slots.lipstick) applyOption('lipstick', state.lipstick);
  // Likewise the eyeshadow is masked by the current eyes' opening.
  if (slotKey === 'eyes' && CHAR.slots.eyeshadow) applyOption('eyeshadow', state.eyeshadow);
}

// ── Colors ─────────────────────────────────────────────────────────────────
// Outline shade for a fill colour: each channel scaled down, so black stays black and
// light pastels become a muted (not neon) darker tone. Computed here rather than with
// CSS color-mix() so the exported PNG (an SVG drawn as an image) renders it reliably.
function shade(hex, k = 0.72) {
  const n = parseInt(hex.slice(1), 16);
  const ch = v => Math.round(v * k).toString(16).padStart(2, '0');
  return '#' + ch((n >> 16) & 255) + ch((n >> 8) & 255) + ch(n & 255);
}

// Every custom property the character art reads. The single source for the live
// svg (applyColors) and the option thumbnails (currentColorStyle). Pure: any look object
// (a friend's, from randomLook) works, and the live state is the default.
function colorVars(look = state) {
  const skin = CHAR.colors.skin[look.skinIdx];
  const hairEntry = CHAR.colors.hair[look.hairIdx];
  const hair = typeof hairEntry === 'object' ? hairEntry : { fill: hairEntry, solid: hairEntry };
  const lip = CHAR.colors.lip[look.lipIdx];
  const clothing = CHAR.colors.clothing[look.clothingIdx];
  return {
    '--skin': skin.light,
    '--skin-dk': skin.dark,
    '--eye': CHAR.colors.eye[look.eyeIdx],
    '--hair': hair.fill,
    '--hair-dk': shade(hair.solid),
    '--brow': hair.solid,
    '--lip': lip,
    '--lip-dk': shade(lip),
    '--clothing': clothing,
    '--clothing-dk': shade(clothing),
    '--shadow': CHAR.colors.shadow[look.shadowIdx],
    '--blush': CHAR.colors.blush[look.blushIdx],
    '--pattern': look.clothingPattern === 'none' ? 'none' : `url(#pat-${look.clothingPattern})`,
  };
}

function applyColors() {
  Object.entries(colorVars()).forEach(([k, v]) => svg.style.setProperty(k, v));
  // Freckle contrast uses the selected skin's luminance, so a skin swatch also
  // redraws that state-derived paint in the SVG source used by the 3D face.
  if (state.marks === 'freckles') applyOption('marks', state.marks);
}

// ── Per-slot resizing & repositioning ─────────────────────────────────────
function transformKey(slotKey, itemId = null) {
  return itemId ? `${slotKey}::${itemId}` : slotKey;
}

// What a look says about a part's size and place. Pure: it never writes the default into the look.
function scaleOf(look, slotKey, itemId = null) {
  return (look.scales && look.scales[transformKey(slotKey, itemId)]) || { x: 1, y: 1 };
}

function offsetOf(look, slotKey, itemId = null) {
  return (look.offsets && look.offsets[transformKey(slotKey, itemId)]) || { x: 0, y: 0 };
}

// The live state's entry for the sliders and dragging to change in place (made on first use).
function getScale(slotKey, itemId = null) {
  const key = transformKey(slotKey, itemId);
  if (!state.scales[key]) state.scales[key] = { x: 1, y: 1 };
  return state.scales[key];
}

function getOffset(slotKey, itemId = null) {
  const key = transformKey(slotKey, itemId);
  if (!state.offsets[key]) state.offsets[key] = { x: 0, y: 0 };
  return state.offsets[key];
}

function getOption(slotKey, optionId) {
  const slot = CHAR.slots[slotKey];
  if (!slot) return null;
  return slot.options.find(o => o.id === optionId) || null;
}

function normalizeAccessoryFocus() {
  if (!state.accessories.includes(state.activeAccessoryId)) {
    state.activeAccessoryId = state.accessories[0] || null;
  }
  return state.activeAccessoryId;
}

function getAccessoryPivot(optionId) {
  const opt = getOption('accessories', optionId);
  if (opt && Array.isArray(opt.pivot) && opt.pivot.length === 2) return opt.pivot;
  return SLOT_PIVOTS.accessories || [200, 180];
}

function pruneAccessoryTransforms() {
  const keep = new Set(state.accessories);
  Object.keys(state.scales).forEach(key => {
    if (!key.startsWith(ACCESSORY_TRANSFORM_PREFIX)) return;
    const id = key.slice(ACCESSORY_TRANSFORM_PREFIX.length);
    if (!keep.has(id)) delete state.scales[key];
  });
  Object.keys(state.offsets).forEach(key => {
    if (!key.startsWith(ACCESSORY_TRANSFORM_PREFIX)) return;
    const id = key.slice(ACCESSORY_TRANSFORM_PREFIX.length);
    if (!keep.has(id)) delete state.offsets[key];
  });
}

// What the 3D her cannot follow: her face shape and her clothes are modelled, so they are not moved or resized there
// (everything else is: the face parts reach her face through its picture, and the hair and extras have their own transforms).
const NOT_ADJUSTABLE_IN_3D = new Set(['face', 'clothing']);
const adjustLockedIn3D = slotKey => preview3dOn() && NOT_ADJUSTABLE_IN_3D.has(CHAR.slots[slotKey]?.transformsAs || slotKey);

function getActiveTransformTarget(slotKey = state.activeTab) {
  if (CHAR.slots[slotKey]?.noTransform) return null;   // scenes are not moved or resized
  if (adjustLockedIn3D(slotKey)) return null;
  if (slotKey === 'accessories') {
    const itemId = normalizeAccessoryFocus();
    if (!itemId) return null;
    return { slotKey: 'accessories', itemId };
  }
  // Eyeshadow and lipstick are moved and scaled with the eyes and the mouth.
  return { slotKey: CHAR.slots[slotKey]?.transformsAs || slotKey, itemId: null };
}

// The extras layer's markup for a look (the live state by default). Pure: reads `look` only.
function buildAccessoryLayerContent(look = state, tilt = scene3D) {
  return look.accessories.map(id => {
    const opt = getOption('accessories', id);
    if (!opt || !opt.svg) return '';
    const t = buildTransformString(
      'accessories',
      scaleOf(look, 'accessories', id),
      offsetOf(look, 'accessories', id),
      getAccessoryPivot(id),
      look, tilt
    );
    const tr = t ? ` transform="${t}"` : '';
    return `<g data-accessory-id="${id}"${tr}>${opt.svg}</g>`;
  }).join('');
}

function renderAccessoryLayer() {
  const el = document.getElementById('layer-accessories');
  if (!el) return;
  el.innerHTML = buildAccessoryLayerContent();
}

// Build the complete SVG transform string for a slot by composing three layers:
//   1. [innermost] own scale — scales the part around its natural pivot
//   2. face-follow — scales/repositions the part with the face (if applicable)
//   3. [outermost] drag offset — translates in SVG world coords
// SVG applies transforms right-to-left, so the attribute string is: drag face own.
// Pure: reads `look` (the live state by default) and `tilt` (the pointer tilt; { x: 0, y: 0 } draws her level).
function buildTransformString(slotKey, scaleOverride = null, offsetOverride = null, pivotOverride = null, look = state, tilt = scene3D) {
  const { x: osx, y: osy } = scaleOverride || scaleOf(look, slotKey);
  const [opx, opy] = pivotOverride || SLOT_PIVOTS[slotKey] || [200, 200];
  const { x: dx, y: dy } = offsetOverride || offsetOf(look, slotKey);
  const depth = SLOT_DEPTH[slotKey] || 0;

  const ownStr = (osx === 1 && osy === 1) ? '' :
    `translate(${opx} ${opy}) scale(${osx.toFixed(4)} ${osy.toFixed(4)}) translate(${-opx} ${-opy})`;

  let faceStr = '';
  if (slotKey !== 'face' && FACE_FOLLOW_SLOTS.has(slotKey)) {
    const fs = scaleOf(look, 'face');
    if (fs.x !== 1 || fs.y !== 1) {
      const [fpx, fpy] = SLOT_PIVOTS.face;
      faceStr = `translate(${fpx} ${fpy}) scale(${fs.x.toFixed(4)} ${fs.y.toFixed(4)}) translate(${-fpx} ${-fpy})`;
    }
  }

  const dragStr = (dx === 0 && dy === 0) ? '' :
    `translate(${dx.toFixed(2)} ${dy.toFixed(2)})`;

  let parallaxStr = '';
  if (tilt.x !== 0 || tilt.y !== 0) {
    const px = tilt.x * depth * 11;
    const py = tilt.y * depth * 8;
    const tiltAmount = Math.max(Math.abs(tilt.x), Math.abs(tilt.y));
    const sceneScale = 1 + (tiltAmount * depth * 0.03);

    const shiftStr = (px === 0 && py === 0) ? '' : `translate(${px.toFixed(2)} ${py.toFixed(2)})`;
    const scaleStr = (sceneScale === 1) ? '' :
      `translate(${opx} ${opy}) scale(${sceneScale.toFixed(4)} ${sceneScale.toFixed(4)}) translate(${-opx} ${-opy})`;
    parallaxStr = [shiftStr, scaleStr].filter(Boolean).join(' ');
  }

  return [dragStr, parallaxStr, faceStr, ownStr].filter(Boolean).join(' ');
}

function applyTransform(slotKey) {
  if (slotKey === 'accessories') {
    const layer = document.getElementById('layer-accessories');
    if (!layer) return;
    layer.removeAttribute('transform');
    state.accessories.forEach(id => {
      const g = layer.querySelector(`g[data-accessory-id="${id}"]`);
      if (!g) return;
      const t = buildTransformString(
        'accessories',
        getScale('accessories', id),
        getOffset('accessories', id),
        getAccessoryPivot(id)
      );
      if (t) g.setAttribute('transform', t);
      else   g.removeAttribute('transform');
    });
    return;
  }

  const transform = buildTransformString(slotKey);
  CHAR.slots[slotKey].layerIds.forEach(id => {
    const el = document.getElementById('layer-' + id);
    if (!el) return;
    if (transform) el.setAttribute('transform', transform);
    else           el.removeAttribute('transform');
  });
}

// When the face scale changes every face-following slot must recalculate.
function applyAllTransforms() {
  Object.keys(CHAR.slots).forEach(k => applyTransform(k));
}

function renderSubpartControls(slotKey) {
  const section = document.getElementById('subpart-section');
  const list = document.getElementById('subpart-list');
  const label = document.getElementById('subpart-label');
  if (!section || !list || !label) return;

  if (slotKey !== 'accessories' || state.accessories.length === 0) {
    section.hidden = true;
    list.innerHTML = '';
    return;
  }

  normalizeAccessoryFocus();
  section.hidden = false;
  label.textContent = 'Select extra to move';
  list.innerHTML = '';

  state.accessories.forEach(id => {
    const opt = getOption('accessories', id);
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'subpart-pill' + (id === state.activeAccessoryId ? ' active' : '');
    btn.textContent = opt ? opt.label : id;
    btn.addEventListener('click', () => {
      state.activeAccessoryId = id;
      renderSubpartControls('accessories');
      renderSizeControls('accessories');
    });
    list.appendChild(btn);
  });
}

// Sync the two sliders + labels to the active slot's stored scale.
function renderSizeControls(slotKey) {
  const sizeSection = document.getElementById('size-section');
  if (sizeSection) sizeSection.style.display = CHAR.slots[slotKey].noTransform ? 'none' : '';
  const adjustBtn = document.getElementById('adjust-toggle');
  if (adjustBtn) adjustBtn.hidden = !!CHAR.slots[slotKey].noTransform;
  const target = getActiveTransformTarget(slotKey);
  const hasTarget = !!target;
  const sc = hasTarget ? getScale(target.slotKey, target.itemId) : { x: 1, y: 1 };
  const activeAccessory = slotKey === 'accessories' && hasTarget
    ? getOption('accessories', target.itemId)
    : null;
  const wEl    = document.getElementById('size-w');
  const hEl    = document.getElementById('size-h');
  const wPct   = Math.round(sc.x * 100);
  const hPct   = Math.round(sc.y * 100);
  wEl.value = wPct;
  hEl.value = hPct;
  wEl.disabled = !hasTarget;
  hEl.disabled = !hasTarget;
  document.getElementById('size-w-val').textContent = wPct + '%';
  document.getElementById('size-h-val').textContent = hPct + '%';
  const locked = adjustLockedIn3D(slotKey);
  const suffix = activeAccessory ? ` (${activeAccessory.label})` : '';
  document.getElementById('size-title').textContent = CHAR.slots[slotKey].label + suffix + (locked ? ': fixed in 3D' : ' size');
  const dragHint = document.getElementById('drag-hint');
  if (dragHint) dragHint.textContent = locked ? "The 3D picture can't move or resize this part" : 'Drag the picture to move the selected part';
  const resetBtn = document.getElementById('size-reset');
  if (resetBtn) resetBtn.disabled = !hasTarget;
}

// ── Render the options grid for the active tab ─────────────────────────────
function renderOptions(slotKey) {
  const slot = CHAR.slots[slotKey];
  const grid = document.getElementById('options-grid');
  grid.innerHTML = '';

  slot.options.forEach(opt => {
    const isActive = slot.multiSelect
      ? (state[slotKey].length === 0 ? opt.id === 'none' : state[slotKey].includes(opt.id))
      : state[slotKey] === opt.id;

    const card = document.createElement('div');
    card.className = 'option-card' + (isActive ? ' active' : '');
    card.title = opt.label;

    const thumbSvg = buildThumb(slotKey, opt);
    card.innerHTML = thumbSvg + `<span>${opt.label}</span>`;
    card.addEventListener('click', () => {
      applyOption(slotKey, opt.id);
      celebrate(card);
      if (slot.multiSelect) {
        renderOptions(slotKey); // rebuild grid so all active states update
      } else {
        grid.querySelectorAll('.option-card').forEach(c => c.classList.remove('active'));
        card.classList.add('active');
      }
    });
    grid.appendChild(card);
  });

  renderColorSwatches(slotKey);
  renderPatternControls(slotKey);
  renderSubpartControls(slotKey);
  renderSizeControls(slotKey);
}

// ── Build a small thumbnail SVG for an option ──────────────────────────────
// The live <defs>, indexed once by id (the markup of each top-level child that has one).
// Built lazily, after the generated defs have been injected at boot.
let thumbDefsIndex = null;
function getThumbDefsIndex() {
  if (!thumbDefsIndex) {
    thumbDefsIndex = new Map();
    document.querySelectorAll('#character-svg defs > [id]').forEach(el => thumbDefsIndex.set(el.id, el.outerHTML));
  }
  return thumbDefsIndex;
}

function buildThumb(slotKey, opt) {
  const slot    = CHAR.slots[slotKey];
  const vb      = opt.thumb || slot.thumbViewBox;
  const colors  = currentColorStyle();

  let content = '';
  if (slotKey === 'hair') {
    content = (opt.svgBack || '') + (opt.svgFront || '');
  } else {
    const thumb = opt.thumbSvg || opt.svg;
    content = typeof thumb === 'function' ? thumb(state) : (thumb || '');
  }

  if (!content.trim()) {
    return `<svg viewBox="${vb}" style="${colors}" xmlns="http://www.w3.org/2000/svg">
      <text x="50%" y="55%" text-anchor="middle" dominant-baseline="middle" font-size="28" opacity="0.3">x</text>
    </svg>`;
  }

  // A thumbnail carries only the defs its artwork uses (hundreds of clip paths and gradients
  // exist; copying them all into every thumbnail made each tab switch take tens of milliseconds).
  // Follow url(#id) references, including defs that use other defs. The colour classes are in
  // the live svg's <style>, which applies to the whole document, so they are not copied.
  const index = getThumbDefsIndex();
  const needed = new Set();
  const todo = [content];
  while (todo.length) {
    for (const m of todo.pop().matchAll(/url\(#([^)]+)\)/g)) {
      if (index.has(m[1]) && !needed.has(m[1])) { needed.add(m[1]); todo.push(index.get(m[1])); }
    }
  }

  // Every id a thumbnail declares is namespaced per thumbnail, otherwise duplicate ids across
  // thumbnails collide and one thumb's gradient resolves against another's. That includes ids
  // declared inside the option's own markup (for example a face's clipPath).
  const inlineIds = [...content.matchAll(/id="([^"]+)"/g)].map(m => m[1]);
  const ids = [...needed, ...inlineIds];
  const prefix = `thumb-${slotKey}-${opt.id}-`;
  const remap = s => {
    let out = s || '';
    ids.forEach(id => {
      out = out.replaceAll(`id="${id}"`, `id="${prefix}${id}"`);
      out = out.replaceAll(`url(#${id})`, `url(#${prefix}${id})`);
    });
    return out;
  };

  const defs = needed.size ? `<defs>${[...needed].map(id => index.get(id)).join('')}</defs>` : '';
  return `<svg viewBox="${vb}" style="${colors}" xmlns="http://www.w3.org/2000/svg">${remap(defs)}${remap(content)}</svg>`;
}

// Returns current color values as an inline style string ────────────────
function currentColorStyle() {
  return Object.entries(colorVars()).map(([k, v]) => `${k}:${v}`).join(';');
}

// ── Render color swatches for the active slot ─────────────────────────────
function renderColorSwatches(slotKey) {
  const slot      = CHAR.slots[slotKey];
  const section   = document.getElementById('color-section');
  const label     = document.getElementById('color-label');
  const swatches  = document.getElementById('color-swatches');

  if (!slot.colorSlot) {
    section.style.display = 'none';
    return;
  }

  section.style.display = 'block';
  label.textContent = slot.colorLabel || 'Colour:';
  swatches.innerHTML = '';

  const palette   = CHAR.colors[slot.colorSlot];
  const stateKey  = slot.colorSlot + 'Idx';

  palette.forEach((color, idx) => {
    const sw = document.createElement('div');
    sw.className = 'swatch' + (state[stateKey] === idx ? ' active' : '');
    const c = typeof color === 'object' ? (color.light || color.solid) : color;
    sw.style.background = typeof color === 'object' && color.css ? color.css : c;
    sw.title = c;
    sw.addEventListener('click', () => {
      state[stateKey] = idx;
      applyColors();
      celebrate(sw, 'color');
      // Refresh thumbnails to show updated color
      renderOptions(slotKey);
    });
    swatches.appendChild(sw);
  });
}

// ── Fabric pattern row (Outfit tab) ────────────────────────────────────────
function renderPatternControls(slotKey) {
  const section = document.getElementById('pattern-section');
  const list = document.getElementById('pattern-list');
  if (!section || !list) return;
  if (!CHAR.slots[slotKey].patterns) { section.hidden = true; list.innerHTML = ''; return; }
  section.hidden = false;
  list.innerHTML = '';
  CHAR.patterns.forEach(p => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'pattern-tile' + (state.clothingPattern === p.id ? ' active' : '');
    btn.title = p.label;
    btn.innerHTML = `<svg viewBox="0 0 44 44" style="${currentColorStyle()}"><rect width="44" height="44" rx="8" class="fill-clothing"/>` +
      (p.id === 'none' ? '' : `<rect width="44" height="44" rx="8" fill="url(#pat-${p.id})"/>`) + '</svg>';
    btn.addEventListener('click', () => {
      state.clothingPattern = p.id;
      applyColors();
      celebrate(btn);
      renderOptions(slotKey);
    });
    list.appendChild(btn);
  });
}

// ── Render the tab buttons ─────────────────────────────────────────────────
// Tab order and colour group (a group shares a colour). Each slot's label is "<emoji> <word>".
const TAB_ORDER = ['face', 'eyes', 'brows', 'nose', 'mouth', 'eyeshadow', 'lipstick', 'cheeks',
                   'hair', 'clothing', 'accessories', 'marks', 'background'];
const TAB_GROUP = { face: 'face', eyes: 'face', brows: 'face', nose: 'face', mouth: 'face',
                    eyeshadow: 'makeup', lipstick: 'makeup', cheeks: 'makeup',
                    hair: 'style', clothing: 'style', accessories: 'style', marks: 'style',
                    background: 'scene' };

function renderTabs() {
  const tabsEl = document.getElementById('tabs');
  tabsEl.innerHTML = '';

  const keys = [...TAB_ORDER.filter(k => CHAR.slots[k]), ...Object.keys(CHAR.slots).filter(k => !TAB_ORDER.includes(k))];
  keys.forEach(key => {
    const slot = CHAR.slots[key];
    const [icon, ...rest] = slot.label.split(' ');
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `tab g-${TAB_GROUP[key] || 'face'}` + (state.activeTab === key ? ' active' : '');
    btn.innerHTML = `<span class="tab-icon">${icon}</span><span class="tab-label">${rest.join(' ')}</span>`;
    btn.addEventListener('click', () => {
      playSound('tab');
      state.activeTab = key;
      tabsEl.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderOptions(key);
      if (preview3dOn()) PREVIEW3D.aim();     // turn to the part of her this tab is about
    });
    tabsEl.appendChild(btn);
  });
}

// ── Reset to defaults ──────────────────────────────────────────────────────
const DEFAULTS = {
  face:'oval', eyes:'round', brows:'arched', nose:'dot', mouth:'bigsmile',
  cheeks:'round', hair:'bob', clothing:'dress', accessories:[], marks:'none',
  activeAccessoryId:null,
  skinIdx:0, eyeIdx:0, hairIdx:1, lipIdx:1, clothingIdx:0, clothingPattern:'none', background:'dreamy', eyeshadow:'none', lipstick:'natural', shadowIdx:0, blushIdx:0, activeTab:'face',
};

function resetCharacter() {
  Object.assign(state, { ...DEFAULTS });
  state.scales     = {};
  state.offsets    = {};
  state.activeAccessoryId = null;
  state.accessories = [];   // fresh array — DEFAULTS.accessories is [] by reference
  Object.keys(CHAR.slots).forEach(key => {
    applyOption(key, state[key]);
    applyTransform(key);
  });
  applyColors();
  renderTabs();
  renderOptions(state.activeTab);
}

// ── Download as PNG ────────────────────────────────────────────────────────
// ── Save the picture ───────────────────────────────────────────────────────
// A 1200x1560 PNG: the character in a rounded frame on a pastel card, with "My Look!" above and
// the date below. The character is the live svg serialised and drawn as an image (its colour
// classes and custom properties travel with it). The text is drawn with canvas fillText after the
// font has loaded: an svg drawn as an image cannot load external fonts.
const SAVE_W = 1200, SAVE_H = 1560;

function roundRectPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function starShape(ctx, cx, cy, R) {
  ctx.beginPath();
  for (let k = 0; k < 8; k++) {
    const a = -Math.PI / 2 + k * Math.PI / 4, r = k % 2 ? R * 0.38 : R;
    ctx[k ? 'lineTo' : 'moveTo'](cx + r * Math.cos(a), cy + r * Math.sin(a));
  }
  ctx.closePath();
}

function saveFileName(d = new Date()) {
  const p = n => String(n).padStart(2, '0');
  return `my-look-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}.png`;
}

async function renderSavedPicture(img, when = new Date()) {
  await document.fonts.load('700 100px Fredoka');
  const canvas = document.createElement('canvas');
  canvas.width = SAVE_W;
  canvas.height = SAVE_H;
  const ctx = canvas.getContext('2d');

  // Pastel card
  const bg = ctx.createLinearGradient(0, 0, SAVE_W, SAVE_H);
  bg.addColorStop(0, '#FFD9EC'); bg.addColorStop(0.52, '#E1E6FF'); bg.addColorStop(1, '#D4F5EA');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, SAVE_W, SAVE_H);
  ctx.fillStyle = 'rgba(255,255,255,0.55)';
  [[130, 120, 70], [1090, 210, 100], [1100, 1420, 80], [90, 1340, 60]].forEach(([x, y, r]) => { ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill(); });

  // Title
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '700 104px Fredoka, "Trebuchet MS", sans-serif';
  const grad = ctx.createLinearGradient(330, 0, 870, 0);
  [['#FF6FA3', 0], ['#FFA94D', 0.22], ['#F5C518', 0.4], ['#3DBE8B', 0.6], ['#4DA3FF', 0.8], ['#A36CFF', 1]].forEach(([c, o]) => grad.addColorStop(o, c));
  ctx.lineJoin = 'round';
  ctx.lineWidth = 18;
  ctx.strokeStyle = '#fff';
  ctx.strokeText('My Look!', SAVE_W / 2, 100);
  ctx.fillStyle = grad;
  ctx.fillText('My Look!', SAVE_W / 2, 100);

  // The picture, in a white rounded frame with a soft shadow
  const px = 100, py = 180, pw = 1000, ph = 1300, r = 64;
  ctx.save();
  ctx.shadowColor = 'rgba(110, 70, 160, 0.35)';
  ctx.shadowBlur = 40;
  ctx.shadowOffsetY = 14;
  ctx.fillStyle = '#fff';
  roundRectPath(ctx, px - 14, py - 14, pw + 28, ph + 28, r + 14);
  ctx.fill();
  ctx.restore();
  ctx.save();
  roundRectPath(ctx, px, py, pw, ph, r);
  ctx.clip();
  ctx.drawImage(img, px, py, pw, ph);
  ctx.restore();

  // A few sparkles in the corners
  [[80, 70, 26, '#FFD54A'], [1120, 90, 20, '#FF6FA3'], [70, 1500, 22, '#7FD1F2'], [1130, 1490, 28, '#FFD54A'], [1150, 700, 16, '#B46BFF']].forEach(([x, y, R, c]) => {
    ctx.fillStyle = c; starShape(ctx, x, y, R); ctx.fill();
  });

  // Date
  ctx.font = '500 44px Fredoka, "Trebuchet MS", sans-serif';
  ctx.fillStyle = '#6f6890';
  ctx.fillText(when.toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' }), SAVE_W / 2, 1527);
  return canvas;
}

// The live character as self-contained svg text: the colour classes live in the svg's own
// <style> and the colour custom properties are on its style attribute, so a clone needs nothing
// else. `mutate(clone)` may change the clone first (the 3D world adds legs and drops the
// background). `level` draws it without the pointer tilt; the saved picture keeps the tilt.
function characterSvgText(mutate, { level = false } = {}) {
  const tilted = level && (scene3D.x !== 0 || scene3D.y !== 0);
  const tilt = { x: scene3D.x, y: scene3D.y };
  if (tilted) { scene3D.x = scene3D.y = 0; applyAllTransforms(); }
  const clone = svg.cloneNode(true);
  if (tilted) { scene3D.x = tilt.x; scene3D.y = tilt.y; applyAllTransforms(); }
  if (mutate) mutate(clone);
  return new XMLSerializer().serializeToString(clone);
}

// Any look as self-contained svg text, drawn level (no pointer tilt) and without touching the page or the state: for
// the friends in the world, whose pictures must not depend on (or disturb) the one live character. It lays the layers out
// the way applyOption and applyTransform do, on a copy of the live svg's fixed parts (its <defs>, <style> and the neck),
// so for her own look it is the same picture as characterSvgText(null, { level: true }).
const LEVEL_TILT = { x: 0, y: 0 };
let lookSvgTemplate = null;
function lookSvgClone(look) {
  if (!lookSvgTemplate) {                      // first use, after init() has put the generated defs in the live svg
    lookSvgTemplate = svg.cloneNode(true);
    lookSvgTemplate.removeAttribute('style');
    lookSvgTemplate.removeAttribute('class');
    lookSvgTemplate.querySelectorAll('g[id^="layer-"]').forEach(g => {
      g.removeAttribute('transform');
      if (g.id !== 'layer-neck') g.innerHTML = '';          // the neck is fixed art, not a slot
    });
  }
  const el = lookSvgTemplate.cloneNode(true);
  const layer = id => el.querySelector('#layer-' + id);
  Object.entries(colorVars(look)).forEach(([k, v]) => el.style.setProperty(k, v));

  for (const [key, slot] of Object.entries(CHAR.slots)) {
    const value = look[key];
    if (key === 'accessories') {
      layer('accessories').innerHTML = buildAccessoryLayerContent(look, LEVEL_TILT);
    } else if (slot.multiSelect) {
      const combined = value.map(id => { const o = getOption(key, id); return o ? (o.svg || '') : ''; }).join('');
      slot.layerIds.forEach(id => { layer(id).innerHTML = combined; });
    } else {
      const opt = getOption(key, value);
      if (!opt) continue;
      if (key === 'hair') {
        layer('hair-back').innerHTML = opt.svgBack || '';
        layer('hair-front').innerHTML = opt.svgFront || '';
      } else {
        const svgStr = typeof opt.svg === 'function' ? opt.svg(look) : (opt.svg || '');
        layer(key).innerHTML = key === 'eyes' || key === 'eyeshadow' ? `<g class="eye-anim">${svgStr}</g>` : svgStr;
      }
    }
    if (key !== 'accessories') {
      const transform = buildTransformString(key, null, null, null, look, LEVEL_TILT);
      if (transform) slot.layerIds.forEach(id => layer(id).setAttribute('transform', transform));
    }
  }
  return el;
}

function lookSvgText(look, mutate) {
  const el = lookSvgClone(look);
  if (mutate) mutate(el);
  return new XMLSerializer().serializeToString(el);
}

// Decode svg text as an image (an svg drawn this way cannot load fonts or outside images).
function svgTextToImage(xml) {
  const url = URL.createObjectURL(new Blob([xml], { type: 'image/svg+xml;charset=utf-8' }));
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('The character picture could not be drawn')); };
    img.src = url;
  });
}

// The saved picture of the 3D her: the backdrop of the flat picture with her 3D self drawn over it.
async function preview3dPicture() {
  const W = 1000, H = 1300;                                  // the frame in renderSavedPicture
  const backdrop = await svgTextToImage(characterSvgText(clone => { clone.querySelector('#figure').innerHTML = ''; }, { level: true }));
  const canvas = document.createElement('canvas');
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(backdrop, 0, 0, W, H);
  ctx.drawImage(PREVIEW3D.snapshot(W, H), 0, 0);
  return canvas;
}

async function downloadCharacter() {
  celebrate(document.getElementById('save-btn'), 'save');
  const img = preview3dOn() ? await preview3dPicture() : await svgTextToImage(characterSvgText());
  const when = new Date();
  const canvas = await renderSavedPicture(img, when);

  const link      = document.createElement('a');
  link.download   = saveFileName(when);
  link.href       = canvas.toDataURL('image/png');
  link.click();
}

// ── Size slider wiring (controls the currently active tab's part) ──────────
function wireSizeControls() {
  const wEl = document.getElementById('size-w');
  const hEl = document.getElementById('size-h');

  wEl.addEventListener('input', e => {
    const target = getActiveTransformTarget(state.activeTab);
    if (!target) return;
    getScale(target.slotKey, target.itemId).x = e.target.value / 100;
    document.getElementById('size-w-val').textContent = e.target.value + '%';
    // Face scale change propagates to all face-following slots.
    if (target.slotKey === 'face') applyAllTransforms();
    else applyTransform(target.slotKey);
  });
  hEl.addEventListener('input', e => {
    const target = getActiveTransformTarget(state.activeTab);
    if (!target) return;
    getScale(target.slotKey, target.itemId).y = e.target.value / 100;
    document.getElementById('size-h-val').textContent = e.target.value + '%';
    if (target.slotKey === 'face') applyAllTransforms();
    else applyTransform(target.slotKey);
  });
  document.getElementById('size-reset').addEventListener('click', () => {
    const target = getActiveTransformTarget(state.activeTab);
    if (!target) return;
    const key = transformKey(target.slotKey, target.itemId);
    state.scales[key] = { x: 1, y: 1 };
    state.offsets[key] = { x: 0, y: 0 };
    if (target.slotKey === 'face') applyAllTransforms();
    else applyTransform(target.slotKey);
    renderSizeControls(state.activeTab);
  });
}

// ── Interactive tilt preview (2D parallax: tilt + per-slot depth) ─────────
function wireTiltPreview() {
  const wrap = document.getElementById('svg-wrap');
  if (!wrap) return;

  const motion = {
    tx: 0, ty: 0,
    x: 0,  y: 0,
    raf: 0,
  }

  function renderScene() {
    motion.raf = 0;

    motion.x += (motion.tx - motion.x) * 0.16;
    motion.y += (motion.ty - motion.y) * 0.16;

    scene3D.x = motion.x;
    scene3D.y = motion.y;
    applyAllTransforms();

    const strength = Math.max(Math.abs(motion.x), Math.abs(motion.y));
    wrap.style.setProperty('--tilt-x', `${(-motion.y * 8).toFixed(2)}deg`);
    wrap.style.setProperty('--tilt-y', `${(motion.x * 10).toFixed(2)}deg`);
    wrap.style.setProperty('--tilt-scale', (1 + strength * 0.016).toFixed(4));
    wrap.style.setProperty('--gloss-x', `${(50 + motion.x * 18).toFixed(2)}%`);
    wrap.style.setProperty('--gloss-y', `${(18 - motion.y * 10).toFixed(2)}%`);
    wrap.style.setProperty('--shadow-x', `${(motion.x * 9).toFixed(2)}px`);
    wrap.style.setProperty('--shadow-y', `${(18 + motion.y * 4).toFixed(2)}px`);

    if (Math.abs(motion.tx - motion.x) > 0.001 || Math.abs(motion.ty - motion.y) > 0.001) {
      motion.raf = requestAnimationFrame(renderScene);
    }
  }

  function requestSceneFrame() {
    if (!motion.raf) motion.raf = requestAnimationFrame(renderScene);
  }

  function setTargetFromPointer(e) {
    if (preview3dOn()) return;     // the 3D her turns by dragging; the flat picture's tilt is for the flat picture
    const rect = wrap.getBoundingClientRect();
    const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const ny = ((e.clientY - rect.top) / rect.height) * 2 - 1;
    motion.tx = Math.max(-1, Math.min(1, nx));
    motion.ty = Math.max(-1, Math.min(1, ny));
    requestSceneFrame();
  }

  wrap.addEventListener('pointermove', setTargetFromPointer);
  wrap.addEventListener('pointerenter', setTargetFromPointer);
  wrap.addEventListener('pointerleave', () => {
    motion.tx = 0;
    motion.ty = 0;
    requestSceneFrame();
  });
}

// ── Drag-to-reposition (moves the active tab's feature) ───────────────────
// Adjust's drag-to-move: the selected part follows the pointer. It works on the flat picture and on the 3D her, whose
// canvas covers it: world/preview3d.js hands its pointer events to adjustDrag.begin / move / end (the same offsets, so the
// flat picture and the 3D her always agree). `unitsPerPx()` says how many SVG units one screen pixel is, as { x, y }.
const adjustDrag = (() => {
  let drag = null;
  return {
    // false (and nothing happens) while Adjust is closed: a small hand clicking a face must not shove the eyes around.
    begin(e, el, unitsPerPx) {
      if (!state.adjustOpen) return false;
      drag = { el, id: e.pointerId, x: e.clientX, y: e.clientY, unitsPerPx };
      el.setPointerCapture?.(e.pointerId);
      e.preventDefault();
      return true;
    },
    move(e) {
      if (!drag || drag.id !== e.pointerId) return false;
      const target = getActiveTransformTarget(state.activeTab);
      if (target) {
        const u = drag.unitsPerPx();
        const off = getOffset(target.slotKey, target.itemId);
        off.x += (e.clientX - drag.x) * u.x;
        off.y += (e.clientY - drag.y) * u.y;
        applyTransform(target.slotKey);
      }
      drag.x = e.clientX;
      drag.y = e.clientY;
      return true;
    },
    end(e) {
      if (!drag || drag.id !== e.pointerId) return false;
      drag = null;
      return true;
    },
  };
})();

function wireDragToReposition() {
  const svgEl = document.getElementById('character-svg');
  const unitsPerPx = () => {
    const rect = svgEl.getBoundingClientRect();       // screen pixels -> SVG user units
    return { x: 400 / rect.width, y: 520 / rect.height };
  };
  svgEl.addEventListener('pointerdown', e => { if (adjustDrag.begin(e, svgEl, unitsPerPx)) svgEl.style.cursor = 'grabbing'; });
  svgEl.addEventListener('pointermove', e => adjustDrag.move(e));
  const stop = e => { if (adjustDrag.end(e)) svgEl.style.cursor = 'grab'; };
  svgEl.addEventListener('pointerup', stop);
  svgEl.addEventListener('pointercancel', stop);
}

// ── The 3D world ───────────────────────────────────────────────────────────
// Its scripts (about 13.6 MB today, mostly her 3D model and the recorded sounds) are added only when Let's play! is pressed. Classic scripts, in order: each needs the one before it. They are
// added once; pressing the button again just rebuilds her picture from the current look.
const WORLD_SCRIPTS = [
  'world/vendor/three.bundle.js',
  'world/assets/packs/nature.js',
  'world/assets/packs/town.js',
  'world/assets/packs/furniture.js',
  'world/assets/packs/character.js',
  'world/assets/packs/sounds.js',
  'world/solid.js',
  'world/layout.js',
  'world/interior.js',
  'world/nav.js',
  'world/cutout.js',
  'world/toon.js',
  'world/facetex.js',
  'world/character3d.js',
  'world/preview3d.js',
  'world/world.js',
  'world/life.js',
  'world/npcs.js',
  'world/fx.js',
  'world/voices.js',
  'world/social.js',
  'world/houses.js',
  'world/roomactions.js',
];
// Each script is added once, however many lists ask for it, and always after the ones before it in its list.
const scriptLoads = new Map();
function loadScripts(list) {
  return list.reduce((chain, src) => chain.then(() => {
    if (!scriptLoads.has(src)) {
      scriptLoads.set(src, new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = src;
        s.onload = resolve;
        s.onerror = () => { scriptLoads.delete(src); reject(new Error('Could not load ' + src)); };   // allow a retry
        document.head.appendChild(s);
      }));
    }
    return scriptLoads.get(src);
  }), Promise.resolve());
}
const loadWorldScripts = () => loadScripts(WORLD_SCRIPTS);

// ── The 3D dressing room ───────────────────────────────────────────────────
// Her live 3D figure takes the place of the flat picture (world/preview3d.js). The flat picture stays in the
// page as the source of truth, and is what she sees if WebGL is missing or the page is opened with #flat.
// Its scripts (the 3D library and her model, about 11 MB) load after the page is up, so the first picture is not delayed.
const PREVIEW_SCRIPTS = [
  'world/vendor/three.bundle.js',
  'world/assets/packs/character.js',
  'world/toon.js',
  'world/facetex.js',
  'world/character3d.js',
  'world/preview3d.js',
];

async function startPreview3d() {
  if (/flat/.test(location.hash)) return;
  try {
    await loadScripts(PREVIEW_SCRIPTS);
    if (await PREVIEW3D.start(document.getElementById('svg-wrap'), svg)) {
      document.body.classList.add('three-d');
      renderSizeControls(state.activeTab);                 // the 3D her cannot move or resize everything (adjustLockedIn3D)
    }
  } catch (err) {
    console.warn('3D dressing room not available:', err);
  }
}
const preview3dOn = () => document.body.classList.contains('three-d');
// The 3D her can drop out and come back (a lost GPU context, world/preview3d.js): the Adjust tools follow what is showing.
document.addEventListener('preview3d:mode', () => renderSizeControls(state.activeTab));

async function openWorld() {
  const overlay = document.getElementById('world-overlay');
  const loading = document.getElementById('world-loading');
  const error = document.getElementById('world-error');
  playSound('surprise');
  overlay.hidden = false;
  loading.hidden = false;
  error.hidden = true;
  if (preview3dOn()) PREVIEW3D.pause(true);     // one picture at a time
  document.activeElement?.blur?.();     // no button keeps the focus in the world: the space bar jumps there, it must not press one
  try {
    await loadWorldScripts();
    await WORLD.open(document.getElementById('world-canvas'));
    loading.hidden = true;
    watchWorldContext();
  } catch (err) {
    console.error(err);
    loading.hidden = true;
    error.hidden = false;     // the Back button is still there
  }
}

// The GPU can take the world away (sleep and wake, a driver reset). The world stops drawing by itself and comes back when the context is given
// back: until then a friendly message shows, and Back still works.
let worldContextWatched = false;
function watchWorldContext() {
  const canvas = document.getElementById('world-canvas'), lostMsg = document.getElementById('world-lost');
  if (!worldContextWatched) {
    worldContextWatched = true;
    canvas.addEventListener('webglcontextlost', () => { lostMsg.hidden = false; });
    canvas.addEventListener('webglcontextrestored', () => { lostMsg.hidden = true; });
  }
  lostMsg.hidden = !WORLD.parts.renderer.getContext().isContextLost();     // it may have gone while the world was closed
}

function closeWorld() {
  const overlay = document.getElementById('world-overlay');
  if (overlay.hidden) return;
  if (window.WORLD) WORLD.close();
  if (preview3dOn()) PREVIEW3D.pause(false);
  overlay.hidden = true;
  playSound('tab');
  document.activeElement?.blur?.();     // not on "Let's play!" either, or the next space bar would open the world again
}

function wireWorld() {
  document.getElementById('play-btn').addEventListener('click', openWorld);
  document.getElementById('world-back').addEventListener('click', closeWorld);
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeWorld(); });
}

// ── Friends: how many other characters play in the world ───────────────────
// 0 to 12, default 4, remembered in localStorage 'makeup.friends'. The world reads
// friendCount() every time it opens; anything that wants to follow live pushes a function onto
// window.onFriendCountChange (called with the new count).
const FRIENDS_MIN = 0, FRIENDS_MAX = 12, FRIENDS_DEFAULT = 4;
window.onFriendCountChange = [];
let friendsN = loadFriendCount();

function loadFriendCount() {
  try {
    const raw = localStorage.getItem('makeup.friends');
    if (raw !== null && /^\d{1,2}$/.test(raw.trim())) {
      const n = Number(raw);
      if (n >= FRIENDS_MIN && n <= FRIENDS_MAX) return n;
    }
  } catch (e) { /* private window */ }
  return FRIENDS_DEFAULT;
}

function friendCount() { return friendsN; }

function renderFriends() {
  const num = document.getElementById('friends-count');
  if (!num) return;
  num.textContent = String(friendsN);
  document.getElementById('friends-minus').disabled = friendsN <= FRIENDS_MIN;
  document.getElementById('friends-plus').disabled = friendsN >= FRIENDS_MAX;
}

function stepFriends(delta, btn) {
  const next = Math.max(FRIENDS_MIN, Math.min(FRIENDS_MAX, friendsN + delta));
  if (next === friendsN) return;
  friendsN = next;
  try { localStorage.setItem('makeup.friends', String(friendsN)); } catch (e) { /* ignore */ }
  renderFriends();
  celebrate(btn, delta > 0 ? 'pick' : 'tab');
  for (const fn of window.onFriendCountChange) { try { fn(friendsN); } catch (e) { console.error(e); } }
}

function wireFriends() {
  document.getElementById('friends-minus').addEventListener('click', e => stepFriends(-1, e.currentTarget));
  document.getElementById('friends-plus').addEventListener('click', e => stepFriends(1, e.currentTarget));
  renderFriends();
}

// ── Boot ───────────────────────────────────────────────────────────────────
// ── Sound ──────────────────────────────────────────────────────────────────
// Short effects from assets/sounds (Kenney, CC0; see CREDITS.md). Played with small pools of
// <audio> elements, not fetch() + Web Audio: the page runs from file://, where fetching local
// files is blocked. One sound per type per 80 ms, so a fast tapper makes pops, not noise.
const SOUND_NAMES = ['tab', 'pick', 'color', 'save', 'reset', 'surprise'];
const SOUND_VOLUME = 0.35;
const SOUND_MIN_GAP_MS = 80;
const sound = { muted: false, pools: {}, next: {}, last: {} };

function initSound() {
  try { sound.muted = localStorage.getItem('makeup.muted') === '1'; } catch (e) { /* private window */ }
  SOUND_NAMES.forEach(name => {
    sound.pools[name] = Array.from({ length: 3 }, () => {
      const a = new Audio(`assets/sounds/${name}.ogg`);
      a.preload = 'auto';
      a.volume = SOUND_VOLUME;
      return a;
    });
    sound.next[name] = 0;
    sound.last[name] = 0;
  });
  renderMuteButton();
  document.getElementById('mute-btn').addEventListener('click', () => {
    sound.muted = !sound.muted;
    try { localStorage.setItem('makeup.muted', sound.muted ? '1' : '0'); } catch (e) { /* ignore */ }
    renderMuteButton();
    playSound('pick');   // a quick "I'm back" pop when un-muting (silent when muting)
  });
}

function renderMuteButton() {
  const btn = document.getElementById('mute-btn');
  if (!btn) return;
  btn.textContent = sound.muted ? '🔇' : '🔊';
  btn.setAttribute('aria-pressed', sound.muted ? 'true' : 'false');
  btn.title = sound.muted ? 'Sound is off' : 'Sound is on';
}

function playSound(name) {
  if (sound.muted || window.__STILL) return;
  const pool = sound.pools[name];
  if (!pool) return;
  const now = performance.now();
  if (now - sound.last[name] < SOUND_MIN_GAP_MS) return;
  sound.last[name] = now;
  const a = pool[sound.next[name]++ % pool.length];
  try { a.currentTime = 0; } catch (e) { /* not loaded yet */ }
  const p = a.play();
  if (p && p.catch) p.catch(() => { /* autoplay blocked before the first tap: ignore */ });
}

// ── Life: blinking and sparkles ────────────────────────────────────────────
// Set window.__STILL = true (the screenshot tools do) to turn all of it off.
const prefersReducedMotion = () =>
  window.__STILL || (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

function startBlinking() {
  if (prefersReducedMotion()) return;
  const svgEl = document.getElementById('character-svg');
  const next = () => setTimeout(() => {
    svgEl.classList.add('blinking');
    setTimeout(() => svgEl.classList.remove('blinking'), 170);
    next();
  }, 2500 + Math.random() * 3500);
  next();
}

// A burst of stars over the picture. Each star removes itself when its animation ends; the
// layer is also capped, so rapid clicking cannot grow the DOM.
function burstSparkles() {
  if (prefersReducedMotion()) return;
  const layer = document.getElementById('spark-layer');
  if (!layer) return;
  const colors = ['#FFD54A', '#FF6FA3', '#7FD1F2', '#B46BFF', '#6BD66B'];
  while (layer.children.length > 40) layer.firstChild.remove();
  for (let i = 0; i < 10; i++) {
    const s = document.createElement('span');
    s.className = 'spark';
    s.textContent = i % 3 ? '★' : '✦';
    const a = Math.random() * Math.PI * 2, d = 50 + Math.random() * 85;
    s.style.setProperty('--dx', `${Math.round(Math.cos(a) * d)}px`);
    s.style.setProperty('--dy', `${Math.round(Math.sin(a) * d)}px`);
    s.style.setProperty('--r', `${Math.round((Math.random() - 0.5) * 240)}deg`);
    s.style.setProperty('--c', colors[i % colors.length]);
    s.style.setProperty('--s', `${Math.round(14 + Math.random() * 14)}px`);
    s.addEventListener('animationend', () => s.remove());
    layer.appendChild(s);
  }
}

// Feedback for a pick: the tapped thing pops and stars burst over the picture.
function celebrate(el, kind = 'pick') {
  playSound(kind);
  if (el && !prefersReducedMotion()) {
    el.classList.remove('popped');
    void el.offsetWidth;
    el.classList.add('popped');
    setTimeout(() => el.classList.remove('popped'), 400);
  }
  burstSparkles();
  if ((kind === 'save' || kind === 'surprise') && preview3dOn()) PREVIEW3D.cheer();
}

// ── Surprise me! ───────────────────────────────────────────────────────────
// A random look. Essentials (eyes, brows, nose, mouth, hair, outfit) are never "none"; the
// face shape only sometimes changes; extras are 0-2 items from different parts of the body, so
// there is never a pair of hats. Pass a seed for a repeatable look (the screenshot tools do).
const ACCESSORY_ZONE = {
  glasses: 'eyes', heartshades: 'eyes', 'hp-glasses': 'eyes',
  earrings: 'ears', 'elf-ears': 'ears', 'dobby-ears': 'ears',
  'gryffindor-scarf': 'neck', wand: 'hand', starwand: 'hand',
};   // everything else is worn on the head

function makeRng(seed) {
  if (seed === undefined) return Math.random;
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

// The single-choice slots a random look draws, in this order: [slot, chance that it is left "none"].
const LOOK_SLOT_ROLLS = [['eyes', 0], ['brows', 0], ['nose', 0], ['mouth', 0], ['hair', 0], ['clothing', 0],
  ['lipstick', 0], ['eyeshadow', 0.4], ['cheeks', 0.2], ['marks', 0.65], ['background', 0]];

// A random look as plain data: the parts and colours of `state`, without the UI keys, and with no sizes or
// moves. Pure: it reads only CHAR and `rng` and touches neither the state nor the page. `faceFallback` is the
// face shape when the 1-in-4 roll leaves the face alone (Surprise me! passes the face she has).
function randomLook(rng = Math.random, faceFallback = 'oval') {
  const below = n => Math.floor(rng() * n);
  const any = arr => arr[below(arr.length)];
  const ids = key => CHAR.slots[key].options.map(o => o.id);
  const look = {};

  LOOK_SLOT_ROLLS.forEach(([key, noneChance]) => {
    const all = ids(key).filter(id => id !== 'none');
    look[key] = rng() < noneChance && ids(key).includes('none') ? 'none' : any(all);
  });
  look.face = rng() < 0.25 ? any(ids('face')) : faceFallback;

  look.skinIdx = below(CHAR.colors.skin.length);
  look.eyeIdx = below(CHAR.colors.eye.length);
  look.hairIdx = below(CHAR.colors.hair.length);
  look.lipIdx = below(CHAR.colors.lip.length);
  look.clothingIdx = below(CHAR.colors.clothing.length);
  look.shadowIdx = below(CHAR.colors.shadow.length);
  look.blushIdx = below(CHAR.colors.blush.length);
  look.clothingPattern = rng() < 0.4 ? 'none' : any(CHAR.patterns.filter(p => p.id !== 'none')).id;

  // 0-2 extras, at most one per zone.
  const wanted = [0, 0, 1, 1, 2][below(5)];
  const zones = new Set(), picks = [];
  ids('accessories').filter(id => id !== 'none').sort(() => rng() - 0.5).forEach(id => {
    const zone = ACCESSORY_ZONE[id] || 'head';
    if (picks.length < wanted && !zones.has(zone)) { zones.add(zone); picks.push(id); }
  });
  look.accessories = picks;
  look.scales = {};
  look.offsets = {};
  return look;
}

// What makes two outfits-and-hairdos the same to the eye: hairstyle and colour, outfit, colour and pattern.
function lookSignature(look) {
  return [look.hair, look.hairIdx, look.clothing, look.clothingIdx, look.clothingPattern].join('|');
}

// n random looks for the friends in the world, all different: no two share a signature (see lookSignature), none
// has hers, and the hairstyles and outfits come out of shuffled bags (hers at the back), so they do not repeat
// until a bag is empty (12 outfits: friend 12 is the first to wear hers, in other colours). Pure, like randomLook.
function friendLooks(n, herLook = null, rng = Math.random) {
  const shuffle = arr => {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
    return a;
  };
  const bagOf = (slotKey, hers) => {
    const all = CHAR.slots[slotKey].options.map(o => o.id).filter(id => id !== 'none');
    let left = [];
    return () => {
      if (!left.length) left = [...shuffle(all.filter(id => id !== hers)), ...(all.includes(hers) ? [hers] : [])];
      return left.shift();
    };
  };
  const nextHair = bagOf('hair', herLook && herLook.hair), nextClothing = bagOf('clothing', herLook && herLook.clothing);
  const taken = new Set(herLook ? [lookSignature(herLook)] : []);
  const looks = [];
  for (let i = 0, count = Math.max(0, Math.floor(n) || 0); i < count; i++) {
    const hair = nextHair(), clothing = nextClothing();
    let look, tries = 0;
    do { look = randomLook(rng); look.hair = hair; look.clothing = clothing; }
    while (taken.has(lookSignature(look)) && ++tries < 1000);
    // (Practically unreachable: only a repeated draw this many times falls back to walking through the outfit colours.)
    for (let k = 0; taken.has(lookSignature(look)) && k < CHAR.colors.clothing.length; k++) look.clothingIdx = (look.clothingIdx + 1) % CHAR.colors.clothing.length;
    taken.add(lookSignature(look));
    looks.push(look);
  }
  return looks;
}

function surpriseMe(seed) {
  const look = randomLook(makeRng(seed), state.face);

  state.scales = {};
  state.offsets = {};
  state.activeAccessoryId = null;

  LOOK_SLOT_ROLLS.forEach(([key]) => applyOption(key, look[key]));
  applyOption('face', look.face);

  state.skinIdx = look.skinIdx;
  state.eyeIdx = look.eyeIdx;
  state.hairIdx = look.hairIdx;
  state.lipIdx = look.lipIdx;
  state.clothingIdx = look.clothingIdx;
  state.shadowIdx = look.shadowIdx;
  state.blushIdx = look.blushIdx;
  state.clothingPattern = look.clothingPattern;
  applyOption('accessories', look.accessories);

  applyColors();
  applyAllTransforms();
  renderTabs();
  renderOptions(state.activeTab);
}

function wireSurprise() {
  const btn = document.getElementById('surprise-btn');
  btn.addEventListener('click', () => { surpriseMe(); celebrate(btn, 'surprise'); });
}

// ── Adjust (size and position) and Start over? ─────────────────────────────
// Size sliders and drag-to-move are grown-up tools: hidden until "Adjust" is opened, and
// dragging the picture does nothing while it is closed (a small hand clicking a face must not
// shove the eyes around). The choice is remembered, where the browser allows it.
function setAdjustOpen(open, remember = true) {
  state.adjustOpen = !!open;
  document.body.classList.toggle('adjust-open', state.adjustOpen);
  const btn = document.getElementById('adjust-toggle');
  if (btn) {
    btn.setAttribute('aria-pressed', state.adjustOpen ? 'true' : 'false');
    btn.textContent = state.adjustOpen ? '🔧 Adjust: on' : '🔧 Adjust';
  }
  if (remember) { try { localStorage.setItem('makeup.adjustOpen', state.adjustOpen ? '1' : '0'); } catch (e) { /* private window */ } }
}

function wireAdjustToggle() {
  let saved = false;
  try { saved = localStorage.getItem('makeup.adjustOpen') === '1'; } catch (e) { /* ignore */ }
  setAdjustOpen(saved, false);
  document.getElementById('adjust-toggle').addEventListener('click', () => setAdjustOpen(!state.adjustOpen));
}

function askReset() {
  document.getElementById('confirm-overlay').classList.add('open');
  document.getElementById('confirm-no').focus();
}

function wireConfirmDialog() {
  const overlay = document.getElementById('confirm-overlay');
  const close = () => overlay.classList.remove('open');
  document.getElementById('confirm-yes').addEventListener('click', () => { close(); playSound('reset'); resetCharacter(); });
  document.getElementById('confirm-no').addEventListener('click', close);
  overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
}

function init() {
  // Defs generated from the art in character.js (eye clipPaths, iris shade). Must be in
  // place before the first option or thumbnail renders.
  svg.querySelector('defs').insertAdjacentHTML('beforeend', CHAR_DEFS.join('\n'));
  // Apply defaults
  Object.keys(CHAR.slots).forEach(key => applyOption(key, state[key]));
  applyColors();
  applyAllTransforms();
  wireSizeControls();
  wireAdjustToggle();
  wireConfirmDialog();
  wireSurprise();
  wireWorld();
  wireFriends();
  if (window.__STILL) document.body.classList.add('still');
  initSound();
  startBlinking();
  wireTiltPreview();
  wireDragToReposition();
  renderTabs();
  renderOptions(state.activeTab);
  // After the page has drawn once, so the 3D never delays the first picture.
  requestAnimationFrame(() => setTimeout(startPreview3d, 0));
}

init();

