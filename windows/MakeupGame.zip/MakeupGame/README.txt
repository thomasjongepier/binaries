MAKE YOUR CHARACTER!
====================

A dress-up game: pick a face, eyes, hair, makeup, outfit, extras and a scene,
then press Save! to keep the picture, or press Let's play! to take your
character for a walk in a little 3D world.

HOW TO PLAY
  Double-click  index.html
  It opens in your web browser (Edge or Chrome work best). No install and no
  internet needed.

HOW TO SHARE IT
  Copy this whole folder (or the .zip) to a USB stick, another computer or an
  email. Keep the files together: index.html needs the "assets" and "world"
  folders beside it.

NOTES
  - Saved pictures go to your browser's Downloads folder as
    my-look-<date>-<time>.png
  - No sound? The speaker button in the top-right corner switches it on and off.
  - In the world: tap the ground (or use the arrow keys / W A S D) to walk.
    The round buttons at the bottom right zoom (+ and -) and turn the camera
    around her (the curly arrows). The mouse wheel zooms too, and dragging with
    the right mouse button turns. Back to dressing up returns to the game. If the picture is jerky on an old
    computer, it makes itself less sharp by itself; grown-ups can press F to see
    the frame rate.
  - Friends in the world: walk up to one who looks at you and they wave, say
    hi, cry or fart. Tap a friend to make them do something else.
  - "Adjust" (bottom of the right-hand panel) is for grown-ups: it lets you
    resize and move the selected part.

Credits for the font and sounds are in CREDITS.md.
