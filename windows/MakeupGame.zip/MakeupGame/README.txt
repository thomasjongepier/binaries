MAKE YOUR CHARACTER!
====================

A dress-up game: pick a face, eyes, hair, makeup, outfit, extras and a scene,
then press Save! to keep the picture.

HOW TO PLAY
  Double-click  index.html
  It opens in your web browser (Edge or Chrome work best). No install and no
  internet needed.

HOW TO SHARE IT
  Copy this whole folder (or the .zip) to a USB stick, another computer or an
  email. Keep the files together: index.html needs the "assets" folder beside it.

NOTES
  - Saved pictures go to your browser's Downloads folder as
    my-look-<date>-<time>.png
  - No sound? The speaker button in the top-right corner switches it on and off.
  - "Adjust" (bottom of the right-hand panel) is for grown-ups: it lets you
    resize and move the selected part.

Credits for the font and sounds are in CREDITS.md.
