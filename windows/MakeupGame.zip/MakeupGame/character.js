// All character customization data. See ART_DIRECTION.md for the style rules.
// SVG viewBox: 0 0 400 520, centre line x=200. Chibi proportions: a big head, small body.
// Face: x 82-318, y 80-328. Eyes at (148,216) and (252,216), right eye mirrored via transform.
// Brows y~165. Nose (200,258). Mouth (200,295). Cheeks (116,264)/(284,264).
// Neck y 300-378. Clothing starts y~356. Hair top y~42.
// Eyes/brows use: <g transform="translate(400,0) scale(-1,1)"> to mirror left→right.
// Lighting convention: one light from the upper-LEFT. Highlights sit upper-left,
// shadows lower-right. Cel shading: hard-edged shadow shapes, outlines in a darker
// shade of the fill (never black).

// ── Draw helpers ───────────────────────────────────────────────────────────
// The art below is authored as raw SVG strings. These name the patterns that
// were previously copy-pasted across options, so a fix lands in one place.

// Mirror a left-side feature onto the right across the x=200 centre line.
// Previously written out inline at nine separate call sites.
const mirror = L => `${L}<g transform="translate(400,0) scale(-1,1)">${L}</g>`;

// A face: ears behind, skin, a hard cel-shadow crescent, outline. `earX` is the x of the
// left ear; the right ear mirrors it about x=200. Ears sit at y=226.
const faceArt = (id, d, earX) => `
  <ellipse class="fill-skin ol-skin" cx="${earX}" cy="226" rx="12" ry="17"/>
  <ellipse class="fill-skin ol-skin" cx="${400 - earX}" cy="226" rx="12" ry="17"/>
  <clipPath id="face-clip-${id}"><path d="${d}"/></clipPath>
  <path class="fill-skin" d="${d}"/>
  <g clip-path="url(#face-clip-${id})">
    <path d="${d}" fill="var(--skin-dk)" opacity="0.5"/>
    <path class="fill-skin" transform="translate(-9 -8)" d="${d}"/>
  </g>
  <path d="${d}" fill="none" class="ol-skin"/>`;

// Markup that belongs in the live svg's <defs> but is generated from the art below (each
// eye's clipPath is built from the same path that draws its sclera, so the geometry is
// written once). game.js injects this at boot, before any option or thumbnail is rendered.
const CHAR_DEFS = [
  // Rainbow hair: vertical bands in user space, so every style shows the same colours top to bottom.
  `<linearGradient id="hair-rainbow" gradientUnits="userSpaceOnUse" x1="0" y1="20" x2="0" y2="480">
     <stop offset="0" stop-color="#FF5E5E"/><stop offset="0.2" stop-color="#FFA94D"/><stop offset="0.4" stop-color="#FFE14D"/>
     <stop offset="0.6" stop-color="#6BD66B"/><stop offset="0.8" stop-color="#4DB8FF"/><stop offset="1" stop-color="#B46BFF"/>
   </linearGradient>`,
  // Iris depth: dark under the upper lid, a touch lighter at the bottom. Black/white alpha,
  // so one gradient serves every eye colour.
  `<linearGradient id="iris-shade" x1="0" y1="0" x2="0" y2="1">
     <stop offset="0" stop-color="#000" stop-opacity="0.5"/>
     <stop offset="0.5" stop-color="#000" stop-opacity="0"/>
     <stop offset="1" stop-color="#fff" stop-opacity="0.3"/>
   </linearGradient>`,
];

const LASH = '#2d1b16';
const ellipsePath = (cx, cy, rx, ry) =>
  `M${cx - rx},${cy} A${rx},${ry} 0 1 0 ${cx + rx},${cy} A${rx},${ry} 0 1 0 ${cx - rx},${cy} Z`;

// A star / heart shape centred on (cx,cy), for catch-lights and pupils.
const starPath = (cx, cy, R, r = R * 0.45) => {
  const pts = [];
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + i * Math.PI / 5, rad = i % 2 ? r : R;
    pts.push(`${(cx + rad * Math.cos(a)).toFixed(1)},${(cy + rad * Math.sin(a)).toFixed(1)}`);
  }
  return `M${pts.join(' L')} Z`;
};
const heartPath = (cx, cy, s) =>
  `M${cx},${cy + s * 0.95} C${cx - s * 1.5},${cy - s * 0.05} ${cx - s * 0.95},${cy - s * 0.95} ${cx},${cy - s * 0.35} ` +
  `C${cx + s * 0.95},${cy - s * 0.95} ${cx + s * 1.5},${cy - s * 0.05} ${cx},${cy + s * 0.95} Z`;

// The LEFT eye (centre ~148,216), cel style. `o` describes one eye:
//   opening  path of the eye opening (sclera, and the clip that keeps the iris inside)
//   iris/pupil  {cx,cy,rx,ry}     lights  catch-light markup (drawn over the pupil)
//   pupilSvg  replaces the pupil (heart pupils)     lid  markup clipped to the opening
//   lashLine / flick / lashes / crease / lower  path data for the lash and lid lines
// Layers bottom to top: sclera, iris, iris shade, limbal ring, pupil, catch-lights, lid
// shadow, then lower lash line, upper lash line, outer flick, lashes, lid crease.
const chibiEye = (id, o) => {
  CHAR_DEFS.push(`<clipPath id="eye-clip-${id}"><path d="${o.opening}"/></clipPath>`);
  const { iris: i, pupil: p } = o;
  return `
    <path d="${o.opening}" fill="#fff"/>
    <g clip-path="url(#eye-clip-${id})">
      <ellipse class="fill-eye" cx="${i.cx}" cy="${i.cy}" rx="${i.rx}" ry="${i.ry}"/>
      <ellipse cx="${i.cx}" cy="${i.cy}" rx="${i.rx}" ry="${i.ry}" fill="url(#iris-shade)"/>
      <ellipse cx="${i.cx}" cy="${i.cy}" rx="${i.rx}" ry="${i.ry}" fill="none" stroke="#000" stroke-opacity="0.28" stroke-width="2.4"/>
      ${o.pupilSvg || `<ellipse cx="${p.cx}" cy="${p.cy}" rx="${p.rx}" ry="${p.ry}" fill="#1B1224"/>`}
      ${o.lights}
      ${o.lid || `<path d="${o.lidShadow}" fill="#3a1f1a" opacity="0.16"/>`}
    </g>
    <path d="${o.lower}" fill="none" stroke="#3a2418" stroke-opacity="0.5" stroke-width="1.8" stroke-linecap="round"/>
    <path d="${o.lashLine}" fill="none" stroke="${LASH}" stroke-width="${o.lashWidth || 5.6}" stroke-linecap="round"/>
    <path d="${o.flick}" fill="${LASH}"/>
    <path d="${o.lashes}" fill="none" stroke="${LASH}" stroke-width="2.6" stroke-linecap="round"/>
    <path d="${o.crease}" fill="none" stroke="var(--skin-dk)" stroke-width="2" stroke-linecap="round" opacity="0.75"/>`;
};

// The two catch-lights every eye has unless it overrides them: a big one upper left, a
// small one lower right.
const EYE_LIGHTS = (x = 139, y = 208, x2 = 158, y2 = 236) =>
  `<ellipse cx="${x}" cy="${y}" rx="8" ry="9.5" fill="#fff"/><circle cx="${x2}" cy="${y2}" r="3.8" fill="#fff" opacity="0.92"/>`;

// The round eye is the base the other styles tweak.
const ROUND_EYE = {
  opening: ellipsePath(148, 216, 26, 28),
  iris: { cx: 148, cy: 222, rx: 22, ry: 26 },
  pupil: { cx: 148, cy: 224, rx: 10, ry: 13 },
  lights: EYE_LIGHTS(),
  lidShadow: 'M122,196 Q148,182 174,196 L174,204 Q148,194 122,204 Z',
  lower: 'M128,237 Q148,248 168,237',
  lashLine: 'M122,214 C121,196 133,188 148,188 C163,188 175,196 174,214',
  flick: 'M123,211 C116,210 110,204 105,194 C112,198 118,198 125,198 Z',
  lashes: 'M127,199 C121,195 118,189 117,183 M134,193 C130,188 129,183 129,178',
  crease: 'M126,188 Q148,174 172,186',
};

// A brow stroke (left brow; mirror() gives the pair). Colour follows the hair.
const browStroke = (d, w) =>
  `<path d="${d}" fill="none" class="stroke-brow" style="stroke-width:${w};stroke-linecap:round"/>`;

// A mouth's lip area, as a clipPath in the live <defs>. The mouth art clips its interior to
// it, and the lipstick finishes (makeup) clip their colour to the same shape. `id` is the
// mouth option id; the clip is `lip-clip-<id>`.
const lipClip = (id, d) => { CHAR_DEFS.push(`<clipPath id="lip-clip-${id}"><path d="${d}"/></clipPath>`); return d; };
const MOUTH_DARK = '#7A2338';

// ── Hair helpers ───────────────────────────────────────────────────────────
// Hair is drawn as separate masses. Each mass gets: the base colour, a hard cel shadow
// (the shape is drawn dark, then the same shape shifted up-left in the hair colour on top,
// both clipped to it, which leaves a crescent on the lower right), optional strand lines
// and one highlight, then the outline. Shapes are drawn whole (never as a mirrored half)
// so the shadow always falls on the lower right. Use flipX() to get the right-hand twin
// of a left-hand path.

// Flip a path about x=200. Paths here use absolute "x,y" pairs only.
const flipX = d => d.replace(/(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/g, (_, x, y) => `${+(400 - x).toFixed(1)},${y}`);

let hairMassId = 0;
// d      outline path of the mass
// edge   path to stroke as the outline (default: all of `d`). A front piece that overlaps
//        the back hair strokes only its inner edge, or the top of the head gets a double line.
// shine  highlight path (white, 0.4)       lines  strand lines (path data)
// flat   true = no shadow crescent (small pieces such as a hair tie knot)
const hairMass = (d, { edge = null, shine = '', lines = '', flat = false } = {}) => {
  const id = `hair-m${hairMassId++}`;
  CHAR_DEFS.push(`<clipPath id="${id}"><path d="${d}"/></clipPath>`);
  return `
    <path class="fill-hair" d="${d}"/>
    ${flat ? '' : `<g clip-path="url(#${id})"><path d="${d}" fill="#000" opacity="0.17"/><path class="fill-hair" transform="translate(-11 -7)" d="${d}"/></g>`}
    ${lines ? `<path d="${lines}" fill="none" stroke="var(--hair-dk)" stroke-opacity="0.55" stroke-width="2.4" stroke-linecap="round"/>` : ''}
    ${shine ? `<path d="${shine}" fill="#fff" opacity="0.4"/>` : ''}
    <path d="${edge || d}" fill="none" class="ol-hair"/>`;
};

// A hair tie / bobble.
const hairTie = (cx, cy, r = 9) =>
  `<circle cx="${cx}" cy="${cy}" r="${r}" fill="#FF6FA3" stroke="#C44A78" stroke-width="2.4"/>
   <circle cx="${cx - r * 0.3}" cy="${cy - r * 0.3}" r="${r * 0.28}" fill="#fff" opacity="0.6"/>`;

// A contact shadow the fringe casts on the forehead. Hidden in the option thumbnails (the
// `occlusion` class), which draw hair without a face under it.
const fringeShadow = d => `<path class="occlusion" d="${d}" fill="var(--skin-dk)" opacity="0.38"/>`;

// Points on an ellipse, joined by outward bulges (curls) or pointed tufts.
const ringPoints = (cx, cy, rx, ry, from, to, n) =>
  Array.from({ length: n + 1 }, (_, k) => {
    const a = (from + (to - from) * k / n) * Math.PI / 180;
    return [cx + rx * Math.cos(a), cy + ry * Math.sin(a), a];
  });
const f1 = v => +v.toFixed(1);
const curlyRing = (cx, cy, rx, ry, from, to, n, amp) => {
  const p = ringPoints(cx, cy, rx, ry, from, to, n);
  let d = `M${f1(p[0][0])},${f1(p[0][1])}`;
  for (let k = 1; k <= n; k++) {
    const mid = (p[k - 1][2] + p[k][2]) / 2;
    const mx = (p[k - 1][0] + p[k][0]) / 2, my = (p[k - 1][1] + p[k][1]) / 2;
    d += ` Q${f1(mx + amp * Math.cos(mid))},${f1(my + amp * Math.sin(mid))} ${f1(p[k][0])},${f1(p[k][1])}`;
  }
  return d;
};
const tuftRing = (cx, cy, rx, ry, from, to, n, len) => {
  const p = ringPoints(cx, cy, rx, ry, from, to, n);
  let d = `M${f1(p[0][0])},${f1(p[0][1])}`;
  for (let k = 1; k <= n; k++) {
    const mid = (p[k - 1][2] + p[k][2]) / 2;
    const mx = (p[k - 1][0] + p[k][0]) / 2, my = (p[k - 1][1] + p[k][1]) / 2;
    d += ` L${f1(mx + len * Math.cos(mid))},${f1(my + len * Math.sin(mid))} L${f1(p[k][0])},${f1(p[k][1])}`;
  }
  return d;
};

// Shared silhouettes. The front pieces cover the forehead; BACK pieces sit behind the face.
const FR_SWEPT = 'M74,214 C58,122 106,54 200,52 C294,54 342,122 326,214 C322,176 306,146 276,128 C254,154 222,164 184,160 C152,156 126,164 108,182 C94,194 82,204 74,214 Z';
const FR_SWEPT_EDGE = 'M326,214 C322,176 306,146 276,128 C254,154 222,164 184,160 C152,156 126,164 108,182 C94,194 82,204 74,214';
const FR_SWEPT_SHADOW = 'M276,128 C254,154 222,164 184,160 C152,156 126,164 108,182 L112,192 C128,174 152,168 184,172 C222,176 256,166 282,140 Z';
const FR_STRAIGHT = 'M74,214 C58,122 106,54 200,52 C294,54 342,122 326,214 C320,180 304,152 280,142 C256,150 228,154 200,154 C172,154 144,150 120,142 C96,152 80,180 74,214 Z';
const FR_STRAIGHT_EDGE = 'M326,214 C320,180 304,152 280,142 C256,150 228,154 200,154 C172,154 144,150 120,142 C96,152 80,180 74,214';
const FR_STRAIGHT_SHADOW = 'M280,142 C256,150 228,154 200,154 C172,154 144,150 120,142 L122,152 C144,160 172,164 200,164 C228,164 256,160 280,152 Z';
const FR_PARTED = 'M74,214 C58,122 106,54 200,52 C294,54 342,122 326,214 C320,170 290,138 252,126 C236,142 216,152 200,154 C184,152 164,142 148,126 C110,138 80,170 74,214 Z';
const FR_PARTED_EDGE = 'M326,214 C320,170 290,138 252,126 C236,142 216,152 200,154 C184,152 164,142 148,126 C110,138 80,170 74,214';
const FR_PARTED_SHADOW = 'M252,126 C236,142 216,152 200,154 C184,152 164,142 148,126 L152,136 C166,150 184,162 200,164 C216,162 234,150 248,136 Z';
const SHINE = 'M118,104 C136,80 176,68 214,70 C178,80 152,94 136,120 C128,122 122,114 118,104 Z';
const STRANDS = 'M150,122 C168,110 196,106 220,112 M230,100 C246,110 258,122 264,136 M112,150 C118,136 128,126 140,120';

const frontSwept = () => fringeShadow(FR_SWEPT_SHADOW) + hairMass(FR_SWEPT, { edge: FR_SWEPT_EDGE, shine: SHINE, lines: STRANDS });
const frontStraight = () => fringeShadow(FR_STRAIGHT_SHADOW) + hairMass(FR_STRAIGHT, { edge: FR_STRAIGHT_EDGE, shine: SHINE, lines: 'M140,112 C160,104 186,102 210,106 M236,100 C252,108 264,120 268,134' });
const frontParted = () => fringeShadow(FR_PARTED_SHADOW) + hairMass(FR_PARTED, { edge: FR_PARTED_EDGE, shine: SHINE, lines: 'M130,116 C142,108 152,114 150,126 M270,116 C258,108 248,114 250,126 M200,70 L200,150' });

const BOB_BACK = 'M66,262 C44,150 88,44 200,42 C312,44 356,150 334,262 C334,296 326,324 306,332 C292,336 284,318 282,296 L118,296 C116,318 108,336 94,332 C74,324 66,296 66,262 Z';
const CAP_BACK = 'M70,236 C54,140 100,46 200,44 C300,46 346,140 330,236 Z';
const LONG_BACK = 'M64,262 C42,150 88,44 200,42 C312,44 358,150 336,262 C342,340 342,420 326,468 Q316,482 298,476 L102,476 Q84,482 74,468 C58,420 58,340 64,262 Z';

// ── Outfit helpers ─────────────────────────────────────────────────────────
// An outfit is a stack of masses (torso, sleeves, skirt, ...), each shaded like hair: a
// hard cel shadow on the lower right, a fabric-pattern overlay, then the outline. The fabric
// pattern is chosen in the UI and arrives as the custom property --pattern (`none` or
// `url(#pat-...)`), so a pattern works on every colour, in thumbnails and in the export.
// Shapes are drawn whole, never as mirrored halves, so the shadow always falls lower right;
// use flipX() for the right-hand twin of a sleeve.

// An ellipse as four cubic curves (flipX-safe, unlike an SVG arc).
const blobPath = (cx, cy, rx, ry) => {
  const k = 0.5523;
  return `M${cx - rx},${cy} C${cx - rx},${f1(cy - k * ry)} ${f1(cx - k * rx)},${cy - ry} ${cx},${cy - ry} ` +
    `C${f1(cx + k * rx)},${cy - ry} ${cx + rx},${f1(cy - k * ry)} ${cx + rx},${cy} ` +
    `C${cx + rx},${f1(cy + k * ry)} ${f1(cx + k * rx)},${cy + ry} ${cx},${cy + ry} ` +
    `C${f1(cx - k * rx)},${cy + ry} ${cx - rx},${f1(cy + k * ry)} ${cx - rx},${cy} Z`;
};

let clothMassId = 0;
// fill/outline: a fixed colour for a part that does not follow the outfit colour (a shirt
// under overalls). flat: no shadow crescent. pattern: false keeps the fabric pattern off.
const clothMass = (d, { fill = null, outline = null, flat = false, pattern = true } = {}) => {
  const id = `cloth-m${clothMassId++}`;
  CHAR_DEFS.push(`<clipPath id="${id}"><path d="${d}"/></clipPath>`);
  const base = fill ? `fill="${fill}"` : 'class="fill-clothing"';
  const line = outline
    ? `stroke="${outline}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"`
    : 'class="ol-cloth"';
  return `
    <path ${base} d="${d}"/>
    ${flat ? '' : `<g clip-path="url(#${id})"><path d="${d}" fill="#000" opacity="0.15"/><path ${base} transform="translate(-13 -6)" d="${d}"/></g>`}
    ${pattern ? `<g clip-path="url(#${id})"><rect x="0" y="330" width="400" height="200" fill="var(--pattern)"/></g>` : ''}
    <path d="${d}" fill="none" ${line}/>`;
};

// Fabric patterns. White shapes with a thin outline in the outfit's own dark shade, so they
// read on light pastels and on dark colours alike.
CHAR_DEFS.push(
  `<pattern id="pat-dots" patternUnits="userSpaceOnUse" width="30" height="30">
     <circle cx="8" cy="8" r="5" fill="#fff" stroke="var(--clothing-dk)" stroke-width="1.2"/>
     <circle cx="23" cy="23" r="5" fill="#fff" stroke="var(--clothing-dk)" stroke-width="1.2"/>
   </pattern>`,
  `<pattern id="pat-stripes" patternUnits="userSpaceOnUse" width="22" height="22">
     <rect width="10" height="22" fill="#fff" fill-opacity="0.75"/>
   </pattern>`,
  `<pattern id="pat-stars" patternUnits="userSpaceOnUse" width="36" height="36">
     <path d="${starPath(10, 10, 8)}" fill="#fff" stroke="var(--clothing-dk)" stroke-width="1.2" stroke-linejoin="round"/>
     <path d="${starPath(28, 28, 8)}" fill="#fff" stroke="var(--clothing-dk)" stroke-width="1.2" stroke-linejoin="round"/>
   </pattern>`,
  `<pattern id="pat-hearts" patternUnits="userSpaceOnUse" width="36" height="36">
     <path d="${heartPath(10, 10, 6)}" fill="#fff" stroke="var(--clothing-dk)" stroke-width="1.2" stroke-linejoin="round"/>
     <path d="${heartPath(28, 28, 6)}" fill="#fff" stroke="var(--clothing-dk)" stroke-width="1.2" stroke-linejoin="round"/>
   </pattern>`
);

// Neckline: the skin patch showing under the collar, and the curve that outlines it.
const NECKLINES = {
  scoop: { patch: 'M170,356 Q200,392 230,356 Z', curve: 'M170,356 Q200,392 230,356', rim: 'M166,358 Q200,402 234,358' },
  crew:  { patch: 'M176,356 Q200,382 224,356 Z', curve: 'M176,356 Q200,382 224,356', rim: 'M172,357 Q200,388 228,357' },
  vneck: { patch: 'M176,356 L200,394 L224,356 Z', curve: 'M176,356 L200,394 L224,356', rim: 'M172,357 L200,400 L228,357' },
  heart: { patch: 'M170,356 C170,346 188,346 200,358 C212,346 230,346 230,356 C230,372 210,386 200,394 C190,386 170,372 170,356 Z',
           curve: 'M170,356 C170,346 188,346 200,358 C212,346 230,346 230,356 C230,372 210,386 200,394 C190,386 170,372 170,356', rim: 'M166,356 C166,342 188,342 200,356 C212,342 234,342 234,356 C234,376 212,392 200,402 C188,392 166,376 166,356' },
};
// collar: 'white' = a white trim (dress), 'rib' = a knitted rim in the outfit colour.
const neckline = (kind, collar = 'rib') => {
  const n = NECKLINES[kind];
  const rim = collar === 'white'
    ? `<path d="${n.rim}" fill="none" stroke="var(--clothing-dk)" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/>
       <path d="${n.rim}" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>`
    : `<path d="${n.rim}" fill="none" stroke="var(--clothing-dk)" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>
       <path d="${n.rim}" fill="none" class="fill-clothing" style="stroke:var(--clothing);stroke-width:4.5;stroke-linecap:round;stroke-linejoin:round;fill:none"/>`;
  return `<path class="fill-skin" d="${n.patch}"/><path d="${n.curve}" fill="none" class="ol-skin"/>${rim}`;
};

const TORSO = 'M104,520 C104,440 116,384 168,356 L232,356 C284,384 296,440 296,520 Z';
const SLEEVE_SHORT = 'M124,372 C104,376 88,392 82,424 L116,438 C120,416 130,402 146,394 Z';
const SLEEVE_LONG = 'M126,372 C100,380 84,420 78,470 L76,520 L114,520 C114,470 124,424 146,394 Z';
const SLEEVE_WIDE = 'M126,372 C96,386 68,430 54,520 L124,520 C126,468 130,424 146,394 Z';
const PUFF = blobPath(114, 402, 30, 27);
const PUFF_BIG = blobPath(108, 398, 35, 31);
const pair = (leftD, opts) => clothMass(leftD, opts) + clothMass(flipX(leftD), opts);
const bowShape = (cx, cy, s = 1, fill = '#fff') =>
  `<g transform="translate(${cx} ${cy}) scale(${s})"><path d="M0,0 C-12,-12 -26,-8 -24,2 C-22,12 -10,10 0,0 Z M0,0 C12,-12 26,-8 24,2 C22,12 10,10 0,0 Z" fill="${fill}" stroke="var(--clothing-dk)" stroke-width="2.5" stroke-linejoin="round"/><circle r="5" fill="${fill}" stroke="var(--clothing-dk)" stroke-width="2.5"/></g>`;
const button = (x, y, r = 4.5) =>
  `<circle cx="${x}" cy="${y}" r="${r}" fill="#F5C542" stroke="#B8860B" stroke-width="2"/>`;
const scallops = (x0, x1, y, n, up = 12) => {
  const w = (x1 - x0) / n;
  let d = `M${x0},${y}`;
  for (let k = 0; k < n; k++) d += ` Q${f1(x0 + w * (k + 0.5))},${y - up} ${f1(x0 + w * (k + 1))},${y}`;
  return d;
};

// ── Accessory helpers ──────────────────────────────────────────────────────
// Accessories are one layer above everything else. Each piece gets the same cel treatment as
// hair and clothes: a fill, a hard shadow crescent, an optional highlight, then an outline in a
// darker shade. `fill`/`stroke` are CSS colours (they may be var(--hair) and friends).
let accMassId = 0;
const accMass = (d, fill, stroke, { shine = '', flat = false, w = 3 } = {}) => {
  const id = `acc-m${accMassId++}`;
  CHAR_DEFS.push(`<clipPath id="${id}"><path d="${d}"/></clipPath>`);
  return `
    <path d="${d}" fill="${fill}"/>
    ${flat ? '' : `<g clip-path="url(#${id})"><path d="${d}" fill="#000" opacity="0.15"/><path d="${d}" fill="${fill}" transform="translate(-6 -4)"/></g>`}
    ${shine ? `<path d="${shine}" fill="#fff" opacity="0.45"/>` : ''}
    <path d="${d}" fill="none" stroke="${stroke}" stroke-width="${w}" stroke-linejoin="round" stroke-linecap="round"/>`;
};
// A thick line drawn twice: a wider dark pass under a narrower coloured one (a wand, a band).
const thickLine = (d, dark, col, wDark, wCol) =>
  `<path d="${d}" fill="none" stroke="${dark}" stroke-width="${wDark}" stroke-linecap="round" stroke-linejoin="round"/>` +
  `<path d="${d}" fill="none" stroke="${col}" stroke-width="${wCol}" stroke-linecap="round" stroke-linejoin="round"/>`;
const sparkle = (x, y, r, fill = '#FFD54A') => `<path d="${starPath(x, y, r, r * 0.4)}" fill="${fill}" opacity="0.95"/>`;
const flower = (cx, cy, r, petal) => {
  const petals = Array.from({ length: 5 }, (_, k) => {
    const a = k * 72 * Math.PI / 180 - Math.PI / 2;
    return `<circle cx="${f1(cx + r * 1.05 * Math.cos(a))}" cy="${f1(cy + r * 1.05 * Math.sin(a))}" r="${f1(r * 0.78)}" fill="${petal}" stroke="rgba(120,50,90,0.45)" stroke-width="1.6"/>`;
  }).join('');
  return petals + `<circle cx="${cx}" cy="${cy}" r="${f1(r * 0.6)}" fill="#FFC93C" stroke="rgba(150,90,20,0.6)" stroke-width="1.6"/>`;
};
const butterfly = (cx, cy, s, c1, c2) => {
  const wings = `<path d="M0,0 C-20,-24 -36,-8 -26,8 C-18,16 -4,8 0,0 Z" fill="${c1}" stroke="rgba(60,30,80,0.55)" stroke-width="2"/>
    <path d="M0,0 C-14,14 -24,28 -13,32 C-4,32 0,14 0,0 Z" fill="${c2}" stroke="rgba(60,30,80,0.55)" stroke-width="2"/>
    <circle cx="-16" cy="-4" r="4" fill="#fff" opacity="0.6"/>`;
  return `<g transform="translate(${cx} ${cy}) scale(${s})">${wings}<g transform="scale(-1 1)">${wings}</g>
    <rect x="-2.2" y="-12" width="4.4" height="26" rx="2.2" fill="#4a2f5e"/><path d="M-1,-12 Q-6,-22 -10,-22 M1,-12 Q6,-22 10,-22" fill="none" stroke="#4a2f5e" stroke-width="1.8" stroke-linecap="round"/></g>`;
};
const GOLD = '#FFD54A', GOLD_DK = '#B8860B';
const HEAD_THUMB = '30 0 340 300';   // thumbnail box for things worn on the head
// Frames for the two eye-glass styles (eyes are at (148,216) and (252,216)).
const glassTemples = col => `<path d="M118,212 L90,208 M282,212 L310,208" fill="none" stroke="${col}" stroke-width="4" stroke-linecap="round"/>`;

// ── Makeup helpers ─────────────────────────────────────────────────────────
// A mouth with a coloured lip rim: `outer` is the lips' outside edge, `inner` the mouth opening.
// Registers two clips: `lip-clip-<id>` is the rim only (outer minus inner, even-odd), which the
// lipstick finishes paint inside; `lip-in-<id>` is the opening, which keeps teeth and tongue
// inside the mouth. Returns both paths.
const lipRing = (id, outer, inner, withInner = true) => {
  CHAR_DEFS.push(`<clipPath id="lip-clip-${id}"><path clip-rule="evenodd" d="${outer} ${inner}"/></clipPath>`);
  if (withInner) CHAR_DEFS.push(`<clipPath id="lip-in-${id}"><path d="${inner}"/></clipPath>`);
  return { outer, inner };
};

CHAR_DEFS.push(
  // Soft eyeshadow: a fading pool of the chosen colour.
  `<radialGradient id="shadow-soft" cx="50%" cy="55%" r="50%">
     <stop offset="0" stop-color="var(--shadow)" stop-opacity="0.9"/>
     <stop offset="0.6" stop-color="var(--shadow)" stop-opacity="0.6"/>
     <stop offset="1" stop-color="var(--shadow)" stop-opacity="0"/>
   </radialGradient>`,
  // Glitter: tiny white and gold sparkles, tiled.
  `<pattern id="pat-glitter" patternUnits="userSpaceOnUse" width="16" height="16">
     <circle cx="3" cy="4" r="1.3" fill="#fff"/><circle cx="11" cy="9" r="1.1" fill="#FFE27A"/>
     <circle cx="6" cy="13" r="1.4" fill="#fff"/><circle cx="14" cy="2" r="0.9" fill="#FFE27A"/>
     <path d="M9,3 l0.8,1.8 1.8,0.8 -1.8,0.8 -0.8,1.8 -0.8,-1.8 -1.8,-0.8 1.8,-0.8 z" fill="#fff"/>
   </pattern>`,
  // Lipstick ombre: darker at the top of the lips fading to lighter at the bottom.
  `<linearGradient id="lip-ombre" gradientUnits="userSpaceOnUse" x1="0" y1="280" x2="0" y2="322">
     <stop offset="0" stop-color="#000" stop-opacity="0.22"/><stop offset="0.5" stop-color="#000" stop-opacity="0"/>
     <stop offset="1" stop-color="#fff" stop-opacity="0.5"/>
   </linearGradient>`
);

// Eyeshadow shapes, for the LEFT eye (eyes are at y~216); mirror() gives the pair.
const SHADOW_LID = 'M117,206 C116,182 132,169 150,169 C168,169 181,182 180,206 C170,191 128,191 117,206 Z';
const shadowLid = fill => `<path d="${SHADOW_LID}" fill="${fill}"/>`;
// A plain eye (sclera + upper lash line), so an eyeshadow thumbnail has something to sit on.
const eyeContext = () => mirror(`<path d="${ROUND_EYE.opening}" fill="#fff"/><path d="${ROUND_EYE.lashLine}" fill="none" stroke="${LASH}" stroke-width="5.6" stroke-linecap="round"/>`);

// A lipstick finish, clipped to the current mouth's lip area. `mouthId` is state.mouth.
const lipFinish = (mouthId, inner) =>
  `<g clip-path="url(#lip-clip-${mouthId})">${inner}</g>`;
const LIP_BOX = '<rect x="160" y="270" width="80" height="60"';
// The lips as a filled shape (for a lipstick thumbnail, which has no mouth layer under it).
const lipThumb = mouthId => {
  const m = CHAR.slots.mouth.options.find(o => o.id === mouthId) || CHAR.slots.mouth.options[0];
  return m.svg;
};

// ── Scene helpers ──────────────────────────────────────────────────────────
// Backgrounds are inline SVG (an exported PNG cannot load external images). They are drawn
// well past the 400x520 canvas, because the tilt parallax shifts and scales this layer a little.
const BG = 'x="-40" y="-40" width="480" height="600"';
const cloud = (x, y, s = 1, fill = '#fff', op = 0.92) =>
  `<g transform="translate(${x} ${y}) scale(${s})" fill="${fill}" opacity="${op}"><ellipse cx="0" cy="0" rx="34" ry="16"/><circle cx="-14" cy="-10" r="14"/><circle cx="8" cy="-16" r="18"/><circle cx="24" cy="-6" r="12"/></g>`;
// A deterministic scatter (so a scene looks the same every time it is drawn).
const scatter = (n, seed, fn) => {
  let s = seed;
  const rnd = () => ((s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296);
  return Array.from({ length: n }, (_, k) => fn(rnd, k)).join('');
};
const lollipop = (x, y, r, c1, c2) =>
  `<path d="M${x},${y + r} L${x},${y + r + 90}" stroke="#fff" stroke-width="7" stroke-linecap="round"/><path d="M${x},${y + r} L${x},${y + r + 90}" stroke="#E9DDF0" stroke-width="2" stroke-linecap="round" stroke-dasharray="1 9" opacity="0.8"/>
   <circle cx="${x}" cy="${y}" r="${r}" fill="${c1}" stroke="rgba(120,60,100,0.35)" stroke-width="2.5"/>
   <path d="M${x},${y} m0,-${r * 0.12} a${r * 0.12},${r * 0.12} 0 1 1 ${r * 0.12},${r * 0.12} a${r * 0.3},${r * 0.3} 0 1 1 -${r * 0.3},-${r * 0.3} a${r * 0.5},${r * 0.5} 0 1 1 ${r * 0.5},${r * 0.5} a${r * 0.7},${r * 0.7} 0 1 1 -${r * 0.7},-${r * 0.7}" fill="none" stroke="${c2}" stroke-width="${r * 0.14}" stroke-linecap="round"/>
   <path d="M${x - r * 0.6},${y - r * 0.4} Q${x - r * 0.4},${y - r * 0.7} ${x - r * 0.05},${y - r * 0.78}" fill="none" stroke="#fff" stroke-opacity="0.6" stroke-width="3" stroke-linecap="round"/>`;

const CHAR = {

  // Fabric patterns for the Outfit tab (the art for each is in CHAR_DEFS as `pat-<id>`).
  patterns: [
    { id: 'none', label: 'Plain' }, { id: 'dots', label: 'Dots' }, { id: 'stripes', label: 'Stripes' },
    { id: 'stars', label: 'Stars' }, { id: 'hearts', label: 'Hearts' },
  ],

  // ── Color palettes ────────────────────────────────────────────────────────
  colors: {
    skin: [
      { light: '#FFE0BD', dark: '#D4A474' },
      { light: '#F5C89A', dark: '#C4905A' },
      { light: '#E0AC69', dark: '#B07840' },
      { light: '#C68642', dark: '#9A5E20' },
      { light: '#8D5524', dark: '#6B3A0F' },
      { light: '#4A2912', dark: '#2E1508' },
      { light: '#FBD5C8', dark: '#D79A8A' },
      { light: '#B5754D', dark: '#8A4F2C' },
    ],
    eye:      ['#5B8ED6','#4A9E5C','#8B6914','#7B5EA7','#3D8A84','#888888','#9B5DE5','#F15BB5','#E9A23B','#7FD1F2'],
    hair:     ['#111111','#5C3317','#C68642','#DEB887','#F5DEB3','#E8393A','#E070C0','#7B4FBB',
              '#FFB3D1','#C9A7F5','#8FE3C4','#8CC8FF','#FFB38A','#CFD3DC',
              // Rainbow: `fill` is what the art paints with, `solid` feeds outlines and brows,
              // `css` is the swatch background.
              { fill: 'url(#hair-rainbow)', solid: '#C45BD6',
                css: 'linear-gradient(180deg,#FF5E5E,#FFA94D,#FFE14D,#6BD66B,#4DB8FF,#B46BFF)' }],
    lip:      ['#FFB6C1','#FF8DA1','#E74C5E','#C23B5C','#FF8C69','#DDA0DD'],
    // Makeup palettes. `shadow` is the eyeshadow colour, `blush` colours the cheek blush
    // and the heart/star cheek stickers. (`lip` above colours the lips.)
    shadow:   ['#FF8DB8','#E0507A','#FFB38A','#F5C542','#6BD66B','#3DC9B8','#4DA3FF','#9B5DE5','#C9A7F5','#3B4B8C'],
    blush:    ['#FF6F93','#FF9E7A','#FF7A7A','#E0507A','#C9A7F5'],
    clothing: ['#FF9999','#99CCFF','#99EE99','#FFCC99','#CC99FF','#FF99CC','#99EEFF','#FFEE99',
               '#111827','#740001','#1a472a','#0e1a40','#ecb939','#708090'],
  },

  // ── Slot definitions ──────────────────────────────────────────────────────
  slots: {

    // ── FACE ──────────────────────────────────────────────────────────────
    // Cel style: skin base, then a hard-edged shadow crescent down the lower right,
    // then an outline. The crescent is the face drawn in `--skin-dk`, with the same
    // face drawn again (shifted up-left, in skin colour) on top, both clipped to the
    // face. What is left visible is the crescent. The clipPath lives inside the
    // option (an id in an option string is remapped for thumbnails by buildThumb).
    face: {
      label: '😊 Face',
      colorSlot: 'skin',
      colorLabel: 'Skin tone',
      layerIds: ['face'],
      thumbViewBox: '60 66 280 276',
      options: [
        { id: 'oval',  label: 'Oval',  svg: faceArt('oval',  "M200,80 C262,80 316,118 318,190 C320,252 288,318 200,328 C112,318 80,252 82,190 C84,118 138,80 200,80 Z", 82) },
        { id: 'round', label: 'Round', svg: faceArt('round', "M200,88 C268,88 322,126 324,196 C326,256 290,316 200,324 C110,316 74,256 76,196 C78,126 132,88 200,88 Z", 76) },
        { id: 'heart', label: 'Heart', svg: faceArt('heart', "M200,80 C266,80 318,116 318,184 C318,236 282,290 224,322 C212,328 206,330 200,330 C194,330 188,328 176,322 C118,290 82,236 82,184 C82,116 134,80 200,80 Z", 84) },
        { id: 'wide',  label: 'Wide',  svg: faceArt('wide',  "M200,90 C272,90 326,124 326,194 C326,256 286,318 200,326 C114,318 74,256 74,194 C74,124 128,90 200,90 Z", 74) },
      ]
    },

    // ── EYES ──────────────────────────────────────────────────────────────
    // Big, glossy chibi eyes. Each option is the LEFT eye (centre ~148,216) built by
    // chibiEye(), with a mirrored copy as the right eye. The eyes are the most
    // important part of the style: see ART_DIRECTION.md.
    // Exception: 'wink' = closed left eye + the mirrored open right eye.
    eyes: {
      label: '👁️ Eyes',
      colorSlot: 'eye',
      colorLabel: 'Eye colour',
      layerIds: ['eyes', 'eyeshadow'],   // the eyeshadow layer is moved and scaled with the eyes
      thumbViewBox: '92 168 216 88',
      options: [
        {
          id: 'round', label: 'Round',
          svg: mirror(chibiEye('round', ROUND_EYE))
        },
        {
          id: 'almond', label: 'Almond',
          svg: mirror(chibiEye('almond', {
            ...ROUND_EYE,
            opening: 'M119,208 C125,194 137,189 152,189 C167,189 178,200 179,216 C179,232 166,243 149,243 C134,243 121,231 119,208 Z',
            iris: { cx: 149, cy: 220, rx: 20, ry: 24 },
            pupil: { cx: 149, cy: 222, rx: 9, ry: 12 },
            lights: EYE_LIGHTS(141, 207, 158, 234),
            lashLine: 'M118,210 C123,194 137,188 152,188 C168,188 178,199 179,214',
            flick: 'M119,207 C111,206 105,199 100,189 C108,193 115,194 122,194 Z',
            lashes: 'M125,198 C119,193 116,187 115,181 M133,192 C129,187 128,181 128,176',
            lower: 'M128,238 Q149,248 170,237',
            crease: 'M124,188 Q148,172 174,186',
          }))
        },
        {
          id: 'sparkle', label: 'Bright',
          svg: mirror(chibiEye('sparkle', {
            ...ROUND_EYE,
            opening: ellipsePath(148, 215, 26, 30),
            iris: { cx: 148, cy: 222, rx: 23, ry: 28 },
            pupil: { cx: 148, cy: 225, rx: 10, ry: 14 },
            // Three catch-lights plus a four-point star.
            lights: EYE_LIGHTS(138, 205, 159, 237) +
              `<circle cx="152" cy="227" r="2.4" fill="#fff" opacity="0.9"/>
               <path d="M160,207 l2.2,5 5,2.2 -5,2.2 -2.2,5 -2.2,-5 -5,-2.2 5,-2.2 z" fill="#fff"/>`,
            lashLine: 'M122,213 C121,194 133,186 148,186 C163,186 175,194 174,213',
            flick: 'M123,210 C115,209 109,202 104,191 C112,196 118,196 125,197 Z',
            lashes: 'M127,197 C121,193 118,187 117,180 M135,191 C131,186 130,180 130,175 M162,190 C164,185 168,181 172,179',
            lower: 'M128,238 Q148,250 168,238',
            crease: 'M126,185 Q148,171 172,183',
          }))
        },
        {
          id: 'sleepy', label: 'Sleepy',
          svg: mirror(chibiEye('sleepy', {
            ...ROUND_EYE,
            opening: ellipsePath(148, 224, 26, 21),
            iris: { cx: 148, cy: 226, rx: 20, ry: 20 },
            pupil: { cx: 148, cy: 227, rx: 9, ry: 10 },
            lights: EYE_LIGHTS(141, 220, 156, 234).replace('rx="8" ry="9.5"', 'rx="6" ry="7"').replace('r="3.8"', 'r="3"'),
            // Heavy upper lid: skin-coloured, drawn over the top of the eye.
            lid: `<path class="fill-skin" d="M118,196 L178,196 L178,213 Q148,205 118,213 Z"/>
                  <path d="M118,208 Q148,201 178,208 L178,213 Q148,205 118,213 Z" fill="#000" opacity="0.1"/>`,
            lashLine: 'M121,215 Q148,204 175,215',
            flick: 'M121,214 C114,215 108,213 103,207 C110,210 116,211 123,211 Z',
            lashes: 'M127,209 C121,208 117,204 115,199',
            lower: 'M130,241 Q148,248 166,241',
            crease: 'M122,203 Q148,190 174,203',
          }))
        },
        {
          id: 'wink', label: 'Wink',
          // Closed left eye (a happy upward curve with lashes) + the open round right eye.
          svg: `
            <path d="M121,221 Q148,194 175,221" fill="none" stroke="${LASH}" stroke-width="5.6" stroke-linecap="round"/>
            <path d="M122,218 C115,217 109,211 105,201 C112,205 118,206 124,206 Z" fill="${LASH}"/>
            <path d="M128,207 C122,203 119,197 118,191 M136,200 C132,195 131,189 131,184" fill="none" stroke="${LASH}" stroke-width="2.6" stroke-linecap="round"/>
            <path d="M128,199 Q148,182 170,200" fill="none" stroke="var(--skin-dk)" stroke-width="2" stroke-linecap="round" opacity="0.6"/>
            <g transform="translate(400,0) scale(-1,1)">${chibiEye('wink', ROUND_EYE)}</g>`
        },
        {
          id: 'starry', label: 'Starry',
          svg: mirror(chibiEye('starry', {
            ...ROUND_EYE,
            // A star for the big catch-light, a smaller one lower right.
            lights: `<path d="${starPath(139, 208, 10)}" fill="#fff"/><path d="${starPath(158, 236, 5)}" fill="#fff" opacity="0.92"/>`,
          }))
        },
        {
          id: 'hearts', label: 'Hearts',
          svg: mirror(chibiEye('hearts', {
            ...ROUND_EYE,
            pupilSvg: `<path d="${heartPath(148, 224, 11)}" fill="#E63E78"/>`,
            lights: `<ellipse cx="141" cy="209" rx="6" ry="7" fill="#fff"/><circle cx="158" cy="236" r="3.4" fill="#fff" opacity="0.92"/>`,
          }))
        },
        {
          id: 'glam', label: 'Glam',
          svg: mirror(chibiEye('glam', {
            ...ROUND_EYE,
            lashWidth: 6.4,
            flick: 'M123,211 C114,211 107,203 101,191 C110,196 118,197 125,198 Z',
            lashes: 'M126,200 C119,196 115,190 113,182 M133,194 C128,189 126,182 126,175 M141,190 C138,184 138,178 140,172 M151,188 C151,182 153,177 157,173 M162,189 C165,184 169,180 174,178',
          }))
        },
      ]
    },

    // ── EYESHADOW ─────────────────────────────────────────────────────────
    // Colour on the upper lid, drawn just under the eyes (so the lashes stay on top) and moved
    // and scaled with them. Works with every eye style. Colour comes from `--shadow`.
    eyeshadow: {
      label: '🦋 Shadow',
      colorSlot: 'shadow',
      colorLabel: 'Eyeshadow colour',
      transformsAs: 'eyes',
      layerIds: [],
      thumbViewBox: '92 160 216 96',
      options: [
        { id: 'none', label: 'None', svg: ``, thumbSvg: () => eyeContext() },
        (() => { const s = mirror(`<ellipse cx="148" cy="188" rx="38" ry="23" fill="url(#shadow-soft)"/>`);
          return { id: 'soft', label: 'Soft', svg: s, thumbSvg: () => eyeContext() + s }; })(),
        (() => { const s = mirror(shadowLid('var(--shadow)').replace('/>', ' opacity="0.85"/>') +
            `<path d="M117,204 C108,204 98,196 90,184 C102,190 112,192 122,192 Z" fill="var(--shadow)"/>`);
          return { id: 'catwing', label: 'Cat Wing', svg: s, thumbSvg: () => eyeContext() + s }; })(),
        (() => { const s = mirror(`<ellipse cx="148" cy="190" rx="41" ry="27" fill="url(#shadow-soft)"/><ellipse cx="148" cy="244" rx="26" ry="7" fill="var(--shadow)" opacity="0.45"/>`);
          return { id: 'smoky', label: 'Smoky', svg: s, thumbSvg: () => eyeContext() + s }; })(),
        (() => { const s = mirror(
            `<path d="M117,206 C116,178 132,164 150,164 C168,164 181,178 180,206 C170,196 128,196 117,206 Z" fill="#FF8DB8"/>
             <path d="M117,206 C116,182 132,170 150,170 C168,170 181,182 180,206 C170,196 128,196 117,206 Z" fill="#FFE14D"/>
             <path d="M117,206 C116,186 132,176 150,176 C168,176 181,186 180,206 C170,196 128,196 117,206 Z" fill="#7FD1F2"/>`);
          return { id: 'rainbow', label: 'Rainbow', svg: s, thumbSvg: () => eyeContext() + s }; })(),
        (() => { const s = mirror(shadowLid('var(--shadow)').replace('/>', ' opacity="0.7"/>') + `<path d="${SHADOW_LID}" fill="url(#pat-glitter)"/>`);
          return { id: 'glitter', label: 'Glitter', svg: s, thumbSvg: () => eyeContext() + s }; })(),
      ]
    },

    // ── EYEBROWS ──────────────────────────────────────────────────────────
    // Simple round-capped strokes above the eyes (eye top is y~188, lashes reach ~175).
    // Each is the LEFT brow, mirrored for the right.
    brows: {
      label: '🙂 Brows',
      colorSlot: null,
      layerIds: ['brows'],
      thumbViewBox: '100 146 200 40',
      options: [
        { id: 'arched', label: 'Arched', svg: mirror(browStroke('M124,172 Q146,160 172,168', 5)) },
        { id: 'flat',   label: 'Flat',   svg: mirror(browStroke('M124,168 Q148,165 172,167', 5.5)) },
        { id: 'thin',   label: 'Thin',   svg: mirror(browStroke('M124,171 Q147,161 172,167', 3)) },
        { id: 'bushy',  label: 'Bushy',  svg: mirror(browStroke('M123,172 Q146,160 172,167', 8.5)) },
        { id: 'raised', label: 'Raised', svg: mirror(browStroke('M126,167 Q148,149 172,161', 5)) },
      ]
    },

    // ── NOSE ──────────────────────────────────────────────────────────────
    // The genre keeps the nose tiny: a tick, two dots, a short line, or a kitty nose.
    nose: {
      label: '👃 Nose',
      colorSlot: null,
      layerIds: ['nose'],
      thumbViewBox: '170 236 60 44',
      options: [
        {
          id: 'dot', label: 'Soft',
          svg: `<path d="M195,257 Q200,262 205,257" fill="none" stroke="var(--skin-dk)" stroke-width="2.6" stroke-linecap="round"/>`
        },
        {
          id: 'button', label: 'Button',
          svg: `<circle cx="195" cy="258" r="2" fill="var(--skin-dk)" opacity="0.85"/>
                <circle cx="205" cy="258" r="2" fill="var(--skin-dk)" opacity="0.85"/>
                <ellipse cx="200" cy="253" rx="3" ry="2" fill="#fff" opacity="0.45"/>`
        },
        {
          id: 'lines', label: 'Defined',
          svg: `<path d="M199,246 Q197,256 194,259 Q200,263 206,259" fill="none" stroke="var(--skin-dk)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>`
        },
        {
          id: 'kitty', label: 'Kitty',
          svg: `<path d="M192,254 Q200,250 208,254 Q205,263 200,264 Q195,263 192,254 Z" fill="#FF8DA1" stroke="#C2586F" stroke-width="2" stroke-linejoin="round"/>
                <ellipse cx="198" cy="255" rx="2.2" ry="1.3" fill="#fff" opacity="0.6"/>`
        },
      ]
    },

    // ── MOUTH ─────────────────────────────────────────────────────────────
    // Small and expressive. Every option defines `lipPath` (the lip area as one path, also
    // registered as the clipPath `lip-clip-<id>`) for the lipstick finishes to reuse.
    // Mouth centre (200,295). Outline is --lip-dk (class ol-lip); the mouth interior is dark.
    mouth: {
      label: '👄 Mouth',
      colorSlot: null,
      layerIds: ['mouth', 'lipstick'],   // the lipstick layer is moved and scaled with the mouth
      thumbViewBox: '150 266 100 62',
      options: [
        (() => {
          const { outer, inner } = lipRing('bigsmile', 'M176,283 Q200,290 224,283 Q220,309 200,310 Q180,309 176,283 Z', 'M181,287 Q200,293 219,287 Q216,304 200,305 Q184,304 181,287 Z');
          return { id: 'bigsmile', label: 'Big Smile', lipPath: outer + ' ' + inner, svg: `
            <path class="fill-lip" d="${outer}"/>
            <path d="${inner}" fill="${MOUTH_DARK}"/>
            <g clip-path="url(#lip-in-bigsmile)">
              <ellipse class="fill-lip" cx="200" cy="306" rx="12" ry="8"/>
              <path d="M181,287 Q200,293 219,287 L219,294 Q200,300 181,294 Z" fill="#fff"/>
            </g>
            <path d="${outer}" fill="none" class="ol-lip"/>
            <path d="M172,281 Q176,283 177,287 M228,281 Q224,283 223,287" fill="none" class="ol-lip" style="stroke-width:2.2"/>` };
        })(),
        (() => {
          const d = lipClip('smile', 'M178,289 Q200,307 222,289 Q200,298 178,289 Z');
          return { id: 'smile', label: 'Smile', lipPath: d, svg: `
            <path class="fill-lip ol-lip" d="${d}"/>
            <path d="M174,287 Q177,288 178,291 M226,287 Q223,288 222,291" fill="none" class="ol-lip" style="stroke-width:2.2"/>` };
        })(),
        (() => {
          const { outer, inner } = lipRing('grin', 'M170,284 Q200,292 230,284 Q228,305 200,306 Q172,305 170,284 Z', 'M175,288 Q200,295 225,288 Q223,301 200,302 Q177,301 175,288 Z');
          return { id: 'grin', label: 'Grin', lipPath: outer + ' ' + inner, svg: `
            <path class="fill-lip" d="${outer}"/>
            <path d="${inner}" fill="${MOUTH_DARK}"/>
            <g clip-path="url(#lip-in-grin)">
              <path d="M175,286 Q200,294 225,286 L225,295 Q200,299 175,295 Z" fill="#fff"/>
              <path d="M175,296 Q200,300 225,296 L225,304 L175,304 Z" fill="#fff"/>
              <path d="M176,295.5 Q200,299.5 224,295.5" fill="none" stroke="#C9A9B0" stroke-width="1.6"/>
            </g>
            <path d="${outer}" fill="none" class="ol-lip"/>` };
        })(),
        (() => {
          const d = lipClip('pout', 'M184,294 Q192,286 200,291 Q208,286 216,294 Q208,305 200,306 Q192,305 184,294 Z');
          return { id: 'pout', label: 'Pout', lipPath: d, svg: `
            <path class="fill-lip ol-lip" d="${d}"/>
            <path d="M185,294 Q200,299 215,294" fill="none" class="ol-lip" style="stroke-width:2"/>
            <ellipse cx="195" cy="301" rx="5" ry="2" fill="#fff" opacity="0.5"/>` };
        })(),
        (() => {
          const d = lipClip('cat', 'M180,288 Q190,302 200,292 Q210,302 220,288 Q210,308 200,298 Q190,308 180,288 Z');
          return { id: 'cat', label: 'Cat', lipPath: d, svg: `<path class="fill-lip ol-lip" d="${d}"/>` };
        })(),
        (() => {
          const { outer, inner } = lipRing('tongue', 'M178,284 Q200,290 222,284 Q220,303 200,304 Q180,303 178,284 Z', 'M183,288 Q200,293 217,288 Q215,299 200,300 Q185,299 183,288 Z');
          return { id: 'tongue', label: 'Tongue', lipPath: outer + ' ' + inner, svg: `
            <path class="fill-lip" d="${outer}"/>
            <path d="${inner}" fill="${MOUTH_DARK}"/>
            <g clip-path="url(#lip-in-tongue)"><path d="M183,288 Q200,293 217,288 L217,294 Q200,299 183,294 Z" fill="#fff"/></g>
            <path d="${outer}" fill="none" class="ol-lip"/>
            <path class="fill-lip ol-lip" d="M189,299 Q188,320 200,320 Q212,320 211,299 Z"/>
            <path d="M200,302 L200,313" fill="none" class="ol-lip" style="stroke-width:1.8"/>` };
        })(),
        (() => {
          const outer = ellipsePath(200, 298, 12, 15), inner = ellipsePath(200, 299, 7.5, 10.5);
          lipRing('surprised', outer, inner, false);
          return { id: 'surprised', label: 'Oh!', lipPath: outer + ' ' + inner, svg: `
            <path class="fill-lip ol-lip" d="${outer}"/>
            <path d="${inner}" fill="${MOUTH_DARK}"/>
            <ellipse class="fill-lip" cx="200" cy="304" rx="5" ry="3.2"/>` };
        })(),
      ]
    },

    // ── LIPSTICK ──────────────────────────────────────────────────────────
    // The lip colour lives here. Finishes (gloss, glitter, ombre) are painted over the lip area of
    // whichever mouth is selected (clipped to `lip-clip-<mouth>`), so the layer is re-rendered
    // when the mouth changes (see applyOption). It moves and scales with the mouth.
    lipstick: {
      label: '💄 Lipstick',
      colorSlot: 'lip',
      colorLabel: 'Lip colour',
      transformsAs: 'mouth',
      layerIds: [],
      thumbViewBox: '152 268 96 60',
      options: [
        { id: 'natural', label: 'Natural', svg: () => ``, thumbSvg: s => lipThumb(s.mouth) },
        { id: 'gloss', label: 'Gloss',
          svg: s => lipFinish(s.mouth, `<path d="M172,304 L228,282 L228,290 L172,312 Z" fill="#fff" opacity="0.5"/><circle cx="188" cy="296" r="2.6" fill="#fff" opacity="0.85"/><circle cx="214" cy="291" r="2" fill="#fff" opacity="0.85"/>`),
          thumbSvg: s => lipThumb(s.mouth) + CHAR.slots.lipstick.options[1].svg(s) },
        { id: 'glitter', label: 'Glitter',
          svg: s => lipFinish(s.mouth, `${LIP_BOX} fill="url(#pat-glitter)"/>`),
          thumbSvg: s => lipThumb(s.mouth) + CHAR.slots.lipstick.options[2].svg(s) },
        { id: 'ombre', label: 'Ombre',
          svg: s => lipFinish(s.mouth, `${LIP_BOX} fill="url(#lip-ombre)"/>`),
          thumbSvg: s => lipThumb(s.mouth) + CHAR.slots.lipstick.options[3].svg(s) },
      ]
    },

    // ── CHEEKS ────────────────────────────────────────────────────────────
    // On the cheekbone at (122,264) / (278,264). The blush gradient reaches zero alpha
    // before any face edge, so it needs no clip and cannot spill onto the backdrop,
    // whichever face shape is selected. Stickers (hearts, stars) stay inside all faces.
    cheeks: {
      label: '🌸 Cheeks',
      colorSlot: 'blush',
      colorLabel: 'Blush colour',
      layerIds: ['cheeks'],
      thumbViewBox: '92 238 216 54',
      options: [
        { id: 'none', label: 'None', svg: `` },
        {
          id: 'round', label: 'Blush',
          svg: mirror(`
            <ellipse cx="122" cy="264" rx="26" ry="15" fill="url(#blush-soft)"/>
            <path d="M110,262 l5,-6 M118,265 l5,-6 M126,266 l5,-6" fill="none" stroke="#fff" stroke-opacity="0.55" stroke-width="2" stroke-linecap="round"/>`)
        },
        {
          id: 'hearts', label: 'Hearts',
          svg: mirror(`<path d="${heartPath(120, 263, 8)}" fill="var(--blush)" opacity="0.9"/>
                       <path d="${heartPath(135, 271, 5)}" fill="var(--blush)" opacity="0.9"/>`)
        },
        {
          id: 'stars', label: 'Stars',
          svg: mirror(`<path d="${starPath(120, 263, 10)}" fill="var(--blush)" opacity="0.95"/>
                       <path d="${starPath(135, 271, 5)}" fill="var(--blush)" opacity="0.95"/>`)
        },
      ]
    },

    // ── HAIR ──────────────────────────────────────────────────────────────
    // `svgBack` sits behind the face (and behind the neck and clothing), `svgFront` sits over
    // the forehead but under the eyes. See the hair helpers above for how a mass is shaded.
    hair: {
      label: '💇‍♀️ Hair',
      colorSlot: 'hair',
      colorLabel: 'Hair colour',
      layerIds: ['hair-back', 'hair-front'],
      thumbViewBox: '20 20 360 340',
      options: [
        {
          id: 'bob', label: 'Bob',
          svgBack: hairMass(BOB_BACK),
          svgFront: frontSwept()
        },
        {
          id: 'long', label: 'Long',
          svgBack: hairMass(LONG_BACK),
          svgFront: frontSwept()
        },
        {
          id: 'pigtails', label: 'Pigtails',
          svgBack: (() => {
            const tail = 'M88,186 C58,192 34,246 40,316 C44,346 80,350 86,322 C94,282 100,236 104,204 Z';
            return hairMass(tail, { lines: 'M70,220 C60,250 58,284 62,316' }) + hairMass(flipX(tail), { lines: flipX('M70,220 C60,250 58,284 62,316') }) +
                   hairMass(CAP_BACK);
          })(),
          svgFront: frontStraight() + hairTie(84, 192) + hairTie(316, 192)
        },
        {
          id: 'bun', label: 'Bun',
          svgBack: hairMass('M200,4 C234,4 252,26 250,52 C248,74 226,86 200,86 C174,86 152,74 150,52 C148,26 166,4 200,4 Z', { lines: 'M180,22 C196,14 218,18 226,32 C230,46 216,56 202,52 C190,48 190,36 200,32' }) +
                   hairTie(200, 80, 11) + hairMass(CAP_BACK),
          svgFront: frontSwept()
        },
        {
          id: 'curly', label: 'Curly',
          svgBack: hairMass(curlyRing(200, 190, 146, 150, 158, 382, 13, 20) + ' L296,262 L104,262 Z'),
          svgFront: (() => {
            const fr = 'M80,200 C66,130 112,70 200,66 C288,70 334,130 320,200 C316,168 300,142 276,132 C260,150 232,158 204,156 C172,154 146,150 124,134 C100,144 86,172 80,200 Z';
            const edge = 'M320,200 C316,168 300,142 276,132 C260,150 232,158 204,156 C172,154 146,150 124,134 C100,144 86,172 80,200';
            return fringeShadow('M276,132 C260,150 232,158 204,156 C172,154 146,150 124,134 L128,144 C148,158 174,164 204,166 C232,168 262,160 280,142 Z') +
                   hairMass(fr, { edge, shine: SHINE, lines: 'M146,100 c10,-10 24,-8 26,4 M196,90 c10,-10 26,-6 26,8 M244,100 c8,-6 22,-2 22,12' });
          })()
        },
        {
          id: 'ponytail', label: 'Ponytail',
          svgBack: hairMass('M318,100 C376,92 404,156 388,240 C380,296 352,344 330,358 C338,306 350,254 328,206 Z', { lines: 'M350,130 C368,180 364,250 344,320' }) + hairMass(CAP_BACK),
          svgFront: frontSwept() + hairTie(322, 106)
        },
        {
          id: 'messy', label: 'Messy',
          svgBack: hairMass(tuftRing(200, 190, 140, 146, 160, 380, 12, 22) + ' L296,262 L104,262 Z'),
          svgFront: (() => {
            const fr = 'M74,214 C58,122 106,54 200,52 C294,54 342,122 326,214 C324,186 312,162 298,150 L284,172 L268,136 L246,164 L226,128 L204,162 L182,130 L164,162 L146,134 L126,166 L112,150 C92,164 80,186 74,214 Z';
            const edge = 'M326,214 C324,186 312,162 298,150 L284,172 L268,136 L246,164 L226,128 L204,162 L182,130 L164,162 L146,134 L126,166 L112,150 C92,164 80,186 74,214';
            return hairMass(fr, { edge, shine: SHINE, lines: 'M150,100 L160,118 M220,88 L226,110 M270,110 L262,128' });
          })()
        },
        {
          id: 'afro', label: 'Afro',
          svgBack: hairMass(curlyRing(200, 168, 166, 162, 150, 390, 18, 16) + ' L296,262 L104,262 Z'),
          svgFront: (() => {
            const fr = 'M88,182 C84,110 136,70 200,70 C264,70 316,110 312,182 C296,150 252,128 200,128 C148,128 104,150 88,182 Z';
            const edge = 'M312,182 C296,150 252,128 200,128 C148,128 104,150 88,182';
            return fringeShadow('M312,182 C296,150 252,128 200,128 C148,128 104,150 88,182 L92,192 C108,162 152,140 200,140 C248,140 292,162 308,192 Z') +
                   hairMass(fr, { edge, shine: 'M124,96 C144,80 180,74 210,78 C178,86 152,98 138,116 Z' });
          })()
        },
        {
          id: 'mohawk', label: 'Mohawk',
          svgBack: ``,
          svgFront: (() => {
            const stubble = 'M96,176 C100,116 146,88 200,88 C254,88 300,116 304,176 C286,136 248,116 200,116 C152,116 114,136 96,176 Z';
            const crest = 'M168,132 L158,64 L178,88 L184,26 L204,74 L214,30 L226,88 L242,62 L234,132 C220,120 182,120 168,132 Z';
            return `<path d="${stubble}" fill="var(--hair-dk)" opacity="0.4"/>` + hairMass(crest, { lines: 'M190,44 L194,100 M216,52 L214,102' });
          })()
        },
        {
          id: 'military', label: 'Military',
          svgBack: ``,
          svgFront: (() => {
            const fr = 'M92,176 C92,110 140,78 200,76 C260,78 308,110 308,176 C294,138 254,118 200,118 C146,118 106,138 92,176 Z';
            const edge = 'M308,176 C294,138 254,118 200,118 C146,118 106,138 92,176';
            return fringeShadow('M308,176 C294,138 254,118 200,118 C146,118 106,138 92,176 L96,186 C112,150 150,130 200,130 C250,130 288,150 304,186 Z') +
                   hairMass(fr, { edge, shine: 'M126,100 C148,86 180,80 208,82 C178,90 154,102 140,118 Z', lines: 'M150,104 l0,0 M176,96 l0,0 M204,94 l0,0 M232,98 l0,0 M258,108 l0,0 M130,124 l0,0 M282,126 l0,0' });
          })()
        },
        {
          id: 'metalhead', label: 'Metalhead',
          svgBack: hairMass('M60,262 C40,150 88,44 200,42 C312,44 360,150 340,262 C350,360 352,450 338,520 L62,520 C48,450 50,360 60,262 Z'),
          svgFront: (() => {
            const left = 'M200,54 C130,56 88,100 84,170 C82,230 78,330 68,440 L112,440 C116,340 112,254 122,204 C134,154 160,120 200,104 Z';
            return hairMass(left, { lines: 'M100,200 C96,280 94,360 92,430' }) + hairMass(flipX(left), { lines: flipX('M100,200 C96,280 94,360 92,430') });
          })()
        },
        {
          id: 'baldish', label: 'Bald-ish',
          svgBack: ``,
          svgFront: `<path class="fill-hair" d="M98,170 C102,112 146,88 200,88 C254,88 298,112 302,170 C282,134 244,118 200,118 C156,118 118,134 98,170 Z" opacity="0.35"/>`
        },
        {
          id: 'spacebuns', label: 'Space Buns',
          svgBack: (() => {
            const bun = 'M108,36 C136,30 152,52 144,78 C138,98 110,100 94,88 C78,76 80,42 108,36 Z';
            return hairMass(bun, { lines: 'M106,50 C120,46 130,58 122,70' }) + hairMass(flipX(bun), { lines: flipX('M106,50 C120,46 130,58 122,70') }) +
                   hairTie(112, 92, 9) + hairTie(288, 92, 9) + hairMass(CAP_BACK);
          })(),
          svgFront: frontStraight()
        },
        {
          id: 'braids', label: 'Braids',
          svgBack: (() => {
            // A plait: five overlapping rounded links falling from beside the ear.
            const link = (x, y, r) => `M${x - r},${y} C${x - r},${y - r * 1.2} ${x + r},${y - r * 1.2} ${x + r},${y} C${x + r},${y + r * 1.2} ${x - r},${y + r * 1.2} ${x - r},${y} Z`;
            const links = [[84, 252, 17], [80, 282, 16], [84, 312, 15], [80, 340, 14], [83, 366, 12]];
            const left = links.map(([x, y, r]) => hairMass(link(x, y, r), { lines: `M${x - 8},${y - 6} L${x + 8},${y + 6}` })).join('');
            const right = links.map(([x, y, r]) => hairMass(flipX(link(x, y, r)), { lines: flipX(`M${x - 8},${y - 6} L${x + 8},${y + 6}`) })).join('');
            return left + right + hairTie(83, 384, 8) + hairTie(317, 384, 8) + hairMass(CAP_BACK);
          })(),
          svgFront: frontParted()
        },
        {
          id: 'princess', label: 'Princess',
          svgBack: hairMass('M64,262 C42,150 88,44 200,42 C312,44 358,150 336,262 C350,300 326,340 346,390 C360,430 334,460 344,494 C318,506 296,486 282,496 L118,496 C104,486 82,506 56,494 C66,460 40,430 54,390 C74,340 50,300 64,262 Z', { lines: 'M78,330 C70,380 76,430 70,480 M322,330 C330,380 324,430 330,480' }),
          svgFront: frontParted()
        },
        {
          id: 'sidetail', label: 'Side Tail',
          svgBack: hairMass('M100,110 C46,110 18,190 32,272 C42,322 70,362 92,376 C84,332 86,290 94,242 C100,202 112,152 116,128 Z', { lines: 'M60,150 C44,210 52,290 80,356' }) + hairMass(CAP_BACK),
          svgFront: frontSwept() + hairTie(104, 122)
        },
        {
          id: 'pixie', label: 'Pixie',
          svgBack: hairMass('M70,236 C56,150 104,56 200,54 C296,56 344,150 330,236 C326,208 318,190 304,178 L96,178 C82,190 74,208 70,236 Z'),
          svgFront: (() => {
            const fr = 'M78,200 C62,122 110,58 200,56 C292,58 336,122 322,200 C318,172 304,150 282,138 C262,156 232,166 198,164 C166,162 136,150 116,138 C96,150 84,172 78,200 Z';
            const edge = 'M322,200 C318,172 304,150 282,138 C262,156 232,166 198,164 C166,162 136,150 116,138 C96,150 84,172 78,200';
            return fringeShadow('M282,138 C262,156 232,166 198,164 C166,162 136,150 116,138 L120,148 C138,160 166,172 198,174 C232,176 264,166 286,148 Z') +
                   hairMass(fr, { edge, shine: SHINE, lines: 'M150,112 C170,104 196,104 220,110 M240,100 C256,108 266,120 270,134' }) +
                   `<path d="${starPath(122, 112, 13)}" fill="#FFD76A" stroke="#C9962E" stroke-width="2.4" stroke-linejoin="round"/>`;
          })()
        },
      ]
    },

    // ── CLOTHING ──────────────────────────────────────────────────────────
    // Chest-up, on a small chibi body (torso x 104-296, collar line y 356). Each outfit is
    // built from shared pieces (TORSO, SLEEVE_*, neckline()) plus its own details. The fabric
    // pattern (none, dots, stripes, stars, hearts) is picked separately: `patterns: true`.
    clothing: {
      label: '👗 Outfit',
      colorSlot: 'clothing',
      colorLabel: 'Outfit colour',
      patterns: true,
      layerIds: ['clothing'],
      thumbViewBox: '40 330 320 190',
      options: [
        {
          id: 'dress', label: 'Dress',
          svg: clothMass(TORSO) + pair(PUFF) + neckline('scoop', 'white') + bowShape(200, 424)
        },
        {
          id: 'tshirt', label: 'T-shirt',
          svg: clothMass(TORSO) + pair(SLEEVE_SHORT) + neckline('crew') +
            `<path d="${starPath(200, 440, 22)}" fill="#fff" stroke="var(--clothing-dk)" stroke-width="2.4" stroke-linejoin="round"/>`
        },
        {
          id: 'rainbowtee', label: 'Rainbow',
          svg: clothMass(TORSO) + pair(SLEEVE_SHORT) + neckline('crew') +
            ['#FF5E5E', '#FFA94D', '#FFE14D', '#6BD66B', '#4DB8FF'].map((col, n) =>
              `<path d="M${148 + n * 6},474 Q200,${410 + n * 7} ${252 - n * 6},474" fill="none" stroke="${col}" stroke-width="6.5" stroke-linecap="round"/>`).join('') +
            `<path d="${blobPath(146, 476, 12, 8)}" fill="#fff" stroke="var(--clothing-dk)" stroke-width="2"/><path d="${blobPath(254, 476, 12, 8)}" fill="#fff" stroke="var(--clothing-dk)" stroke-width="2"/>`
        },
        {
          id: 'overalls', label: 'Overalls',
          svg: clothMass(TORSO, { fill: '#FFF6EE', outline: '#CDBFD0', pattern: false }) +
            pair(SLEEVE_LONG, { fill: '#FFF6EE', outline: '#CDBFD0', pattern: false }) +
            neckline('crew') +
            clothMass('M150,356 L168,356 L172,408 L228,408 L232,356 L250,356 L262,420 L296,520 L104,520 L138,420 Z') +
            button(158, 412) + button(242, 412) +
            `<path d="M178,436 L222,436 L222,476 L178,476 Z" fill="none" stroke="var(--clothing-dk)" stroke-width="2.4" stroke-dasharray="5 4" stroke-linejoin="round"/>`
        },
        {
          id: 'hoodie', label: 'Hoodie',
          svg: clothMass(TORSO) + pair(SLEEVE_LONG) +
            clothMass('M124,472 C150,462 250,462 276,472 L292,520 L108,520 Z', { pattern: false }) +
            clothMass('M138,378 C130,350 156,336 200,336 C244,336 270,350 262,378 C240,394 160,394 138,378 Z', { pattern: false }) +
            `<path class="fill-skin" d="M166,366 C172,352 228,352 234,366 C226,382 174,382 166,366 Z"/>
             <path d="M166,366 C172,352 228,352 234,366 C226,382 174,382 166,366 Z" fill="none" class="ol-skin"/>
             <path d="M180,384 L178,420 M220,384 L222,420" fill="none" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/>
             <circle cx="178" cy="422" r="4.5" fill="#fff" stroke="var(--clothing-dk)" stroke-width="2"/><circle cx="222" cy="422" r="4.5" fill="#fff" stroke="var(--clothing-dk)" stroke-width="2"/>`
        },
        {
          id: 'gown', label: 'Gown',
          svg: clothMass('M168,356 L232,356 C262,372 278,400 270,430 C300,460 330,490 352,520 L48,520 C70,490 100,460 130,430 C122,400 138,372 168,356 Z') +
            pair(PUFF) + neckline('scoop', 'white') +
            `<path d="M128,430 C170,442 230,442 272,430 L276,446 C230,458 170,458 124,446 Z" fill="var(--clothing-dk)" stroke="var(--clothing-dk)" stroke-width="2" stroke-linejoin="round"/>` +
            bowShape(200, 448, 1.15) +
            [[112, 492, 7], [158, 506, 6], [244, 500, 7], [290, 490, 6], [70, 510, 5]].map(([x, y, r]) =>
              `<path d="${starPath(x, y, r)}" fill="#fff" opacity="0.85"/>`).join('')
        },
        {
          id: 'princess', label: 'Princess',
          svg: clothMass('M104,470 C86,492 66,506 44,520 L356,520 C334,506 314,492 296,470 Z', { pattern: true }) +
            clothMass(TORSO) + pair(PUFF_BIG) + neckline('heart', 'white') +
            `<path d="M70,520 ${scallops(70, 330, 520, 10, 14).replace(/^M[\d.]+,[\d.]+/, '')}" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round"/>
             <path d="M112,452 C170,462 230,462 288,452 L290,468 C230,478 170,478 110,468 Z" fill="#F5C542" stroke="#B8860B" stroke-width="2.4" stroke-linejoin="round"/>
             <path d="${heartPath(200, 465, 9)}" fill="#FF6FA3" stroke="#C44A78" stroke-width="2.2" stroke-linejoin="round"/>`
        },
        {
          id: 'tutu', label: 'Tutu',
          svg: `<path class="fill-skin ol-skin" d="${blobPath(120, 398, 24, 28)}"/><path class="fill-skin ol-skin" d="${blobPath(280, 398, 24, 28)}"/>` +
            clothMass('M128,520 C128,450 140,392 176,364 L224,364 C260,392 272,450 272,520 Z') +
            neckline('crew') +
            clothMass('M132,466 C100,488 62,506 34,520 L366,520 C338,506 300,488 268,466 C236,474 164,474 132,466 Z', { pattern: false }) +
            clothMass('M150,458 C122,482 96,500 74,520 L326,520 C304,500 278,482 250,458 C226,466 174,466 150,458 Z', { pattern: false }) +
            `<path d="${scallops(74, 326, 520, 9, 13)}" fill="none" stroke="#fff" stroke-opacity="0.8" stroke-width="4" stroke-linecap="round"/>` +
            [[132, 500], [168, 508], [214, 504], [262, 500], [176, 484], [228, 482]].map(([x, y]) =>
              `<path d="${starPath(x, y, 5)}" fill="#fff" opacity="0.9"/>`).join('')
        },
        {
          id: 'pyjamas', label: 'Pyjamas',
          svg: clothMass(TORSO) + pair(SLEEVE_LONG) + neckline('crew') +
            `<path d="M200,386 L200,520" fill="none" stroke="var(--clothing-dk)" stroke-width="2.6"/>` +
            button(200, 408, 4) + button(200, 440, 4) + button(200, 472, 4) + button(200, 504, 4) +
            [[150, 430, 9], [246, 452, 8], [166, 490, 7], [240, 506, 6], [232, 412, 6]].map(([x, y, r]) =>
              `<path d="${starPath(x, y, r)}" fill="#fff" stroke="var(--clothing-dk)" stroke-width="1.4" stroke-linejoin="round"/>`).join('')
        },
        {
          id: 'raincoat', label: 'Raincoat',
          svg: clothMass(TORSO) + pair(SLEEVE_LONG) + neckline('vneck') +
            clothMass('M172,352 L138,390 L192,400 L200,358 Z', { pattern: false }) + clothMass(flipX('M172,352 L138,390 L192,400 L200,358 Z'), { pattern: false }) +
            `<path d="M200,402 L200,520" fill="none" stroke="var(--clothing-dk)" stroke-width="3"/>` +
            [424, 458, 492].map(y => `<circle cx="186" cy="${y}" r="7" fill="#fff" stroke="var(--clothing-dk)" stroke-width="2.4"/><circle cx="186" cy="${y}" r="2" fill="var(--clothing-dk)"/>`).join('') +
            `<path d="M124,440 L168,440 L166,478 L122,474 Z M276,440 L232,440 L234,478 L278,474 Z" fill="none" stroke="var(--clothing-dk)" stroke-width="2.4" stroke-linejoin="round"/>
             <path d="M132,392 C128,410 130,428 136,444" fill="none" stroke="#fff" stroke-opacity="0.45" stroke-width="5" stroke-linecap="round"/>`
        },
        {
          id: 'robes', label: 'Robes',
          svg: clothMass(TORSO) + pair(SLEEVE_WIDE) +
            `<path d="M168,356 L232,356 L200,432 Z" fill="#fff" stroke="var(--clothing-dk)" stroke-width="2.4" stroke-linejoin="round"/>
             <path d="M194,384 L206,384 L211,436 L200,448 L189,436 Z" fill="#B3202A" stroke="#6E1018" stroke-width="2" stroke-linejoin="round"/>
             <path d="M193,402 L209,402 M192,418 L210,418" fill="none" stroke="#F5C542" stroke-width="3"/>
             <path d="M168,356 L200,432 L232,356" fill="none" class="ol-cloth" style="stroke-width:5"/>` +
            button(200, 476, 7)
        },
        {
          id: 'jersey', label: 'Sports',
          svg: clothMass(TORSO) + pair(SLEEVE_SHORT) + neckline('vneck', 'white') +
            `<path d="M85,430 L119,443 M83,438 L117,451" fill="none" stroke="#fff" stroke-width="4.5" stroke-linecap="round"/>
             <path d="M315,430 L281,443 M317,438 L283,451" fill="none" stroke="#fff" stroke-width="4.5" stroke-linecap="round"/>
             <path d="M116,420 C113,458 111,490 109,520 M284,420 C287,458 289,490 291,520" fill="none" stroke="#fff" stroke-opacity="0.85" stroke-width="8" stroke-linecap="round"/>
             <path d="M183,424 L217,424 L199,478" fill="none" stroke="var(--clothing-dk)" stroke-width="14" stroke-linecap="round" stroke-linejoin="round"/>
             <path d="M183,424 L217,424 L199,478" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>`
        },
      ]
    },

    // ── ACCESSORIES ───────────────────────────────────────────────────────
    // Multi-select, each item with its own size and position. Anchored to the new head: hair
    // top y~52, ears (82,226)/(318,226), eyes (148,216)/(252,216), neck base y~356.
    // `thumb` overrides the thumbnail viewBox (items sit anywhere from the head to the chest).
    accessories: {
      label: '✨ Extras',
      colorSlot: null,
      multiSelect: true,
      layerIds: ['accessories'],
      thumbViewBox: '30 0 340 300',
      options: [
        { id: 'none', label: 'None', svg: `` },
        {
          id: 'glasses', label: 'Glasses', pivot: [200, 216], thumb: '70 170 260 100',
          svg: [148, 252].map(x => `<circle cx="${x}" cy="216" r="31" fill="rgba(200,235,255,0.2)" stroke="#3D4A66" stroke-width="4.5"/>
              <path d="M${x - 20},202 Q${x - 12},192 ${x},190" fill="none" stroke="#fff" stroke-opacity="0.75" stroke-width="3.5" stroke-linecap="round"/>`).join('') +
            `<path d="M178,214 Q200,206 222,214" fill="none" stroke="#3D4A66" stroke-width="4.5" stroke-linecap="round"/>` + glassTemples('#3D4A66')
        },
        {
          id: 'heartshades', label: 'Heart Shades', pivot: [200, 216], thumb: '70 170 260 100',
          svg: [148, 252].map(x => `<path d="${heartPath(x, 214, 21)}" fill="#FF5FA2" fill-opacity="0.92" stroke="#B82C6A" stroke-width="3.5" stroke-linejoin="round"/>
              <path d="M${x - 16},206 Q${x - 12},198 ${x - 4},198" fill="none" stroke="#fff" stroke-opacity="0.75" stroke-width="3.5" stroke-linecap="round"/>`).join('') +
            `<path d="M180,212 Q200,206 220,212" fill="none" stroke="#B82C6A" stroke-width="4" stroke-linecap="round"/>` + glassTemples('#B82C6A')
        },
        {
          id: 'hp-glasses', label: 'HP Specs', pivot: [200, 216], thumb: '70 170 260 100',
          svg: [148, 252].map(x => `<circle cx="${x}" cy="216" r="28" fill="rgba(210,240,255,0.12)" stroke="${GOLD_DK}" stroke-width="3"/>
              <path d="M${x - 18},204 Q${x - 12},196 ${x - 2},194" fill="none" stroke="#fff" stroke-opacity="0.6" stroke-width="2.6" stroke-linecap="round"/>`).join('') +
            `<path d="M176,214 Q200,208 224,214" fill="none" stroke="${GOLD_DK}" stroke-width="3" stroke-linecap="round"/>` + glassTemples(GOLD_DK)
        },
        {
          id: 'crown', label: 'Crown', pivot: [200, 70], thumb: HEAD_THUMB,
          svg: accMass('M150,84 L146,42 L174,64 L200,36 L226,64 L254,42 L250,84 Z', GOLD, GOLD_DK, { shine: 'M156,76 L153,52 L166,63 Z' }) +
            accMass('M148,80 L252,80 L252,97 L148,97 Z', '#FFC527', GOLD_DK, { flat: true }) +
            `<circle cx="200" cy="56" r="6" fill="#FF4D6D" stroke="#B8243F" stroke-width="2"/><circle cx="170" cy="89" r="4.5" fill="#4DA3FF" stroke="#2A63A8" stroke-width="1.8"/>
             <circle cx="200" cy="89" r="4.5" fill="#FF4D6D" stroke="#B8243F" stroke-width="1.8"/><circle cx="230" cy="89" r="4.5" fill="#4DD07A" stroke="#2A8A4E" stroke-width="1.8"/>`
        },
        {
          id: 'tiara', label: 'Tiara', pivot: [200, 80], thumb: HEAD_THUMB,
          svg: (() => {
            const P = t => [f1((1 - t) ** 2 * 124 + 2 * (1 - t) * t * 200 + t * t * 276), f1((1 - t) ** 2 * 102 + 2 * (1 - t) * t * 62 + t * t * 102)];
            const spikes = [0.18, 0.32, 0.68, 0.82].map(t => { const [x, y] = P(t); return `<path d="M${x - 7},${y} L${x},${y - 18} L${x + 7},${y} Z" fill="#E7E2FA" stroke="#9C8FCB" stroke-width="2.4" stroke-linejoin="round"/><circle cx="${x}" cy="${y - 20}" r="3.4" fill="#8FE3FF" stroke="#3D8FB0" stroke-width="1.4"/>`; }).join('');
            return thickLine('M124,102 Q200,62 276,102', '#9C8FCB', '#E7E2FA', 11, 6.5) + spikes +
              `<path d="${heartPath(200, 66, 11)}" fill="#FF6FA3" stroke="#C44A78" stroke-width="2.4" stroke-linejoin="round"/>`;
          })()
        },
        {
          id: 'hat', label: 'Sun Hat', pivot: [200, 90], thumb: HEAD_THUMB,
          svg: `<g transform="translate(0 14)">` + accMass(blobPath(200, 94, 134, 26), '#F7D98E', '#C9963E', { shine: 'M96,88 Q130,76 170,74 Q130,82 100,94 Z' }) +
            accMass('M136,92 C136,44 264,44 264,92 Q200,106 136,92 Z', '#F7D98E', '#C9963E', { shine: 'M150,80 C152,62 172,54 192,52 C172,62 162,72 158,86 Z' }) +
            `<path d="M138,84 Q200,100 262,84 L262,72 Q200,88 138,72 Z" fill="#FF8DB8" stroke="#C23A85" stroke-width="2.6" stroke-linejoin="round"/>` +
            `<g transform="translate(236 84) rotate(12) scale(0.9)"><path d="M0,0 C-12,-12 -26,-8 -24,2 C-22,12 -10,10 0,0 Z M0,0 C12,-12 26,-8 24,2 C22,12 10,10 0,0 Z" fill="#fff" stroke="#C23A85" stroke-width="2.5" stroke-linejoin="round"/><circle r="5" fill="#fff" stroke="#C23A85" stroke-width="2.5"/></g>` + `</g>`
        },
        {
          id: 'bow', label: 'Hair Bow', pivot: [142, 76], thumb: HEAD_THUMB,
          svg: `<g transform="translate(142 76) rotate(-18) scale(1.7)"><path d="M0,0 C-12,-12 -26,-8 -24,2 C-22,12 -10,10 0,0 Z M0,0 C12,-12 26,-8 24,2 C22,12 10,10 0,0 Z" fill="#FF6EB4" stroke="#C23A85" stroke-width="1.8" stroke-linejoin="round"/><path d="M-16,-3 C-18,0 -17,4 -14,5" fill="none" stroke="#fff" stroke-opacity="0.6" stroke-width="1.4" stroke-linecap="round"/><circle r="5" fill="#FF88CC" stroke="#C23A85" stroke-width="1.8"/></g>`
        },
        {
          id: 'headband', label: 'Headband', pivot: [200, 110], thumb: HEAD_THUMB,
          svg: thickLine('M86,178 C74,108 130,58 200,56 C270,58 326,108 314,178', '#C23A85', '#FF6EB4', 12, 7.5) +
            `<path d="M110,100 C126,76 160,62 192,60" fill="none" stroke="#fff" stroke-opacity="0.5" stroke-width="2.4" stroke-linecap="round"/>` +
            `<g transform="translate(262 70) rotate(16) scale(1.35)"><path d="M0,0 C-12,-12 -26,-8 -24,2 C-22,12 -10,10 0,0 Z M0,0 C12,-12 26,-8 24,2 C22,12 10,10 0,0 Z" fill="#FF6EB4" stroke="#C23A85" stroke-width="2" stroke-linejoin="round"/><circle r="5" fill="#FF88CC" stroke="#C23A85" stroke-width="2"/></g>`
        },
        {
          id: 'catears', label: 'Cat Ears', pivot: [200, 86], thumb: HEAD_THUMB,
          svg: (() => {
            const ear = 'M108,122 C104,92 108,62 122,46 C140,56 164,72 178,90 Z';
            const inner = 'M122,100 C122,82 124,68 128,60 C140,68 154,78 162,90 Z';
            return accMass(ear, 'var(--hair)', 'var(--hair-dk)') + `<path d="${inner}" fill="#FFB3C8" stroke="#E07AA0" stroke-width="2" stroke-linejoin="round"/>` +
              accMass(flipX(ear), 'var(--hair)', 'var(--hair-dk)') + `<path d="${flipX(inner)}" fill="#FFB3C8" stroke="#E07AA0" stroke-width="2" stroke-linejoin="round"/>`;
          })()
        },
        {
          id: 'bunnyears', label: 'Bunny Ears', pivot: [200, 88], thumb: HEAD_THUMB,
          svg: (() => {
            const ear = 'M146,92 C122,58 120,22 138,12 C158,4 176,44 182,92 Z';
            const inner = 'M150,84 C136,60 136,32 146,24 C158,22 168,50 172,84 Z';
            return accMass(ear, '#fff', '#B9A6CF', { shine: 'M134,30 C130,44 132,56 138,68 C136,54 136,42 142,28 Z' }) + `<path d="${inner}" fill="#FFB3C8"/>` +
              accMass(flipX(ear), '#fff', '#B9A6CF') + `<path d="${flipX(inner)}" fill="#FFB3C8"/>`;
          })()
        },
        {
          id: 'flowercrown', label: 'Flower Crown', pivot: [200, 90], thumb: HEAD_THUMB,
          svg: (() => {
            const pts = Array.from({ length: 9 }, (_, k) => {
              const a = (196 + k * 18.5) * Math.PI / 180;
              return [f1(200 + 116 * Math.cos(a)), f1(102 + 54 * Math.sin(a))];
            });
            const leaves = pts.slice(0, -1).map(([x, y], k) => {
              const [x2, y2] = pts[k + 1];
              return `<ellipse cx="${f1((x + x2) / 2)}" cy="${f1((y + y2) / 2 - 3)}" rx="11" ry="5.5" fill="#6BC46B" stroke="#3E8A3E" stroke-width="1.8" transform="rotate(${f1(Math.atan2(y2 - y, x2 - x) * 180 / Math.PI)} ${f1((x + x2) / 2)} ${f1((y + y2) / 2 - 3)})"/>`;
            }).join('');
            const cols = ['#FF8DB8', '#FFE14D', '#C9A7F5', '#FFFFFF'];
            return leaves + pts.map(([x, y], k) => flower(x, y, 7.5, cols[k % 4])).join('');
          })()
        },
        {
          id: 'butterflyclips', label: 'Butterflies', pivot: [200, 130], thumb: '84 84 240 76',
          svg: butterfly(118, 116, 0.9, '#FF8DB8', '#FFC1DA') + butterfly(290, 132, 0.8, '#7FD1F2', '#B9E8FA')
        },
        {
          id: 'earrings', label: 'Earrings', pivot: [200, 250], thumb: '50 228 300 52',
          svg: [82, 318].map(x => `<circle cx="${x}" cy="246" r="6.5" fill="${GOLD}" stroke="${GOLD_DK}" stroke-width="2.4"/>
              <path d="${heartPath(x, 264, 6.5)}" fill="#FF6FA3" stroke="#C23A85" stroke-width="2" stroke-linejoin="round"/>`).join('')
        },
        {
          id: 'wizard-hat', label: 'Wizard Hat', pivot: [200, 90], thumb: '60 0 280 120',
          svg: `<g transform="translate(0 14)">` + accMass(blobPath(200, 94, 120, 22), 'var(--clothing)', 'var(--clothing-dk)', { shine: 'M96,90 Q120,80 156,78 Q124,86 102,96 Z' }) +
            accMass('M122,92 Q160,76 176,40 Q188,10 214,4 Q208,32 224,62 Q240,84 278,92 Z', 'var(--clothing)', 'var(--clothing-dk)', { shine: 'M176,44 Q186,22 204,10 Q194,30 186,56 Z' }) +
            `<path d="M146,88 Q200,102 254,88" fill="none" stroke="#3a2a55" stroke-width="10" stroke-linecap="round"/>
             <rect x="184" y="86" width="32" height="18" rx="4" fill="${GOLD}" stroke="${GOLD_DK}" stroke-width="2.4"/><rect x="192" y="91" width="16" height="8" rx="2" fill="#3a2a55"/>` + `</g>`
        },
        {
          id: 'sorting-hat', label: 'Sorting Hat', pivot: [200, 90], thumb: '60 0 280 120',
          svg: `<g transform="translate(0 14)">` + accMass(blobPath(200, 98, 130, 20), '#7A5A38', '#3F2C14', { shine: 'M90,94 Q124,84 162,84 Q126,90 96,100 Z' }) +
            accMass('M120,98 C128,62 148,30 176,20 C196,12 222,10 238,34 C248,54 254,76 264,98 Q200,110 120,98 Z', '#7A5A38', '#3F2C14', { shine: 'M150,78 C156,56 170,36 190,26 C172,44 164,62 160,84 Z' }) +
            `<path d="M170,86 Q200,96 230,86" fill="none" stroke="#3F2C14" stroke-width="3" stroke-linecap="round" stroke-dasharray="4 3"/>
             <path d="M184,52 Q178,68 180,80 M216,50 Q222,66 220,80" fill="none" stroke="#3F2C14" stroke-opacity="0.5" stroke-width="2.4" stroke-linecap="round"/>` + `</g>`
        },
        {
          id: 'gryffindor-scarf', label: 'G. Scarf', pivot: [200, 360], thumb: '110 320 180 190',
          svg: accMass('M146,346 Q200,376 254,346 L258,372 Q200,402 142,372 Z', '#B3202A', '#6E1018') +
            `<path d="M148,356 Q200,385 252,356 M146,364 Q200,394 254,364" fill="none" stroke="${GOLD}" stroke-width="4" stroke-linecap="round"/>` +
            accMass('M158,378 Q148,436 154,494 L188,498 Q184,444 194,392 Z', '#B3202A', '#6E1018') +
            `<path d="M156,420 L190,426 M155,446 L189,452 M154,472 L188,478" fill="none" stroke="${GOLD}" stroke-width="5" stroke-linecap="round"/>` +
            accMass('M226,386 Q238,420 236,452 L262,448 Q258,418 248,380 Z', '#B3202A', '#6E1018') +
            `<path d="M234,420 L260,416 M235,436 L261,432" fill="none" stroke="${GOLD}" stroke-width="4" stroke-linecap="round"/>`
        },
        {
          id: 'wand', label: 'Wand', pivot: [316, 400], thumb: '250 320 130 150',
          svg: thickLine('M294,452 L338,362', '#3A2010', '#6B4226', 10, 6) +
            `<circle cx="342" cy="352" r="14" fill="${GOLD}" opacity="0.3"/>` + sparkle(342, 352, 12) + sparkle(360, 366, 6) + sparkle(324, 340, 5)
        },
        {
          id: 'starwand', label: 'Star Wand', pivot: [316, 400], thumb: '250 320 130 150',
          svg: thickLine('M294,452 L334,376', '#C23A85', '#FF8DC7', 9, 5) +
            `<path d="M330,384 C346,392 352,406 344,418" fill="none" stroke="#FF8DC7" stroke-width="2.6" stroke-linecap="round"/>` +
            `<path d="${starPath(340, 356, 22)}" fill="${GOLD}" stroke="${GOLD_DK}" stroke-width="3" stroke-linejoin="round"/>` +
            `<path d="M330,350 L336,342" fill="none" stroke="#fff" stroke-opacity="0.7" stroke-width="3" stroke-linecap="round"/>` + sparkle(366, 340, 6, '#fff') + sparkle(312, 334, 5, '#fff')
        },
        {
          id: 'elf-ears', label: 'Elf Ears', pivot: [200, 226], thumb: '30 140 340 130',
          svg: (() => {
            const ear = 'M92,240 C72,232 54,204 42,170 C66,182 86,192 96,204 Z';
            return `<path d="${ear}" class="fill-skin ol-skin"/><path d="M84,222 C74,214 62,200 54,186" fill="none" stroke="var(--skin-dk)" stroke-width="2" stroke-linecap="round" opacity="0.6"/>` +
              `<path d="${flipX(ear)}" class="fill-skin ol-skin"/><path d="${flipX('M84,222 C74,214 62,200 54,186')}" fill="none" stroke="var(--skin-dk)" stroke-width="2" stroke-linecap="round" opacity="0.6"/>`;
          })()
        },
        {
          id: 'dobby-ears', label: 'Dobby Ears', pivot: [200, 240], thumb: '0 170 400 130',
          svg: (() => {
            const ear = 'M96,224 C58,202 24,218 22,258 C20,294 58,304 86,270 C96,256 98,240 96,224 Z';
            const inner = 'M86,236 C64,226 44,236 42,258 C42,276 60,280 76,262';
            return `<path d="${ear}" class="fill-skin ol-skin"/><path d="${inner}" fill="none" stroke="var(--skin-dk)" stroke-width="2.4" stroke-linecap="round" opacity="0.6"/>` +
              `<path d="${flipX(ear)}" class="fill-skin ol-skin"/><path d="${flipX(inner)}" fill="none" stroke="var(--skin-dk)" stroke-width="2.4" stroke-linecap="round" opacity="0.6"/>`;
          })()
        },
        {
          id: 'demon-horns', label: 'Demon Horns', pivot: [200, 90], thumb: HEAD_THUMB,
          svg: (() => {
            const horn = 'M138,94 C116,72 118,40 140,24 C136,50 150,68 168,82 Z';
            return accMass(horn, '#C0262D', '#7A1018', { shine: 'M130,60 C132,50 136,42 140,34 C138,46 140,54 144,62 Z' }) + accMass(flipX(horn), '#C0262D', '#7A1018');
          })()
        },
        {
          id: 'ram-horns', label: 'Ram Horns', pivot: [200, 130], thumb: '0 60 400 200',
          svg: (() => {
            const horn = 'M114,110 C72,104 54,156 92,168 C122,176 136,148 122,132 C112,148 98,148 94,138 C94,126 108,116 114,110 Z';
            return accMass(horn, '#C9B08A', '#7F6547', { shine: 'M86,128 C80,140 84,152 94,158 C88,148 86,138 92,128 Z' }) + accMass(flipX(horn), '#C9B08A', '#7F6547');
          })()
        },
        {
          id: 'antlers', label: 'Antlers', pivot: [200, 80], thumb: HEAD_THUMB,
          svg: (() => {
            const side = 'M164,88 L154,40 M158,62 L134,50 M155,48 L142,26 M158,74 L172,52';
            return thickLine(side, '#5E3F22', '#8B5E3C', 11, 6.5) + thickLine(flipX(side), '#5E3F22', '#8B5E3C', 11, 6.5);
          })()
        },
        {
          id: 'unicorn-horn', label: 'Unicorn', pivot: [200, 70], thumb: HEAD_THUMB,
          svg: accMass('M184,84 L200,8 L216,84 Q200,92 184,84 Z', '#FFF6DC', '#C9B27C', { shine: 'M192,70 L199,26 L200,70 Z' }) +
            `<path d="M187,72 Q200,64 214,72 M190,56 Q200,49 211,56 M194,40 Q200,35 207,40" fill="none" stroke="#D2A0FF" stroke-width="3" stroke-linecap="round"/>` + sparkle(222, 26, 6, '#fff') + sparkle(178, 38, 5, '#9BE6FF')
        },
        {
          id: 'crystal-horns', label: 'Crystal Horns', pivot: [200, 90], thumb: HEAD_THUMB,
          svg: (() => {
            const horn = 'M152,92 L136,38 L178,68 Z';
            return accMass(horn, '#B6E8FF', '#5E9FC4', { shine: 'M146,76 L140,52 L156,66 Z' }) + accMass(flipX(horn), '#B6E8FF', '#5E9FC4');
          })()
        },
        {
          id: 'dragon-horns', label: 'Dragon Horns', pivot: [200, 90], thumb: HEAD_THUMB,
          svg: (() => {
            const horn = 'M152,94 C122,88 106,62 112,34 C128,52 146,62 170,74 Z';
            return accMass(horn, '#8A6750', '#3F2A1F', { shine: 'M122,56 C122,48 124,42 128,38 C126,48 130,56 136,62 Z' }) + accMass(flipX(horn), '#8A6750', '#3F2A1F');
          })()
        },
      ]
    },

    // ── MARKS ─────────────────────────────────────────────────────────────
    // Face paint and skin marks. Drawn over the cheeks, under the front hair and the eyes.
    marks: {
      label: '🎨 Paint',
      colorSlot: null,
      layerIds: ['marks'],
      thumbViewBox: '80 130 240 180',
      options: [
        { id: 'none', label: 'None', svg: `` },
        {
          id: 'heart', label: 'Heart',
          thumb: '246 232 72 64',
          svg: `<path d="${heartPath(282, 262, 13)}" fill="#FF4F86" stroke="#C2245A" stroke-width="2.6" stroke-linejoin="round"/><path d="M272,256 Q274,250 280,250" fill="none" stroke="#fff" stroke-opacity="0.7" stroke-width="3" stroke-linecap="round"/>`
        },
        {
          id: 'butterfly', label: 'Butterfly',
          thumb: '252 216 64 68',
          svg: butterfly(284, 250, 0.8, '#FF8DB8', '#7FD1F2')
        },
        {
          id: 'rainbow', label: 'Rainbow',
          thumb: '248 228 72 56',
          svg: ['#FF5E5E', '#FFA94D', '#FFE14D', '#6BD66B', '#4DB8FF'].map((col, n) =>
              `<path d="M${262 + n * 3.5},268 Q284,${236 + n * 3.5} ${306 - n * 3.5},268" fill="none" stroke="${col}" stroke-width="4" stroke-linecap="round"/>`).join('') +
            `<path d="${blobPath(262, 270, 9, 6)}" fill="#fff" stroke="rgba(80,110,150,0.6)" stroke-width="1.6"/><path d="${blobPath(306, 270, 9, 6)}" fill="#fff" stroke="rgba(80,110,150,0.6)" stroke-width="1.6"/>`
        },
        {
          id: 'starcluster', label: 'Stars',
          thumb: '258 194 60 66',
          svg: `<path d="${starPath(294, 214, 12)}" fill="#FFD54A" stroke="#B8860B" stroke-width="2.2" stroke-linejoin="round"/>
                <path d="${starPath(276, 240, 8)}" fill="#FF8DB8" stroke="#C2245A" stroke-width="2" stroke-linejoin="round"/>
                <path d="${starPath(302, 244, 6)}" fill="#7FD1F2" stroke="#2A7FA8" stroke-width="1.8" stroke-linejoin="round"/>`
        },
        {
          id: 'whiskers', label: 'Whiskers',
          thumb: '80 236 240 52',
          svg: mirror(`<path d="M92,250 L138,258 M94,264 L138,266 M100,278 L140,274" fill="none" stroke="#3a2a2a" stroke-width="2.8" stroke-linecap="round"/>`)
        },
        {
          id: 'daisy', label: 'Flower',
          thumb: '92 232 58 62',
          svg: flower(120, 252, 7, '#fff') + `<path d="M120,262 Q116,276 106,282" fill="none" stroke="#3E8A3E" stroke-width="2.6" stroke-linecap="round"/><ellipse cx="108" cy="279" rx="8" ry="4" fill="#6BC46B" stroke="#3E8A3E" stroke-width="1.6" transform="rotate(-30 108 279)"/>`
        },
        {
          id: 'lightning', label: 'HP Scar',
          thumb: '186 140 48 66',
          svg: `<path d="M204,150 L212,168 L205,169 L215,194" fill="none" stroke="rgba(160,40,50,0.18)" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M204,150 L212,168 L205,169 L215,194" fill="none" stroke="#9b2335" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round" opacity="0.85"/>
                <path d="M204,150 L212,168 L205,169 L215,194" fill="none" stroke="rgba(255,180,180,0.3)" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>`
        },
        {
          id: 'freckles', label: 'Freckles',
          thumb: '100 232 200 52',
          svg: (() => {
            const L = [[128, 258, 2.8, .42], [139, 252, 2.2, .35], [147, 262, 2, .3], [122, 268, 1.9, .28], [134, 272, 2.4, .33], [156, 256, 1.8, .28], [160, 268, 1.7, .24]];
            const dots = l => l.map(([x, y, r, a]) => `<circle cx="${x}" cy="${y}" r="${r}" fill="rgba(115,64,34,${a})"/>`).join('');
            return dots(L) + dots(L.map(([x, y, r, a]) => [400 - x, y, r, a])) +
              `<circle cx="195" cy="246" r="1.9" fill="rgba(115,64,34,0.28)"/><circle cx="205" cy="245" r="1.9" fill="rgba(115,64,34,0.28)"/><circle cx="200" cy="251" r="1.7" fill="rgba(115,64,34,0.23)"/>`;
          })()
        },
        {
          id: 'sparkles', label: 'Sparkles',
          svg: sparkle(110, 192, 7) + sparkle(292, 184, 7) + sparkle(124, 154, 6, '#C8EEFF') + sparkle(276, 160, 6, '#C8EEFF') +
            `<circle cx="104" cy="228" r="2.5" fill="${GOLD}" opacity="0.8"/><circle cx="298" cy="222" r="2.5" fill="${GOLD}" opacity="0.8"/><circle cx="118" cy="172" r="1.8" fill="#fff" opacity="0.9"/><circle cx="282" cy="176" r="1.8" fill="#fff" opacity="0.9"/>`
        },
      ]
    },

    // ── BACKGROUND ────────────────────────────────────────────────────────
    // Scenes behind the character. Nothing to colour, move or resize (`noTransform`), but the
    // layer gets a little tilt parallax, so every scene is drawn past the canvas edges.
    background: {
      label: '🌈 Scene',
      colorSlot: null,
      noTransform: true,
      layerIds: ['background'],
      thumbViewBox: '0 0 400 520',
      options: [
        {
          id: 'dreamy', label: 'Dreamy',
          svg: `<linearGradient id="bgs-dreamy" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE6F2"/><stop offset=".6" stop-color="#E4ECFF"/><stop offset="1" stop-color="#D5F1F0"/></linearGradient>
            <rect ${BG} fill="url(#bgs-dreamy)"/>
            <g fill="#fff" opacity=".6"><circle cx="46" cy="70" r="18"/><circle cx="356" cy="110" r="26"/><circle cx="330" cy="430" r="14"/><circle cx="60" cy="400" r="22"/></g>
            <g fill="#FFD76A" opacity=".9"><path d="M350,40 l4,10 10,4 -10,4 -4,10 -4,-10 -10,-4 10,-4z"/><path d="M38,160 l3,8 8,3 -8,3 -3,8 -3,-8 -8,-3 8,-3z"/><path d="M372,300 l3,7 7,3 -7,3 -3,7 -3,-7 -7,-3 7,-3z"/></g>`
        },
        {
          id: 'bedroom', label: 'Bedroom',
          svg: `<linearGradient id="bgs-wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE9F1"/><stop offset="1" stop-color="#FFD9E6"/></linearGradient>
            <pattern id="bgs-stripes" patternUnits="userSpaceOnUse" width="40" height="40"><rect width="20" height="40" fill="#fff" fill-opacity="0.35"/></pattern>
            <rect ${BG} fill="url(#bgs-wall)"/><rect ${BG} fill="url(#bgs-stripes)"/>
            <rect x="-40" y="440" width="480" height="120" fill="#F3CDA6"/><path d="M-40,440 H440 M-40,470 H440 M-40,500 H440" stroke="#DDA97B" stroke-width="2.4" opacity="0.7"/>
            <rect x="-40" y="432" width="480" height="10" fill="#fff" opacity="0.85"/>
            <rect x="24" y="64" width="108" height="132" rx="10" fill="#BDE6FF" stroke="#fff" stroke-width="7"/>
            ${cloud(62, 110, 0.5)}<path d="M78,64 V196 M24,130 H132" stroke="#fff" stroke-width="5"/>
            <path d="M14,56 C40,84 42,150 18,204 L14,204 Z" fill="#FF9EC4"/><path d="M142,56 C116,84 114,150 138,204 L142,204 Z" fill="#FF9EC4"/>
            <rect x="282" y="70" width="74" height="90" rx="6" fill="#fff" stroke="#F5B8CF" stroke-width="7"/><path d="${heartPath(319, 112, 16)}" fill="#FF6FA3"/>
            <path d="M-20,34 Q100,74 200,34 T420,34" fill="none" stroke="#B89A8C" stroke-width="2.4"/>
            ${[[40, 50, '#FFD76A'], [100, 60, '#FF8DB8'], [160, 54, '#7FD1F2'], [232, 44, '#FFD76A'], [292, 56, '#FF8DB8'], [352, 48, '#7FD1F2']].map(([x, y, col]) =>
              `<circle cx="${x}" cy="${y}" r="9" fill="${col}" opacity="0.3"/><circle cx="${x}" cy="${y}" r="5" fill="${col}"/>`).join('')}
            <g stroke="#9C6A43" stroke-width="3"><ellipse cx="62" cy="494" rx="26" ry="22" fill="#C9956B"/><circle cx="58" cy="458" r="22" fill="#C9956B"/><circle cx="42" cy="440" r="8" fill="#C9956B"/><circle cx="74" cy="440" r="8" fill="#C9956B"/><ellipse cx="58" cy="466" rx="10" ry="7.5" fill="#F3D3B0"/></g>
            <circle cx="51" cy="455" r="2.6" fill="#3a2418"/><circle cx="65" cy="455" r="2.6" fill="#3a2418"/><ellipse cx="58" cy="463" rx="3.4" ry="2.4" fill="#3a2418"/>`
        },
        {
          id: 'beach', label: 'Beach',
          svg: `<linearGradient id="bgs-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9FDDFF"/><stop offset="1" stop-color="#E6F8FF"/></linearGradient>
            <rect ${BG} fill="url(#bgs-sky)"/>
            <circle cx="336" cy="92" r="54" fill="#FFE14D" opacity="0.3"/><circle cx="336" cy="92" r="34" fill="#FFE14D"/>
            ${cloud(90, 70, 1)}${cloud(250, 150, 0.7)}
            <rect x="-40" y="290" width="480" height="130" fill="#6EC9F0"/><rect x="-40" y="290" width="480" height="22" fill="#9BDCF7"/>
            <path d="M-30,330 q25,-12 50,0 t50,0 t50,0 t50,0 t50,0 t50,0 t50,0 t50,0 t50,0" fill="none" stroke="#fff" stroke-opacity="0.75" stroke-width="3.4" stroke-linecap="round"/>
            <path d="M-5,368 q25,-12 50,0 t50,0 t50,0 t50,0 t50,0 t50,0 t50,0 t50,0 t50,0" fill="none" stroke="#fff" stroke-opacity="0.6" stroke-width="3" stroke-linecap="round"/>
            <path d="M-40,410 Q90,388 200,408 T440,398 L440,560 L-40,560 Z" fill="#FFE7B0"/>
            <path d="M64,560 C52,480 76,410 64,344" fill="none" stroke="#7A5230" stroke-width="15" stroke-linecap="round"/><path d="M64,560 C52,480 76,410 64,344" fill="none" stroke="#A6733F" stroke-width="9" stroke-linecap="round"/>
            ${['M64,344 C30,330 10,340 0,362', 'M64,344 C40,310 20,300 2,304', 'M64,344 C70,306 88,290 112,290', 'M64,344 C96,328 122,336 136,358', 'M64,344 C62,318 52,300 36,288'].map(d =>
              `<path d="${d}" fill="none" stroke="#3E8A3E" stroke-width="13" stroke-linecap="round"/><path d="${d}" fill="none" stroke="#6BC46B" stroke-width="7" stroke-linecap="round"/>`).join('')}
            <circle cx="344" cy="478" r="26" fill="#fff" stroke="#E0708A" stroke-width="3"/><path d="M344,452 A26,26 0 0 1 366,465 L344,478Z" fill="#FF6F93"/><path d="M366,491 A26,26 0 0 1 344,504 L344,478Z" fill="#7FD1F2"/><path d="M322,465 A26,26 0 0 1 344,452 L344,478Z" fill="#FFE14D"/>
            <path d="M190,110 q8,-8 16,0 q8,-8 16,0 M240,80 q6,-6 12,0 q6,-6 12,0" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round"/>`
        },
        {
          id: 'night', label: 'Starry Night',
          svg: `<linearGradient id="bgs-night" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1B1A4A"/><stop offset=".62" stop-color="#5A3A8C"/><stop offset="1" stop-color="#B565A7"/></linearGradient>
            <mask id="bgs-moonmask"><rect x="0" y="0" width="200" height="200" fill="#fff"/><circle cx="102" cy="84" r="34" fill="#000"/></mask>
            <rect ${BG} fill="url(#bgs-night)"/>
            <circle cx="82" cy="98" r="46" fill="#FFF3B0" opacity="0.18"/><circle cx="82" cy="98" r="40" fill="#FFF3B0" mask="url(#bgs-moonmask)" transform="translate(0 0)"/>
            ${scatter(22, 7, (r, k) => sparkle(Math.round(r() * 400), Math.round(r() * 330), 3 + Math.round(r() * 6), k % 3 ? '#fff' : '#FFE27A'))}
            ${cloud(300, 120, 0.8, '#C9B8F0', 0.35)}
            <path d="M-40,470 Q60,410 160,450 T360,430 T440,450 L440,560 L-40,560Z" fill="#33215F"/><path d="M-40,500 Q80,470 200,496 T440,486 L440,560 L-40,560Z" fill="#241647"/>
            ${scatter(9, 21, r => `<circle cx="${Math.round(r() * 400)}" cy="${Math.round(400 + r() * 100)}" r="2.6" fill="#FFF3A0"/>`)}`
        },
        {
          id: 'candy', label: 'Candy Land',
          svg: `<linearGradient id="bgs-candy" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFD6EC"/><stop offset="1" stop-color="#D6F5EA"/></linearGradient>
            <rect ${BG} fill="url(#bgs-candy)"/>
            ${cloud(300, 80, 1, '#fff', 0.8)}${cloud(70, 150, 0.7, '#fff', 0.7)}
            ${lollipop(56, 350, 38, '#FF8DB8', '#fff')}${lollipop(348, 380, 32, '#7FD1F2', '#fff')}
            <path d="M300,520 L300,430 Q300,408 322,408" fill="none" stroke="#fff" stroke-width="13" stroke-linecap="round"/><path d="M300,520 L300,430 Q300,408 322,408" fill="none" stroke="#FF5E7E" stroke-width="13" stroke-linecap="round" stroke-dasharray="11 11"/>
            ${scatter(46, 11, (r, k) => { const x = Math.round(r() * 400), y = Math.round(r() * 440), a = Math.round(r() * 180); const col = ['#FF5E7E', '#FFE14D', '#6BD66B', '#4DB8FF', '#B46BFF'][k % 5]; return `<path d="M${x},${y} l7,0" transform="rotate(${a} ${x} ${y})" stroke="${col}" stroke-width="3.4" stroke-linecap="round" opacity="0.85"/>`; })}
            <path d="M-40,470 Q-10,462 20,474 T80,474 T140,474 T200,474 T260,474 T320,474 T380,474 T440,474 L440,560 L-40,560Z" fill="#FF9EC8"/>
            <path d="M40,474 v22 q0,8 8,0 v-22 M150,474 v30 q0,8 8,0 v-30 M290,474 v18 q0,8 8,0 v-18" stroke="#FF9EC8" stroke-width="9" stroke-linecap="round" fill="none"/>`
        },
        {
          id: 'stage', label: 'Stage',
          svg: `<linearGradient id="bgs-stage" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#22103F"/><stop offset="1" stop-color="#5A2A86"/></linearGradient>
            <linearGradient id="bgs-beam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity="0.55"/><stop offset="1" stop-color="#fff" stop-opacity="0.05"/></linearGradient>
            <rect ${BG} fill="url(#bgs-stage)"/>
            <path d="M120,-10 L-20,520 L230,520 Z" fill="url(#bgs-beam)" opacity="0.5"/><path d="M290,-10 L170,520 L440,520 Z" fill="url(#bgs-beam)" opacity="0.4"/>
            <path d="M-40,-40 L92,-40 C70,120 94,300 48,560 L-40,560 Z" fill="#B3202A"/><path d="M30,0 C18,150 34,330 10,540 M62,-20 C50,150 66,330 38,540" fill="none" stroke="#7A1018" stroke-width="3" opacity="0.6"/>
            <path d="M440,-40 L308,-40 C330,120 306,300 352,560 L440,560 Z" fill="#B3202A"/><path d="M370,0 C382,150 366,330 390,540 M338,-20 C350,150 334,330 362,540" fill="none" stroke="#7A1018" stroke-width="3" opacity="0.6"/>
            <circle cx="200" cy="44" r="24" fill="#D9D7F0" stroke="#fff" stroke-width="2"/><path d="M200,-10 V20 M178,44 H222 M184,30 H216 M184,58 H216 M190,22 V66 M210,22 V66" stroke="#9C9ABF" stroke-width="1.6" fill="none"/>
            ${[[110, 22, '#FF6FA3'], [150, 12, '#7FD1F2'], [250, 12, '#FFE14D'], [290, 22, '#6BD66B']].map(([x, y, col]) => `<circle cx="${x}" cy="${y}" r="9" fill="${col}" opacity="0.35"/><circle cx="${x}" cy="${y}" r="5" fill="${col}"/>`).join('')}
            ${scatter(10, 5, (r, k) => sparkle(Math.round(110 + r() * 180), Math.round(90 + r() * 300), 3 + Math.round(r() * 4), k % 2 ? '#fff' : '#FFE27A'))}
            <rect x="-40" y="452" width="480" height="110" fill="#3B2357"/><path d="M-40,452 H440" stroke="#FF6FA3" stroke-width="5"/><path d="M-40,482 H440 M-40,512 H440" stroke="#6A4290" stroke-width="2.4"/>
            <ellipse cx="200" cy="470" rx="150" ry="14" fill="#fff" opacity="0.14"/>`
        },
        {
          id: 'garden', label: 'Garden',
          svg: `<linearGradient id="bgs-gsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#BDE9FF"/><stop offset="1" stop-color="#F1FBFF"/></linearGradient>
            <rect ${BG} fill="url(#bgs-gsky)"/>
            <circle cx="64" cy="76" r="48" fill="#FFE14D" opacity="0.3"/><circle cx="64" cy="76" r="30" fill="#FFE14D"/>
            ${cloud(270, 90, 1)}${cloud(330, 190, 0.6)}
            <path d="M-40,360 Q70,300 190,350 T440,330 L440,560 L-40,560Z" fill="#9EE39A"/><path d="M-40,420 Q100,376 220,416 T440,404 L440,560 L-40,560Z" fill="#6DCB78"/>
            ${[22, 56, 330, 364].map(x => `<rect x="${x}" y="368" width="20" height="74" rx="8" fill="#fff" stroke="#D5E4EE" stroke-width="2.4"/>`).join('')}<rect x="10" y="390" width="136" height="9" fill="#fff" stroke="#D5E4EE" stroke-width="2.4"/><rect x="306" y="390" width="104" height="9" fill="#fff" stroke="#D5E4EE" stroke-width="2.4"/>
            ${[[34, 486, '#FF8DB8'], [86, 500, '#FFE14D'], [318, 492, '#C9A7F5'], [372, 480, '#FF8DB8'], [352, 508, '#FFE14D']].map(([x, y, col]) =>
              `<path d="M${x},${y + 10} L${x},${y + 52}" stroke="#3E8A3E" stroke-width="5" stroke-linecap="round"/>${flower(x, y, 12, col)}`).join('')}
            ${butterfly(300, 250, 0.9, '#FF8DB8', '#FFC1DA')}${butterfly(70, 250, 0.8, '#7FD1F2', '#B9E8FA')}`
        },
      ]
    },

  }  // end slots
};
