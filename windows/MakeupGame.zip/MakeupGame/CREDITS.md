# Credits

Everything in this project is drawn in code (SVG) except the items below.

## Font

- **Fredoka** (latin subset, variable weight) - Copyright 2016 The Fredoka Project Authors
  (https://github.com/hafontia/Fredoka-One). SIL Open Font License 1.1.
  Licence text: [assets/fonts/Fredoka-OFL.txt](assets/fonts/Fredoka-OFL.txt).
  File: `assets/fonts/fredoka-latin.woff2`, served from Google Fonts (fonts.gstatic.com) and
  bundled here so the page works offline.

## Sounds

- **Interface Sounds** by Kenney (www.kenney.nl), 1.0 - Creative Commons Zero (CC0). Free for
  personal, educational and commercial use; credit is appreciated but not required.
  https://kenney.nl/assets/interface-sounds - licence: `assets/sounds/Kenney-Interface-Sounds-License.txt`.
  Six of its 100 files are used, renamed:

  | File | Original | Used for |
  |---|---|---|
  | `tab.ogg` | `select_002.ogg` | switching tab |
  | `pick.ogg` | `pluck_002.ogg` | choosing a look or pattern |
  | `color.ogg` | `glass_006.ogg` | choosing a colour |
  | `save.ogg` | `confirmation_004.ogg` | saving the picture |
  | `reset.ogg` | `minimize_008.ogg` | starting over |
  | `surprise.ogg` | `maximize_009.ogg` | the Surprise me! button |

## Art references (nothing copied)

The look was inspired by kids' dress-up apps (Avatar World / Avatar Maker by Pazu Games,
Gacha Life by Lunime, Toca Boca). No assets from them are used.
