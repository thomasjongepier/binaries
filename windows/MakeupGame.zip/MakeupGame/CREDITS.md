# Credits

Everything in this project is drawn in code (SVG) except the items below.

## Font

- **Fredoka** (latin subset, variable weight) - Copyright 2016 The Fredoka Project Authors
  (https://github.com/hafontia/Fredoka-One). SIL Open Font License 1.1.
  Licence text: [assets/fonts/Fredoka-OFL.txt](assets/fonts/Fredoka-OFL.txt).
  File: `assets/fonts/fredoka-latin.woff2`, served from Google Fonts (fonts.gstatic.com) and
  bundled here so the page works offline.

## Sounds

- **Interface Sounds** by Kenney (www.kenney.nl), 1.0 - Creative Commons Zero (CC0). Free for
  personal, educational and commercial use; credit is appreciated but not required.
  https://kenney.nl/assets/interface-sounds - licence: `assets/sounds/Kenney-Interface-Sounds-License.txt`.
  Six of its 100 files are used, renamed:

  | File | Original | Used for |
  |---|---|---|
  | `tab.ogg` | `select_002.ogg` | switching tab |
  | `pick.ogg` | `pluck_002.ogg` | choosing a look or pattern |
  | `color.ogg` | `glass_006.ogg` | choosing a colour |
  | `save.ogg` | `confirmation_004.ogg` | saving the picture |
  | `reset.ogg` | `minimize_008.ogg` | starting over |
  | `surprise.ogg` | `maximize_009.ogg` | the Surprise me! button |

## Art references (nothing copied)

The look was inspired by kids' dress-up apps (Avatar World / Avatar Maker by Pazu Games,
Gacha Life by Lunime, Toca Boca). No assets from them are used.

## 3D world (in `world/`)

- **three.js** 0.186.1 - MIT licence, https://threejs.org. Bundled with two of its addons
  (GLTFLoader, SkeletonUtils) into `world/vendor/three.bundle.js`.
- **Nature Kit 2.1** and **Fantasy Town Kit 2.0** by Kenney (www.kenney.nl) - Creative Commons Zero
  (CC0). Free for personal, educational and commercial use; credit is appreciated but not required.
  https://kenney.nl/assets/nature-kit and https://kenney.nl/assets/fantasy-town-kit.
  Originals (and their licence texts) in `world/assets/kenney/`; the models the world uses are packed into
  `world/assets/packs/`. The 3D world's extras (flowers that sway, fountain spray, butterflies, fire) are
  drawn in code; its sounds are the dress-up game's own (above).
- **KayKit Character Animations 1.1** and **KayKit Adventurers 2.0** by Kay Lousberg (www.kaylousberg.com) -
  Creative Commons Zero (CC0). Free for personal, educational and commercial use; credit is appreciated but
  not required. https://kaylousberg.itch.io/kaykit-character-animations and
  https://kaylousberg.itch.io/kaykit-adventurers. Originals (and their licence texts) in
  `world/assets/kaykit/`. The 3D character uses the skeleton (`Rig_Medium`) and a few animation clips
  (idle, walk, run, wave, cheer), packed into `world/assets/packs/character.js`. The character's own
  meshes are made for this game with Blender (a build tool, GPL; nothing of it ships) from the scripts in
  `world/character-src/`.
